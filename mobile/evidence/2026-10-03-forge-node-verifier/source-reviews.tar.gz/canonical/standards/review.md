# Standards review — canonical local Forge DigestInfo extension

**Pass: no blocking Standards findings or actionable baseline smells in the three changed files.** Their hashes match the 100-file green input capture made before focused execution; the archive and current files also match that complete snapshot. The installed RSA postimage is exactly `3dde91b05b403e062e0c7c8e97e63e79337c651db59f18fa7c836d18b15697d5`.

The patch retains the pinned guard, lock/caller inventories and original preimage. The ASN.1 schema validates required sequence/primitive types before short-circuited nested-array access. Child counts prohibit unconsumed nodes; captured primitive NULL must be empty. Whole-object DER re-encoding binds tags, lengths and complete input bytes. Separate OID decode/re-encode rejects nonminimal OID bytes that the general serializer preserves. The existing digest-OID allowlist, digest comparison and MD2/MD5 required-NULL rule remain intact. Unknown/unrepresentable OIDs throw or fail closed. Existing parser depth bounds and the RSA-block input bound remain unchanged.

[RFC 8017 §9.2](https://www.rfc-editor.org/rfc/rfc8017#section-9.2) specifies DER and explains rejection of some older BER encodings. [Appendix B.1](https://www.rfc-editor.org/rfc/rfc8017#appendix-B.1) permits SHA AlgorithmIdentifiers with absent or NULL parameters. The code preserves that compatibility and documents intentional BER refusal. PSS and NONE paths remain separate and unchanged.

Whole-byte equality also rejects trailing bytes when the unsupported diagnostic `_parseAllDigestBytes:false` option is supplied; that option is explicitly unsupported in the pinned upstream source. `_skipPaddingChecks` is not changed. No general guarantee for unsupported diagnostic options is claimed.

Tests meaningfully cover nonempty NULL, noncanonical lengths/OIDs, SHA absent parameters, MD5 required NULL, default schemes and actual local Expo helpers. Root's retained focused invocation exits zero and its stdout records 52 passing tests. This reviewer executed none of those tests or cryptographic fixtures; broader green verification remains root-owned.

The README/manifest keep raw Forge/Braces audit gates, browser distributions, global/cloud EAS, signing and native artifact acceptance open. Two-space/LF conventions hold. This is local defensive source validation, not a replacement RSA implementation or cryptographic certification. Read-only review of source/diff/pinned ASN.1 support and primary RFC; only private report outputs, with no product/Git/index/provider/deployment mutations.
