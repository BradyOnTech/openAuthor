Spec review: PASS; zero open findings.

The expanded byte-bound patch matches the authorized default PKCS#1 v1.5 DigestInfo scope. It adds explicit empty primitive NULL validation, whole-payload canonical DER equality, and canonical OID roundtrip equality while preserving prior child counts, supported OIDs and MD2/MD5 required parameters. Whole-payload equality also statically refuses trailing bytes when the diagnostic parseAll setting is false; no new probe of that option was performed.

Existing SHA NULL/absence compatibility, PSS/NONE paths and actual installed Expo certificate/CSR/manifest helpers are retained. The README accurately documents intentional BER-only DigestInfo refusal and keeps browser/global/cloud EAS/native acceptance and the raw Forge/Braces gates open. This does not claim general ASN.1 or all-scheme validation, unsafe diagnostic padding safety, global advisory remediation, or signed release acceptance.

Retained red evidence has three new regressions failing against the prior cardinality-only postimage and 23 prior cases passing. Green receipts show 52 focused tests, 281 tests in 35 mobile files, typecheck, byte guard and preflight passing. The offline three-platform export reports three containment maps. All 100 green archive/input hashes match their current files; the reviewed three hashes match green-review-hashes.json. Guard/package/lock/build-security and manifest caller/runtime/inventory pins stay unchanged. No tests, malformed fixtures, crypto probes or repository mutations were performed by this reviewer.

Final source SHA-256:

- mobile/security/forge-backport-1.4.0.json: 01767e261bbf56a58b02ed6dbb6bab993a14c3eb905b7b60b1787de377a1af5a
- mobile/test/forgeBackport.test.mjs: ffd6441b1fcd6067817f890f0803d10241d788720b09b218606abd9e6a1b1c1a
- mobile/README.md: 190ada013a96693d4470a39e6789986b0f48590a0c219a579a4350882437116a

Installed RSA postimage: 3dde91b05b403e062e0c7c8e97e63e79337c651db59f18fa7c836d18b15697d5

Evidence: /private/tmp/openauthor-forge-strict-q1f62y70
Detailed findings: findings.json
