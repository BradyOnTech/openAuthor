import json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
r=Path(__file__).resolve().parent;repo=Path('~/Developer/openAuthor');x=json.loads((r/'final-seven.json').read_text());names=json.loads((r/'source-commit-paths.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert names==list(x['final_seven']);assert {p:sha(repo/p) for p in names}==x['final_seven'];assert not subprocess.run(['git','diff','--cached','--name-only'],cwd=repo,text=True,capture_output=True,check=True).stdout.strip()
subprocess.run(['git','add','--',*names],cwd=repo,check=True)
staged=subprocess.run(['git','diff','--cached','--name-only'],cwd=repo,text=True,capture_output=True,check=True).stdout.splitlines();assert sorted(staged)==sorted(names)
subprocess.run(['git','commit','-m','Guard local Expo Forge verifier with pinned backport'],cwd=repo,check=True)
commit=subprocess.run(['git','rev-parse','HEAD'],cwd=repo,text=True,capture_output=True,check=True).stdout.strip();committed={}
for name in names:
 data=subprocess.run(['git','show',commit+':'+name],cwd=repo,capture_output=True,check=True).stdout;committed[name]=hashlib.sha256(data).hexdigest()
assert committed==x['final_seven'];receipt={'commit':commit,'at':datetime.now(timezone.utc).isoformat(),'source_files':committed,'exact_reviewed_bytes_committed':True,'raw_audit_gate':'open','scope':'Pinned local Node/lib extra AlgorithmIdentifier-child backport only; primitive NULL/strict DER still unvalidated; outside browser/globalEAS/native acceptance'};(r/'source-commit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'commit':commit,'reviewed_files':len(committed)}))
