import json,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
r=Path(__file__).resolve().parent;repo=Path('~/Developer/openAuthor');x=json.loads((r/'green-review-hashes.json').read_text());names=json.loads((r/'source-commit-paths.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert names==list(x['three_files']);assert {p:sha(repo/p) for p in names}==x['three_files'];assert not subprocess.run(['git','diff','--cached','--name-only'],cwd=repo,text=True,capture_output=True,check=True).stdout.strip()
a=json.loads(Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/author-hashes-before.json').read_text());assert {p:sha(repo/p) for p in a}==a
subprocess.run(['git','add','--',*names],cwd=repo,check=True);staged=subprocess.run(['git','diff','--cached','--name-only'],cwd=repo,text=True,capture_output=True,check=True).stdout.splitlines();assert set(staged)==set(names);subprocess.run(['git','commit','-m','Require canonical DigestInfo in pinned Expo verifier'],cwd=repo,check=True);commit=subprocess.run(['git','rev-parse','HEAD'],cwd=repo,text=True,capture_output=True,check=True).stdout.strip();actual={}
for name in names:
 data=subprocess.run(['git','show',commit+':'+name],cwd=repo,capture_output=True,check=True).stdout;actual[name]=hashlib.sha256(data).hexdigest()
assert actual==x['three_files'];assert {p:sha(repo/p) for p in a}==a;(r/'source-commit.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'commit':commit,'files':actual,'reviewed_committed_bytes_match':True,'author_unchanged':True,'release_certified':False,'all_six_priorities':'in_progress'},indent=2)+'\n');print(json.dumps({'commit':commit,'files':len(actual)}))
