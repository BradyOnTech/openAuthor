import json,os,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
r=Path(__file__).resolve().parent; mobile=Path('~/Developer/openAuthor/mobile');mode=sys.argv[1]
commands={'apply':['node','scripts/forge-backport.mjs','apply'],'check':['node','scripts/forge-backport.mjs','check'],'focused':['node','node_modules/vitest/vitest.mjs','run','test/forgeBackport.test.mjs','test/buildSecurity.test.mjs'],'full':['node','node_modules/vitest/vitest.mjs','run'],'typecheck':['node','node_modules/typescript/bin/tsc','--noEmit'],'preflight':['node','scripts/build-security.mjs','preflight']}
commands['export']=['node','scripts/build-security.mjs','export','--platform','all','--output-dir',str(r/'export')]
assert mode == 'export'
out=r/('green-'+mode+'.stdout.txt');err=r/('green-'+mode+'.stderr.txt');receipt=r/('green-'+mode+'-invocation.json');assert not out.exists() and not err.exists() and not receipt.exists()
env={k:v for k,v in os.environ.items() if not k.startswith(('CODEX_','OPENAUTHOR_','PYTHON','GIT_','EXPO_PUBLIC_','SUPABASE_')) and k not in ('OPENAI_API_KEY','ANTHROPIC_API_KEY','OPENROUTER_API_KEY','EXPO_TOKEN')}
env.update({'CI':'1','EXPO_OFFLINE':'1','EXPO_NO_TELEMETRY':'1','EXPO_NO_DOCTOR':'1'})
x={'mode':mode,'command':commands[mode],'cwd':str(mobile),'started_at':datetime.now(timezone.utc).isoformat(),'scope':'Local defensive Forge/mobile verification; external provider/signing/deployment not invoked'}
with out.open('w') as o,err.open('w') as e:
 p=subprocess.Popen(commands[mode],cwd=mobile,env=env,stdout=o,stderr=e);x['pid']=p.pid;receipt.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'mode':mode,'pid':p.pid}),flush=True)
 try: code=p.wait(timeout=300);x['timed_out']=False
 except subprocess.TimeoutExpired: p.kill();code=p.wait(timeout=10);x['timed_out']=True
x.update({'exit_code':code,'finished_at':datetime.now(timezone.utc).isoformat()});receipt.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'mode':mode,'exit_code':code,'logs':str(r)}));raise SystemExit(code if code>=0 else 1)
