from pathlib import Path
import subprocess,json,hashlib,datetime
repo=Path('~/Developer/openAuthor'); receipt_dir=Path('/private/tmp/openauthor-braces-root-zoq2gjiq')
green=json.loads((receipt_dir/'green-inputs.json').read_text()); validation=json.loads((receipt_dir/'post-validation.json').read_text()); files=green['selected']
h=lambda b:hashlib.sha256(b).hexdigest()
run=lambda *args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
base=run('rev-parse','HEAD');assert base=='1048aa4a3b3633150aaf220eaf3601475e9a2aac'
assert not run('diff','--cached','--name-only')
assert len(files)==17
assert all(h((repo/n).read_bytes())==green['files'][n] for n in green['files'])
assert all(h((repo/n).read_bytes())==v for n,v in validation['author_files_unchanged'].items())
subprocess.run(['git','diff','--check','--',*files],cwd=repo,check=True)
subprocess.run(['git','add','--',*files],cwd=repo,check=True)
assert sorted(run('diff','--cached','--name-only').splitlines())==sorted(files)
subprocess.run(['git','commit','-m','Bound all pinned local Braces copies'],cwd=repo,check=True)
commit=run('rev-parse','HEAD');assert sorted(run('diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())==sorted(files)
assert all(h((repo/n).read_bytes())==v for n,v in validation['author_files_unchanged'].items())
assert not run('diff','--cached','--name-only')
doc={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'commit':commit,'files':{n:green['files'][n] for n in files},'author_files_unchanged':validation['author_files_unchanged'],'scope':'Exact17 reviewed/tested source allowlist; unrelated Makefile fix and author artifacts excluded.'}
(receipt_dir/'source-commit.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps({'commit':commit,'files':len(files),'author_files_unchanged':4}))
