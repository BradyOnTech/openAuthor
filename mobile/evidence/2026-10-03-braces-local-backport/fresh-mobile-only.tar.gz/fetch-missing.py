from pathlib import Path
import json,hashlib,base64,urllib.request,datetime
root=Path(__file__).resolve().parent
lock=json.loads((root/'project/mobile/package-lock.json').read_text())
item=lock['packages']['node_modules/brace-expansion']
url=item['resolved']
assert url=='https://registry.npmjs.org/brace-expansion/-/brace-expansion-5.0.12.tgz'
assert item['integrity']=='sha512-YovQ3rzhaLMIrDjNDMkNS01tea93qhEhG5xy8f6+R0l+dw3Ki+5sCoIoI942iuLZTHWogWktgwVDhU09iNEimQ=='
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(urllib.request.Request(url,headers={'User-Agent':'OpenAuthor dependency acceptance'}),timeout=30) as response:
 assert response.status==200 and response.url==url
 data=response.read(8*1024*1024+1)
assert len(data)<=8*1024*1024
assert base64.b64encode(hashlib.sha512(data).digest()).decode()==item['integrity'].split('-',1)[1]
hexadecimal=hashlib.sha512(data).hexdigest()
file=root/'npm-cache/_cacache/content-v2/sha512'/hexadecimal[:2]/hexadecimal[2:4]/hexadecimal[4:]
file.parent.mkdir(parents=True,exist_ok=True)
assert not file.exists()
file.write_bytes(data)
receipt={'url':url,'integrity':item['integrity'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'cache_path':str(file),'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Single missing lock-integrity-pinned public package download for isolated offline installation; no install/provider/ambient configuration'}
(root/'fetched-pinned-package.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'package':'brace-expansion@5.0.12','integrity_verified':True,'bytes':len(data)}))
