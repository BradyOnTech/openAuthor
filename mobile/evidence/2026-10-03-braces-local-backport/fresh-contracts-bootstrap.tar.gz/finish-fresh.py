from pathlib import Path
import hashlib,json,subprocess,datetime,sys
root=Path('/private/tmp/openauthor-braces-fresh-install-l8kiljzo')
name=sys.argv[1]
assert name in ['contracts-bootstrap-ci','typecheck-after-bootstrap','forge-apply','braces-apply','export-all']
assert not (root/(name+'-invocation.json')).exists(), 'Refusing to overwrite a terminal receipt'
plan=json.loads((root/('contracts-bootstrap-plan.json' if name=='contracts-bootstrap-ci' else 'run-plan.json')).read_text())
h=lambda b:hashlib.sha256(b).hexdigest()
final=json.loads((root/'contracts-bootstrap-final-seal.json').read_text())
assert all(h((root/n).read_bytes())==v for n,v in final['files'].items())
sources=json.loads((root/'contracts-bootstrap-final-sources.json').read_text())['files']
assert all(h((root/n).read_bytes())==v for n,v in sources.items())
tools=json.loads((root/'tools-receipt.json').read_text())
assert h(Path(tools['node_path']).read_bytes())==tools['node_sha256']
assert h(Path(tools['npm_cli_path']).read_bytes())==tools['npm_cli_sha256']
if name=='contracts-bootstrap-ci':
 assert not (Path(plan['cwd'])/'node_modules').exists()
 argv=plan['install_argv']
else:
 assert json.loads((root/'contracts-bootstrap-ci-invocation.json').read_text())['exit_code']==0
 node=plan['install_argv'][0]
 commands={'typecheck-after-bootstrap':[node,'node_modules/typescript/bin/tsc','--noEmit'],'forge-apply':[node,'scripts/forge-backport.mjs','apply'],'braces-apply':[node,'scripts/braces-backport.mjs','apply'],'export-all':[node,'scripts/build-security.mjs','export','--platform','all','--output-dir',str(root/'export-all')]}
 argv=commands[name]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.stdout.txt')).open('x') as out,(root/(name+'.stderr.txt')).open('x') as err:
 process=subprocess.Popen(argv,cwd=plan['cwd'],env=plan['environment'],stdout=out,stderr=err)
 (root/(name+'-started.json')).write_text(json.dumps({'pid':process.pid,'argv':argv,'started_at':started,'cwd':plan['cwd']},indent=2)+'\n')
 timed_out=False
 try: code=process.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timed_out=True;process.kill();code=process.wait()
receipt={'argv':argv,'cwd':plan['cwd'],'pid':process.pid,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'timed_out':timed_out,'environment_keys':sorted(plan['environment']),'node_sha256':tools['node_sha256'],'driver_sha256':h(Path(__file__).read_bytes()),'verified_source_files':len(sources),'scope':'Actual isolated offline contracts bootstrap/mobile follow-up; lifecycle enabled; no audit/native/global/cloud acceptance'}
(root/(name+'-invocation.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'command':name,'exit_code':code,'root':str(root)}))
for suffix in ['stdout','stderr']:
 print((root/(name+'.'+suffix+'.txt')).read_text()[-16000:])
sys.exit(code)
