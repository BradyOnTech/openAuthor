from pathlib import Path
import os,json,subprocess,sys,datetime,hashlib
root=Path(__file__).resolve().parent
mobile=Path('~/Developer/openAuthor/mobile')
node='~/.nvm/versions/node/v22.17.0/bin/node'
name=sys.argv[1]
commands={'original-check':[node,'scripts/braces-backport.mjs','check'],'apply':[node,'scripts/braces-backport.mjs','apply'],'check':[node,'scripts/braces-backport.mjs','check'],'focused':[node,'node_modules/vitest/vitest.mjs','run','test/bracesBackportBehavior.test.mjs','test/bracesBackportGuard.test.mjs','test/forgeBackport.test.mjs','test/buildSecurity.test.mjs'],'full':[node,'node_modules/vitest/vitest.mjs','run'],'typecheck':[node,'node_modules/typescript/bin/tsc','--noEmit'],'preflight':[node,'scripts/build-security.mjs','preflight'],'export':[node,'scripts/build-security.mjs','export','--output-dir',str(root/'export')],'export-all':[node,'scripts/build-security.mjs','export','--platform','all','--output-dir',str(root/'export-all')],'forge-check':[node,'scripts/forge-backport.mjs','check']}
private=root/'environment';private.mkdir(exist_ok=True);(private/'tmp').mkdir(exist_ok=True);(private/'empty.npmrc').touch()
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(private),'TMPDIR':str(private/'tmp'),'CI':'1','EXPO_OFFLINE':'1','EXPO_NO_TELEMETRY':'1','NODE_ENV':'test','NPM_CONFIG_USERCONFIG':str(private/'empty.npmrc'),'NPM_CONFIG_CACHE':str(private/'npm-cache')}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.stdout.txt')).open('w') as out,(root/(name+'.stderr.txt')).open('w') as err:
 result=subprocess.run(commands[name],cwd=mobile,env=env,stdout=out,stderr=err)
receipt={'argv':commands[name],'cwd':str(mobile),'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'timed_out':False,'environment_keys':sorted(env),'node_sha256':hashlib.sha256(Path(node).read_bytes()).hexdigest()}
(root/(name+'-invocation.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'command':name,'exit_code':result.returncode,'log_root':str(root)}))
for suffix in ['stdout','stderr']:
 text=(root/(name+'.'+suffix+'.txt')).read_text()
 print(text[-18000:] if result.returncode else text[-3500:])
sys.exit(result.returncode)
