from pathlib import Path
import hashlib,json,subprocess,datetime,sys
root=Path('/private/tmp/openauthor-braces-fresh-install-l8kiljzo')
name=sys.argv[1]
plan=json.loads((root/'run-plan.json').read_text())
if name=='ci':
 seal=root/'prepared-files-sha256.json'
 assert hashlib.sha256(seal.read_bytes()).hexdigest()=='e332a0e531fd20f45fb647202f9591568c0e0c7cd9e4a858c74262eb48f2c110'
 files=json.loads(seal.read_text())['files']
 assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==v for n,v in files.items())
 assert not (Path(plan['cwd'])/'node_modules').exists()
 argv=plan['install_argv']
elif name in ['focused','typecheck','preflight','export-all']:
 node=plan['install_argv'][0]
 commands={'focused':[node,'node_modules/vitest/vitest.mjs','run','test/bracesBackportBehavior.test.mjs','test/bracesBackportGuard.test.mjs','test/forgeBackport.test.mjs','test/buildSecurity.test.mjs'],'typecheck':[node,'node_modules/typescript/bin/tsc','--noEmit'],'preflight':[node,'scripts/build-security.mjs','preflight'],'export-all':[node,'scripts/build-security.mjs','export','--platform','all','--output-dir',str(root/'export-all')]}
 argv=commands[name]
else:
 mapping={'forge-check':0,'braces-check':1,'forge-apply':2,'braces-apply':3}
 argv=plan['follow_up_commands'][mapping[name]]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.stdout.txt')).open('w') as out,(root/(name+'.stderr.txt')).open('w') as err:
 process=subprocess.Popen(argv,cwd=plan['cwd'],env=plan['environment'],stdout=out,stderr=err)
 (root/(name+'-started.json')).write_text(json.dumps({'pid':process.pid,'argv':argv,'started_at':started,'cwd':plan['cwd']},indent=2)+'\n')
 code=process.wait()
receipt={'argv':argv,'cwd':plan['cwd'],'pid':process.pid,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'timed_out':False,'environment_keys':sorted(plan['environment']),'scope':'Actual isolated offline install/guard command; lifecycle enabled; no audit/native/global/cloud acceptance'}
(root/(name+'-invocation.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'command':name,'exit_code':code,'root':str(root)}))
for suffix in ['stdout','stderr']:
 print((root/(name+'.'+suffix+'.txt')).read_text()[-12000:])
sys.exit(code)
