from pathlib import Path
import subprocess,json,hashlib,datetime
repo=Path('~/Developer/openAuthor'); root=Path('/private/tmp/openauthor-marker-gate-3evgjsaj')
run=lambda *args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
base=run('rev-parse','HEAD');assert base=='98f4d4a67c32941b23beb5d7bcdaf1d6e901bfbe'
assert not run('diff','--cached','--name-only')
hashvalue=hashlib.sha256((repo/'Makefile').read_bytes()).hexdigest();assert hashvalue=='bf11c9a4ee351eab9b761eaee15aee8be468b22ea688816f73e682438d73780e'
author=json.loads(Path('/private/tmp/openauthor-braces-root-zoq2gjiq/post-validation.json').read_text())['author_files_unchanged']
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==v for n,v in author.items())
subprocess.run(['git','diff','--check','--','Makefile'],cwd=repo,check=True)
subprocess.run(['git','add','--','Makefile'],cwd=repo,check=True);assert run('diff','--cached','--name-only')=='Makefile'
subprocess.run(['git','commit','-m','Fail placeholder audit on scanner errors'],cwd=repo,check=True)
commit=run('rev-parse','HEAD');assert run('diff-tree','--no-commit-id','--name-only','-r',commit)=='Makefile'
assert not run('diff','--cached','--name-only')
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==v for n,v in author.items())
(root/'source-commit.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'commit':commit,'files':{'Makefile':hashvalue},'author_files_unchanged':author,'scope':'Only independently reviewed/verified Makefile gate repair committed.'},indent=2)+'\n')
print(json.dumps({'commit':commit,'file_count':1,'author_files_unchanged':4}))
