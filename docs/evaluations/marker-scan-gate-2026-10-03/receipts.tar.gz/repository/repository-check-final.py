import subprocess,sys,json,datetime,hashlib
from pathlib import Path
root=Path('/private/tmp/openauthor-braces-root-zoq2gjiq')
name='repository-check-final'
assert not (root/(name+'-invocation.json')).exists()
env={'PATH':str(Path(sys.executable).parent)+':/opt/homebrew/bin:~/.nvm/versions/node/v22.17.0/bin:/usr/bin:/bin','HOME':str(root/'home'),'TMPDIR':str(root/'tmp'),'PYTHONPATH':'~/Developer/openAuthor','CI':'1'}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.stdout.txt')).open('x') as out,(root/(name+'.stderr.txt')).open('x') as err:
 p=subprocess.Popen(['make','check'],cwd='~/Developer/openAuthor',env=env,stdout=out,stderr=err)
 code=p.wait()
receipt={'argv':['make','check'],'cwd':'~/Developer/openAuthor','pid':p.pid,'exit_code':code,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Repository integrity/capability and placeholder gate only; not mobile audit or runtime acceptance','environment_keys':sorted(env),'python_path':sys.executable,'makefile_sha256':hashlib.sha256(Path('~/Developer/openAuthor/Makefile').read_bytes()).hexdigest()}
(root/(name+'-invocation.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print((root/(name+'.stdout.txt')).read_text());print((root/(name+'.stderr.txt')).read_text())
sys.exit(code)
