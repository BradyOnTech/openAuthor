import ctypes,os,struct,subprocess
from pathlib import Path
libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int


def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0:
    raise ProcessLookupError(pid)
  return os.fsdecode(buffer.value)


def argv(pid):
  mib = (ctypes.c_int * 3)(1, 49, pid)
  capacity = ctypes.c_size_t(1024 * 1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib, 3, buffer, ctypes.byref(capacity), None, 0):
    raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i', raw)[0]
  if not 0 < count < 500:
    raise RuntimeError('Unexpected argument count')
  cursor = raw.find(b'\0', 4)
  while cursor < len(raw) and raw[cursor] == 0:
    cursor += 1
  values = []
  for _ in range(count):
    end = raw.find(b'\0', cursor)
    if end < 0:
      raise RuntimeError('Incomplete process argument data')
    values.append(os.fsdecode(raw[cursor:end]))
    cursor = end + 1
  return values


def details(pid):
  result = subprocess.run(['/bin/ps', '-p', str(pid), '-o', 'ppid=', '-o', 'lstart=', '-o', 'stat='], capture_output=True, text=True, timeout=2)
  if result.returncode or not result.stdout.strip():
    raise ProcessLookupError(pid)
  parts = result.stdout.strip().split()
  return {'pid': pid, 'ppid': int(parts[0]), 'start': ' '.join(parts[1:-1]), 'state': parts[-1], 'executable': executable(pid), 'argv': argv(pid)}


def cwd(pid):
  result = subprocess.run(['/usr/sbin/lsof', '-a', '-p', str(pid), '-d', 'cwd', '-Fn'], capture_output=True, text=True, timeout=3)
  locations = [line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  if result.returncode or len(locations) != 1:
    raise RuntimeError('Cannot verify owned worker cwd')
  return str(Path(locations[0]).resolve())

