# Private native interruption fixture

The `book` is a synthetic three-scene book with three pending, non-stale manual
Change Sets in one group. Each has one shortened opening sentence and about
256 KiB of exactly retained, unique ledger prose. Preparation used the genuine
packaged engine interfaces from the a523 QA app without provider calls. The
whole original scene and proposal files, original HEAD, and hashes are retained
under `preparation/originals` and sealed in `preparation/evidence-sha256.json`.

`watch.py` is an outside observer. It never imports openauthor or acquires the
book lock. Before arming it checks the packaged Python and core fingerprints.
It verifies the supplied owner's exact QA executable, identifies only its direct
child with the exact packaged Python, exact apply-batch proposal IDs (or explicit
undo-batch Revision), and fixture cwd. It observes raw journal and scene bytes.
After seeing an active journal and at least one changed scene, it rechecks
worker PID/start/executable/argv/parent and sends SIGSTOP only to that worker.
It then requires a stopped process, active journal, changed scene bytes, and
stable raw file snapshots. Capture intentionally leaves the worker stopped.

Root must inspect `result.json` and kill the exact QA app/readers before killing
the stopped mutation worker, so a queued normal read cannot silently recover the
journal ahead of the intended GUI relaunch. Root must recheck process identity
before each kill. This script never kills the app or worker itself. On a raced
committed state it resumes the worker and reports a missed window. Observer
errors attempt to resume only the unchanged exact worker. Timeout, missed
window, and errors are evidence of an unsuccessful capture, never acceptance.

The nominal observation deadline is at most 60 seconds. External inspection
subprocesses each also have short timeouts; command scheduling can add a small
amount of overhead. Start with `--timeout 55` if a strict 60-second wall-clock
tool-call budget is needed. New output folders preserve attempts separately.
The watcher does not force a chosen journal stage; it may capture one, two, or
all three replaced scenes while the transaction remains uncommitted. Describe
only the actual captured state. It establishes neither power-loss recovery nor
signing/notarization or clean-machine behavior.

The `mechanics-trial` is a separate disposable CLI copy. Its captured process
is explicitly identified as a CLI process, not GUI evidence. Two scenes changed
before SIGSTOP. Explicit SIGKILL followed by a normal packaged-core scene read
restored all original scene/proposal bytes and HEAD, then retired the journal.
The main GUI fixture was never applied by preparation or this trial.
