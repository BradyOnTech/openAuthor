import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from openauthor.codex import ensure_codex
from openauthor.project import initialize_project
from openauthor.proposals import create_proposal, get_proposal, list_proposals, set_proposal_draft
from openauthor.revisions import checkpointed_edit, revision_head
from openauthor.scenes import add_scene, get_scene


root = Path(__file__).resolve().parent
book = root / 'book'
evidence = root / 'preparation'
if book.exists() or evidence.exists():
  raise RuntimeError('Refusing to overwrite an existing private fixture')
evidence.mkdir()
python = Path(sys.executable).absolute()
app = Path('/private/tmp/openauthor-keyboard-native-a523097/acceptance-a523097.app')
expected_python = app / 'Contents/Resources/resources/runtime/python/bin/python3'
if python != expected_python:
  raise RuntimeError('Fixture must run with the exact a523 packaged Python')
for key in ('OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'OPENROUTER_API_KEY'):
  if os.environ.get(key):
    raise RuntimeError('Provider keys must be removed before preparation')
paths = initialize_project(book, name='Native mid-write recovery acceptance')
ensure_codex(paths)
rows = []
group = 'native-midwrite-recovery'
target_bytes = 256 * 1024
originals = evidence / 'originals'
originals.mkdir()
for number, first in enumerate(('The signal began to drift.', 'Mara started to pace beside the gate.', 'Ivo really waited beside the very narrow door.'), 1):
  opening = first + '\n\n'
  chunks = []
  size = len(opening.encode())
  index = 1
  while size < target_bytes:
    sentence = (f'Ledger {number:02d}-{index:05d} records the shutter angle and the barometer reading beside the gate; '
      'the observer copies both measurements into the field notebook before returning the brass instrument to its case.\n')
    chunks.append(sentence)
    size += len(sentence.encode())
    index += 1
  body = opening + ''.join(chunks)
  with checkpointed_edit(paths, f'Scene add: Mid-write scene {number}'):
    location = add_scene(paths, title=f'Mid-write scene {number}', body=body)
  scene = get_scene(paths, f'scene-{number:04d}')
  desired_first = ('The signal drifted.', 'Mara paced beside the gate.', 'Ivo waited beside the narrow door.')[number - 1]
  proposed = scene['body'].replace(first, desired_first, 1)
  proposal_id = create_proposal(paths, title=f'Tighten opening in scene {number}',
    instruction='Tighten only the first sentence; retain every ledger observation exactly.',
    scene_id=scene['id'], source='manual', change_group_id=group,
    revision_intent={'goal': 'Tighten only the first sentence', 'scope': 'scene', 'constraints': ['Retain all ledger observations exactly'], 'protected_elements': []})
  drafted = set_proposal_draft(paths, proposal_id=proposal_id, proposed_body=proposed,
    draft={'provider': 'manual', 'model': 'private-deterministic-fixture'})
  if drafted['stale'] or drafted['status'] != 'pending' or len(drafted['change_set']['hunks']) != 1:
    raise RuntimeError('Fixture proposal is stale, non-pending, or has unexpected hunks')
  if drafted['proposed_body'] != proposed or scene['body'].split('\n', 2)[2] != proposed.split('\n', 2)[2]:
    raise RuntimeError('Fixture did not retain unchanged prose exactly')
  relative = location.relative_to(book).as_posix()
  target = originals / relative
  target.parent.mkdir(parents=True, exist_ok=True)
  shutil.copyfile(location, target)
  proposal_relative = f'.openauthor/workspace/proposals/{proposal_id}.json'
  target_proposal = originals / proposal_relative
  target_proposal.parent.mkdir(parents=True, exist_ok=True)
  shutil.copyfile(book / proposal_relative, target_proposal)
  (evidence / f'proposal-{number}.json').write_text(json.dumps(get_proposal(paths, proposal_id), indent=2) + '\n')
  row = {'scene_id': scene['id'], 'scene_path': relative, 'proposal_id': proposal_id,
    'proposal_path': proposal_relative, 'original_file_sha256': hashlib.sha256(location.read_bytes()).hexdigest(),
    'original_body_sha256': hashlib.sha256(scene['body'].encode()).hexdigest(),
    'proposed_body_sha256': hashlib.sha256(proposed.encode()).hexdigest(),
    'original_body_bytes': len(scene['body'].encode()), 'original_first_sentence': first,
    'proposed_first_sentence': desired_first, 'retained_unchanged_prose': True, 'hunks': 1}
  rows.append(row)
head = revision_head(paths)
for relative in ('.openauthor/project.json', '.openauthor/structure.json', '.openauthor/revisions/HEAD'):
  location = book / relative
  if location.exists():
    target = originals / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(location, target)
baseline = {p.relative_to(originals).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(originals.rglob('*')) if p.is_file()}
installed = app / 'Contents/Resources/resources/runtime/python/lib/python3.11/site-packages/openauthor'
core = hashlib.sha256()
for source in sorted(installed.rglob('*.py')):
  relative = source.relative_to(installed).as_posix()
  core.update(relative.encode() + b'\0' + hashlib.sha256(source.read_bytes()).digest())
pending = list_proposals(paths, status='pending')
assert len(pending) == 3 and all(not p['stale'] for p in pending)
assert not (paths.workspace_dir / 'book-transaction.json').exists()
manifest = {'schema_version': 1, 'prepared_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'fixture_root': str(root), 'book': str(book), 'preparation': str(evidence),
  'source_build_commit': 'a5230979315e3e0dd665c5cae5b9af44fa399f93', 'app': str(app),
  'python': str(python), 'python_sha256': hashlib.sha256(python.read_bytes()).hexdigest(),
  'bundled_core_source_sha256': core.hexdigest(), 'provider_calls': 0, 'provider_keys_present': False,
  'method': 'Genuine packaged initialize_project, checkpointed_edit/add_scene, create_proposal/set_proposal_draft; no instrumented core and no generation calls.',
  'change_group': group, 'original_revision_head': head, 'pending_proposals': 3, 'applied': False,
  'scenes': rows, 'baseline_sha256': baseline,
  'scope': 'Private preparation only; not GUI interruption or recovery evidence.'}
(evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
shutil.copyfile(root / 'prepare.py', evidence / 'prepare.py')
seal = {p.relative_to(evidence).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(evidence.rglob('*')) if p.is_file()}
(evidence / 'evidence-sha256.json').write_text(json.dumps(seal, indent=2) + '\n')
print(json.dumps({'book': str(book), 'manifest': str(evidence / 'manifest.json'), 'pending_proposals': 3,
  'original_revision_head': head, 'scenes': rows, 'core_sha256': core.hexdigest()}, indent=2))
