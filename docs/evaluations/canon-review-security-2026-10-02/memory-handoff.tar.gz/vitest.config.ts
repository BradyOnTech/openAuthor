import { defineConfig } from 'vitest/config';
export default defineConfig({ root:'/private/tmp/openauthor-memory-gap-audit', esbuild:{ jsx:'automatic' }, test:{ environment:'jsdom' } });
