import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, '~/Developer/openAuthor')
from openauthor.canon import add_canon_fact, list_canon_facts, review_canon_fact, update_canon_fact
from openauthor.git_ops import current_branch, initialize_git, create_snapshot
from openauthor.project import initialize_project, OpenAuthorError
from openauthor.scene_edits import workspace_edit_scope
from openauthor.scenes import add_scene, get_scene
from openauthor.storylines import create_storyline

os.environ.update(GIT_AUTHOR_NAME='Acceptance Fixture', GIT_AUTHOR_EMAIL='acceptance@example.invalid',
  GIT_COMMITTER_NAME='Acceptance Fixture', GIT_COMMITTER_EMAIL='acceptance@example.invalid',
  GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')
root = Path(tempfile.mkdtemp(prefix='book-', dir='/private/tmp/openauthor-memory-gap-audit'))
paths = initialize_project(root, name='Fresh Memory evidence scope probe')
first = 'Neri set a blue token beside the loom. The shuttle stayed still.'
second = 'At dawn, Neri returned the token to the cabinet.'
add_scene(paths, title='The loom', body=first)
add_scene(paths, title='At dawn', body=second)
fact = add_canon_fact(paths, subject_entity_id='', predicate='token color', value='blue',
  evidence=[{'scene_id':'scene-0001','excerpt':'Neri set a blue token beside the loom.'}])
initialize_git(paths)
create_snapshot(paths, 'Establish original synthetic book')
saved_bodies = {identifier:get_scene(paths,identifier)['body'] for identifier in ['scene-0001','scene-0002']}
loaded = list_canon_facts(paths, for_editing=True)[0]
source_scope = workspace_edit_scope(paths)
storyline = create_storyline(paths, name='Cabinet alternative', hypothesis='Test the cabinet ending')
target_scope = workspace_edit_scope(paths)
new_storyline_fact = list_canon_facts(paths, for_editing=True)[0]
before = (root / 'codex/memory.json').read_bytes()
guarded_refused = False
try:
  update_canon_fact(paths, fact['id'], expected_version=loaded['edit_version'], changes={'status':'rejected'})
except OpenAuthorError as error:
  guarded_refused = str(error)
legacy = review_canon_fact(paths, fact['id'], disposition='rejected', expected_updated_at=loaded['updated_at'])
scope_case = {'loaded_scope':source_scope,'current_scope':target_scope,'current_branch':current_branch(paths),
  'same_fact_timestamp_on_new_storyline':new_storyline_fact['updated_at'] == loaded['updated_at'],
  'guarded_update_refused':guarded_refused,'legacy_review_status':legacy['status'],
  'legacy_mutated_other_storyline':before != (root/'codex/memory.json').read_bytes()}
withdrawn = list_canon_facts(paths, for_editing=True)[0]
bad_range = update_canon_fact(paths, fact['id'], expected_version=withdrawn['edit_version'], changes={
  'validity':{'from_scene_id':'scene-0002','to_scene_id':'scene-0001'}})
guarded_restore_refused = False
try:
  update_canon_fact(paths, fact['id'], expected_version=bad_range['edit_version'], changes={'status':'accepted'})
except OpenAuthorError as error:
  guarded_restore_refused = str(error)
restored = review_canon_fact(paths, fact['id'], disposition='accepted', expected_updated_at=bad_range['updated_at'], evidence=bad_range['evidence'])
range_case = {'validity':restored['validity'],'guarded_restore_refused':guarded_restore_refused,
  'legacy_restore_status':restored['status'],'source_excerpt_exact':restored['evidence'][0]['excerpt'] in first}
result = {'fixture':str(root),'source_commit':os.popen('git -C ~/Developer/openAuthor rev-parse HEAD').read().strip(),
  'storyline_review':scope_case,'invalid_validity_restore':range_case,
  'scene_bodies_unchanged':all(get_scene(paths,identifier)['body'] == body for identifier,body in saved_bodies.items())}
(Path('/private/tmp/openauthor-memory-gap-audit')/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert not scope_case['legacy_mutated_other_storyline'], 'Old loaded evidence review must not mutate the new Storyline'
assert restored['status'] != 'accepted', 'Restore must reject inverted validity, even with exact evidence'
