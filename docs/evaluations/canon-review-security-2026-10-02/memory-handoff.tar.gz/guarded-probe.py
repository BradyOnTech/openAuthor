import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, '~/Developer/openAuthor')
from openauthor.canon import add_canon_fact, list_canon_facts, review_canon_fact, update_canon_fact
from openauthor.git_ops import initialize_git, create_snapshot
from openauthor.project import initialize_project, OpenAuthorError
from openauthor.scenes import add_scene, get_scene
from openauthor.storylines import create_storyline

os.environ.update(GIT_AUTHOR_NAME='Acceptance Fixture', GIT_AUTHOR_EMAIL='acceptance@example.invalid',
  GIT_COMMITTER_NAME='Acceptance Fixture', GIT_COMMITTER_EMAIL='acceptance@example.invalid',
  GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')
paths = initialize_project(Path(tempfile.mkdtemp(prefix='guarded-book-', dir='/private/tmp/openauthor-memory-gap-audit')), name='Guarded evidence review')
add_scene(paths, title='The loom', body='Neri set a blue token beside the loom.')
add_scene(paths, title='At dawn', body='Neri returned the blue token to the cabinet.')
add_canon_fact(paths, subject_entity_id='', predicate='token color', value='blue', evidence=[{'scene_id':'scene-0001','excerpt':'Neri set a blue token beside the loom.'}])
initialize_git(paths)
create_snapshot(paths, 'Save original evidence')
loaded = list_canon_facts(paths, for_editing=True)[0]
original_prose = {identifier:get_scene(paths,identifier)['body'] for identifier in ['scene-0001','scene-0002']}
create_storyline(paths, name='Cabinet alternative', hypothesis='Test another ending')
errors = {}
before = (paths.root / 'codex/memory.json').read_bytes()
for disposition in ['accepted','rejected']:
  try:
    review_canon_fact(paths, loaded['id'], disposition=disposition, expected_version=loaded['edit_version'])
  except OpenAuthorError as error:
    errors[disposition] = str(error)
  else:
    raise AssertionError('Old original version mutated the new Storyline')
assert (paths.root / 'codex/memory.json').read_bytes() == before
current = list_canon_facts(paths, for_editing=True)[0]
withdrawn = update_canon_fact(paths, current['id'], expected_version=current['edit_version'], changes={'status':'rejected','validity':{'from_scene_id':'scene-0002','to_scene_id':'scene-0001'}})
before = (paths.root / 'codex/memory.json').read_bytes()
try:
  review_canon_fact(paths, withdrawn['id'], disposition='accepted', expected_version=withdrawn['edit_version'], evidence=withdrawn['evidence'])
except OpenAuthorError as error:
  errors['inverted_validity'] = str(error)
else:
  raise AssertionError('Accepted an inverted validity range')
assert (paths.root / 'codex/memory.json').read_bytes() == before
result = {'fixture':str(paths.root),'protocol':'original expected_version, matching current desktop','refusals':errors,
  'failed_reviews_preserve_memory_bytes':True,'prose_unchanged':all(get_scene(paths,identifier)['body'] == body for identifier,body in original_prose.items()),
  'legacy_timestamp_scope_protection_claimed':False,'author_quality_claimed':False}
(Path('/private/tmp/openauthor-memory-gap-audit')/'guarded-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
