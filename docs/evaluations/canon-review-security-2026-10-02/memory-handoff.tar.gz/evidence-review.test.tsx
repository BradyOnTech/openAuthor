// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { CanonFactReview } from '~/Developer/openAuthor/desktop/src/components/editor/CanonFactReview';
import { reviewCanonFact } from '~/Developer/openAuthor/desktop/src/api';

const workspace = vi.hoisted(() => ({projectRoot:'/synthetic-book', branches:[{name:'main',current:true}], scenes:[{id:'s1',title:'The loom'}], setError:vi.fn(),setMessage:vi.fn()}));
const editor = vi.hoisted(() => ({openTab:vi.fn(),tabs:[],updateTab:vi.fn(),setActiveTab:vi.fn(),beginNavigation:vi.fn(() => () => true)}));
vi.mock('~/Developer/openAuthor/desktop/src/contexts/WorkspaceContext', () => ({useWorkspace:() => workspace}));
vi.mock('~/Developer/openAuthor/desktop/src/contexts/EditorContext', () => ({useEditor:() => editor}));
vi.mock('~/Developer/openAuthor/desktop/src/api', () => ({reviewCanonFact:vi.fn(),getScene:vi.fn()}));
const fact = {id:'f1',edit_version:'original-storyline-version',subject_entity_id:'',predicate:'token color',value:'blue',status:'accepted' as const,confidence:1,updated_at:'2026-10-02T10:00:00Z',evidence:[{scene_id:'s1',excerpt:'Neri set a blue token beside the loom.',start:0,end:36}],validity:{from_scene_id:'',to_scene_id:''},knowledge:[],scope:'project' as const};
beforeEach(() => {vi.clearAllMocks(); localStorage.clear();});
afterEach(cleanup);

it('does not label an unaccepted suggested fact as accepted by its author', () => {
  render(<CanonFactReview fact={{...fact,status:'suggested'}} onUpdated={vi.fn(async () => {})}/>);
  expect(screen.queryByText(/Accepted by the author/)).toBeNull();
});

it('retains the original evidence correction and precondition when an older response follows a newer saved fact', async () => {
  let finish!: (value:typeof fact) => void;
  vi.mocked(reviewCanonFact).mockImplementationOnce(() => new Promise(resolve => {finish = resolve;}));
  const refreshed=vi.fn(async () => {});
  const view=render(<CanonFactReview fact={fact} onUpdated={refreshed}/>);
  fireEvent.change(screen.getByRole('textbox',{name:'Supporting passage for token color: blue'}),{target:{value:'Neri returned the blue token to the cabinet.'}});
  fireEvent.click(screen.getByRole('button',{name:'Save verified evidence'}));
  await waitFor(() => expect(finish).toBeTypeOf('function'));
  const newer={...fact,updated_at:'2026-10-02T10:02:00Z',edit_version:'newer-version',evidence:[{scene_id:'s1',excerpt:'The blue token stayed inside the cabinet.',start:0,end:40}]};
  view.rerender(<CanonFactReview fact={newer} onUpdated={refreshed}/>);
  await act(async () => finish({...fact,updated_at:'2026-10-02T10:01:00Z',edit_version:'older-committed-version',evidence:[{scene_id:'s1',excerpt:'Neri returned the blue token to the cabinet.',start:0,end:43}]}));
  const record=JSON.parse(localStorage.getItem('openauthor:canon-evidence:/synthetic-book:main:f1') || 'null');
  expect(record?.base.updatedAt).toBe(fact.updated_at);
  expect(record?.value.evidence[0].excerpt).toBe('Neri returned the blue token to the cabinet.');
  expect((screen.getByRole('button',{name:'Save verified evidence'}) as HTMLButtonElement).disabled).toBe(true);
});
