import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from datetime import datetime, timezone

root = Path('~/Developer/openAuthor')
mobile = root / 'mobile'
out = Path(__file__).parent
export = out / 'observed-all-platform-export'
retained = out / 'observed-retained-maps'
observer = out / 'retain-maps.cjs'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not export.exists() and not retained.exists()
inputs = json.loads((out / 'export-source-sha256.json').read_text())
assert all(sha(root / p) == expected for p, expected in inputs.items())
assert not os.environ.get('NODE_OPTIONS')

def installed_hashes():
  records = {}
  for directory, dirs, files in os.walk(mobile / 'node_modules'):
    dirs[:] = [name for name in dirs if name not in ['.vite', '.cache'] and not (Path(directory) / name).is_symlink()]
    for name in files:
      file = Path(directory) / name
      if file.is_file() and not file.is_symlink():
        records[str(file.relative_to(mobile))] = sha(file)
  return records

before = installed_hashes()
with gzip.open(out / 'observed-installed-source-sha256-before.json.gz', 'wt') as file:
  json.dump(before, file, indent=2)
argv = ['npm', 'run', 'build:export', '--', '--platform', 'all', '--output-dir', str(export)]
started = datetime.now(timezone.utc).isoformat()
environment = {**os.environ, 'NODE_ENV': 'production', 'EXPO_OFFLINE': '1', 'EXPO_NO_TELEMETRY': '1', 'NODE_OPTIONS': '--require=' + str(observer)}
print(json.dumps({'started_at': started, 'argv': argv, 'cwd': str(mobile), 'scope': 'One secondary observational pre-unlink map capture; original guard executes without bypass', 'observer_sha256': sha(observer), 'source_input_count': len(inputs), 'installed_file_count': len(before)}), flush=True)
with (out / 'observed-all-platform-export.stdout.txt').open('w') as stdout, (out / 'observed-all-platform-export.stderr.txt').open('w') as stderr:
  process = subprocess.run(argv, cwd=mobile, env=environment, stdout=stdout, stderr=stderr, timeout=240)
after = installed_hashes()
with gzip.open(out / 'observed-installed-source-sha256-after.json.gz', 'wt') as file:
  json.dump(after, file, indent=2)
source_after = {p: sha(root / p) for p in inputs}
record = {'argv': argv, 'cwd': str(mobile), 'environment_changes': {'NODE_ENV': 'production', 'EXPO_OFFLINE': '1', 'EXPO_NO_TELEMETRY': '1', 'NODE_OPTIONS': environment['NODE_OPTIONS']}, 'scope': 'Secondary diagnostic observation; this record does not replace or modify normal first-export evidence', 'observer_sha256': sha(observer), 'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'exit_code': process.returncode, 'input_count': len(inputs), 'input_hashes_unchanged': inputs == source_after, 'installed_file_count': len(before), 'installed_file_hashes_unchanged': before == after, 'excluded_generated_install_directories': ['.vite', '.cache'], 'stdout': 'observed-all-platform-export.stdout.txt', 'stderr': 'observed-all-platform-export.stderr.txt'}
if process.returncode == 0:
  report = json.loads((export / 'security-build.json').read_text())
  assert report['dependency_audit_gate'] == 'open'
  assert report['advisories'] == ['GHSA-86w9-cpqp-85rv', 'GHSA-vfj7-8cjw-p6xm']
  assert report['platforms'] == ['web', 'ios', 'android']
  assert report['map_count'] == 3
  assert not list(export.rglob('*.map'))
  captures = [json.loads(line) for line in (retained / 'capture.jsonl').read_text().splitlines()]
  assert len(captures) == 3
  inventory = []
  forbidden = re.compile(r'(?:^|/)(?:node-forge|braces|micromatch|resolve-workspace-root|expo-doctor)(?:/|$)|(?:^|/)@expo/code-signing-certificates(?:/|$)')
  for bundle in report['bundles']:
    assert sha(export / bundle['file']) == bundle['bundle_sha256']
    name = bundle['file'] + '.map'
    file = retained / name
    assert sha(file) == bundle['map_sha256']
    capture = next(c for c in captures if c['source'] == name)
    assert capture['sha256'] == sha(file)
    data = json.loads(file.read_text())
    sources = data['sources']
    assert len(sources) == bundle['source_count']
    assert not [s for s in sources if forbidden.search(s.replace('\\', '/'))]
    inventory.append({'map': name, 'map_sha256': sha(file), 'source_count': len(sources), 'sources': sources})
  (out / 'observed-module-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
  (out / 'observed-all-platform-build.json').write_text(json.dumps(report, indent=2) + '\n')
  record['report'] = 'observed-all-platform-build.json'
  record['retained_map_count'] = len(captures)
  record['independent_map_inventory_check'] = 'No affected signing or forbidden pattern-tooling package source; hashes match original guard report and retained bytes'
(out / 'observed-export-acceptance.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print((out / 'observed-all-platform-export.stdout.txt').read_text()[-5500:], flush=True)
print((out / 'observed-all-platform-export.stderr.txt').read_text()[-2000:], flush=True)
assert process.returncode == 0
assert inputs == source_after
assert before == after
