import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import urllib.request

out = Path(__file__).parent
urls = {
  'braces': 'https://registry.npmjs.org/braces/latest',
  'micromatch': 'https://registry.npmjs.org/micromatch/latest',
  'advisory': 'https://api.github.com/advisories/GHSA-vfj7-8cjw-p6xm',
  'repair-pr': 'https://api.github.com/repos/micromatch/braces/pulls/72',
}
records = []
for name, url in urls.items():
  request = urllib.request.Request(url, headers={'User-Agent': 'openauthor-local-dependency-assessment', 'Accept': 'application/json'})
  with urllib.request.urlopen(request, timeout=20) as response:
    raw = response.read(2 * 1024 * 1024)
    data = json.loads(raw)
  (out / (name + '-official.json')).write_bytes(raw)
  record = {'url': url, 'file': name + '-official.json', 'sha256': hashlib.sha256(raw).hexdigest(), 'observed_at': datetime.now(timezone.utc).isoformat()}
  if name in ['braces', 'micromatch']:
    record.update({'name': data['name'], 'version': data['version'], 'dependencies': data.get('dependencies', {}), 'gitHead': data.get('gitHead'), 'dist': data['dist']})
  if name == 'advisory':
    record.update({'ghsa_id': data['ghsa_id'], 'updated_at': data['updated_at'], 'vulnerabilities': data['vulnerabilities']})
  if name == 'repair-pr':
    record.update({'number': data['number'], 'state': data['state'], 'merged': data['merged'], 'merged_at': data['merged_at'], 'head_sha': data['head']['sha'], 'base_sha': data['base']['sha']})
  records.append(record)
(out / 'upstream.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
