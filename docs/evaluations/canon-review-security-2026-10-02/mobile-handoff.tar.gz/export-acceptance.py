import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
from datetime import datetime, timezone

root = Path('~/Developer/openAuthor')
mobile = root / 'mobile'
out = Path(__file__).parent
export = out / 'all-platform-export'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not export.exists()
tracked = subprocess.check_output(['git', 'ls-files', 'mobile/src', 'mobile/scripts', 'mobile/test', 'mobile/App.tsx', 'mobile/index.ts', 'mobile/package.json', 'mobile/package-lock.json', 'mobile/app.json', 'contracts/src', 'contracts/package.json', 'contracts/package-lock.json'], cwd=root, text=True).splitlines()
frozen_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
inputs = {p: sha(root / p) for p in tracked if (root / p).is_file()}
assert inputs['mobile/package-lock.json'] == '4b48f2bb2d1d49df09b77ffc77a2d093b4b7793c9cd33847a458fd399e202968'
assert inputs['mobile/scripts/build-security.mjs'] == '175c5510595add3440ef71b3f284db442122352370a3f3170b13ab3beb286c74'
(out / 'export-source-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
with tarfile.open(out / 'export-tested-inputs.tar.gz', 'w:gz') as archive:
  for p in inputs:
    archive.add(root / p, arcname=p, recursive=False)

def installed_hashes():
  records = {}
  for directory, dirs, files in os.walk(mobile / 'node_modules'):
    dirs[:] = [name for name in dirs if name not in ['.vite', '.cache'] and not (Path(directory) / name).is_symlink()]
    for name in files:
      file = Path(directory) / name
      if file.is_file() and not file.is_symlink():
        records[str(file.relative_to(mobile))] = sha(file)
  return records

before = installed_hashes()
with gzip.open(out / 'installed-source-sha256-before.json.gz', 'wt') as file:
  json.dump(before, file, indent=2)
argv = ['npm', 'run', 'build:export', '--', '--platform', 'all', '--output-dir', str(export)]
started = datetime.now(timezone.utc).isoformat()
environment = {**os.environ, 'NODE_ENV': 'production', 'EXPO_OFFLINE': '1', 'EXPO_NO_TELEMETRY': '1'}
print(json.dumps({'started_at': started, 'argv': argv, 'cwd': str(mobile), 'source_input_count': len(inputs), 'installed_file_count': len(before)}), flush=True)
with (out / 'all-platform-export.stdout.txt').open('w') as stdout, (out / 'all-platform-export.stderr.txt').open('w') as stderr:
  process = subprocess.run(argv, cwd=mobile, env=environment, stdout=stdout, stderr=stderr, timeout=240)
after = installed_hashes()
with gzip.open(out / 'installed-source-sha256-after.json.gz', 'wt') as file:
  json.dump(after, file, indent=2)
source_after = {p: sha(root / p) for p in inputs}
record = {'argv': argv, 'cwd': str(mobile), 'environment_changes': {'NODE_ENV': 'production', 'EXPO_OFFLINE': '1', 'EXPO_NO_TELEMETRY': '1'}, 'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'exit_code': process.returncode, 'git_head_when_frozen': frozen_head, 'input_count': len(inputs), 'input_hashes_unchanged': inputs == source_after, 'installed_file_count': len(before), 'installed_file_hashes_unchanged': before == after, 'excluded_generated_install_directories': ['.vite', '.cache'], 'stdout': 'all-platform-export.stdout.txt', 'stderr': 'all-platform-export.stderr.txt'}
if process.returncode == 0:
  report = json.loads((export / 'security-build.json').read_text())
  assert report['dependency_audit_gate'] == 'open'
  assert report['advisories'] == ['GHSA-86w9-cpqp-85rv', 'GHSA-vfj7-8cjw-p6xm']
  assert report['platforms'] == ['web', 'ios', 'android']
  assert report['map_count'] == 3
  assert not list(export.rglob('*.map'))
  for bundle in report['bundles']:
    assert sha(export / bundle['file']) == bundle['bundle_sha256']
  (out / 'all-platform-build.json').write_text(json.dumps(report, indent=2) + '\n')
  record['report'] = 'all-platform-build.json'
(out / 'export-acceptance.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print((out / 'all-platform-export.stdout.txt').read_text()[-5500:], flush=True)
print((out / 'all-platform-export.stderr.txt').read_text()[-2000:], flush=True)
assert process.returncode == 0
assert inputs == source_after
assert before == after
