import hashlib
import json
from pathlib import Path
import re
import subprocess
from datetime import datetime, timezone

root = Path('~/Developer/openAuthor')
out = Path(__file__).parent
node = '~/.nvm/versions/node/v22.17.0/bin/node'
npm = '~/.nvm/versions/node/v22.17.0/bin/npm'
mobile = root / 'mobile'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

sources = [
  'mobile/package.json', 'mobile/package-lock.json', 'mobile/app.json',
  'mobile/scripts/build-security.mjs',
  'mobile/node_modules/braces/index.js',
  'mobile/node_modules/braces/lib/parse.js',
  'mobile/node_modules/braces/lib/compile.js',
  'mobile/node_modules/braces/lib/expand.js',
  'mobile/node_modules/braces/lib/constants.js',
  'mobile/node_modules/micromatch/index.js',
  'mobile/node_modules/@expo/metro-file-map/build/watchers/common.js',
  'mobile/node_modules/@expo/metro-file-map/build/Watcher.js',
  'mobile/node_modules/metro-file-map/src/watchers/common.js',
  'mobile/node_modules/metro-file-map/src/Watcher.js',
  'mobile/node_modules/resolve-workspace-root/build/index.js',
  'mobile/node_modules/expo-doctor/build/index.js',
  'mobile/node_modules/@react-native/codegen/package.json',
  'mobile/node_modules/jest-util/build/globsToMatcher.js',
  'docs/evaluations/project-completion-2026-10-02/forge-module-lists.json',
]
before = {str(p): sha(root / p) for p in sources}
results = {'started_at': datetime.now(timezone.utc).isoformat(), 'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'source_sha256': before, 'live_provider_calls': 0, 'deployed_operations': 0, 'package_installs': 0, 'dependency_changes': False, 'probes': []}

def run(name, args, cwd=mobile):
  try:
    r = subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=15)
    (out / (name + '.stdout.txt')).write_text(r.stdout)
    (out / (name + '.stderr.txt')).write_text(r.stderr)
    return {'name': name, 'argv': args, 'cwd': str(cwd), 'exit_code': r.returncode, 'stdout': name + '.stdout.txt', 'stderr': name + '.stderr.txt'}
  except subprocess.TimeoutExpired as e:
    raise AssertionError(f'Probe {name} timed out') from e

results['installed_tree'] = run('installed-tree', [npm, 'ls', 'braces', 'micromatch', '--all', '--json', '--offline', '--ignore-scripts'])
assert results['installed_tree']['exit_code'] == 0
results['invocation_sentinel'] = run('invocation-sentinel', [node, str(out / 'probe.cjs')])
assert results['invocation_sentinel']['exit_code'] == 0
sentinel = json.loads((out / 'invocation-sentinel.stdout.txt').read_text())
assert len(sentinel['results']) == 19

for method in ['default', 'compile', 'expand']:
  for depth in [3500, 4000, 4400, 4900]:
    js = "const braces = require('./node_modules/braces'); const depth = " + str(depth) + "; const pattern = '{'.repeat(depth) + 'a,b' + '}'.repeat(depth); console.log(JSON.stringify({node: process.version,method:" + json.dumps(method) + ",depth,length:pattern.length,max_length:10000})); " + ('braces(pattern)' if method == 'default' else f'braces.{method}(pattern)') + "; console.log('completed');"
    name = f'isolated-{method}-{depth}'
    (out / (name + '.cjs')).write_text(js + '\n')
    record = run(name, [node, '-e', js])
    stderr = (out / record['stderr']).read_text()
    record.update({'method': method, 'depth': depth, 'length': depth * 2 + 3, 'uncaught_stack_exhaustion': 'RangeError: Maximum call stack size exceeded' in stderr})
    assert record['exit_code'] in [0, 1]
    assert record['exit_code'] == 0 or record['uncaught_stack_exhaustion']
    results['probes'].append(record)

assert any(p['uncaught_stack_exhaustion'] for p in results['probes'])
old = json.loads((root / sources[-1]).read_text())
results['historical_exports'] = [{'inventory_file': key, 'source_count': len(values), 'braces_sources': [s for s in values if re.search(r'(?:^|/)braces(?:/|$)', s)], 'micromatch_sources': [s for s in values if re.search(r'(?:^|/)micromatch(?:/|$)', s)], 'scope': 'Retained earlier module-name inventory, not a fresh export or proof of current signed native artifact'} for key, values in old.items()]
for record in results['historical_exports']:
  assert not record['braces_sources'] and not record['micromatch_sources']
after = {str(p): sha(root / p) for p in sources}
assert before == after
results['source_hashes_unchanged'] = True
results['finished_at'] = datetime.now(timezone.utc).isoformat()
results['dependency_audit_gate'] = 'open'
results['limits'] = 'Package-level synthetic sentinel and isolated dependency crash probes. No network-facing dev server requests, current full exports, actual signing, native distribution, or blanket dependency remediation claim.'
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'out': str(out), 'sentinel_cases': len(sentinel['results']), 'braces_loads': sentinel['braces_loads'], 'metro_caller_invocations': sum(r.get('braces_calls', 0) for r in sentinel['results'] if 'file' in r), 'dependency_probes': len(results['probes']), 'uncaught_stack_exhaustion_probes': sum(r['uncaught_stack_exhaustion'] for r in results['probes']), 'source_hashes_unchanged': True, 'dependency_audit_gate': 'open'}))
