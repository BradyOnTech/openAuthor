const assert = require('node:assert/strict');
const fs = require('node:fs');
const Module = require('node:module');
const path = require('node:path');
const mobile = '~/Developer/openAuthor/mobile';
const localRequire = Module.createRequire(path.join(mobile, 'package.json'));
const bracesPath = localRequire.resolve('braces');
const originalLoad = Module._load;
const calls = [];
let loads = 0;
const sentinel = new Proxy(function (...args) {
  calls.push({ method: 'default', length: String(args[0]).length });
  throw new Error('Synthetic Braces invocation sentinel');
}, {
  get(target, property) {
    if (typeof property === 'symbol') return target[property];
    return (...args) => {
      calls.push({ method: property, length: String(args[0]).length });
      throw new Error('Synthetic Braces invocation sentinel');
    };
  }
});
Module._load = function (request, parent, isMain) {
  if (Module._resolveFilename(request, parent) === bracesPath) {
    loads++;
    return sentinel;
  }
  return originalLoad.call(this, request, parent, isMain);
};
const results = [];
for (const file of [
  'node_modules/@expo/metro-file-map/build/watchers/common.js',
  'node_modules/metro-file-map/src/watchers/common.js',
]) {
  const { includedByGlob } = require(path.join(mobile, file));
  const cases = [
    ['f', ['**/*.js'], true, 'src/editor.js', true],
    ['f', ['**/*.{js,ts,tsx}'], true, 'src/editor.tsx', true],
    ['f', ['**/*.{js,ts,tsx}'], true, 'src/editor.css', false],
    ['f', [], false, '.hidden', false],
    ['f', [], true, '.hidden', true],
    ['d', ['**/*.js'], true, 'src', true],
    ['f', ['**/*.js'], true, '{'.repeat(4400) + 'a,b' + '}'.repeat(4400), false],
    ['f', ['{'.repeat(4400) + 'a,b' + '}'.repeat(4400)], true, 'unmatched.js', false],
  ];
  for (let index = 0; index < cases.length; index++) {
    const [type, globs, dot, relativePath, expected] = cases[index];
    const start = calls.length;
    const result = includedByGlob(type, globs, dot, relativePath);
    assert.equal(result, expected);
    assert.equal(calls.length, start);
    results.push({ file, case: index + 1, result, braces_calls: calls.length - start, pattern_lengths: globs.map(s => s.length), path_length: relativePath.length });
  }
}
const micromatch = localRequire('micromatch');
for (const method of ['parse', 'braces', 'braceExpand']) {
  const start = calls.length;
  assert.throws(() => micromatch[method]('{a,b}'), /Synthetic Braces invocation sentinel/);
  assert.equal(calls.length, start + 1);
  results.push({ direct_synthetic_method: method, braces_calls: calls.length - start });
}
assert.equal(loads, 1);
process.stdout.write(JSON.stringify({ scope: 'Synthetic package-level invocation sentinel; no dev server, app runtime, or signed artifact acceptance', braces_loads: loads, results, calls }, null, 2) + '\n');
