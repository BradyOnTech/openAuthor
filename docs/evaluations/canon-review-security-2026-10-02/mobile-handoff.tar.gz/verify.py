import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--seal', action='store_true')
parser.add_argument('--current', action='store_true')
args = parser.parse_args()
out = Path(__file__).parent
root = Path('~/Developer/openAuthor')
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = out / 'evidence-sha256.json'
if args.seal:
  records = {str(file.relative_to(out)): sha(file.read_bytes()) for file in sorted(out.rglob('*')) if file.is_file() and file != manifest}
  manifest.write_text(json.dumps(records, indent=2) + '\n')
records = json.loads(manifest.read_text())
for file, expected in records.items():
  assert sha((out / file).read_bytes()) == expected, file
assessment = json.loads((out / 'assessment.json').read_text())
assert assessment['dependency_audit_gate'] == 'open'
assert assessment['advisories'] == ['GHSA-86w9-cpqp-85rv', 'GHSA-vfj7-8cjw-p6xm']
original = json.loads((out / 'results.json').read_text())
inputs = json.loads((out / 'export-source-sha256.json').read_text())
for archive_name, expected in [('read-only-tested-sources.tar.gz', original['source_sha256']), ('export-tested-inputs.tar.gz', inputs)]:
  with tarfile.open(out / archive_name, 'r:gz') as archive:
    files = {item.name: item for item in archive.getmembers() if item.isfile()}
    assert set(files) == set(expected)
    for file, digest in expected.items():
      assert sha(archive.extractfile(files[file]).read()) == digest
for prefix in ['', 'observed-']:
  before = json.loads(gzip.decompress((out / (prefix + 'installed-source-sha256-before.json.gz')).read_bytes()))
  after = json.loads(gzip.decompress((out / (prefix + 'installed-source-sha256-after.json.gz')).read_bytes()))
  assert before == after and len(before) == 26518
  result = json.loads((out / (prefix + 'export-acceptance.json')).read_text())
  assert result['exit_code'] == 0 and result['input_hashes_unchanged'] and result['installed_file_hashes_unchanged']
  report = json.loads((out / (prefix + 'all-platform-build.json')).read_text())
  assert report['map_count'] == 3 and report['dependency_audit_gate'] == 'open'
  assert report['advisories'] == assessment['advisories']
  exported = out / (prefix + 'all-platform-export')
  assert not list(exported.rglob('*.map'))
  for bundle in report['bundles']:
    assert sha((exported / bundle['file']).read_bytes()) == bundle['bundle_sha256']
report = json.loads((out / 'observed-all-platform-build.json').read_text())
inventory = json.loads((out / 'observed-module-inventory.json').read_text())
for bundle in report['bundles']:
  name = bundle['file'] + '.map'
  data = gzip.decompress((out / 'observed-retained-maps' / (name + '.gz')).read_bytes())
  assert sha(data) == bundle['map_sha256']
  sources = json.loads(data)['sources']
  record = next(item for item in inventory if item['map'] == name)
  assert record['map_sha256'] == sha(data) and sources == record['sources']
  assert len(sources) == bundle['source_count']
  assert not [source for source in sources if re.search(r'(?:^|/)(?:node-forge|braces|micromatch|resolve-workspace-root|expo-doctor)(?:/|$)|(?:^|/)@expo/code-signing-certificates(?:/|$)', source.replace('\\', '/'))]
red = json.loads((out / 'containment-red.json').read_text())
green = json.loads((out / 'containment-green.json').read_text())
assert red['exit_code'] == 1 and green['exit_code'] == 0
assert '11 failed | 14 passed (25)' in (out / red['stdout']).read_text()
assert '25 passed (25)' in (out / green['stdout']).read_text()
assert green['source_sha256']['mobile/scripts/build-security.mjs'] == assessment['owned_files']['mobile/scripts/build-security.mjs']
assert green['source_sha256']['mobile/test/buildSecurity.test.mjs'] == assessment['owned_files']['mobile/test/buildSecurity.test.mjs']
assert len(original['probes']) == 12 and all(case['uncaught_stack_exhaustion'] for case in original['probes'])
if args.current:
  for file, expected in inputs.items():
    assert sha((root / file).read_bytes()) == expected, file
print(json.dumps({'evidence_files': len(records), 'inspected_original_sources': len(original['source_sha256']), 'export_inputs': len(inputs), 'focused_tests': 25, 'normal_and_observed_exports': 2, 'retained_observed_maps': 3, 'dependency_audit_gate': 'open'}))
