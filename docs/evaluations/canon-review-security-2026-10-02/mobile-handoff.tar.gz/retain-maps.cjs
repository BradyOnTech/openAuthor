const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { syncBuiltinESMExports } = require('node:module');
const output = '/private/tmp/openauthor-braces-reachability-5tfl6oro/observed-all-platform-export';
const retained = '/private/tmp/openauthor-braces-reachability-5tfl6oro/observed-retained-maps';
const originalUnlink = fs.unlinkSync;
fs.unlinkSync = function (file, ...args) {
  const resolved = typeof file === 'string' ? path.resolve(file) : '';
  if (resolved.startsWith(output + path.sep) && resolved.endsWith('.map')) {
    const relative = path.relative(output, resolved);
    const target = path.join(retained, relative);
    const bytes = fs.readFileSync(resolved);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, bytes, { flag: 'wx' });
    fs.appendFileSync(path.join(retained, 'capture.jsonl'), JSON.stringify({ source: relative, sha256: crypto.createHash('sha256').update(bytes).digest('hex'), size: bytes.length, pid: process.pid, captured_before_unlink: true }) + '\n');
  }
  return originalUnlink.call(this, file, ...args);
};
syncBuiltinESMExports();
