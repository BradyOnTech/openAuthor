const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const crypto = require('node:crypto');
const mobile = '~/Developer/openAuthor/mobile';
const parser = Module.createRequire(path.join(mobile, 'package.json'))('@babel/parser');
const records = [];
for (const name of ['resolve-workspace-root/build/index.js', 'expo-doctor/build/index.js']) {
  const file = path.join(mobile, 'node_modules', name);
  const text = fs.readFileSync(file, 'utf8');
  const ast = parser.parse(text, { sourceType: 'unambiguous' });
  const calls = [];
  const definitions = [];
  function walk(node, moduleId = null) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'ObjectProperty' && node.key.type === 'NumericLiteral' && ['ArrowFunctionExpression', 'FunctionExpression'].includes(node.value.type)) {
      moduleId = node.key.value;
      if ([6228, 610, 9434, 5873, 6477, 8750].includes(moduleId)) definitions.push({ module_id: moduleId, start: node.start, end: node.end, source: text.slice(node.start, node.end) });
    }
    if (node.type === 'CallExpression' && node.arguments.length === 1 && node.arguments[0].type === 'NumericLiteral' && [6228, 610].includes(node.arguments[0].value)) {
      calls.push({ owner_module_id: moduleId, required_module_id: node.arguments[0].value, callee: node.callee.name, start: node.start, end: node.end, context: text.slice(Math.max(0, node.start - 100), Math.min(text.length, node.end + 400)) });
    }
    for (const [key, value] of Object.entries(node)) {
      if (['start', 'end', 'loc', 'extra', 'comments', 'tokens'].includes(key)) continue;
      if (Array.isArray(value)) value.forEach(child => walk(child, moduleId));
      else if (value && typeof value === 'object') walk(value, moduleId);
    }
  }
  walk(ast);
  if (calls.length !== 2 || calls.filter(c => c.required_module_id === 6228).length !== 1 || calls.filter(c => c.required_module_id === 610 && c.owner_module_id === 6228).length !== 1) throw new Error('Unexpected bundled caller graph');
  const ownerIds = new Set(calls.filter(c => c.required_module_id === 6228).map(c => c.owner_module_id));
  function findOwners(node) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'ObjectProperty' && node.key.type === 'NumericLiteral' && ownerIds.has(node.key.value)) definitions.push({ module_id: node.key.value, start: node.start, end: node.end, source: text.slice(node.start, node.end) });
    for (const [key, value] of Object.entries(node)) {
      if (['start', 'end', 'loc', 'extra', 'comments', 'tokens'].includes(key)) continue;
      if (Array.isArray(value)) value.forEach(findOwners);
      else if (value && typeof value === 'object') findOwners(value);
    }
  }
  findOwners(ast);
  records.push({ file: 'mobile/node_modules/' + name, sha256: crypto.createHash('sha256').update(text).digest('hex'), method: 'Read-only Babel AST analysis of installed bundled source; internal module 6228=Micromatch, 610=Braces; numeric require calls only', calls, definitions });
}
const out = path.join(__dirname, 'bundle-analysis.json');
fs.writeFileSync(out, JSON.stringify(records, null, 2) + '\n');
console.log(JSON.stringify(records.map(r => ({ file: r.file, calls: r.calls.map(c => ({ owner_module_id: c.owner_module_id, required_module_id: c.required_module_id })), definition_count: r.definitions.length }))));
