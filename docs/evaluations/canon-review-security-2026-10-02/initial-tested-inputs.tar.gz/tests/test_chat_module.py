from __future__ import annotations

import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from openauthor.budget import update_generation_budget_policy
from openauthor.assistant.turns import AssistantTurnStore
from openauthor.chat import (
  _build_provider_history,
  create_chat_thread,
  execute_pending_tool_call,
  get_chat_turn_diff,
  list_chat_messages,
  list_chat_threads,
  rename_chat_thread,
  regenerate_chat_turn,
  send_chat_message,
  truncate_chat_messages,
  update_chat_thread,
)
from openauthor.generations import list_generation_runs
from openauthor.git_ops import create_snapshot, initialize_git
from openauthor.project import OpenAuthorError, initialize_project
from openauthor.scenes import add_scene


def _completion(text: str, tool_calls: list | None = None) -> dict:
  return {
    "text": text,
    "tool_calls": tool_calls or [],
    "input_tokens": 12,
    "output_tokens": 8,
    "latency_ms": 3,
    "provider_attempts": 1,
    "estimated_cost_usd": None,
    "generation_id": "gen-000000000000",
    "log_path": "",
  }


class ChatModuleTests(unittest.TestCase):
  def test_regeneration_is_idempotent_and_marks_original_turn_superseded(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      paths = initialize_project(Path(tmp), name="Atomic Regeneration")
      thread = create_chat_thread(paths, title="Regenerate", provider="local", mode="chat")
      with patch("openauthor.chat.complete_chat", return_value=_completion("First answer.")):
        original = send_chat_message(
          paths,
          thread_id=thread["id"],
          message="Try an answer.",
          turn_id="turn-original",
        )

      with patch("openauthor.chat.complete_chat", return_value=_completion("Second answer.")) as provider:
        replacement = regenerate_chat_turn(
          paths,
          thread_id=thread["id"],
          from_message_id=original["user_message"]["id"],
          replacement_turn_id="turn-replacement",
          message="Try an answer.",
        )
        retry = regenerate_chat_turn(
          paths,
          thread_id=thread["id"],
          from_message_id=original["user_message"]["id"],
          replacement_turn_id="turn-replacement",
          message="Try an answer.",
        )

      self.assertEqual(provider.call_count, 1)
      self.assertEqual(replacement["assistant_message"]["id"], retry["assistant_message"]["id"])
      self.assertEqual(
        [row["content"] for row in list_chat_messages(paths, thread_id=thread["id"])],
        ["Try an answer.", "Second answer."],
      )
      original_turn = AssistantTurnStore(paths).get("turn-original")
      self.assertEqual(original_turn.status, "superseded")
      self.assertEqual(original_turn.superseded_by, "turn-replacement")

  def test_send_and_truncate_same_thread_cannot_leave_orphan_assistant(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      paths = initialize_project(Path(tmp), name="Serialized Chat Mutation")
      thread = create_chat_thread(paths, title="Race", provider="local", mode="chat")
      provider_entered = threading.Event()
      release_provider = threading.Event()
      truncate_finished = threading.Event()
      send_errors: list[BaseException] = []
      truncate_errors: list[BaseException] = []

      def blocked_completion(*_args: object, **_kwargs: object) -> dict:
        provider_entered.set()
        release_provider.wait(timeout=2)
        return _completion("Settled answer.")

      def run_send() -> None:
        try:
          send_chat_message(
            paths,
            thread_id=thread["id"],
            message="Hold this turn.",
            turn_id="turn-race",
          )
        except BaseException as error:  # pragma: no cover - asserted below
          send_errors.append(error)

      def run_truncate(message_id: str) -> None:
        try:
          truncate_chat_messages(
            paths,
            thread_id=thread["id"],
            from_message_id=message_id,
          )
        except BaseException as error:  # pragma: no cover - asserted below
          truncate_errors.append(error)
        finally:
          truncate_finished.set()

      send_chat_message(paths, thread_id=thread["id"], message="A prior turn.")
      with patch("openauthor.chat.complete_chat", side_effect=blocked_completion):
        send_worker = threading.Thread(target=run_send)
        send_worker.start()
        self.assertTrue(provider_entered.wait(timeout=1))
        user_message = list_chat_messages(paths, thread_id=thread["id"])[0]
        truncate_worker = threading.Thread(
          target=run_truncate,
          args=(str(user_message["id"]),),
        )
        truncate_worker.start()
        time.sleep(0.03)
        self.assertFalse(truncate_finished.is_set())
        release_provider.set()
        send_worker.join(timeout=2)
        truncate_worker.join(timeout=2)

      self.assertEqual(send_errors, [])
      self.assertEqual(truncate_errors, [])
  def test_retry_after_transcript_write_failure_recovers_without_another_generation(self) -> None:
    with tempfile.TemporaryDirectory() as temporary:
      paths = initialize_project(Path(temporary), name="Delivery recovery")
      thread = create_chat_thread(paths, title="Receipt", provider="local", mode="chat")
      from openauthor.project import atomic_write_text
      def fail_transcript(path, content):
        if path.suffix == ".jsonl":
          raise OSError("Simulated disk failure after provider completion")
        return atomic_write_text(path, content)
      with patch("openauthor.chat.atomic_write_text", side_effect=fail_transcript):
        with self.assertRaises(OSError):
          send_chat_message(paths, thread_id=thread["id"], message="Try another opening", request_id="delivery-1")
      before = list_generation_runs(paths)
      result = send_chat_message(paths, thread_id=thread["id"], message="Try another opening", request_id="delivery-1")
      self.assertEqual(len(list_chat_messages(paths, thread_id=thread["id"])), 2)
      self.assertEqual(list_generation_runs(paths), before)
      self.assertEqual(send_chat_message(paths, thread_id=thread["id"], message="Try another opening", request_id="delivery-1"), result)
      with self.assertRaises(OpenAuthorError):
        send_chat_message(paths, thread_id=thread["id"], message="Different prompt", request_id="delivery-1")
      truncate_chat_messages(paths, thread_id=thread["id"], from_message_id=result["user_message"]["id"])
      send_chat_message(paths, thread_id=thread["id"], message="Try another opening", request_id="delivery-1")
      self.assertEqual(list_chat_messages(paths, thread_id=thread["id"]), [])

  def test_chat_thread_lifecycle(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Thread Lifecycle")
      created = create_chat_thread(
        paths,
        title="Worldbuilding",
        provider="local",
        mode="chat",
      )
      self.assertEqual(created["title"], "Worldbuilding")
      self.assertEqual(created["provider"], "local")
      self.assertEqual(created["mode"], "chat")
      self.assertEqual(created["model"], "heuristic-v1")

      renamed = rename_chat_thread(paths, thread_id=created["id"], title="Draft Room")
      self.assertEqual(renamed["title"], "Draft Room")

      updated = update_chat_thread(
        paths,
        thread_id=created["id"],
        mode="agent",
        context_profile={
          "include_codex": "explicit",
          "retrieval_mode": "auto",
        },
      )
      self.assertEqual(updated["mode"], "agent")
      self.assertEqual(updated["context_profile"]["include_codex"], "explicit")
      self.assertEqual(updated["context_profile"]["retrieval_mode"], "auto")

      threads = list_chat_threads(paths)
      self.assertEqual(len(threads), 1)
      self.assertEqual(threads[0]["id"], created["id"])

  def test_uncertain_tool_execution_is_never_automatically_repeated(self) -> None:
    with tempfile.TemporaryDirectory() as temporary:
      paths = initialize_project(Path(temporary), name="Uncertain tool")
      add_scene(paths, title="Opening", summary="", pov="", status="draft", body="Synthetic prose")
      thread = create_chat_thread(paths, title="Tools", provider="local", mode="agent")
      sent = send_chat_message(paths, thread_id=thread["id"], message="Please create proposal for this scene.", current_scene_id="scene-0001")
      from openauthor.project import atomic_write_json
      from openauthor.proposals import list_proposals
      def fail_completion(path, payload):
        if path.parent.name == "tools" and payload.get("status") != "executing":
          raise OSError("Synthetic disk failure after tool execution")
        return atomic_write_json(path, payload)
      args = {"thread_id": thread["id"], "assistant_message_id": sent["assistant_message"]["id"], "tool_index": 0}
      with patch("openauthor.chat.atomic_write_json", side_effect=fail_completion):
        with self.assertRaises(OSError):
          execute_pending_tool_call(paths, **args)
      self.assertEqual(len(list_proposals(paths)), 1)
      with self.assertRaisesRegex(OpenAuthorError, "may already have changed"):
        execute_pending_tool_call(paths, **args)
      self.assertEqual(len(list_proposals(paths)), 1)

  def test_cancelled_partial_turn_is_not_published_and_can_be_retried(self) -> None:
    with tempfile.TemporaryDirectory() as temporary:
      paths = initialize_project(Path(temporary), name="Cancelled delivery")
      thread = create_chat_thread(paths, title="Cancellation", provider="local", mode="chat")
      from openauthor.ai import ChatInterrupted
      def interrupt(text):
        raise ChatInterrupted("Synthetic stop after first delta")
      args = {"thread_id": thread["id"], "message": "Synthetic prompt", "request_id": "cancelled-delivery"}
      with self.assertRaises(ChatInterrupted):
        send_chat_message(paths, **args, on_delta=interrupt)
      self.assertEqual(list_chat_messages(paths, thread_id=thread["id"]), [])
      send_chat_message(paths, **args)
      self.assertEqual(len(list_chat_messages(paths, thread_id=thread["id"])), 2)

  def test_chat_send_agent_executes_read_tools_and_queues_writes(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Send")
      add_scene(
        paths,
        title="Scene One",
        summary="Opening",
        pov="narrator",
        status="draft",
        body="A simple opening scene body.",
      )
      thread = create_chat_thread(
        paths,
        title="Agent Thread",
        provider="local",
        mode="agent",
      )

      read_result = send_chat_message(
        paths,
        thread_id=thread["id"],
        message="Please list scenes for me.",
        current_scene_id="scene-0001",
      )
      self.assertEqual(read_result["assistant_message"]["role"], "assistant")
      self.assertEqual(len(read_result["pending_tool_calls"]), 0)
      self.assertGreaterEqual(len(read_result["tool_messages"]), 1)

      write_result = send_chat_message(
        paths,
        thread_id=thread["id"],
        message="Please create proposal for this scene.",
        current_scene_id="scene-0001",
      )
      self.assertGreaterEqual(len(write_result["pending_tool_calls"]), 1)
      pending = write_result["pending_tool_calls"][0]
      self.assertEqual(pending["tool"], "proposal.add")
      self.assertEqual(pending["classification"], "write")

      executed = execute_pending_tool_call(
        paths,
        thread_id=thread["id"],
        assistant_message_id=write_result["assistant_message"]["id"],
        tool_index=0,
      )
      self.assertEqual(executed["tool"], "proposal.add")
      self.assertEqual(execute_pending_tool_call(
        paths, thread_id=thread["id"],
        assistant_message_id=write_result["assistant_message"]["id"], tool_index=0,
      ), executed)
      # Simulate an older book: its successful tool message is the receipt.
      for receipt in paths.chats_dir.glob("deliveries/*/tools/*.json"):
        receipt.unlink()
      self.assertEqual(execute_pending_tool_call(
        paths, thread_id=thread["id"],
        assistant_message_id=write_result["assistant_message"]["id"], tool_index=0,
      )["result"], executed["result"])

      messages = list_chat_messages(paths, thread_id=thread["id"])
      self.assertTrue(any(row["role"] == "tool" for row in messages))

  def test_duplicate_tool_approval_executes_side_effect_once(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      paths = initialize_project(Path(tmp), name="Idempotent Tool Approval")
      thread = create_chat_thread(paths, title="Agent", provider="local", mode="agent")
      queued = _completion(
        "I prepared a proposal.",
        [
          {
            "id": "call-idempotent",
            "name": "proposal_add",
            "args": {"title": "Try this", "rationale": "Safer revision"},
          }
        ],
      )
      with patch("openauthor.chat.complete_chat", return_value=queued):
        turn = send_chat_message(
          paths,
          thread_id=thread["id"],
          message="Prepare one proposal.",
          turn_id="turn-tool-idempotent",
        )

      with patch(
        "openauthor.chat._execute_tool",
        return_value={"id": "proposal-one", "title": "Try this"},
      ) as execute:
        first = execute_pending_tool_call(
          paths,
          thread_id=thread["id"],
          assistant_message_id=turn["assistant_message"]["id"],
          tool_index=0,
        )
        retry = execute_pending_tool_call(
          paths,
          thread_id=thread["id"],
          assistant_message_id=turn["assistant_message"]["id"],
          tool_index=0,
        )

      self.assertEqual(execute.call_count, 1)
      self.assertEqual(first["tool_message"]["id"], retry["tool_message"]["id"])
      messages = list_chat_messages(paths, thread_id=thread["id"])
      self.assertEqual([row["role"] for row in messages].count("tool"), 1)
      assistant = next(row for row in messages if row["role"] == "assistant")
      self.assertTrue(assistant["tool_calls"][0]["executed"])

  def test_chat_send_includes_explicit_scene_mentions_in_context(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Scene Mentions")
      add_scene(
        paths,
        title="Scene One",
        summary="Opening",
        pov="narrator",
        status="draft",
        body="Body one",
      )
      add_scene(
        paths,
        title="Scene Two",
        summary="Follow up",
        pov="narrator",
        status="draft",
        body="Body two",
      )
      thread = create_chat_thread(paths, title="Context Thread", provider="local", mode="agent")

      result = send_chat_message(
        paths,
        thread_id=thread["id"],
        message="Use both scenes for this suggestion.",
        current_scene_id="scene-0001",
        scene_ids=["scene-0002"],
      )

      context_used = result["user_message"]["context_used"]
      self.assertEqual(context_used["scene_ids"], ["scene-0001", "scene-0002"])

  def test_book_scope_uses_bounded_scene_anchors_and_grounded_local_guidance(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      paths = initialize_project(Path(tmp), name="Book Scope")
      add_scene(
        paths,
        title="The Missing Minute",
        pov="Mara",
        body=(
          "At noon, Mara alone remembered the missing thirteen minutes. "
          "She found a brass key warm in her hand."
        ),
      )
      add_scene(paths, title="Aftermath", pov="Mara", body="The city denied anything had happened.")
      thread = create_chat_thread(paths, title="Book Guide", provider="local", mode="chat")

      result = send_chat_message(
        paths,
        thread_id=thread["id"],
        message="What unresolved story question should I develop next, and why?",
        context_overrides={"scope": "project"},
      )

      context_used = result["user_message"]["context_used"]
      self.assertEqual(context_used["scene_ids"], ["scene-0001", "scene-0002"])
      self.assertEqual(context_used["profile"]["scope"], "project")
      reply = result["assistant_message"]["content"]
      self.assertIn("Mara", reply)
      self.assertIn("missing thirteen minutes", reply)
      self.assertIn("brass key", reply)

  def test_build_provider_history_maps_roles_and_windows_by_tokens(self) -> None:
    rows = [
      {"role": "user", "content": "First question."},
      {"role": "assistant", "content": "First answer."},
      {"role": "tool", "content": '{"tool":"scene.list","result":[]}'},
    ]
    history = _build_provider_history(rows, token_budget=4000)
    self.assertEqual(
      [entry["role"] for entry in history],
      ["user", "assistant", "user"],
    )
    self.assertEqual(history[0]["content"], "First question.")
    self.assertTrue(history[2]["content"].startswith("Tool result:"))

    self.assertEqual(_build_provider_history(rows, token_budget=0), [])

    old_row = {"role": "user", "content": "old words " * 100}
    new_row = {"role": "user", "content": "keep this recent question"}
    windowed = _build_provider_history([old_row, new_row], token_budget=20)
    self.assertEqual(len(windowed), 1)
    self.assertEqual(windowed[0]["content"], "keep this recent question")

    # A window that starts mid-conversation must not lead with an assistant
    # turn, and consecutive same-role entries collapse into one.
    dangling = _build_provider_history(
      [
        {"role": "assistant", "content": "Orphaned answer."},
        {"role": "user", "content": "Follow-up one."},
        {"role": "user", "content": "Follow-up two."},
      ],
      token_budget=4000,
    )
    self.assertEqual(len(dangling), 1)
    self.assertEqual(dangling[0]["role"], "user")
    self.assertIn("Follow-up one.", dangling[0]["content"])
    self.assertIn("Follow-up two.", dangling[0]["content"])

  def test_chat_send_passes_thread_history_to_provider(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat History")
      thread = create_chat_thread(paths, title="History Thread", provider="local", mode="chat")

      completion = {
        "text": "Reply one.",
        "input_tokens": 10,
        "output_tokens": 5,
        "latency_ms": 4,
        "provider_attempts": 1,
        "estimated_cost_usd": None,
        "generation_id": "gen-000000000000",
        "log_path": "",
      }
      with patch("openauthor.chat.complete_chat", return_value=completion) as fake:
        send_chat_message(paths, thread_id=thread["id"], message="First question.")
        first_history = fake.call_args.kwargs["history"]
        self.assertEqual(first_history, [])

        send_chat_message(paths, thread_id=thread["id"], message="Second question.")
        second_history = fake.call_args.kwargs["history"]
        self.assertEqual(
          [entry["role"] for entry in second_history],
          ["user", "assistant"],
        )
        self.assertEqual(second_history[0]["content"], "First question.")
        self.assertEqual(second_history[1]["content"], "Reply one.")
        self.assertEqual(fake.call_args.kwargs["thread_id"], thread["id"])

  def test_chat_send_writes_generation_log_with_thread_provenance(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Provenance")
      thread = create_chat_thread(paths, title="Logged Thread", provider="local", mode="chat")

      result = send_chat_message(
        paths,
        thread_id=thread["id"],
        message="What should happen in the next scene?",
      )
      generation_id = result["assistant_message"]["usage"]["generation_id"]
      self.assertTrue(generation_id.startswith("gen-"))

      runs = list_generation_runs(paths)
      row = next(item for item in runs if item["run_id"] == generation_id)
      self.assertEqual(row["kind"], "chat")
      self.assertEqual(row["thread_id"], thread["id"])
      self.assertEqual(row["status"], "succeeded")
      self.assertIsNotNone(row["input_tokens"])
      self.assertIsNotNone(row["output_tokens"])

  def test_chat_send_blocked_by_budget_policy_fails_closed(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Budget")
      thread = create_chat_thread(paths, title="Budget Thread", provider="local", mode="chat")
      update_generation_budget_policy(paths, max_output_tokens=64)

      with self.assertRaises(OpenAuthorError) as context:
        send_chat_message(paths, thread_id=thread["id"], message="Hello there.")
      self.assertIn("budget", str(context.exception).lower())

      runs = list_generation_runs(paths, status="failed")
      self.assertTrue(
        any(
          row["kind"] == "chat"
          and row["thread_id"] == thread["id"]
          and row["error_category"] == "budget_policy_violation"
          for row in runs
        )
      )
      messages = list_chat_messages(paths, thread_id=thread["id"])
      self.assertEqual(messages, [])

  def test_truncate_chat_messages_rewinds_thread(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Chat Truncate")
      thread = create_chat_thread(paths, title="Rewind Thread", provider="local", mode="chat")
      send_chat_message(paths, thread_id=thread["id"], message="First question.")
      second = send_chat_message(paths, thread_id=thread["id"], message="Second question.")

      before = list_chat_messages(paths, thread_id=thread["id"])
      self.assertEqual(len(before), 4)

      result = truncate_chat_messages(
        paths,
        thread_id=thread["id"],
        from_message_id=second["user_message"]["id"],
      )
      self.assertEqual(result["removed_count"], 2)
      self.assertEqual(result["remaining_count"], 2)
      self.assertIn(second["assistant_message"]["id"], result["removed_ids"])

      after = list_chat_messages(paths, thread_id=thread["id"])
      self.assertEqual([row["id"] for row in after], [row["id"] for row in before[:2]])

      with self.assertRaises(OpenAuthorError):
        truncate_chat_messages(
          paths,
          thread_id=thread["id"],
          from_message_id="msg-does-not-exist",
        )

  def test_agent_tool_loop_feeds_results_back_to_provider(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Tool Loop")
      add_scene(
        paths,
        title="Scene One",
        summary="Opening",
        pov="narrator",
        status="draft",
        body="Opening scene body.",
      )
      thread = create_chat_thread(paths, title="Loop Thread", provider="local", mode="agent")

      rounds = [
        _completion(
          "Let me check the scene list.",
          [{"id": "call-1", "name": "scene_list", "args": {}}],
        ),
        _completion("You have one scene: Scene One."),
      ]
      with patch("openauthor.chat.complete_chat", side_effect=rounds) as fake:
        result = send_chat_message(
          paths,
          thread_id=thread["id"],
          message="What scenes exist?",
        )

      self.assertEqual(fake.call_count, 2)
      continuation = fake.call_args_list[1].kwargs
      self.assertEqual(continuation["user_prompt"], "")
      assistant_entry = continuation["history"][-2]
      tool_entry = continuation["history"][-1]
      self.assertEqual(assistant_entry["role"], "assistant")
      self.assertEqual(assistant_entry["tool_calls"][0]["name"], "scene_list")
      self.assertEqual(tool_entry["role"], "tool")
      self.assertEqual(tool_entry["tool_call_id"], "call-1")
      self.assertIn("Scene One", tool_entry["content"])

      self.assertEqual(result["assistant_message"]["content"], "You have one scene: Scene One.")
      self.assertEqual(len(result["tool_messages"]), 1)
      self.assertEqual(result["pending_tool_calls"], [])
      roles = [row["role"] for row in list_chat_messages(paths, thread_id=thread["id"])]
      self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])

  def test_pending_write_execution_snapshots_and_turn_diff(self) -> None:
    with tempfile.TemporaryDirectory() as tmp:
      root = Path(tmp)
      paths = initialize_project(root, name="Turn Checkpoints")
      initialize_git(paths)
      add_scene(
        paths,
        title="Scene One",
        summary="Opening",
        pov="narrator",
        status="draft",
        body="Opening scene body.",
      )
      create_snapshot(paths, "initial state")
      thread = create_chat_thread(paths, title="Checkpoint Thread", provider="local", mode="agent")

      queued = _completion(
        "I will queue a codex entry for approval.",
        [
          {
            "id": "call-9",
            "name": "codex_add",
            "args": {"type": "character", "name": "Mira", "description": "Sky captain."},
          }
        ],
      )
      with patch("openauthor.chat.complete_chat", return_value=queued):
        result = send_chat_message(
          paths,
          thread_id=thread["id"],
          message="Add Mira to the codex.",
        )
      pending = result["pending_tool_calls"]
      self.assertEqual(len(pending), 1)
      self.assertEqual(pending[0]["tool"], "codex.add")
      self.assertEqual(pending[0]["classification"], "write")

      assistant_vcs = result["assistant_message"]["context_used"]["vcs"]
      self.assertNotEqual(assistant_vcs["base_commit"], "")

      executed = execute_pending_tool_call(
        paths,
        thread_id=thread["id"],
        assistant_message_id=result["assistant_message"]["id"],
        tool_index=0,
      )
      self.assertTrue(executed["vcs"]["changed"])
      self.assertNotIn("Snapshot failed", executed["vcs"]["snapshot"])
      self.assertNotEqual(
        executed["vcs"]["before_commit"],
        executed["vcs"]["after_commit"],
      )

      diff = get_chat_turn_diff(
        paths,
        thread_id=thread["id"],
        message_id=result["assistant_message"]["id"],
      )
      changed_paths = [item["path"] for item in diff["files"]]
      self.assertIn("codex/codex.json", changed_paths)


if __name__ == "__main__":
  unittest.main()
