import json, os, subprocess, sys
from pathlib import Path
out=Path(__file__).parent
name=sys.argv[1]
commands={"core":["make","test"],"desktop":["npm","run","test"],"build":["npm","run","build"]}
cwd=Path("~/Developer/openAuthor")
if name!="core": cwd=cwd/"desktop"
env=os.environ.copy()
for key in ["OPENAI_API_KEY","ANTHROPIC_API_KEY","OPENROUTER_API_KEY"]:env.pop(key,None)
env.update(VITE_PROJECT_REGISTRY="local",VITE_CLOUD_GATEWAY_URL="",VITE_SUPABASE_URL="",VITE_SUPABASE_ANON_KEY="")
with (out/(name+".txt")).open("w") as log:
 p=subprocess.run(commands[name],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({"check":name,"command":commands[name],"cwd":str(cwd),"exit_code":p.returncode,"log":str(out/(name+".txt"))}))
sys.exit(p.returncode)
