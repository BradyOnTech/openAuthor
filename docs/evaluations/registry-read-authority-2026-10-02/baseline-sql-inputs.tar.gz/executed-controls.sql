-- Actual authenticated table reads and own-state writes. Fixture grants model
-- configured Supabase table privileges and are rolled back with all test data.
begin;
create temporary table registry_controls(message text);
grant insert,select on registry_controls to authenticated,anon;
create function pg_temp.assert_true(p_condition boolean, p_message text)
returns void language plpgsql as $$ begin
  if p_condition is not true then raise exception 'assertion failed: %', p_message; end if;
  insert into pg_temp.registry_controls values(p_message);
end $$;
create function pg_temp.assert_error(p_sql text, p_state text, p_message text)
returns void language plpgsql as $$ begin
  begin execute p_sql;
  exception when others then
    if sqlstate = p_state then
      insert into pg_temp.registry_controls values(p_message);
      return;
    end if;
    raise exception 'wrong SQLSTATE %: % (%)', sqlstate, p_message, sqlerrm;
  end;
  raise exception 'assertion failed: %', p_message;
end $$;
create temporary table registry_authors(n integer primary key, user_id uuid, session_id uuid, device_id uuid);
insert into registry_authors select n,
  ('f1000000-0000-4000-8000-' || lpad(n::text,12,'0'))::uuid,
  ('f9000000-0000-4000-8000-' || lpad(n::text,12,'0'))::uuid,
  ('f4000000-0000-4000-8000-' || lpad(n::text,12,'0'))::uuid
from generate_series(1,5) n;
insert into auth.users(id) select user_id from registry_authors;
insert into auth.sessions(id,user_id) select session_id,user_id from registry_authors;
insert into public.workspaces(id,name,slug) values
  ('f2000000-0000-4000-8000-000000000001','Shared registry','registry-read-shared'),
  ('f2000000-0000-4000-8000-000000000002','Foreign registry','registry-read-foreign');
insert into public.workspace_members(workspace_id,user_id,role) select
  ('f2000000-0000-4000-8000-' || case when n=4 then '000000000002' else '000000000001' end)::uuid,
  user_id, (case when n in (1,4,5) then 'owner' when n=2 then 'editor' else 'viewer' end)::public.workspace_role
from registry_authors;
insert into public.projects(id,workspace_id,name,slug,created_by) values
  ('f3000000-0000-4000-8000-000000000001','f2000000-0000-4000-8000-000000000001','Shared book','shared','f1000000-0000-4000-8000-000000000001'),
  ('f3000000-0000-4000-8000-000000000002','f2000000-0000-4000-8000-000000000002','Foreign book','foreign','f1000000-0000-4000-8000-000000000004');
insert into public.project_activity(project_id,actor_user_id,event_type) values
  ('f3000000-0000-4000-8000-000000000001','f1000000-0000-4000-8000-000000000001','registry_read_fixture'),
  ('f3000000-0000-4000-8000-000000000002','f1000000-0000-4000-8000-000000000004','registry_read_fixture');
insert into public.workspace_user_state(workspace_id,user_id,active_project_id)
select 'f2000000-0000-4000-8000-000000000001',user_id,'f3000000-0000-4000-8000-000000000001'
from registry_authors where n in (1,2,3);
grant select on registry_authors to authenticated,anon;
grant select on public.workspaces,public.workspace_members,public.projects,public.project_activity,public.workspace_user_state to authenticated,anon;
grant insert,update,delete on public.workspace_user_state to authenticated,anon;
create function pg_temp.author(p_number integer)
returns void language sql as $$
  select set_config('request.jwt.claims',jsonb_build_object('sub',user_id,'session_id',session_id,'device_id',device_id)::text,true)
  from registry_authors where n=p_number
$$;
create function pg_temp.assert_shared_read(p_role text)
returns void language plpgsql as $$ begin
  perform pg_temp.assert_true((select count(*)=1 from public.workspaces),p_role || ' reads only its workspace');
  perform pg_temp.assert_true((select count(*)=4 from public.workspace_members),p_role || ' reads shared membership without recursion');
  perform pg_temp.assert_true((select count(*)=1 from public.projects),p_role || ' reads only its book');
  perform pg_temp.assert_true((select count(*)=1 from public.project_activity),p_role || ' reads only its activity');
  perform pg_temp.assert_true((select count(*)=1 from public.workspace_user_state),p_role || ' reads only its own state');
end $$;
create function pg_temp.assert_no_read(p_reason text)
returns void language plpgsql as $$ begin
  perform pg_temp.assert_true((select count(*)=0 from public.workspaces),p_reason || ' hides workspaces');
  perform pg_temp.assert_true((select count(*)=0 from public.workspace_members),p_reason || ' hides memberships');
  perform pg_temp.assert_true((select count(*)=0 from public.projects),p_reason || ' hides books');
  perform pg_temp.assert_true((select count(*)=0 from public.project_activity),p_reason || ' hides activity');
  perform pg_temp.assert_true((select count(*)=0 from public.workspace_user_state),p_reason || ' hides own state');
end $$;


create function pg_temp.observe(p_sql text) returns jsonb language plpgsql as $$
declare v_count bigint; begin
  execute p_sql into v_count;
  return jsonb_build_object('rows',v_count);
exception when others then
  return jsonb_build_object('sqlstate',sqlstate,'message',sqlerrm);
end $$;
set local role authenticated;
select pg_temp.author(1);
select jsonb_build_object('scope','live owner registry reads',
  'workspaces',pg_temp.observe('select count(*) from public.workspaces'),
  'memberships',pg_temp.observe('select count(*) from public.workspace_members'),
  'projects',pg_temp.observe('select count(*) from public.projects'),
  'activity',pg_temp.observe('select count(*) from public.project_activity'),
  'own_state',pg_temp.observe('select count(*) from public.workspace_user_state'));
reset role;
delete from auth.sessions where user_id='f1000000-0000-4000-8000-000000000001';
set local role authenticated;
select pg_temp.author(1);
select jsonb_build_object('scope','ended owner Auth session',
  'own_state',pg_temp.observe('select count(*) from public.workspace_user_state'));
rollback;
