"""Make a fresh synthetic book/portable backup using only installed core APIs."""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import openauthor
from openauthor.backups import create_backup
from openauthor.canon import add_canon_fact
from openauthor.codex import add_entity
from openauthor.git_ops import create_snapshot, initialize_git, run_git
from openauthor.planning import update_brief
from openauthor.project import initialize_project
from openauthor.revisions import create_revision, revision_head
from openauthor.scenes import add_scene, get_scene, update_scene
from openauthor.storylines import create_storyline

root = Path(__file__).resolve().parent
app = Path(sys.argv[1]).resolve()
runtime = app / "Contents/Resources/resources/runtime"
assert sys.flags.isolated and sys.dont_write_bytecode
assert Path(sys.executable).resolve() == (runtime / "python/bin/python3").resolve()
installed = Path(openauthor.__file__).resolve().parent
assert installed.is_relative_to((runtime / "python").resolve())
fingerprint = hashlib.sha256()
for source in sorted(installed.rglob("*.py")):
  fingerprint.update(source.relative_to(installed).as_posix().encode() + b"\0" + hashlib.sha256(source.read_bytes()).digest())
assert fingerprint.hexdigest() == "fa60a9dc36ab214668688177b3a93283008701ce38c9b7f6ae9a0146868a5f46"
book = root / "source-book"
assert not book.exists()
paths = initialize_project(book, name="Interrupted portable recovery acceptance")
for number in range(1, 65):
  body = "\n\n".join(
    f"Ledger {number:02d} line {line:03d}: Neri carried the blue token past marker "
    f"{hashlib.sha256(f'{number}/{line}'.encode()).hexdigest()[:12]}. Mara watched the eastern gate until dawn."
    for line in range(1, 141))
  add_scene(paths, title=f"Recovery ledger {number:02d}", body=body)
entity = add_entity(paths, kind="character", name="Neri", description="Carries the blue token through the eastern gate.")
add_canon_fact(paths, subject_entity_id=entity, predicate="token color", value="blue",
  evidence=[{"scene_id": "scene-0001", "excerpt": get_scene(paths, "scene-0001")["body"].split("\n\n")[0]}])
update_brief(paths, synopsis="A synthetic ledger book for process interruption acceptance.")
first_revision = create_revision(paths, "Original ledger book")
initialize_git(paths)
create_snapshot(paths, "Original portable history")
alternative = create_storyline(paths, name="Gate alternative", hypothesis="A distinct private acceptance branch")
original_first = get_scene(paths, "scene-0001")["body"]
for index in range(1, 129):
  update_scene(paths, scene_identifier="scene-0001", body=original_first + f"\n\nAcceptance revision {index:03d}: Ivo checked marker {hashlib.sha256(str(index).encode()).hexdigest()[:16]}.")
  create_revision(paths, f"Retained synthetic revision {index:03d}")
archive = root / "portable-recovery.openauthor.zip"
created = create_backup(paths, archive)
refs = run_git(paths, ["for-each-ref", "--format=%(refname) %(objectname)", "refs/heads"]).stdout.splitlines()
head = run_git(paths, ["symbolic-ref", "HEAD"]).stdout.strip()
files = {p.relative_to(book).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
  for p in sorted(book.rglob("*")) if p.is_file() and not p.is_symlink()}
result = {"captured_at": datetime.now(timezone.utc).isoformat(), "root": str(root), "app": str(app),
  "python": str(runtime / "python/bin/python3"), "python_sha256": hashlib.sha256((runtime / "python/bin/python3").read_bytes()).hexdigest(),
  "core_source_sha256": fingerprint.hexdigest(), "book": str(book), "archive": str(archive),
  "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "archive_bytes": archive.stat().st_size,
  "scene_count": 64, "revision_count": len(list(paths.revision_records_dir.glob("*.json"))),
  "first_revision": first_revision, "latest_revision": revision_head(paths), "storyline": alternative,
  "git_refs": refs, "git_head": head, "original_book_sha256": files, "backup_created": created,
  "provider_calls": 0, "fixture_kind": "Fresh synthetic book, genuine packaged APIs and portable backup"}
(root / "preparation/manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("root", "scene_count", "revision_count", "archive_bytes", "archive_sha256", "core_source_sha256")}))
