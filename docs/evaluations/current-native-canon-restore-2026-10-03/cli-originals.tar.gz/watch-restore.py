"""Observe partial extraction, then stop only an exact owned restore worker.

No installed-core imports, lock acquisition, recovery reads, or debug hooks.
Success deliberately leaves the worker stopped for the owner to inspect/kill.
"""
import argparse
import ctypes
import hashlib
import json
import os
import shutil
import signal
import struct
import subprocess
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--owner-pid', type=int, required=True)
parser.add_argument('--app', required=True)
parser.add_argument('--target', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--timeout', type=float, default=55)
parser.add_argument('--mechanics-trial', action='store_true')
parser.add_argument('--owner-executable')
args = parser.parse_args()
assert args.owner_pid > 1 and 0 < args.timeout <= 60
root = Path(__file__).resolve().parent
assert root.name.startswith('openauthor-current-backup-interruption-') and root.parent == Path('/private/tmp')
manifest = json.loads((root/'preparation/manifest.json').read_text())
app = Path(args.app).resolve()
allowed_apps = {
  Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/normal-36a4058.app'),
  Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app'),
}
assert app in allowed_apps
runtime = app/'Contents/Resources/resources/runtime'
python = (runtime/'python/bin/python3').resolve()
target = Path(args.target).resolve()
assert target.is_relative_to(root) and target.parent == root
assert target.name.startswith('recovered-') and not target.is_symlink()
archive = Path(manifest['archive']).resolve()
cwd_expected = str(Path(args.cwd).resolve())
output = Path(args.output).resolve()
assert output.is_relative_to(root) and output.parent == root and not output.exists()
output.mkdir()
if args.mechanics_trial:
  assert args.owner_executable
  owner_expected = str(Path(args.owner_executable).resolve())
else:
  assert app.name == 'acceptance-36a4058.app' and not args.owner_executable
  owner_expected = str((app/'Contents/MacOS/openauthor-desktop').resolve())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(python) == manifest['python_sha256']
assert sha(archive) == manifest['archive_sha256']
installed = runtime/'python/lib/python3.11/site-packages/openauthor'
fingerprint = hashlib.sha256()
for p in sorted(installed.rglob('*.py')):
  fingerprint.update(p.relative_to(installed).as_posix().encode()+b'\0'+hashlib.sha256(p.read_bytes()).digest())
assert fingerprint.hexdigest() == manifest['core_source_sha256']
with zipfile.ZipFile(archive) as zipped:
  expected_files = json.loads(zipped.read('openauthor-backup.json'))['files']
assert not target.exists() or (target.is_dir() and not any(target.iterdir()))
target_initially_exists = target.exists()
existing_stages = {p.resolve() for p in root.glob('openauthor-recovery-*') if p.is_dir()}

libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int
def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0: raise ProcessLookupError(pid)
  return str(Path(os.fsdecode(buffer.value)).resolve())
def argv(pid):
  mib = (ctypes.c_int*3)(1,49,pid)
  capacity = ctypes.c_size_t(1024*1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib,3,buffer,ctypes.byref(capacity),None,0): raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i',raw)[0]
  assert 0<count<500
  cursor=raw.find(b'\0',4)
  while cursor<len(raw) and raw[cursor]==0: cursor+=1
  values=[]
  for _ in range(count):
    end=raw.find(b'\0',cursor)
    assert end>=0
    values.append(os.fsdecode(raw[cursor:end]));cursor=end+1
  return values
def details(pid):
  result=subprocess.run(['/bin/ps','-p',str(pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  if result.returncode or not result.stdout.strip(): raise ProcessLookupError(pid)
  parts=result.stdout.strip().split()
  return {'pid':pid,'ppid':int(parts[0]),'start':' '.join(parts[1:-1]),'state':parts[-1],'executable':executable(pid),'argv':argv(pid)}
def cwd(pid):
  result=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,timeout=3)
  paths=[line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  assert result.returncode==0 and len(paths)==1
  return str(Path(paths[0]).resolve())
def owned(row):
  if row['ppid']!=args.owner_pid or row['executable']!=str(python): return False
  values=row['argv']
  if not values or str(Path(values[0]).resolve())!=str(python): return False
  tail=values[1:]
  if tail and tail[0]=='-I': tail=tail[1:]
  if tail and tail[0]=='-B': tail=tail[1:]
  return tail==['-m','openauthor','backup','restore','--source',str(archive),'--target',str(target),'--json']
def target_unpublished():
  return (target.exists()==target_initially_exists) and (not target.exists() or (target.is_dir() and not any(target.iterdir())))
def partial(stage):
  project=stage/'project'
  if not project.is_dir() or not target_unpublished(): return None
  records={p.relative_to(project).as_posix():sha(p) for p in project.rglob('*') if p.is_file() and not p.is_symlink()}
  complete=[name for name,value in records.items() if expected_files.get(name)==value]
  missing=[name for name in expected_files if name not in records]
  incomplete=[name for name,value in records.items() if name in expected_files and expected_files[name]!=value]
  if not complete or not (missing or incomplete): return None
  return {'staged_file_sha256':records,'complete_archived_files':complete,'missing_archived_files':missing,'incomplete_archived_files':incomplete}

owner=details(args.owner_pid)
assert owner['executable']==owner_expected
started=time.monotonic();deadline=started+args.timeout
events=[];candidate=None;stopped=False
def finish(value):
  value.update({'scope':'Actual packaged CLI mechanics trial' if args.mechanics_trial else 'Unmodified native GUI-spawned packaged backup restore observer',
    'manifest':str(root/'preparation/manifest.json'),'owner':owner,'app':str(app),'source':str(archive),'target':str(target),
    'cwd':cwd_expected,'core_source_sha256':fingerprint.hexdigest(),'target_initially_exists':target_initially_exists,
    'provider_calls':0,'normal_core_calls_during_observation':0,'production_hooks_or_monkeypatches':False,
    'timeout_seconds':args.timeout,'elapsed_seconds':time.monotonic()-started,'completed_at':datetime.now(timezone.utc).isoformat(),'events':events})
  (output/'result.json').write_text(json.dumps(value,indent=2)+'\n')
  sealed={p.relative_to(output).as_posix():sha(p) for p in sorted(output.rglob('*')) if p.is_file() and p.name!='evidence-sha256.json'}
  (output/'evidence-sha256.json').write_text(json.dumps(sealed,indent=2)+'\n')
  print(json.dumps({'result':value['result'],'worker_pid':value.get('worker',{}).get('pid'),'worker_left_stopped':value.get('worker_left_stopped',False),'evidence':str(output)}),flush=True)
print(json.dumps({'status':'armed','owner_pid':args.owner_pid,'source':str(archive),'target':str(target),'timeout_seconds':args.timeout}),flush=True)
try:
  while time.monotonic()<deadline:
    if candidate is None:
      now=details(args.owner_pid)
      assert now['executable']==owner['executable'] and now['start']==owner['start']
      listing=subprocess.run(['/bin/ps','-axo','pid=,ppid='],capture_output=True,text=True,timeout=2)
      assert listing.returncode==0
      children=[int(line.split()[0]) for line in listing.stdout.splitlines() if len(line.split())==2 and int(line.split()[1])==args.owner_pid]
      for pid in children:
        try:
          row=details(pid)
          if owned(row) and cwd(pid)==cwd_expected:
            candidate=row;events.append({'event':'exact_owned_restore_worker_found','worker':row,'cwd':cwd_expected});break
        except ProcessLookupError: pass
      if candidate is None:
        time.sleep(.002);continue
    for stage in root.glob('openauthor-recovery-*'):
      if not stage.is_dir() or stage.resolve() in existing_stages: continue
      try:
        observed=partial(stage)
      except (FileNotFoundError,NotADirectoryError): continue
      if observed is None: continue
      row=details(candidate['pid'])
      assert owned(row) and row['start']==candidate['start']
      os.kill(row['pid'],signal.SIGSTOP);stopped=True
      for _ in range(30):
        settled=details(row['pid'])
        if 'T' in settled['state']: break
        time.sleep(.002)
      else: raise RuntimeError('Exact restore worker did not stop')
      settled_observation=partial(stage)
      if settled_observation is None:
        os.kill(row['pid'],signal.SIGCONT);stopped=False
        finish({'result':'missed_timing_window','worker':settled,'worker_left_stopped':False,'reason':'Extraction completed/published before the stopped observation settled'})
        raise SystemExit(2)
      assert sha(stage/'source.zip')==manifest['archive_sha256']
      shutil.copytree(stage/'project',output/'raw-project')
      copied={p.relative_to(output/'raw-project').as_posix():sha(p) for p in (output/'raw-project').rglob('*') if p.is_file()}
      assert copied==settled_observation['staged_file_sha256']
      assert partial(stage)==settled_observation
      assert sha(archive)==manifest['archive_sha256']
      finish({'result':'captured_partial_restore','worker':settled,'worker_left_stopped':True,'stage':str(stage),
        **settled_observation,'backup_sha256':manifest['archive_sha256'],'private_source_copy_sha256':sha(stage/'source.zip'),
        'destination_unpublished':target_unpublished(),'raw_snapshot_stable':True})
      raise SystemExit(0)
    try: details(candidate['pid'])
    except ProcessLookupError:
      finish({'result':'missed_timing_window','worker':candidate,'worker_left_stopped':False,'reason':'Exact restore worker exited before partial extraction could be stopped'})
      raise SystemExit(2)
    time.sleep(.001)
  finish({'result':'timed_out','worker_left_stopped':stopped})
  raise SystemExit(3)
except BaseException:
  if stopped:
    # Success intentionally stays stopped; every exceptional exit resumes its
    # own verified worker so a harness error cannot strand application work.
    if not (output/'result.json').exists() or json.loads((output/'result.json').read_text()).get('result')!='captured_partial_restore':
      try:
        now=details(candidate['pid'])
        if owned(now) and now['start']==candidate['start']: os.kill(now['pid'],signal.SIGCONT)
      except ProcessLookupError: pass
  raise
