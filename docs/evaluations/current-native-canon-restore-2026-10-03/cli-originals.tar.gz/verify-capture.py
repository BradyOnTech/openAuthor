"""Validate retained partial-extraction evidence; this does not replay a crash."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
output=Path(sys.argv[1]).resolve()
assert output.parent==root and not output.is_symlink()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
sealed=json.loads((output/'evidence-sha256.json').read_text())
for name,value in sealed.items():
  path=output/name
  assert path.resolve().is_relative_to(output) and sha(path)==value,name
result=json.loads((output/'result.json').read_text())
manifest=json.loads((root/'preparation/manifest.json').read_text())
archive=Path(manifest['archive'])
assert sha(archive)==manifest['archive_sha256']==result['backup_sha256']==result['private_source_copy_sha256']
with zipfile.ZipFile(archive) as zipped:
  expected=json.loads(zipped.read('openauthor-backup.json'))['files']
actual={p.relative_to(output/'raw-project').as_posix():sha(p) for p in (output/'raw-project').rglob('*') if p.is_file()}
assert actual==result['staged_file_sha256']
complete=[name for name,value in actual.items() if expected.get(name)==value]
missing=[name for name in expected if name not in actual]
incomplete=[name for name,value in actual.items() if name in expected and expected[name]!=value]
assert sorted(complete)==sorted(result['complete_archived_files'])
assert sorted(missing)==sorted(result['missing_archived_files'])
assert sorted(incomplete)==sorted(result['incomplete_archived_files'])
assert complete and (missing or incomplete)
assert result['result']=='captured_partial_restore' and result['destination_unpublished'] and result['raw_snapshot_stable']
assert result['worker_left_stopped'] and 'T' in result['worker']['state']
assert result['worker']['ppid']==result['owner']['pid']
assert result['core_source_sha256']==manifest['core_source_sha256']
assert not result['production_hooks_or_monkeypatches'] and result['normal_core_calls_during_observation']==0
print(json.dumps({'retained_capture_integrity':'passed','sealed_files':len(sealed),'complete_archived_files':len(complete),
  'missing_archived_files':len(missing),'incomplete_archived_files':len(incomplete),
  'historical_destination_unpublished_receipt':True,'current_target_absence_or_live_process_claimed':False,
  'crash_replayed_by_verifier':False,'scope':result['scope']}))
