"""Check a completed packaged restore against genuine archived bytes/history."""
import hashlib
import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import openauthor
from openauthor.git_ops import run_git
from openauthor.hardening import collect_startup_health
from openauthor.project import resolve_project
from openauthor.revisions import verify_revision_store
from openauthor.storylines import list_storylines

root=Path(__file__).resolve().parent
app=Path(sys.argv[1]).resolve()
target=Path(sys.argv[2]).resolve()
output=Path(sys.argv[3]).resolve()
assert sys.flags.isolated and sys.dont_write_bytecode
assert target.parent==root and target.name.startswith('recovered-') and output.parent==root and not output.exists()
installed=Path(openauthor.__file__).resolve().parent
assert installed.is_relative_to(app/'Contents/Resources/resources/runtime/python')
manifest=json.loads((root/'preparation/manifest.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
archive=Path(manifest['archive'])
assert sha(archive)==manifest['archive_sha256']
with zipfile.ZipFile(archive) as zipped:
  expected=json.loads(zipped.read('openauthor-backup.json'))['files']
  assert all(sha(target/name)==value for name,value in expected.items() if name!='storylines.bundle')
assert not (target/'storylines.bundle').exists()
paths=resolve_project(target)
health=collect_startup_health(paths)
assert health['ready'],health
revisions=verify_revision_store(paths)
assert revisions['ready'],revisions
refs=run_git(paths,['for-each-ref','--format=%(refname) %(objectname)','refs/heads']).stdout.splitlines()
head=run_git(paths,['symbolic-ref','HEAD']).stdout.strip()
assert refs==manifest['git_refs'] and head==manifest['git_head']
storylines=list_storylines(paths)
assert all(row['branch_available'] for row in storylines['storylines'])
assert all(sha(target/name)==value for name,value in expected.items() if name!='storylines.bundle')
source=Path(manifest['book'])
current={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*')) if p.is_file() and not p.is_symlink()}
assert current==manifest['original_book_sha256']
record={'captured_at':datetime.now(timezone.utc).isoformat(),'target':str(target),'archive':str(archive),
  'archive_sha256':sha(archive),'all_archived_project_files_byte_exact':True,'archived_file_count':len(expected),
  'published_project_file_count':len(expected)-1,'storyline_bundle_consumed_and_removed':True,
  'source_book_file_count_unchanged':len(current),'source_book_whole_files_unchanged':True,
  'startup_health':health,'revision_health':revisions,'git_refs':refs,'git_head':head,'storylines':storylines,
  'installed_core':str(installed),'provider_calls':0,'scope':'Packaged CLI restore exact files/history; GUI attachment not assessed'}
output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'target':str(target),'archived_project_files_exact':len(expected)-1,'source_book_unchanged_files':len(current),'revision_health_ready':revisions['ready'],'git_refs_exact':True}))
