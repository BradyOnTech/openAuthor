"""Stop a genuine packaged CLI mid-extraction, kill it, retry untouched backup."""
import hashlib
import json
import os
import select
import signal
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root=Path(__file__).resolve().parent
app=Path(sys.argv[1]).resolve()
assert sys.flags.isolated and sys.dont_write_bytecode
manifest=json.loads((root/'preparation/manifest.json').read_text())
archive=Path(manifest['archive'])
target=root/'recovered-cli'
output=root/'cli-observation'
assert not target.exists() and not output.exists()
watch_command=[sys.executable,'-I','-B',str(root/'watch-restore.py'),'--owner-pid',str(os.getpid()),
  '--app',str(app),'--target',str(target),'--cwd',str(root/'working'),'--output',str(output),
  '--timeout','55','--mechanics-trial','--owner-executable',str(Path(sys.executable).resolve())]
watch=subprocess.Popen(watch_command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
worker=None
try:
  ready,_,_=select.select([watch.stdout],[],[],10)
  assert ready,'Restore observer did not arm'
  armed=watch.stdout.readline()
  assert json.loads(armed)['status']=='armed',armed
  command=[sys.executable,'-I','-B','-m','openauthor','backup','restore','--source',str(archive),'--target',str(target),'--json']
  worker=subprocess.Popen(command,cwd=root/'working',stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  print(json.dumps({'worker_pid':worker.pid,'observer_pid':watch.pid,'target':str(target)}),flush=True)
  try:
    watcher_stdout,watcher_stderr=watch.communicate(timeout=60)
  except subprocess.TimeoutExpired:
    watch.kill();watcher_stdout,watcher_stderr=watch.communicate(timeout=5)
    raise RuntimeError('Restore observer exceeded its bounded deadline')
  (root/'cli-observer.stdout.txt').write_text(armed+watcher_stdout)
  (root/'cli-observer.stderr.txt').write_text(watcher_stderr)
  assert watch.returncode==0,(watch.returncode,watcher_stderr)
  captured=json.loads((output/'result.json').read_text())
  assert captured['result']=='captured_partial_restore' and captured['worker_left_stopped']
  assert captured['worker']['pid']==worker.pid and worker.poll() is None
  check=subprocess.run(['/bin/ps','-p',str(worker.pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  parts=check.stdout.strip().split()
  assert check.returncode==0 and int(parts[0])==os.getpid() and ' '.join(parts[1:-1])==captured['worker']['start'] and 'T' in parts[-1]
  assert not target.exists()
  worker.kill()
  stdout,stderr=worker.communicate(timeout=10)
  assert worker.returncode==-signal.SIGKILL
  (root/'interrupted-cli.stdout.txt').write_text(stdout)
  (root/'interrupted-cli.stderr.txt').write_text(stderr)
  stage=Path(captured['stage'])
  def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
  original_stage={p.relative_to(stage/'project').as_posix():sha(p) for p in (stage/'project').rglob('*') if p.is_file()}
  assert original_stage==captured['staged_file_sha256'] and sha(archive)==manifest['archive_sha256'] and not target.exists()
  retry=subprocess.run(command,cwd=root/'working',capture_output=True,text=True,timeout=90)
  (root/'retry-cli.stdout.txt').write_text(retry.stdout)
  (root/'retry-cli.stderr.txt').write_text(retry.stderr)
  assert retry.returncode==0,retry.stderr
  assert json.loads(retry.stdout)['restored']
  unchanged_stage={p.relative_to(stage/'project').as_posix():sha(p) for p in (stage/'project').rglob('*') if p.is_file()}
  assert unchanged_stage==original_stage
  verified=subprocess.run([sys.executable,'-I','-B',str(root/'verify.py'),str(app),str(target),str(root/'cli-restore-validation.json')],cwd=root/'working',capture_output=True,text=True,timeout=60)
  (root/'cli-restore-validation.stdout.txt').write_text(verified.stdout)
  (root/'cli-restore-validation.stderr.txt').write_text(verified.stderr)
  assert verified.returncode==0,verified.stderr
  result={'completed_at':datetime.now(timezone.utc).isoformat(),'command':command,'observer_command':watch_command,
    'worker_pid':worker.pid,'worker_exit_code':worker.returncode,'observer_exit_code':watch.returncode,
    'captured_partial_file_count':len(original_stage),'captured_complete_file_count':len(captured['complete_archived_files']),
    'captured_missing_file_count':len(captured['missing_archived_files']),
    'destination_absent_before_and_after_kill':True,'killed_partial_stage_retained':str(stage),
    'partial_stage_not_reused_or_changed_by_retry':True,'retry_exit_code':retry.returncode,
    'validation_exit_code':verified.returncode,'source_book_and_backup_unchanged':True,
    'gui_attachment_assessed':False,'hooks_or_monkeypatches':False,'provider_calls':0,'all_owned_workers_terminal':True}
  (root/'cli-trial-result.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result))
finally:
  if watch.poll() is None:
    watch.kill();watch.communicate(timeout=5)
  if worker is not None and worker.poll() is None:
    worker.kill();worker.communicate(timeout=10)
