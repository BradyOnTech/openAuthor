import datetime,hashlib,json,os
from pathlib import Path
import openauthor
from openauthor.project import get_project_paths
from openauthor.canon import list_canon_facts
from openauthor.storylines import create_storyline
from openauthor.git_ops import current_branch
root=Path('/private/tmp/openauthor-current-canon-root-8fponqmo')
book=root/'book'; package=Path(openauthor.__file__).resolve().parent
assert package==Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app/Contents/Resources/resources/runtime/python/lib/python3.11/site-packages/openauthor')
manifest=json.loads((root/'preparation/manifest.json').read_text())
modules={p.relative_to(package).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*.py')}
assert modules==manifest['module_sha256']
os.environ.update(OPENAUTHOR_GIT_BIN='/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app/Contents/Resources/resources/runtime/git/bin/git',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_AUTHOR_NAME='Acceptance Fixture',GIT_AUTHOR_EMAIL='acceptance@example.invalid',GIT_COMMITTER_NAME='Acceptance Fixture',GIT_COMMITTER_EMAIL='acceptance@example.invalid')
for key in ('OPENAI_API_KEY','ANTHROPIC_API_KEY'): os.environ.pop(key,None)
paths=get_project_paths(book); before_facts=list_canon_facts(paths,for_editing=True)
old=next(x for x in before_facts if x['id']==manifest['accepted_fact_id'])
assert old['edit_version']==next(x for x in manifest['facts'] if x['id']==old['id'])['edit_version']
before={name:(book/name).read_bytes() for name in manifest['baseline_sha256']}
branch_before=current_branch(paths)
row=create_storyline(paths,name='Native evidence authority',hypothesis='Exercise an external Storyline change while an original evidence correction remains open.')
after_facts=list_canon_facts(paths,for_editing=True); new=next(x for x in after_facts if x['id']==old['id'])
assert new['updated_at']==old['updated_at'] and new['edit_version']!=old['edit_version']
checks={name:(book/name).read_bytes()==data for name,data in before.items()}
assert checks['codex/memory.json']
assert all(v for k,v in checks.items() if k.startswith('manuscript/'))
for phase,files in [('before-switch',before),('after-switch',{k:(book/k).read_bytes() for k in before})]:
  for name,data in files.items():
    dest=root/'native-run'/phase/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Genuine current packaged create_storyline with switch; no direct metadata editing or provider calls','book':str(book),'branch_before':branch_before,'branch_after':current_branch(paths),'storyline':row,'facts_before':before_facts,'facts_after':after_facts,'fact_timestamp_unchanged':True,'original_edit_version_invalidated':True,'baseline_bytes_unchanged':checks,'provider_calls':0}
(root/'native-run/storyline-switch.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'branch_after':r['branch_after'],'fact_timestamp_unchanged':True,'original_edit_version_invalidated':True,'baseline_bytes_unchanged':checks}))
