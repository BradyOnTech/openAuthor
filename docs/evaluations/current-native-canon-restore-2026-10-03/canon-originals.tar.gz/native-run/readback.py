import argparse,datetime,hashlib,json,os
from pathlib import Path
import openauthor
from openauthor.project import get_project_paths
from openauthor.canon import list_canon_facts
from openauthor.git_ops import current_branch
parser=argparse.ArgumentParser();parser.add_argument('phase');args=parser.parse_args()
root=Path('/private/tmp/openauthor-current-canon-root-8fponqmo');manifest=json.loads((root/'preparation/manifest.json').read_text());book=Path(manifest['book']);package=Path(openauthor.__file__).resolve().parent
assert package==Path(manifest['installed_package'])
assert {p.relative_to(package).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*.py')}==manifest['module_sha256']
os.environ.update(OPENAUTHOR_GIT_BIN='/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app/Contents/Resources/resources/runtime/git/bin/git',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
paths=get_project_paths(book);facts=list_canon_facts(paths,for_editing=True)
dest=root/'native-run'/args.phase;dest.mkdir()
sha={}
for name in manifest['baseline_sha256']:
  data=(book/name).read_bytes();p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);sha[name]=hashlib.sha256(data).hexdigest()
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'book':str(book),'branch':current_branch(paths),'facts':facts,'sha256':sha,'installed_package':str(package),'core_sha256':manifest['core_sha256']}
(dest/'readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'phase':args.phase,'branch':r['branch'],'facts':facts}))
