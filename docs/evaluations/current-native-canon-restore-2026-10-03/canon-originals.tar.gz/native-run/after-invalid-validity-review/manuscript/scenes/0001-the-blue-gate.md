---
id: scene-0001
title: The blue gate
summary: 
pov: 
status: draft
created_at: 2026-10-03T05:04:28.160695+00:00
updated_at: 2026-10-03T05:04:28.160695+00:00
---

The gate was blue. Mara saw the blue gate before the mist rose.
