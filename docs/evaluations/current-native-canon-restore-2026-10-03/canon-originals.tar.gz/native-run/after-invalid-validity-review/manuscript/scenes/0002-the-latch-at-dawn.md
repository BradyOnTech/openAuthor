---
id: scene-0002
title: The latch at dawn
summary: 
pov: 
status: draft
created_at: 2026-10-03T05:04:28.161051+00:00
updated_at: 2026-10-03T05:04:28.161051+00:00
---

The gate was blue at dawn. Ivo watched the brass latch before the bell.
