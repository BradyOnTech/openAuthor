"""Read-only correlation of retained native Canon/restore receipts."""
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

out=Path(__file__).resolve().parent
canon=Path('/private/tmp/openauthor-current-canon-root-8fponqmo')
backup=Path('/private/tmp/openauthor-current-backup-interruption-4g079g__')
packaged=Path('/private/tmp/openauthor-current-packaged-core-368mvc0y')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
manifest=read(canon/'preparation/manifest.json')
observed_files=[p for folder in [canon/'preparation',canon/'native-run'] for p in folder.rglob('*') if p.is_file()]
observed={p.relative_to(canon).as_posix():sha(p) for p in sorted(observed_files)}
names=list(manifest['baseline_sha256'])
stages=['preparation/baseline','native-run/before-switch','native-run/after-switch','native-run/after-refused-review',
  'native-run/before-successful-review','native-run/after-successful-review','native-run/after-invalid-validity-review']
captures={stage:{name:sha(canon/stage/name) for name in names} for stage in stages}
assert captures['preparation/baseline']==manifest['baseline_sha256']
initial_plan=read(canon/'preparation/baseline/manuscript/structure.json')
opened_plan=read(canon/'native-run/before-switch/manuscript/structure.json')
assert initial_plan['unassigned_scene_ids']==[] and opened_plan['unassigned_scene_ids']==['scene-0001','scene-0002']
assert {k:v for k,v in initial_plan.items() if k!='unassigned_scene_ids'}=={k:v for k,v in opened_plan.items() if k!='unassigned_scene_ids'}
initial_changes=[name for name in names if captures['preparation/baseline'][name]!=captures['native-run/before-switch'][name]]
assert initial_changes==['manuscript/structure.json']
assert captures['native-run/before-switch']==captures['native-run/after-switch']==captures['native-run/after-refused-review']==captures['native-run/before-successful-review']
assert captures['native-run/after-successful-review']==captures['native-run/after-invalid-validity-review']
changed_by_success=[name for name in names if captures['native-run/before-successful-review'][name]!=captures['native-run/after-successful-review'][name]]
assert changed_by_success==['codex/memory.json']
assert all(captures[stage][name]==manifest['baseline_sha256'][name] for stage in stages for name in names if name.startswith('manuscript/scenes/'))

switch=read(canon/'native-run/storyline-switch.json')
assert switch['branch_before']=='master' and switch['branch_after']==switch['storyline']['branch'] and switch['branch_after']!='master'
assert all(switch['baseline_bytes_unchanged'].values())
before_scope={fact['id']:fact for fact in switch['facts_before']}
after_scope={fact['id']:fact for fact in switch['facts_after']}
assert before_scope.keys()==after_scope.keys()
for identifier in before_scope:
  left=before_scope[identifier];right=after_scope[identifier]
  assert left['updated_at']==right['updated_at'] and left['edit_version']!=right['edit_version']
  assert {k:v for k,v in left.items() if k!='edit_version'}=={k:v for k,v in right.items() if k!='edit_version'}
readbacks={stage:read(canon/'native-run'/stage/'readback.json') for stage in ['before-successful-review','after-successful-review','after-invalid-validity-review']}
for stage,record in readbacks.items():
  assert record['sha256']==captures[f'native-run/{stage}']
  assert record['branch']=='master' and record['core_sha256']==manifest['core_sha256'] and record['installed_package']==manifest['installed_package']
  stored=read(canon/'native-run'/stage/'codex/memory.json')['facts']
  assert stored==[{k:v for k,v in fact.items() if k!='edit_version'} for fact in record['facts']]
old=read(canon/'native-run/before-successful-review/codex/memory.json')
new=read(canon/'native-run/after-successful-review/codex/memory.json')
assert {k:v for k,v in old.items() if k!='facts'}=={k:v for k,v in new.items() if k!='facts'}
old_facts={fact['id']:fact for fact in old['facts']};new_facts={fact['id']:fact for fact in new['facts']}
accepted=manifest['accepted_fact_id'];suggested=manifest['suggested_fact_id']
assert old_facts[suggested]==new_facts[suggested]
changed_fact_fields=sorted(k for k in set(old_facts[accepted])|set(new_facts[accepted]) if old_facts[accepted].get(k)!=new_facts[accepted].get(k))
assert changed_fact_fields==['evidence','updated_at']
assert new_facts[accepted]['evidence']==[{'scene_id':'scene-0001','excerpt':'Mara saw the blue gate before the mist rose.','start':19,'end':63}]
for facts in [old_facts,new_facts]:
  for fact in facts.values():
    for evidence in fact['evidence']:
      assert manifest['prose'][evidence['scene_id']][evidence['start']:evidence['end']]==evidence['excerpt']
assert new_facts[suggested]['status']=='suggested' and new_facts[suggested]['validity']=={'from_scene_id':'scene-0002','to_scene_id':'scene-0001'}

refusal=read(canon/'native-run/native-refused-review.json')
success=read(canon/'native-run/native-successful-review.json')
invalid=read(canon/'native-run/native-invalid-validity-review.json')
assert refusal['draft_retained_after_refusal'] and all(refusal['compared_to_fresh_post_open_after_switch_baseline'].values())
assert 'Storyline changed' in refusal['refusal']
assert refusal['dirty_draft']==success['draft_recovered_exactly']==new_facts[accepted]['evidence'][0]['excerpt']
assert success['gui_status']=='Saved' and success['other_fact_unchanged'] and all(success['all_other_captured_book_files_unchanged'].values())
after_edit={fact['id']:fact for fact in readbacks['after-successful-review']['facts']}
assert success['new_fact_version']==after_edit[accepted]['edit_version'] and success['new_updated_at']==after_edit[accepted]['updated_at']
assert invalid['pending_fact_status']=='suggested' and invalid['both_facts_unchanged'] and invalid['all_five_captured_book_files_unchanged']
assert invalid['refusal'].endswith('The fact cannot stop being true before it begins.')
assert invalid['label']=='Needs author review · excluded from accepted Canon checks'

installed=Path(manifest['installed_package'])
module_hashes={p.relative_to(installed).as_posix():sha(p) for p in installed.rglob('*.py')}
assert module_hashes==manifest['module_sha256']
fingerprint=hashlib.sha256()
for name,value in sorted(module_hashes.items()): fingerprint.update(name.encode()+b'\0'+bytes.fromhex(value))
assert fingerprint.hexdigest()==manifest['core_sha256']
launch=read(canon/'native-run/launched-process.json')
assert sha(Path(launch['executable']))==launch['sha256']=='195c81233806fda9fc3f68d6d162af3f7c294357e88f352200ef218ccf31946f'
assert refusal['qa_pid']==launch['pid']==41441
failed=read(canon/'native-run/switch-storyline-import-setup-failure.json')
assert sha(canon/'native-run/switch-storyline-import-setup-failure.py')==failed['original_script_sha256']
assert failed['product_failure'] is False

existing_seals={}
for path in [packaged/'evidence-sha256.json',backup/'cli-evidence-sha256.json']:
  seal=read(path)
  files=seal['files']
  assert all(sha(path.parent/name)==value for name,value in files.items())
  existing_seals[str(path)]={'files_verified':len(files),'seal_sha256':sha(path)}
gui=read(backup/'gui-observation/result.json')
gui_seal=read(backup/'gui-observation/evidence-sha256.json')
assert all(sha(backup/'gui-observation'/name)==value for name,value in gui_seal.items())
assert gui['scope'].startswith('Unmodified native GUI-spawned') and gui['owner']['pid']==launch['pid']
assert gui['destination_unpublished'] and gui['raw_snapshot_stable'] and gui['worker_left_stopped']
assert 'T' in gui['worker']['state'] and gui['worker']['ppid']==launch['pid']
assert gui['worker']['executable']==str(Path(gui['app'])/'Contents/Resources/resources/runtime/python/bin/python3')
assert gui['core_source_sha256']==manifest['core_sha256']
assert gui['backup_sha256']==gui['private_source_copy_sha256']==sha(Path(gui['source']))
assert len(gui['complete_archived_files'])==375 and len(gui['missing_archived_files'])==26 and len(gui['incomplete_archived_files'])==1

assert all(sha(canon/name)==value for name,value in observed.items())
(out/'canon-observed-sha256.json').write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),'root':str(canon),'files':observed},indent=2)+'\n')
with tarfile.open(out/'canon-observed-originals.tar.gz','w:gz') as archive:
  for name in observed: archive.add(canon/name,arcname=name,recursive=False)
assessment={'captured_at':datetime.now(timezone.utc).isoformat(),'verdict':'Retained receipts and raw snapshots are internally consistent; no material inconsistency found',
  'canon_input_file_count':len(observed),'captured_book_file_scope':names,'core_module_count':len(module_hashes),'core_source_sha256':fingerprint.hexdigest(),
  'plan_normalization':{'only_initial_changed_file':'manuscript/structure.json','only_changed_field':'unassigned_scene_ids','before':[],'after':['scene-0001','scene-0002'],'later_plan_byte_identical':True,'cause_scope':'Consistent with persist=True get_plan startup normalization; no runtime caller trace captured'},
  'refused_storyline_review':{'five_fresh_baseline_files_exact':True,'both_fact_timestamps_unchanged_across_switch':True,'both_edit_versions_invalidated':True,'dirty_draft_retention_scope':'Root manual CUA accessibility transcription, without an archived recovery-journal payload'},
  'successful_review':{'only_changed_file':'codex/memory.json','only_changed_fact':accepted,'changed_fields':changed_fact_fields,'exact_evidence_start':19,'exact_evidence_end':63,'suggested_fact_unchanged':True,'returned_master_supported_by_readback':True},
  'invalid_validity_review':{'all_five_files_exact_after_refusal':True,'both_facts_unchanged':True,'suggested_fact_remained_suggested':True,'exact_evidence_independently_valid':True,'interval_inverts_observed_plan_order':True},
  'gui_restore_capture':{'worker_pid':gui['worker']['pid'],'owner_pid':gui['owner']['pid'],'complete':375,'missing':26,'incomplete':1,'sealed_files':len(gui_seal),'scope':'Historical stopped partial-extraction capture only; kill/restart/retry are root-owned and not assessed here'},
  'existing_seals_verified':existing_seals,
  'provenance_limits':['Native Canon GUI text/draft/save status comes from root manual CUA AX/inline screenshot observations; no native screenshot file archive or automated GUI replay exists.',
    'Readback JSON records pin actual installed package and 64 module bytes, but omit interpreter executable/version and original command exit status. Add a separate original-invocation receipt only from existing authoritative tool history; do not rewrite the originals.',
    'Five captured files support the stated narrow book invariants; no all-history/all-project-files immutability claim for the Canon correction.',
    'Returning to master is proven by before/after readback state; the raw receipts do not independently record the exact GUI Storyline return action.',
    'Neither this receipt audit nor seal verification replays GUI behavior, interruption, VoiceOver, physical power loss, signing or release acceptance.'],
  'setup_failure':'Original helper ImportError was before book mutation; preserve original script/hash and classify as harness setup failure, not product failure.',
  'recommended_packet':'Separate canon and restore folders; retain raw original snapshots and setup failure losslessly, explicit manual observation JSON, process/core provenance, original ZIP and partial capture archives, killed/relaunched/retry receipts, exact-byte/history validation; one packet manifest and an integrity-only verifier. Reference the existing current-bundle/583-test packet rather than duplicating it.',
  'actions':'Read files only; wrote this independent private assessment/snapshot. No repo/receipt edits, core calls, process inspections/signals, UI or locks.'}
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
sealed={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='evidence-sha256.json'}
(out/'evidence-sha256.json').write_text(json.dumps({'files':sealed,'scope':'Independent retained-receipt correlation; no behavior replay'},indent=2)+'\n')
print(json.dumps({'verdict':assessment['verdict'],'canon_input_files':len(observed),'core_modules':len(module_hashes),'assessment':str(out/'assessment.json'),'private_files_sealed':len(sealed)}))
