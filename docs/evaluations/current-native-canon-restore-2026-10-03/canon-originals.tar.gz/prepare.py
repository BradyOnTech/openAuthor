import argparse, json, hashlib, os, datetime
from pathlib import Path
import openauthor
from openauthor.project import initialize_project
from openauthor.scenes import add_scene, get_scene
from openauthor.canon import add_canon_fact, list_canon_facts
from openauthor.git_ops import initialize_git, create_snapshot

parser=argparse.ArgumentParser()
parser.add_argument('--root',required=True)
parser.add_argument('--package',required=True)
parser.add_argument('--core-sha256',required=True)
args=parser.parse_args()
root=Path(args.root).resolve();package=Path(openauthor.__file__).resolve().parent
assert package==Path(args.package).resolve()
h=hashlib.sha256()
modules={}
for p in sorted(package.rglob('*.py')):
 relative=p.relative_to(package).as_posix();sha=hashlib.sha256(p.read_bytes()).digest()
 modules[relative]=sha.hex();h.update(relative.encode()+b'\0'+sha)
assert h.hexdigest()==args.core_sha256
book=root/'book';assert not book.exists()
os.environ.update(GIT_AUTHOR_NAME='Acceptance Fixture',GIT_AUTHOR_EMAIL='acceptance@example.invalid',GIT_COMMITTER_NAME='Acceptance Fixture',GIT_COMMITTER_EMAIL='acceptance@example.invalid',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
paths=initialize_project(book,name='Current Canon native acceptance')
add_scene(paths,title='The blue gate',body='The gate was blue. Mara saw the blue gate before the mist rose.')
add_scene(paths,title='The latch at dawn',body='The gate was blue at dawn. Ivo watched the brass latch before the bell.')
accepted=add_canon_fact(paths,subject_entity_id='',predicate='gate color',value='blue',evidence=[{'scene_id':'scene-0001','excerpt':'The gate was blue.'}],valid_from_scene_id='scene-0001',valid_to_scene_id='scene-0002')
suggested=add_canon_fact(paths,subject_entity_id='',predicate='latch material',value='brass',status='suggested',evidence=[{'scene_id':'scene-0002','excerpt':'Ivo watched the brass latch before the bell.'}],valid_from_scene_id='scene-0002',valid_to_scene_id='scene-0001')
initialize_git(paths);create_snapshot(paths,'Save synthetic Canon acceptance fixture')
facts=list_canon_facts(paths,for_editing=True)
prose={id:get_scene(paths,id)['body'] for id in ['scene-0001','scene-0002']}
sha256={name:hashlib.sha256((book/name).read_bytes()).hexdigest() for name in ['codex/memory.json','.openauthor/project.json','manuscript/structure.json',*[p.relative_to(book).as_posix() for p in (book/'manuscript/scenes').glob('*.md')]]}
preparation=root/'preparation';preparation.mkdir()
for name in sha256:
 p=preparation/'baseline'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((book/name).read_bytes())
record={'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'book':str(book),'method':'Genuine current packaged initialize/add_scene/add_canon_fact/Git snapshot; no model calls or direct metadata fabrication. Suggested inverted interval remains unaccepted by design.','installed_package':str(package),'core_sha256':h.hexdigest(),'module_sha256':modules,'facts':facts,'accepted_fact_id':accepted['id'],'suggested_fact_id':suggested['id'],'prose':prose,'baseline_sha256':sha256,'provider_calls':0,'author_quality_claimed':False}
(preparation/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'book':str(book),'accepted_fact_id':accepted['id'],'suggested_fact_id':suggested['id'],'core_sha256':h.hexdigest()}))
