---
id: scene-0011
title: Recovery ledger 11
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.158464+00:00
updated_at: 2026-10-03T12:14:52.158464+00:00
---

Ledger 11 line 001: Neri carried the blue token past marker 9a2885560a03. Mara watched the eastern gate until dawn.

Ledger 11 line 002: Neri carried the blue token past marker 6315eda1e4e8. Mara watched the eastern gate until dawn.

Ledger 11 line 003: Neri carried the blue token past marker 21c926feec30. Mara watched the eastern gate until dawn.

Ledger 11 line 004: Neri carried the blue token past marker 426064218d85. Mara watched the eastern gate until dawn.

Ledger 11 line 005: Neri carried the blue token past marker 90dc537c512a. Mara watched the eastern gate until dawn.

Ledger 11 line 006: Neri carried the blue token past marker 140dd1f22e07. Mara watched the eastern gate until dawn.

Ledger 11 line 007: Neri carried the blue token past marker 300d7e571fc1. Mara watched the eastern gate until dawn.

Ledger 11 line 008: Neri carried the blue token past marker cb5a3a1c0419. Mara watched the eastern gate until dawn.

Ledger 11 line 009: Neri carried the blue token past marker d74bfd86864f. Mara watched the eastern gate until dawn.

Ledger 11 line 010: Neri carried the blue token past marker fd692ae6fdd2. Mara watched the eastern gate until dawn.

Ledger 11 line 011: Neri carried the blue token past marker f391e17dfcff. Mara watched the eastern gate until dawn.

Ledger 11 line 012: Neri carried the blue token past marker 13f7b6ab3202. Mara watched the eastern gate until dawn.

Ledger 11 line 013: Neri carried the blue token past marker 5d6079977694. Mara watched the eastern gate until dawn.

Ledger 11 line 014: Neri carried the blue token past marker bb2bc7f7d40f. Mara watched the eastern gate until dawn.

Ledger 11 line 015: Neri carried the blue token past marker fbe2ab8bcc34. Mara watched the eastern gate until dawn.

Ledger 11 line 016: Neri carried the blue token past marker 3e29725408a4. Mara watched the eastern gate until dawn.

Ledger 11 line 017: Neri carried the blue token past marker 1d71fe6ad974. Mara watched the eastern gate until dawn.

Ledger 11 line 018: Neri carried the blue token past marker 240aba76e7b1. Mara watched the eastern gate until dawn.

Ledger 11 line 019: Neri carried the blue token past marker 1cf5c0a4fbec. Mara watched the eastern gate until dawn.

Ledger 11 line 020: Neri carried the blue token past marker 2d4382142361. Mara watched the eastern gate until dawn.

Ledger 11 line 021: Neri carried the blue token past marker 5b7d9af3ea4e. Mara watched the eastern gate until dawn.

Ledger 11 line 022: Neri carried the blue token past marker cb27cf12b237. Mara watched the eastern gate until dawn.

Ledger 11 line 023: Neri carried the blue token past marker 0efc32547f51. Mara watched the eastern gate until dawn.

Ledger 11 line 024: Neri carried the blue token past marker ec8f9811f61a. Mara watched the eastern gate until dawn.

Ledger 11 line 025: Neri carried the blue token past marker 7fa8127e9f3d. Mara watched the eastern gate until dawn.

Ledger 11 line 026: Neri carried the blue token past marker 679cf550f9d3. Mara watched the eastern gate until dawn.

Ledger 11 line 027: Neri carried the blue token past marker d6fd559895a2. Mara watched the eastern gate until dawn.

Ledger 11 line 028: Neri carried the blue token past marker 32fb17fba490. Mara watched the eastern gate until dawn.

Ledger 11 line 029: Neri carried the blue token past marker a4546eff6450. Mara watched the eastern gate until dawn.

Ledger 11 line 030: Neri carried the blue token past marker 5af62c959f74. Mara watched the eastern gate until dawn.

Ledger 11 line 031: Neri carried the blue token past marker c4e157e3480c. Mara watched the eastern gate until dawn.

Ledger 11 line 032: Neri carried the blue token past marker 2cdf39c779e5. Mara watched the eastern gate until dawn.

Ledger 11 line 033: Neri carried the blue token past marker 03b6a4afa7ce. Mara watched the eastern gate until dawn.

Ledger 11 line 034: Neri carried the blue token past marker 835e6f2f91f0. Mara watched the eastern gate until dawn.

Ledger 11 line 035: Neri carried the blue token past marker 306bc65a8fc2. Mara watched the eastern gate until dawn.

Ledger 11 line 036: Neri carried the blue token past marker 592093256a6e. Mara watched the eastern gate until dawn.

Ledger 11 line 037: Neri carried the blue token past marker 6e199a5e60c3. Mara watched the eastern gate until dawn.

Ledger 11 line 038: Neri carried the blue token past marker 56c8b48eedc9. Mara watched the eastern gate until dawn.

Ledger 11 line 039: Neri carried the blue token past marker efab8a925117. Mara watched the eastern gate until dawn.

Ledger 11 line 040: Neri carried the blue token past marker 553123329377. Mara watched the eastern gate until dawn.

Ledger 11 line 041: Neri carried the blue token past marker 557919c5ff41. Mara watched the eastern gate until dawn.

Ledger 11 line 042: Neri carried the blue token past marker a4dfbbf529ff. Mara watched the eastern gate until dawn.

Ledger 11 line 043: Neri carried the blue token past marker f7ee6e7603b0. Mara watched the eastern gate until dawn.

Ledger 11 line 044: Neri carried the blue token past marker 9f83113f6c01. Mara watched the eastern gate until dawn.

Ledger 11 line 045: Neri carried the blue token past marker dc4b83371853. Mara watched the eastern gate until dawn.

Ledger 11 line 046: Neri carried the blue token past marker 8b90c0262fb4. Mara watched the eastern gate until dawn.

Ledger 11 line 047: Neri carried the blue token past marker 45ded0653f35. Mara watched the eastern gate until dawn.

Ledger 11 line 048: Neri carried the blue token past marker 71ce220fb200. Mara watched the eastern gate until dawn.

Ledger 11 line 049: Neri carried the blue token past marker 63d5d21360ad. Mara watched the eastern gate until dawn.

Ledger 11 line 050: Neri carried the blue token past marker 7dedc615e389. Mara watched the eastern gate until dawn.

Ledger 11 line 051: Neri carried the blue token past marker 0b008cabca04. Mara watched the eastern gate until dawn.

Ledger 11 line 052: Neri carried the blue token past marker d4cc5f279139. Mara watched the eastern gate until dawn.

Ledger 11 line 053: Neri carried the blue token past marker 7cb39609f03f. Mara watched the eastern gate until dawn.

Ledger 11 line 054: Neri carried the blue token past marker 705b478ed30c. Mara watched the eastern gate until dawn.

Ledger 11 line 055: Neri carried the blue token past marker a6f6c0a7fbf2. Mara watched the eastern gate until dawn.

Ledger 11 line 056: Neri carried the blue token past marker 85a2124255ec. Mara watched the eastern gate until dawn.

Ledger 11 line 057: Neri carried the blue token past marker 3117101d7970. Mara watched the eastern gate until dawn.

Ledger 11 line 058: Neri carried the blue token past marker 5f27e48bb5e4. Mara watched the eastern gate until dawn.

Ledger 11 line 059: Neri carried the blue token past marker 0579d7353391. Mara watched the eastern gate until dawn.

Ledger 11 line 060: Neri carried the blue token past marker e1e6dc8f4d7e. Mara watched the eastern gate until dawn.

Ledger 11 line 061: Neri carried the blue token past marker b9226f4d3eb4. Mara watched the eastern gate until dawn.

Ledger 11 line 062: Neri carried the blue token past marker 8146cea037f4. Mara watched the eastern gate until dawn.

Ledger 11 line 063: Neri carried the blue token past marker 188e8c7eda27. Mara watched the eastern gate until dawn.

Ledger 11 line 064: Neri carried the blue token past marker 146c60b539e8. Mara watched the eastern gate until dawn.

Ledger 11 line 065: Neri carried the blue token past marker 15387d44693a. Mara watched the eastern gate until dawn.

Ledger 11 line 066: Neri carried the blue token past marker 5f9ec36f1cf2. Mara watched the eastern gate until dawn.

Ledger 11 line 067: Neri carried the blue token past marker 9bff3cce6284. Mara watched the eastern gate until dawn.

Ledger 11 line 068: Neri carried the blue token past marker 200587b7c8c3. Mara watched the eastern gate until dawn.

Ledger 11 line 069: Neri carried the blue token past marker 22392fe2c50f. Mara watched the eastern gate until dawn.

Ledger 11 line 070: Neri carried the blue token past marker 9efb2b49c35d. Mara watched the eastern gate until dawn.

Ledger 11 line 071: Neri carried the blue token past marker 8ca97b7cd024. Mara watched the eastern gate until dawn.

Ledger 11 line 072: Neri carried the blue token past marker 46077a35c61a. Mara watched the eastern gate until dawn.

Ledger 11 line 073: Neri carried the blue token past marker 27a55801870e. Mara watched the eastern gate until dawn.

Ledger 11 line 074: Neri carried the blue token past marker d802b6653dfa. Mara watched the eastern gate until dawn.

Ledger 11 line 075: Neri carried the blue token past marker dc19513e00a9. Mara watched the eastern gate until dawn.

Ledger 11 line 076: Neri carried the blue token past marker ba5cfaba0a06. Mara watched the eastern gate until dawn.

Ledger 11 line 077: Neri carried the blue token past marker 30917d6e323d. Mara watched the eastern gate until dawn.

Ledger 11 line 078: Neri carried the blue token past marker b6d0c2539848. Mara watched the eastern gate until dawn.

Ledger 11 line 079: Neri carried the blue token past marker 342a3c52b880. Mara watched the eastern gate until dawn.

Ledger 11 line 080: Neri carried the blue token past marker 29c471bd5e35. Mara watched the eastern gate until dawn.

Ledger 11 line 081: Neri carried the blue token past marker 739da7595826. Mara watched the eastern gate until dawn.

Ledger 11 line 082: Neri carried the blue token past marker c2524455f892. Mara watched the eastern gate until dawn.

Ledger 11 line 083: Neri carried the blue token past marker c32fae8dabba. Mara watched the eastern gate until dawn.

Ledger 11 line 084: Neri carried the blue token past marker 60ee5d9253d8. Mara watched the eastern gate until dawn.

Ledger 11 line 085: Neri carried the blue token past marker 2cca7759241c. Mara watched the eastern gate until dawn.

Ledger 11 line 086: Neri carried the blue token past marker 2f25ef71614c. Mara watched the eastern gate until dawn.

Ledger 11 line 087: Neri carried the blue token past marker f046c28a72c2. Mara watched the eastern gate until dawn.

Ledger 11 line 088: Neri carried the blue token past marker 8c1b65b03f75. Mara watched the eastern gate until dawn.

Ledger 11 line 089: Neri carried the blue token past marker 18edf3d15f8d. Mara watched the eastern gate until dawn.

Ledger 11 line 090: Neri carried the blue token past marker 6a7573e01e49. Mara watched the eastern gate until dawn.

Ledger 11 line 091: Neri carried the blue token past marker 5238bdd7bcb6. Mara watched the eastern gate until dawn.

Ledger 11 line 092: Neri carried the blue token past marker a17e892f931a. Mara watched the eastern gate until dawn.

Ledger 11 line 093: Neri carried the blue token past marker 174042a1a145. Mara watched the eastern gate until dawn.

Ledger 11 line 094: Neri carried the blue token past marker 8c29534f43bf. Mara watched the eastern gate until dawn.

Ledger 11 line 095: Neri carried the blue token past marker 29551cb54ad3. Mara watched the eastern gate until dawn.

Ledger 11 line 096: Neri carried the blue token past marker c44f7c2cbb27. Mara watched the eastern gate until dawn.

Ledger 11 line 097: Neri carried the blue token past marker 102866854c09. Mara watched the eastern gate until dawn.

Ledger 11 line 098: Neri carried the blue token past marker 9e2384b0f911. Mara watched the eastern gate until dawn.

Ledger 11 line 099: Neri carried the blue token past marker 5ade31085aea. Mara watched the eastern gate until dawn.

Ledger 11 line 100: Neri carried the blue token past marker 049e04b44205. Mara watched the eastern gate until dawn.

Ledger 11 line 101: Neri carried the blue token past marker 82a7411c84ea. Mara watched the eastern gate until dawn.

Ledger 11 line 102: Neri carried the blue token past marker 32267d869585. Mara watched the eastern gate until dawn.

Ledger 11 line 103: Neri carried the blue token past marker 95b9e2702372. Mara watched the eastern gate until dawn.

Ledger 11 line 104: Neri carried the blue token past marker 535a7a7d4521. Mara watched the eastern gate until dawn.

Ledger 11 line 105: Neri carried the blue token past marker 37b976942066. Mara watched the eastern gate until dawn.

Ledger 11 line 106: Neri carried the blue token past marker ea8903d55ca0. Mara watched the eastern gate until dawn.

Ledger 11 line 107: Neri carried the blue token past marker 58fd1cc0cd7c. Mara watched the eastern gate until dawn.

Ledger 11 line 108: Neri carried the blue token past marker 589abf3d26ca. Mara watched the eastern gate until dawn.

Ledger 11 line 109: Neri carried the blue token past marker 28fbe21bb1dd. Mara watched the eastern gate until dawn.

Ledger 11 line 110: Neri carried the blue token past marker a5edd52f3360. Mara watched the eastern gate until dawn.

Ledger 11 line 111: Neri carried the blue token past marker 14ed042e9d57. Mara watched the eastern gate until dawn.

Ledger 11 line 112: Neri carried the blue token past marker 17707e04c7bd. Mara watched the eastern gate until dawn.

Ledger 11 line 113: Neri carried the blue token past marker 426ddea0f060. Mara watched the eastern gate until dawn.

Ledger 11 line 114: Neri carried the blue token past marker 5b5393276216. Mara watched the eastern gate until dawn.

Ledger 11 line 115: Neri carried the blue token past marker c1ccb2ef98c1. Mara watched the eastern gate until dawn.

Ledger 11 line 116: Neri carried the blue token past marker 9fb2dbdecbd3. Mara watched the eastern gate until dawn.

Ledger 11 line 117: Neri carried the blue token past marker 387e294ba15d. Mara watched the eastern gate until dawn.

Ledger 11 line 118: Neri carried the blue token past marker ac002273f7e8. Mara watched the eastern gate until dawn.

Ledger 11 line 119: Neri carried the blue token past marker ed568959a4d6. Mara watched the eastern gate until dawn.

Ledger 11 line 120: Neri carried the blue token past marker e7ea9891a241. Mara watched the eastern gate until dawn.

Ledger 11 line 121: Neri carried the blue token past marker 78173abdba01. Mara watched the eastern gate until dawn.

Ledger 11 line 122: Neri carried the blue token past marker 7c9b40ec78f5. Mara watched the eastern gate until dawn.

Ledger 11 line 123: Neri carried the blue token past marker 589fa42e39af. Mara watched the eastern gate until dawn.

Ledger 11 line 124: Neri carried the blue token past marker ecef07c72617. Mara watched the eastern gate until dawn.

Ledger 11 line 125: Neri carried the blue token past marker b8596f602d41. Mara watched the eastern gate until dawn.

Ledger 11 line 126: Neri carried the blue token past marker 156669828b9e. Mara watched the eastern gate until dawn.

Ledger 11 line 127: Neri carried the blue token past marker 1ecf0fa8093d. Mara watched the eastern gate until dawn.

Ledger 11 line 128: Neri carried the blue token past marker 634bdf8cf4fa. Mara watched the eastern gate until dawn.

Ledger 11 line 129: Neri carried the blue token past marker 1303feb4a2d1. Mara watched the eastern gate until dawn.

Ledger 11 line 130: Neri carried the blue token past marker f59cc35b9e4a. Mara watched the eastern gate until dawn.

Ledger 11 line 131: Neri carried the blue token past marker 5d59207172f5. Mara watched the eastern gate until dawn.

Ledger 11 line 132: Neri carried the blue token past marker b261158935d9. Mara watched the eastern gate until dawn.

Ledger 11 line 133: Neri carried the blue token past marker 847ab07bdd78. Mara watched the eastern gate until dawn.

Ledger 11 line 134: Neri carried the blue token past marker 48821ce3b11e. Mara watched the eastern gate until dawn.

Ledger 11 line 135: Neri carried the blue token past marker 21184d51176e. Mara watched the eastern gate until dawn.

Ledger 11 line 136: Neri carried the blue token past marker 3bb8f4ccc368. Mara watched the eastern gate until dawn.

Ledger 11 line 137: Neri carried the blue token past marker d6ff02beba5a. Mara watched the eastern gate until dawn.

Ledger 11 line 138: Neri carried the blue token past marker d749e76c8982. Mara watched the eastern gate until dawn.

Ledger 11 line 139: Neri carried the blue token past marker ab314f54fa98. Mara watched the eastern gate until dawn.

Ledger 11 line 140: Neri carried the blue token past marker 3f936790b579. Mara watched the eastern gate until dawn.
