---
id: scene-0038
title: Recovery ledger 38
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.172958+00:00
updated_at: 2026-10-03T12:14:52.172958+00:00
---

Ledger 38 line 001: Neri carried the blue token past marker 39d55b51bfc2. Mara watched the eastern gate until dawn.

Ledger 38 line 002: Neri carried the blue token past marker 505b594e6f3d. Mara watched the eastern gate until dawn.

Ledger 38 line 003: Neri carried the blue token past marker f0fae363a05b. Mara watched the eastern gate until dawn.

Ledger 38 line 004: Neri carried the blue token past marker bacca2b71613. Mara watched the eastern gate until dawn.

Ledger 38 line 005: Neri carried the blue token past marker 7e162dbbae7e. Mara watched the eastern gate until dawn.

Ledger 38 line 006: Neri carried the blue token past marker 3b8d05f718fd. Mara watched the eastern gate until dawn.

Ledger 38 line 007: Neri carried the blue token past marker 631ee2ae10f3. Mara watched the eastern gate until dawn.

Ledger 38 line 008: Neri carried the blue token past marker e1500edd1189. Mara watched the eastern gate until dawn.

Ledger 38 line 009: Neri carried the blue token past marker 3e4007dc5180. Mara watched the eastern gate until dawn.

Ledger 38 line 010: Neri carried the blue token past marker 46de4e55cfeb. Mara watched the eastern gate until dawn.

Ledger 38 line 011: Neri carried the blue token past marker a74ae86a43c6. Mara watched the eastern gate until dawn.

Ledger 38 line 012: Neri carried the blue token past marker 71d5c4697813. Mara watched the eastern gate until dawn.

Ledger 38 line 013: Neri carried the blue token past marker 17db88c2b056. Mara watched the eastern gate until dawn.

Ledger 38 line 014: Neri carried the blue token past marker 214421f54243. Mara watched the eastern gate until dawn.

Ledger 38 line 015: Neri carried the blue token past marker 3e8fbca9e6d5. Mara watched the eastern gate until dawn.

Ledger 38 line 016: Neri carried the blue token past marker 54a48ef44ecf. Mara watched the eastern gate until dawn.

Ledger 38 line 017: Neri carried the blue token past marker 37ea8788b299. Mara watched the eastern gate until dawn.

Ledger 38 line 018: Neri carried the blue token past marker 317e9fe10bba. Mara watched the eastern gate until dawn.

Ledger 38 line 019: Neri carried the blue token past marker 55565a5c035c. Mara watched the eastern gate until dawn.

Ledger 38 line 020: Neri carried the blue token past marker fbb342750ecf. Mara watched the eastern gate until dawn.

Ledger 38 line 021: Neri carried the blue token past marker 222039a57be0. Mara watched the eastern gate until dawn.

Ledger 38 line 022: Neri carried the blue token past marker 602e48618384. Mara watched the eastern gate until dawn.

Ledger 38 line 023: Neri carried the blue token past marker a4169efd9ac6. Mara watched the eastern gate until dawn.

Ledger 38 line 024: Neri carried the blue token past marker 41af3469aeb8. Mara watched the eastern gate until dawn.

Ledger 38 line 025: Neri carried the blue token past marker c9d7a2ab91f2. Mara watched the eastern gate until dawn.

Ledger 38 line 026: Neri carried the blue token past marker 9a59d4f63b30. Mara watched the eastern gate until dawn.

Ledger 38 line 027: Neri carried the blue token past marker 53586b93e7cd. Mara watched the eastern gate until dawn.

Ledger 38 line 028: Neri carried the blue token past marker a4cef97b0474. Mara watched the eastern gate until dawn.

Ledger 38 line 029: Neri carried the blue token past marker 386897f627b1. Mara watched the eastern gate until dawn.

Ledger 38 line 030: Neri carried the blue token past marker 3607ba62f98c. Mara watched the eastern gate until dawn.

Ledger 38 line 031: Neri carried the blue token past marker c34d953156a8. Mara watched the eastern gate until dawn.

Ledger 38 line 032: Neri carried the blue token past marker 37e197e0e906. Mara watched the eastern gate until dawn.

Ledger 38 line 033: Neri carried the blue token past marker e567d27c6eb3. Mara watched the eastern gate until dawn.

Ledger 38 line 034: Neri carried the blue token past marker 3648a95c6f19. Mara watched the eastern gate until dawn.

Ledger 38 line 035: Neri carried the blue token past marker f15efa2b7a02. Mara watched the eastern gate until dawn.

Ledger 38 line 036: Neri carried the blue token past marker 9affd8d70f7b. Mara watched the eastern gate until dawn.

Ledger 38 line 037: Neri carried the blue token past marker 93bcf232b3c3. Mara watched the eastern gate until dawn.

Ledger 38 line 038: Neri carried the blue token past marker 12d754682ac7. Mara watched the eastern gate until dawn.

Ledger 38 line 039: Neri carried the blue token past marker 0fcfdc8efc87. Mara watched the eastern gate until dawn.

Ledger 38 line 040: Neri carried the blue token past marker a882d3242a58. Mara watched the eastern gate until dawn.

Ledger 38 line 041: Neri carried the blue token past marker fb73ce922f51. Mara watched the eastern gate until dawn.

Ledger 38 line 042: Neri carried the blue token past marker b3dfb3f8a49e. Mara watched the eastern gate until dawn.

Ledger 38 line 043: Neri carried the blue token past marker 914a38fe1a73. Mara watched the eastern gate until dawn.

Ledger 38 line 044: Neri carried the blue token past marker 0a912a1391dc. Mara watched the eastern gate until dawn.

Ledger 38 line 045: Neri carried the blue token past marker 02bb39de88d0. Mara watched the eastern gate until dawn.

Ledger 38 line 046: Neri carried the blue token past marker 8a94a2001421. Mara watched the eastern gate until dawn.

Ledger 38 line 047: Neri carried the blue token past marker 381de671085a. Mara watched the eastern gate until dawn.

Ledger 38 line 048: Neri carried the blue token past marker 1708fae553bb. Mara watched the eastern gate until dawn.

Ledger 38 line 049: Neri carried the blue token past marker 0db4ab2c3d86. Mara watched the eastern gate until dawn.

Ledger 38 line 050: Neri carried the blue token past marker 6bd14e9c2e7e. Mara watched the eastern gate until dawn.

Ledger 38 line 051: Neri carried the blue token past marker f15c97e0fae2. Mara watched the eastern gate until dawn.

Ledger 38 line 052: Neri carried the blue token past marker a9754edec4fe. Mara watched the eastern gate until dawn.

Ledger 38 line 053: Neri carried the blue token past marker 1e345d14ec30. Mara watched the eastern gate until dawn.

Ledger 38 line 054: Neri carried the blue token past marker c8e8b4d63efb. Mara watched the eastern gate until dawn.

Ledger 38 line 055: Neri carried the blue token past marker 4e070bc0afc8. Mara watched the eastern gate until dawn.

Ledger 38 line 056: Neri carried the blue token past marker 268df8dd3384. Mara watched the eastern gate until dawn.

Ledger 38 line 057: Neri carried the blue token past marker ee13f44183e2. Mara watched the eastern gate until dawn.

Ledger 38 line 058: Neri carried the blue token past marker a5670b107863. Mara watched the eastern gate until dawn.

Ledger 38 line 059: Neri carried the blue token past marker 650197a53fef. Mara watched the eastern gate until dawn.

Ledger 38 line 060: Neri carried the blue token past marker 09f1fe883ce7. Mara watched the eastern gate until dawn.

Ledger 38 line 061: Neri carried the blue token past marker 2e8624c5b04e. Mara watched the eastern gate until dawn.

Ledger 38 line 062: Neri carried the blue token past marker 75c7dd48b82b. Mara watched the eastern gate until dawn.

Ledger 38 line 063: Neri carried the blue token past marker aeba5742fb01. Mara watched the eastern gate until dawn.

Ledger 38 line 064: Neri carried the blue token past marker c4169f5cf492. Mara watched the eastern gate until dawn.

Ledger 38 line 065: Neri carried the blue token past marker fe7b664cb69d. Mara watched the eastern gate until dawn.

Ledger 38 line 066: Neri carried the blue token past marker e2b28de41641. Mara watched the eastern gate until dawn.

Ledger 38 line 067: Neri carried the blue token past marker 1f18cf0e4a61. Mara watched the eastern gate until dawn.

Ledger 38 line 068: Neri carried the blue token past marker 5231a898c13e. Mara watched the eastern gate until dawn.

Ledger 38 line 069: Neri carried the blue token past marker e1535a815c5c. Mara watched the eastern gate until dawn.

Ledger 38 line 070: Neri carried the blue token past marker d0e56e73c2e8. Mara watched the eastern gate until dawn.

Ledger 38 line 071: Neri carried the blue token past marker a60252f61097. Mara watched the eastern gate until dawn.

Ledger 38 line 072: Neri carried the blue token past marker 0ce868577142. Mara watched the eastern gate until dawn.

Ledger 38 line 073: Neri carried the blue token past marker 2053d552d0a2. Mara watched the eastern gate until dawn.

Ledger 38 line 074: Neri carried the blue token past marker c67f43f5b2de. Mara watched the eastern gate until dawn.

Ledger 38 line 075: Neri carried the blue token past marker 1ad4299c2363. Mara watched the eastern gate until dawn.

Ledger 38 line 076: Neri carried the blue token past marker 1fad679f04f1. Mara watched the eastern gate until dawn.

Ledger 38 line 077: Neri carried the blue token past marker 07640c56dec4. Mara watched the eastern gate until dawn.

Ledger 38 line 078: Neri carried the blue token past marker d2f7eec0ade8. Mara watched the eastern gate until dawn.

Ledger 38 line 079: Neri carried the blue token past marker 6f4d2842463f. Mara watched the eastern gate until dawn.

Ledger 38 line 080: Neri carried the blue token past marker 37a785a44daf. Mara watched the eastern gate until dawn.

Ledger 38 line 081: Neri carried the blue token past marker a23a09ed2580. Mara watched the eastern gate until dawn.

Ledger 38 line 082: Neri carried the blue token past marker 53fab263a793. Mara watched the eastern gate until dawn.

Ledger 38 line 083: Neri carried the blue token past marker 4f65bb3bbc98. Mara watched the eastern gate until dawn.

Ledger 38 line 084: Neri carried the blue token past marker 9dac19400e10. Mara watched the eastern gate until dawn.

Ledger 38 line 085: Neri carried the blue token past marker dddbab8a90af. Mara watched the eastern gate until dawn.

Ledger 38 line 086: Neri carried the blue token past marker b7fe963beaa6. Mara watched the eastern gate until dawn.

Ledger 38 line 087: Neri carried the blue token past marker f244c29c96f6. Mara watched the eastern gate until dawn.

Ledger 38 line 088: Neri carried the blue token past marker e92f7f92928c. Mara watched the eastern gate until dawn.

Ledger 38 line 089: Neri carried the blue token past marker 5a7ca93b8609. Mara watched the eastern gate until dawn.

Ledger 38 line 090: Neri carried the blue token past marker 16124427873f. Mara watched the eastern gate until dawn.

Ledger 38 line 091: Neri carried the blue token past marker 16c7a85d1c55. Mara watched the eastern gate until dawn.

Ledger 38 line 092: Neri carried the blue token past marker fbecd4ed19f6. Mara watched the eastern gate until dawn.

Ledger 38 line 093: Neri carried the blue token past marker 067121be55b0. Mara watched the eastern gate until dawn.

Ledger 38 line 094: Neri carried the blue token past marker 79d8f3e6a1de. Mara watched the eastern gate until dawn.

Ledger 38 line 095: Neri carried the blue token past marker 46f02e2931b5. Mara watched the eastern gate until dawn.

Ledger 38 line 096: Neri carried the blue token past marker 3d0330e2b31c. Mara watched the eastern gate until dawn.

Ledger 38 line 097: Neri carried the blue token past marker 228bd123363e. Mara watched the eastern gate until dawn.

Ledger 38 line 098: Neri carried the blue token past marker fa784a7eb29f. Mara watched the eastern gate until dawn.

Ledger 38 line 099: Neri carried the blue token past marker 3be122fc231f. Mara watched the eastern gate until dawn.

Ledger 38 line 100: Neri carried the blue token past marker 938609d8a550. Mara watched the eastern gate until dawn.

Ledger 38 line 101: Neri carried the blue token past marker f6c081f809a7. Mara watched the eastern gate until dawn.

Ledger 38 line 102: Neri carried the blue token past marker d4271c03a6fe. Mara watched the eastern gate until dawn.

Ledger 38 line 103: Neri carried the blue token past marker 2fc110034e22. Mara watched the eastern gate until dawn.

Ledger 38 line 104: Neri carried the blue token past marker 900cb40e58d1. Mara watched the eastern gate until dawn.

Ledger 38 line 105: Neri carried the blue token past marker d163ae1dfe38. Mara watched the eastern gate until dawn.

Ledger 38 line 106: Neri carried the blue token past marker 00e968a6d74d. Mara watched the eastern gate until dawn.

Ledger 38 line 107: Neri carried the blue token past marker 89bb96faca2e. Mara watched the eastern gate until dawn.

Ledger 38 line 108: Neri carried the blue token past marker 67505f2857ef. Mara watched the eastern gate until dawn.

Ledger 38 line 109: Neri carried the blue token past marker ad37c763bc14. Mara watched the eastern gate until dawn.

Ledger 38 line 110: Neri carried the blue token past marker 219742a3e706. Mara watched the eastern gate until dawn.

Ledger 38 line 111: Neri carried the blue token past marker 437cec52b666. Mara watched the eastern gate until dawn.

Ledger 38 line 112: Neri carried the blue token past marker d2cc330e72f7. Mara watched the eastern gate until dawn.

Ledger 38 line 113: Neri carried the blue token past marker 88d06efdbb3b. Mara watched the eastern gate until dawn.

Ledger 38 line 114: Neri carried the blue token past marker 43d5c95f3759. Mara watched the eastern gate until dawn.

Ledger 38 line 115: Neri carried the blue token past marker 3d2d520721a8. Mara watched the eastern gate until dawn.

Ledger 38 line 116: Neri carried the blue token past marker 124794323e4f. Mara watched the eastern gate until dawn.

Ledger 38 line 117: Neri carried the blue token past marker 66780d87adc3. Mara watched the eastern gate until dawn.

Ledger 38 line 118: Neri carried the blue token past marker ce96d413029a. Mara watched the eastern gate until dawn.

Ledger 38 line 119: Neri carried the blue token past marker 4358318cb512. Mara watched the eastern gate until dawn.

Ledger 38 line 120: Neri carried the blue token past marker 4b0659708a81. Mara watched the eastern gate until dawn.

Ledger 38 line 121: Neri carried the blue token past marker 4c2c8d140572. Mara watched the eastern gate until dawn.

Ledger 38 line 122: Neri carried the blue token past marker a50ed1f5554a. Mara watched the eastern gate until dawn.

Ledger 38 line 123: Neri carried the blue token past marker 726111778e99. Mara watched the eastern gate until dawn.

Ledger 38 line 124: Neri carried the blue token past marker 658999cbc8a2. Mara watched the eastern gate until dawn.

Ledger 38 line 125: Neri carried the blue token past marker 874edacb5242. Mara watched the eastern gate until dawn.

Ledger 38 line 126: Neri carried the blue token past marker fdbd991c8b58. Mara watched the eastern gate until dawn.

Ledger 38 line 127: Neri carried the blue token past marker 8e2ad57cc4d4. Mara watched the eastern gate until dawn.

Ledger 38 line 128: Neri carried the blue token past marker 45ef15982391. Mara watched the eastern gate until dawn.

Ledger 38 line 129: Neri carried the blue token past marker 0a54d17e8aef. Mara watched the eastern gate until dawn.

Ledger 38 line 130: Neri carried the blue token past marker c4b5b1cb9610. Mara watched the eastern gate until dawn.

Ledger 38 line 131: Neri carried the blue token past marker 96e17b1155d3. Mara watched the eastern gate until dawn.

Ledger 38 line 132: Neri carried the blue token past marker 860490f3c352. Mara watched the eastern gate until dawn.

Ledger 38 line 133: Neri carried the blue token past marker c9395a5bd838. Mara watched the eastern gate until dawn.

Ledger 38 line 134: Neri carried the blue token past marker f6bdab90cdd1. Mara watched the eastern gate until dawn.

Ledger 38 line 135: Neri carried the blue token past marker 9a7e7f37a0b6. Mara watched the eastern gate until dawn.

Ledger 38 line 136: Neri carried the blue token past marker 3f42052c5bc6. Mara watched the eastern gate until dawn.

Ledger 38 line 137: Neri carried the blue token past marker 2aac40644399. Mara watched the eastern gate until dawn.

Ledger 38 line 138: Neri carried the blue token past marker 62747a4114a5. Mara watched the eastern gate until dawn.

Ledger 38 line 139: Neri carried the blue token past marker b6996d9920e5. Mara watched the eastern gate until dawn.

Ledger 38 line 140: Neri carried the blue token past marker 76ad4c1691b6. Mara watched the eastern gate until dawn.
