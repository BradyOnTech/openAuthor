---
id: scene-0028
title: Recovery ledger 28
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.167438+00:00
updated_at: 2026-10-03T12:14:52.167438+00:00
---

Ledger 28 line 001: Neri carried the blue token past marker 0f1f68c262bc. Mara watched the eastern gate until dawn.

Ledger 28 line 002: Neri carried the blue token past marker 4a7fd3b9e062. Mara watched the eastern gate until dawn.

Ledger 28 line 003: Neri carried the blue token past marker 7c7bbe4ac916. Mara watched the eastern gate until dawn.

Ledger 28 line 004: Neri carried the blue token past marker 06cba9488a5a. Mara watched the eastern gate until dawn.

Ledger 28 line 005: Neri carried the blue token past marker e0c72e89e606. Mara watched the eastern gate until dawn.

Ledger 28 line 006: Neri carried the blue token past marker 66f0bb01297c. Mara watched the eastern gate until dawn.

Ledger 28 line 007: Neri carried the blue token past marker e2db1fc3c0d6. Mara watched the eastern gate until dawn.

Ledger 28 line 008: Neri carried the blue token past marker 009d25a2f73a. Mara watched the eastern gate until dawn.

Ledger 28 line 009: Neri carried the blue token past marker a2a87c9b10ea. Mara watched the eastern gate until dawn.

Ledger 28 line 010: Neri carried the blue token past marker 94ed7620f4e5. Mara watched the eastern gate until dawn.

Ledger 28 line 011: Neri carried the blue token past marker af654e40f032. Mara watched the eastern gate until dawn.

Ledger 28 line 012: Neri carried the blue token past marker 7e4be8dad66a. Mara watched the eastern gate until dawn.

Ledger 28 line 013: Neri carried the blue token past marker 3db6678aeef8. Mara watched the eastern gate until dawn.

Ledger 28 line 014: Neri carried the blue token past marker 059f65236440. Mara watched the eastern gate until dawn.

Ledger 28 line 015: Neri carried the blue token past marker bca836f2633c. Mara watched the eastern gate until dawn.

Ledger 28 line 016: Neri carried the blue token past marker 6ff30ad33f9f. Mara watched the eastern gate until dawn.

Ledger 28 line 017: Neri carried the blue token past marker db5745d62304. Mara watched the eastern gate until dawn.

Ledger 28 line 018: Neri carried the blue token past marker fe832960b27e. Mara watched the eastern gate until dawn.

Ledger 28 line 019: Neri carried the blue token past marker 8025d8426f6c. Mara watched the eastern gate until dawn.

Ledger 28 line 020: Neri carried the blue token past marker 4a888a7f3c8a. Mara watched the eastern gate until dawn.

Ledger 28 line 021: Neri carried the blue token past marker ea86ec41fde4. Mara watched the eastern gate until dawn.

Ledger 28 line 022: Neri carried the blue token past marker 81f8ec20a07d. Mara watched the eastern gate until dawn.

Ledger 28 line 023: Neri carried the blue token past marker 3328af753c1a. Mara watched the eastern gate until dawn.

Ledger 28 line 024: Neri carried the blue token past marker 3bf160ffdb63. Mara watched the eastern gate until dawn.

Ledger 28 line 025: Neri carried the blue token past marker 9753234bba88. Mara watched the eastern gate until dawn.

Ledger 28 line 026: Neri carried the blue token past marker 2ed3b249cb84. Mara watched the eastern gate until dawn.

Ledger 28 line 027: Neri carried the blue token past marker 6b6e7044cca5. Mara watched the eastern gate until dawn.

Ledger 28 line 028: Neri carried the blue token past marker 3afbd439cfc5. Mara watched the eastern gate until dawn.

Ledger 28 line 029: Neri carried the blue token past marker dc50d2e65928. Mara watched the eastern gate until dawn.

Ledger 28 line 030: Neri carried the blue token past marker 454d0be0ae8a. Mara watched the eastern gate until dawn.

Ledger 28 line 031: Neri carried the blue token past marker cb1b8cc1f890. Mara watched the eastern gate until dawn.

Ledger 28 line 032: Neri carried the blue token past marker 1ad5ac0c0254. Mara watched the eastern gate until dawn.

Ledger 28 line 033: Neri carried the blue token past marker c3f4fa780f5f. Mara watched the eastern gate until dawn.

Ledger 28 line 034: Neri carried the blue token past marker 46356a9e299e. Mara watched the eastern gate until dawn.

Ledger 28 line 035: Neri carried the blue token past marker cfbb6078384f. Mara watched the eastern gate until dawn.

Ledger 28 line 036: Neri carried the blue token past marker 095184349bb4. Mara watched the eastern gate until dawn.

Ledger 28 line 037: Neri carried the blue token past marker df1b6953de77. Mara watched the eastern gate until dawn.

Ledger 28 line 038: Neri carried the blue token past marker d79c51aecbec. Mara watched the eastern gate until dawn.

Ledger 28 line 039: Neri carried the blue token past marker b1a910a69651. Mara watched the eastern gate until dawn.

Ledger 28 line 040: Neri carried the blue token past marker 87f9e1328aad. Mara watched the eastern gate until dawn.

Ledger 28 line 041: Neri carried the blue token past marker 9938f321bd79. Mara watched the eastern gate until dawn.

Ledger 28 line 042: Neri carried the blue token past marker 422bd10698bd. Mara watched the eastern gate until dawn.

Ledger 28 line 043: Neri carried the blue token past marker 8bf51e9528ea. Mara watched the eastern gate until dawn.

Ledger 28 line 044: Neri carried the blue token past marker d4945c60cb66. Mara watched the eastern gate until dawn.

Ledger 28 line 045: Neri carried the blue token past marker e4c9f30e407d. Mara watched the eastern gate until dawn.

Ledger 28 line 046: Neri carried the blue token past marker 6026afc6950b. Mara watched the eastern gate until dawn.

Ledger 28 line 047: Neri carried the blue token past marker ecacc83bb27f. Mara watched the eastern gate until dawn.

Ledger 28 line 048: Neri carried the blue token past marker 8e6def8d7c5f. Mara watched the eastern gate until dawn.

Ledger 28 line 049: Neri carried the blue token past marker 11b126c99e5e. Mara watched the eastern gate until dawn.

Ledger 28 line 050: Neri carried the blue token past marker a54131b28d49. Mara watched the eastern gate until dawn.

Ledger 28 line 051: Neri carried the blue token past marker 74e540b3acd1. Mara watched the eastern gate until dawn.

Ledger 28 line 052: Neri carried the blue token past marker 37de86552ec9. Mara watched the eastern gate until dawn.

Ledger 28 line 053: Neri carried the blue token past marker 8652ffcfce86. Mara watched the eastern gate until dawn.

Ledger 28 line 054: Neri carried the blue token past marker 5ffd2cac33c5. Mara watched the eastern gate until dawn.

Ledger 28 line 055: Neri carried the blue token past marker 543fab8d736e. Mara watched the eastern gate until dawn.

Ledger 28 line 056: Neri carried the blue token past marker a42c96634059. Mara watched the eastern gate until dawn.

Ledger 28 line 057: Neri carried the blue token past marker 239baf127c8b. Mara watched the eastern gate until dawn.

Ledger 28 line 058: Neri carried the blue token past marker 2c7bd290feda. Mara watched the eastern gate until dawn.

Ledger 28 line 059: Neri carried the blue token past marker f6def56c22bc. Mara watched the eastern gate until dawn.

Ledger 28 line 060: Neri carried the blue token past marker 48eb26fde4fc. Mara watched the eastern gate until dawn.

Ledger 28 line 061: Neri carried the blue token past marker 4408029a8bff. Mara watched the eastern gate until dawn.

Ledger 28 line 062: Neri carried the blue token past marker 4f2b4f204c18. Mara watched the eastern gate until dawn.

Ledger 28 line 063: Neri carried the blue token past marker d434a1af3121. Mara watched the eastern gate until dawn.

Ledger 28 line 064: Neri carried the blue token past marker 68e668c506a8. Mara watched the eastern gate until dawn.

Ledger 28 line 065: Neri carried the blue token past marker c33bdf9078b9. Mara watched the eastern gate until dawn.

Ledger 28 line 066: Neri carried the blue token past marker 42db493c2f89. Mara watched the eastern gate until dawn.

Ledger 28 line 067: Neri carried the blue token past marker 3a8e583d467a. Mara watched the eastern gate until dawn.

Ledger 28 line 068: Neri carried the blue token past marker 9df4920d9c36. Mara watched the eastern gate until dawn.

Ledger 28 line 069: Neri carried the blue token past marker ad50ea7c9ad1. Mara watched the eastern gate until dawn.

Ledger 28 line 070: Neri carried the blue token past marker 21b9f80115cd. Mara watched the eastern gate until dawn.

Ledger 28 line 071: Neri carried the blue token past marker 75a33c751d93. Mara watched the eastern gate until dawn.

Ledger 28 line 072: Neri carried the blue token past marker f3973407c9d5. Mara watched the eastern gate until dawn.

Ledger 28 line 073: Neri carried the blue token past marker be4ddc3df297. Mara watched the eastern gate until dawn.

Ledger 28 line 074: Neri carried the blue token past marker 623c1b244f3c. Mara watched the eastern gate until dawn.

Ledger 28 line 075: Neri carried the blue token past marker 91a0009d29c6. Mara watched the eastern gate until dawn.

Ledger 28 line 076: Neri carried the blue token past marker 379a7cb182d0. Mara watched the eastern gate until dawn.

Ledger 28 line 077: Neri carried the blue token past marker b96630e74839. Mara watched the eastern gate until dawn.

Ledger 28 line 078: Neri carried the blue token past marker 7b9c19298544. Mara watched the eastern gate until dawn.

Ledger 28 line 079: Neri carried the blue token past marker 4e4556b414ad. Mara watched the eastern gate until dawn.

Ledger 28 line 080: Neri carried the blue token past marker 35be1edddf63. Mara watched the eastern gate until dawn.

Ledger 28 line 081: Neri carried the blue token past marker 477baa78065f. Mara watched the eastern gate until dawn.

Ledger 28 line 082: Neri carried the blue token past marker 76bafe645e11. Mara watched the eastern gate until dawn.

Ledger 28 line 083: Neri carried the blue token past marker ed0936019053. Mara watched the eastern gate until dawn.

Ledger 28 line 084: Neri carried the blue token past marker 4941167ef898. Mara watched the eastern gate until dawn.

Ledger 28 line 085: Neri carried the blue token past marker ec256c7dc2d7. Mara watched the eastern gate until dawn.

Ledger 28 line 086: Neri carried the blue token past marker a2c5d578a5b5. Mara watched the eastern gate until dawn.

Ledger 28 line 087: Neri carried the blue token past marker e72c93f39bec. Mara watched the eastern gate until dawn.

Ledger 28 line 088: Neri carried the blue token past marker 4186b8aa2a1f. Mara watched the eastern gate until dawn.

Ledger 28 line 089: Neri carried the blue token past marker 409a1982196f. Mara watched the eastern gate until dawn.

Ledger 28 line 090: Neri carried the blue token past marker cac09d7acdd1. Mara watched the eastern gate until dawn.

Ledger 28 line 091: Neri carried the blue token past marker d2bbafb9bd10. Mara watched the eastern gate until dawn.

Ledger 28 line 092: Neri carried the blue token past marker 7e4419f66b35. Mara watched the eastern gate until dawn.

Ledger 28 line 093: Neri carried the blue token past marker 37690c72199f. Mara watched the eastern gate until dawn.

Ledger 28 line 094: Neri carried the blue token past marker a9a88d7322da. Mara watched the eastern gate until dawn.

Ledger 28 line 095: Neri carried the blue token past marker 952602f4a1b7. Mara watched the eastern gate until dawn.

Ledger 28 line 096: Neri carried the blue token past marker a21fc4b31021. Mara watched the eastern gate until dawn.

Ledger 28 line 097: Neri carried the blue token past marker f1b4bb85b785. Mara watched the eastern gate until dawn.

Ledger 28 line 098: Neri carried the blue token past marker f66c3ff036af. Mara watched the eastern gate until dawn.

Ledger 28 line 099: Neri carried the blue token past marker 7ea005fb06c5. Mara watched the eastern gate until dawn.

Ledger 28 line 100: Neri carried the blue token past marker db9d2ba88a2b. Mara watched the eastern gate until dawn.

Ledger 28 line 101: Neri carried the blue token past marker b5d67d2a2e56. Mara watched the eastern gate until dawn.

Ledger 28 line 102: Neri carried the blue token past marker b0ff523a308d. Mara watched the eastern gate until dawn.

Ledger 28 line 103: Neri carried the blue token past marker 1403befa3613. Mara watched the eastern gate until dawn.

Ledger 28 line 104: Neri carried the blue token past marker 84db2220400a. Mara watched the eastern gate until dawn.

Ledger 28 line 105: Neri carried the blue token past marker f0ef1f2b4486. Mara watched the eastern gate until dawn.

Ledger 28 line 106: Neri carried the blue token past marker 6fe93005a3f5. Mara watched the eastern gate until dawn.

Ledger 28 line 107: Neri carried the blue token past marker 6a16e087114d. Mara watched the eastern gate until dawn.

Ledger 28 line 108: Neri carried the blue token past marker 88d007974d80. Mara watched the eastern gate until dawn.

Ledger 28 line 109: Neri carried the blue token past marker 25d5559a22e7. Mara watched the eastern gate until dawn.

Ledger 28 line 110: Neri carried the blue token past marker a79e3ad159e3. Mara watched the eastern gate until dawn.

Ledger 28 line 111: Neri carried the blue token past marker db90dcc7b1fb. Mara watched the eastern gate until dawn.

Ledger 28 line 112: Neri carried the blue token past marker 89d58c7c5139. Mara watched the eastern gate until dawn.

Ledger 28 line 113: Neri carried the blue token past marker 47776b06a058. Mara watched the eastern gate until dawn.

Ledger 28 line 114: Neri carried the blue token past marker 671cf1da4023. Mara watched the eastern gate until dawn.

Ledger 28 line 115: Neri carried the blue token past marker f7d0bbde6772. Mara watched the eastern gate until dawn.

Ledger 28 line 116: Neri carried the blue token past marker 6dd90c0a788e. Mara watched the eastern gate until dawn.

Ledger 28 line 117: Neri carried the blue token past marker 79b55cb3648b. Mara watched the eastern gate until dawn.

Ledger 28 line 118: Neri carried the blue token past marker caaf0b17a794. Mara watched the eastern gate until dawn.

Ledger 28 line 119: Neri carried the blue token past marker 898df2c0fa04. Mara watched the eastern gate until dawn.

Ledger 28 line 120: Neri carried the blue token past marker 86a9f8313d16. Mara watched the eastern gate until dawn.

Ledger 28 line 121: Neri carried the blue token past marker ce4a1e5f5873. Mara watched the eastern gate until dawn.

Ledger 28 line 122: Neri carried the blue token past marker 79a349b10d9f. Mara watched the eastern gate until dawn.

Ledger 28 line 123: Neri carried the blue token past marker 7163524b7ce7. Mara watched the eastern gate until dawn.

Ledger 28 line 124: Neri carried the blue token past marker 97d07cb4759a. Mara watched the eastern gate until dawn.

Ledger 28 line 125: Neri carried the blue token past marker 9122b7441a80. Mara watched the eastern gate until dawn.

Ledger 28 line 126: Neri carried the blue token past marker ab8c996b6a9d. Mara watched the eastern gate until dawn.

Ledger 28 line 127: Neri carried the blue token past marker 63988c313149. Mara watched the eastern gate until dawn.

Ledger 28 line 128: Neri carried the blue token past marker 38a068738d44. Mara watched the eastern gate until dawn.

Ledger 28 line 129: Neri carried the blue token past marker b4d70c48cbad. Mara watched the eastern gate until dawn.

Ledger 28 line 130: Neri carried the blue token past marker 3f95f08b3250. Mara watched the eastern gate until dawn.

Ledger 28 line 131: Neri carried the blue token past marker bb45eb98b16d. Mara watched the eastern gate until dawn.

Ledger 28 line 132: Neri carried the blue token past marker db0fa24de0bd. Mara watched the eastern gate until dawn.

Ledger 28 line 133: Neri carried the blue token past marker 5a128383688f. Mara watched the eastern gate until dawn.

Ledger 28 line 134: Neri carried the blue token past marker 1dff68cb13c7. Mara watched the eastern gate until dawn.

Ledger 28 line 135: Neri carried the blue token past marker 45d88304d614. Mara watched the eastern gate until dawn.

Ledger 28 line 136: Neri carried the blue token past marker 1fc75273204c. Mara watched the eastern gate until dawn.

Ledger 28 line 137: Neri carried the blue token past marker 30a4b921ef79. Mara watched the eastern gate until dawn.

Ledger 28 line 138: Neri carried the blue token past marker 051b6cc884df. Mara watched the eastern gate until dawn.

Ledger 28 line 139: Neri carried the blue token past marker 242c7c84fe82. Mara watched the eastern gate until dawn.

Ledger 28 line 140: Neri carried the blue token past marker d0957249ee14. Mara watched the eastern gate until dawn.
