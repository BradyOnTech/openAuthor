---
id: scene-0010
title: Recovery ledger 10
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.158003+00:00
updated_at: 2026-10-03T12:14:52.158003+00:00
---

Ledger 10 line 001: Neri carried the blue token past marker a0ae6afe297e. Mara watched the eastern gate until dawn.

Ledger 10 line 002: Neri carried the blue token past marker 35845fee474a. Mara watched the eastern gate until dawn.

Ledger 10 line 003: Neri carried the blue token past marker 8d4a87aa02d6. Mara watched the eastern gate until dawn.

Ledger 10 line 004: Neri carried the blue token past marker 618da6e454d3. Mara watched the eastern gate until dawn.

Ledger 10 line 005: Neri carried the blue token past marker e6fc38198bd2. Mara watched the eastern gate until dawn.

Ledger 10 line 006: Neri carried the blue token past marker 5f7438f391d7. Mara watched the eastern gate until dawn.

Ledger 10 line 007: Neri carried the blue token past marker cc5925b930e6. Mara watched the eastern gate until dawn.

Ledger 10 line 008: Neri carried the blue token past marker c573ab743a87. Mara watched the eastern gate until dawn.

Ledger 10 line 009: Neri carried the blue token past marker 898ae49e8a61. Mara watched the eastern gate until dawn.

Ledger 10 line 010: Neri carried the blue token past marker bac89235c814. Mara watched the eastern gate until dawn.

Ledger 10 line 011: Neri carried the blue token past marker 549c75e46eac. Mara watched the eastern gate until dawn.

Ledger 10 line 012: Neri carried the blue token past marker cd51176243dd. Mara watched the eastern gate until dawn.

Ledger 10 line 013: Neri carried the blue token past marker 2bd9391b76a1. Mara watched the eastern gate until dawn.

Ledger 10 line 014: Neri carried the blue token past marker d5580d718ed2. Mara watched the eastern gate until dawn.

Ledger 10 line 015: Neri carried the blue token past marker 8a076fee742d. Mara watched the eastern gate until dawn.

Ledger 10 line 016: Neri carried the blue token past marker 521dc1144006. Mara watched the eastern gate until dawn.

Ledger 10 line 017: Neri carried the blue token past marker b4dd52185765. Mara watched the eastern gate until dawn.

Ledger 10 line 018: Neri carried the blue token past marker 0c246b76b034. Mara watched the eastern gate until dawn.

Ledger 10 line 019: Neri carried the blue token past marker c6b844870712. Mara watched the eastern gate until dawn.

Ledger 10 line 020: Neri carried the blue token past marker bbd7a63d6f51. Mara watched the eastern gate until dawn.

Ledger 10 line 021: Neri carried the blue token past marker b3bee13719ec. Mara watched the eastern gate until dawn.

Ledger 10 line 022: Neri carried the blue token past marker db5b192ea6ea. Mara watched the eastern gate until dawn.

Ledger 10 line 023: Neri carried the blue token past marker 07a5e40ead67. Mara watched the eastern gate until dawn.

Ledger 10 line 024: Neri carried the blue token past marker 32d772b611c6. Mara watched the eastern gate until dawn.

Ledger 10 line 025: Neri carried the blue token past marker 740c8b1c673e. Mara watched the eastern gate until dawn.

Ledger 10 line 026: Neri carried the blue token past marker 552e837c20ee. Mara watched the eastern gate until dawn.

Ledger 10 line 027: Neri carried the blue token past marker 7032dcd28cdf. Mara watched the eastern gate until dawn.

Ledger 10 line 028: Neri carried the blue token past marker 9c1a0f4e710d. Mara watched the eastern gate until dawn.

Ledger 10 line 029: Neri carried the blue token past marker 07b59e52790a. Mara watched the eastern gate until dawn.

Ledger 10 line 030: Neri carried the blue token past marker 08c89d2c1d45. Mara watched the eastern gate until dawn.

Ledger 10 line 031: Neri carried the blue token past marker bac3e3490824. Mara watched the eastern gate until dawn.

Ledger 10 line 032: Neri carried the blue token past marker 50e7c75ae558. Mara watched the eastern gate until dawn.

Ledger 10 line 033: Neri carried the blue token past marker e181484c5176. Mara watched the eastern gate until dawn.

Ledger 10 line 034: Neri carried the blue token past marker f94d93ad040a. Mara watched the eastern gate until dawn.

Ledger 10 line 035: Neri carried the blue token past marker c7a95c96627d. Mara watched the eastern gate until dawn.

Ledger 10 line 036: Neri carried the blue token past marker 1f5cd34bfd14. Mara watched the eastern gate until dawn.

Ledger 10 line 037: Neri carried the blue token past marker b60ed944ca0a. Mara watched the eastern gate until dawn.

Ledger 10 line 038: Neri carried the blue token past marker b0c2b9119186. Mara watched the eastern gate until dawn.

Ledger 10 line 039: Neri carried the blue token past marker 014e676e5543. Mara watched the eastern gate until dawn.

Ledger 10 line 040: Neri carried the blue token past marker 43a6e1022840. Mara watched the eastern gate until dawn.

Ledger 10 line 041: Neri carried the blue token past marker c2d7dfdda1d6. Mara watched the eastern gate until dawn.

Ledger 10 line 042: Neri carried the blue token past marker 574aa5369d4a. Mara watched the eastern gate until dawn.

Ledger 10 line 043: Neri carried the blue token past marker 392374f2ee57. Mara watched the eastern gate until dawn.

Ledger 10 line 044: Neri carried the blue token past marker 75d5fdae3152. Mara watched the eastern gate until dawn.

Ledger 10 line 045: Neri carried the blue token past marker 49bc8f9a906d. Mara watched the eastern gate until dawn.

Ledger 10 line 046: Neri carried the blue token past marker ffa96ef8d2d7. Mara watched the eastern gate until dawn.

Ledger 10 line 047: Neri carried the blue token past marker 43400699a524. Mara watched the eastern gate until dawn.

Ledger 10 line 048: Neri carried the blue token past marker fe0b673349b4. Mara watched the eastern gate until dawn.

Ledger 10 line 049: Neri carried the blue token past marker 75f19fdc2fdc. Mara watched the eastern gate until dawn.

Ledger 10 line 050: Neri carried the blue token past marker d8f0f0c1d291. Mara watched the eastern gate until dawn.

Ledger 10 line 051: Neri carried the blue token past marker 2de0384ae002. Mara watched the eastern gate until dawn.

Ledger 10 line 052: Neri carried the blue token past marker 77b00fcecf5b. Mara watched the eastern gate until dawn.

Ledger 10 line 053: Neri carried the blue token past marker 13c653856552. Mara watched the eastern gate until dawn.

Ledger 10 line 054: Neri carried the blue token past marker 40d247bacf15. Mara watched the eastern gate until dawn.

Ledger 10 line 055: Neri carried the blue token past marker f88d9ef52ec5. Mara watched the eastern gate until dawn.

Ledger 10 line 056: Neri carried the blue token past marker a4bcbf07f527. Mara watched the eastern gate until dawn.

Ledger 10 line 057: Neri carried the blue token past marker d3c425ce7494. Mara watched the eastern gate until dawn.

Ledger 10 line 058: Neri carried the blue token past marker 70970c5bfb14. Mara watched the eastern gate until dawn.

Ledger 10 line 059: Neri carried the blue token past marker fecdfc96e24a. Mara watched the eastern gate until dawn.

Ledger 10 line 060: Neri carried the blue token past marker 8c47f4cd1a49. Mara watched the eastern gate until dawn.

Ledger 10 line 061: Neri carried the blue token past marker df86ce2fd0c0. Mara watched the eastern gate until dawn.

Ledger 10 line 062: Neri carried the blue token past marker c0d4a2a06360. Mara watched the eastern gate until dawn.

Ledger 10 line 063: Neri carried the blue token past marker 43ea2e6f4510. Mara watched the eastern gate until dawn.

Ledger 10 line 064: Neri carried the blue token past marker eff4a09b068c. Mara watched the eastern gate until dawn.

Ledger 10 line 065: Neri carried the blue token past marker 5fba4408e716. Mara watched the eastern gate until dawn.

Ledger 10 line 066: Neri carried the blue token past marker 25265f306425. Mara watched the eastern gate until dawn.

Ledger 10 line 067: Neri carried the blue token past marker afbb65cc8940. Mara watched the eastern gate until dawn.

Ledger 10 line 068: Neri carried the blue token past marker 915a2da4582a. Mara watched the eastern gate until dawn.

Ledger 10 line 069: Neri carried the blue token past marker fcddd67eae2c. Mara watched the eastern gate until dawn.

Ledger 10 line 070: Neri carried the blue token past marker 8d920908fe03. Mara watched the eastern gate until dawn.

Ledger 10 line 071: Neri carried the blue token past marker 897fd41c1116. Mara watched the eastern gate until dawn.

Ledger 10 line 072: Neri carried the blue token past marker 745e7cfcadda. Mara watched the eastern gate until dawn.

Ledger 10 line 073: Neri carried the blue token past marker 34585aac9242. Mara watched the eastern gate until dawn.

Ledger 10 line 074: Neri carried the blue token past marker 4745652ab859. Mara watched the eastern gate until dawn.

Ledger 10 line 075: Neri carried the blue token past marker 2a10ccdd92bb. Mara watched the eastern gate until dawn.

Ledger 10 line 076: Neri carried the blue token past marker 0ff2e949eff9. Mara watched the eastern gate until dawn.

Ledger 10 line 077: Neri carried the blue token past marker a7ab5afbdc58. Mara watched the eastern gate until dawn.

Ledger 10 line 078: Neri carried the blue token past marker a351d9f6650c. Mara watched the eastern gate until dawn.

Ledger 10 line 079: Neri carried the blue token past marker d94ced841996. Mara watched the eastern gate until dawn.

Ledger 10 line 080: Neri carried the blue token past marker cf5610d1f0a9. Mara watched the eastern gate until dawn.

Ledger 10 line 081: Neri carried the blue token past marker 4a393e1c5a08. Mara watched the eastern gate until dawn.

Ledger 10 line 082: Neri carried the blue token past marker 00d728aad6b1. Mara watched the eastern gate until dawn.

Ledger 10 line 083: Neri carried the blue token past marker c228278064f7. Mara watched the eastern gate until dawn.

Ledger 10 line 084: Neri carried the blue token past marker 8b424a026b4c. Mara watched the eastern gate until dawn.

Ledger 10 line 085: Neri carried the blue token past marker 339f2e5fc854. Mara watched the eastern gate until dawn.

Ledger 10 line 086: Neri carried the blue token past marker ea1989e02c71. Mara watched the eastern gate until dawn.

Ledger 10 line 087: Neri carried the blue token past marker 73965eeccac1. Mara watched the eastern gate until dawn.

Ledger 10 line 088: Neri carried the blue token past marker 1d0b52c56706. Mara watched the eastern gate until dawn.

Ledger 10 line 089: Neri carried the blue token past marker b0dab35acd2f. Mara watched the eastern gate until dawn.

Ledger 10 line 090: Neri carried the blue token past marker 3958b7281a87. Mara watched the eastern gate until dawn.

Ledger 10 line 091: Neri carried the blue token past marker 99043a8811d2. Mara watched the eastern gate until dawn.

Ledger 10 line 092: Neri carried the blue token past marker e1e5917b069a. Mara watched the eastern gate until dawn.

Ledger 10 line 093: Neri carried the blue token past marker 3b56719f2bee. Mara watched the eastern gate until dawn.

Ledger 10 line 094: Neri carried the blue token past marker 49a3adfdfa1e. Mara watched the eastern gate until dawn.

Ledger 10 line 095: Neri carried the blue token past marker 63f07d8e0273. Mara watched the eastern gate until dawn.

Ledger 10 line 096: Neri carried the blue token past marker 253fc42ccb83. Mara watched the eastern gate until dawn.

Ledger 10 line 097: Neri carried the blue token past marker af866ea269c9. Mara watched the eastern gate until dawn.

Ledger 10 line 098: Neri carried the blue token past marker 2deadd4c7d48. Mara watched the eastern gate until dawn.

Ledger 10 line 099: Neri carried the blue token past marker a24f7cc9d78a. Mara watched the eastern gate until dawn.

Ledger 10 line 100: Neri carried the blue token past marker 9653fd242356. Mara watched the eastern gate until dawn.

Ledger 10 line 101: Neri carried the blue token past marker 9dfbf8978e51. Mara watched the eastern gate until dawn.

Ledger 10 line 102: Neri carried the blue token past marker b11402e25f36. Mara watched the eastern gate until dawn.

Ledger 10 line 103: Neri carried the blue token past marker 5d4ecfd561bd. Mara watched the eastern gate until dawn.

Ledger 10 line 104: Neri carried the blue token past marker 38e955e605d1. Mara watched the eastern gate until dawn.

Ledger 10 line 105: Neri carried the blue token past marker 31580c0965e4. Mara watched the eastern gate until dawn.

Ledger 10 line 106: Neri carried the blue token past marker 928d0ebf8d31. Mara watched the eastern gate until dawn.

Ledger 10 line 107: Neri carried the blue token past marker 656f28209915. Mara watched the eastern gate until dawn.

Ledger 10 line 108: Neri carried the blue token past marker f7e7f4aca95e. Mara watched the eastern gate until dawn.

Ledger 10 line 109: Neri carried the blue token past marker ef1aed3eb1d0. Mara watched the eastern gate until dawn.

Ledger 10 line 110: Neri carried the blue token past marker f924c80f629f. Mara watched the eastern gate until dawn.

Ledger 10 line 111: Neri carried the blue token past marker 7fbde9aeb3f6. Mara watched the eastern gate until dawn.

Ledger 10 line 112: Neri carried the blue token past marker e867dd912b34. Mara watched the eastern gate until dawn.

Ledger 10 line 113: Neri carried the blue token past marker dec34871142f. Mara watched the eastern gate until dawn.

Ledger 10 line 114: Neri carried the blue token past marker 482f17f81315. Mara watched the eastern gate until dawn.

Ledger 10 line 115: Neri carried the blue token past marker da8f58408c90. Mara watched the eastern gate until dawn.

Ledger 10 line 116: Neri carried the blue token past marker 209511d4ea4b. Mara watched the eastern gate until dawn.

Ledger 10 line 117: Neri carried the blue token past marker c9f36ab1ecc2. Mara watched the eastern gate until dawn.

Ledger 10 line 118: Neri carried the blue token past marker 4a5a1e6b7ef2. Mara watched the eastern gate until dawn.

Ledger 10 line 119: Neri carried the blue token past marker 90c75a5cf0b8. Mara watched the eastern gate until dawn.

Ledger 10 line 120: Neri carried the blue token past marker c81baae25c86. Mara watched the eastern gate until dawn.

Ledger 10 line 121: Neri carried the blue token past marker e864ca73a01d. Mara watched the eastern gate until dawn.

Ledger 10 line 122: Neri carried the blue token past marker eb42f9202d1f. Mara watched the eastern gate until dawn.

Ledger 10 line 123: Neri carried the blue token past marker 3aa742c0a6ba. Mara watched the eastern gate until dawn.

Ledger 10 line 124: Neri carried the blue token past marker 31e6be46a52c. Mara watched the eastern gate until dawn.

Ledger 10 line 125: Neri carried the blue token past marker 4352d8f94998. Mara watched the eastern gate until dawn.

Ledger 10 line 126: Neri carried the blue token past marker fae72a53f92a. Mara watched the eastern gate until dawn.

Ledger 10 line 127: Neri carried the blue token past marker db8cfc0be40a. Mara watched the eastern gate until dawn.

Ledger 10 line 128: Neri carried the blue token past marker d5ad9fbefef0. Mara watched the eastern gate until dawn.

Ledger 10 line 129: Neri carried the blue token past marker 39436c08849e. Mara watched the eastern gate until dawn.

Ledger 10 line 130: Neri carried the blue token past marker 600007a7cff4. Mara watched the eastern gate until dawn.

Ledger 10 line 131: Neri carried the blue token past marker 0b8d51a49d3e. Mara watched the eastern gate until dawn.

Ledger 10 line 132: Neri carried the blue token past marker e51aad07a1d6. Mara watched the eastern gate until dawn.

Ledger 10 line 133: Neri carried the blue token past marker f834ed7396bf. Mara watched the eastern gate until dawn.

Ledger 10 line 134: Neri carried the blue token past marker 657bd6d279db. Mara watched the eastern gate until dawn.

Ledger 10 line 135: Neri carried the blue token past marker 793f9215560a. Mara watched the eastern gate until dawn.

Ledger 10 line 136: Neri carried the blue token past marker 34de3d465218. Mara watched the eastern gate until dawn.

Ledger 10 line 137: Neri carried the blue token past marker e4c32f716529. Mara watched the eastern gate until dawn.

Ledger 10 line 138: Neri carried the blue token past marker 9fb553bb433c. Mara watched the eastern gate until dawn.

Ledger 10 line 139: Neri carried the blue token past marker 0a35bab56e3c. Mara watched the eastern gate until dawn.

Ledger 10 line 140: Neri carried the blue token past marker 8cc2e0f65cff. Mara watched the eastern gate until dawn.
