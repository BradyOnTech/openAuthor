---
id: scene-0054
title: Recovery ledger 54
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.181334+00:00
updated_at: 2026-10-03T12:14:52.181334+00:00
---

Ledger 54 line 001: Neri carried the blue token past marker 9d4cf0858f5b. Mara watched the eastern gate until dawn.

Ledger 54 line 002: Neri carried the blue token past marker 79eafbc242ed. Mara watched the eastern gate until dawn.

Ledger 54 line 003: Neri carried the blue token past marker 4ab96ba800bd. Mara watched the eastern gate until dawn.

Ledger 54 line 004: Neri carried the blue token past marker b31079c2544a. Mara watched the eastern gate until dawn.

Ledger 54 line 005: Neri carried the blue token past marker 8c6326b5d33d. Mara watched the eastern gate until dawn.

Ledger 54 line 006: Neri carried the blue token past marker 63623ba9488d. Mara watched the eastern gate until dawn.

Ledger 54 line 007: Neri carried the blue token past marker 45cdb6ec4f4f. Mara watched the eastern gate until dawn.

Ledger 54 line 008: Neri carried the blue token past marker d7d872c0203d. Mara watched the eastern gate until dawn.

Ledger 54 line 009: Neri carried the blue token past marker 6e3cc7dbd46e. Mara watched the eastern gate until dawn.

Ledger 54 line 010: Neri carried the blue token past marker 9f12ca1e38b2. Mara watched the eastern gate until dawn.

Ledger 54 line 011: Neri carried the blue token past marker f0f4102f6737. Mara watched the eastern gate until dawn.

Ledger 54 line 012: Neri carried the blue token past marker 3feb6d8f10df. Mara watched the eastern gate until dawn.

Ledger 54 line 013: Neri carried the blue token past marker dc6ab0fb49af. Mara watched the eastern gate until dawn.

Ledger 54 line 014: Neri carried the blue token past marker aa69dd3f0afb. Mara watched the eastern gate until dawn.

Ledger 54 line 015: Neri carried the blue token past marker a30a0d387e86. Mara watched the eastern gate until dawn.

Ledger 54 line 016: Neri carried the blue token past marker a0cee91c2295. Mara watched the eastern gate until dawn.

Ledger 54 line 017: Neri carried the blue token past marker 8ed3920b35ea. Mara watched the eastern gate until dawn.

Ledger 54 line 018: Neri carried the blue token past marker b302413b0ead. Mara watched the eastern gate until dawn.

Ledger 54 line 019: Neri carried the blue token past marker bd0fb6a1723b. Mara watched the eastern gate until dawn.

Ledger 54 line 020: Neri carried the blue token past marker 842ed9ad7cb1. Mara watched the eastern gate until dawn.

Ledger 54 line 021: Neri carried the blue token past marker 16cb1b384735. Mara watched the eastern gate until dawn.

Ledger 54 line 022: Neri carried the blue token past marker 170396bf7eda. Mara watched the eastern gate until dawn.

Ledger 54 line 023: Neri carried the blue token past marker 2264d1216e04. Mara watched the eastern gate until dawn.

Ledger 54 line 024: Neri carried the blue token past marker 68dc61b0dcbf. Mara watched the eastern gate until dawn.

Ledger 54 line 025: Neri carried the blue token past marker 567721fae0f8. Mara watched the eastern gate until dawn.

Ledger 54 line 026: Neri carried the blue token past marker 4d6d9e0f9b22. Mara watched the eastern gate until dawn.

Ledger 54 line 027: Neri carried the blue token past marker bf5215b61eae. Mara watched the eastern gate until dawn.

Ledger 54 line 028: Neri carried the blue token past marker a00b24658358. Mara watched the eastern gate until dawn.

Ledger 54 line 029: Neri carried the blue token past marker faa7bb55d34c. Mara watched the eastern gate until dawn.

Ledger 54 line 030: Neri carried the blue token past marker 9f22145ee775. Mara watched the eastern gate until dawn.

Ledger 54 line 031: Neri carried the blue token past marker 7039c29ae71f. Mara watched the eastern gate until dawn.

Ledger 54 line 032: Neri carried the blue token past marker 0cd31ccb655e. Mara watched the eastern gate until dawn.

Ledger 54 line 033: Neri carried the blue token past marker 6ce983eafe7a. Mara watched the eastern gate until dawn.

Ledger 54 line 034: Neri carried the blue token past marker 69bbe6675892. Mara watched the eastern gate until dawn.

Ledger 54 line 035: Neri carried the blue token past marker e74e4a917af9. Mara watched the eastern gate until dawn.

Ledger 54 line 036: Neri carried the blue token past marker aa9c13fbad7b. Mara watched the eastern gate until dawn.

Ledger 54 line 037: Neri carried the blue token past marker e8f8d9c6b1a0. Mara watched the eastern gate until dawn.

Ledger 54 line 038: Neri carried the blue token past marker 90099f974d6b. Mara watched the eastern gate until dawn.

Ledger 54 line 039: Neri carried the blue token past marker 0dddba8d797f. Mara watched the eastern gate until dawn.

Ledger 54 line 040: Neri carried the blue token past marker ce6d7d2f2c68. Mara watched the eastern gate until dawn.

Ledger 54 line 041: Neri carried the blue token past marker ac2da127e0a9. Mara watched the eastern gate until dawn.

Ledger 54 line 042: Neri carried the blue token past marker 78903929d315. Mara watched the eastern gate until dawn.

Ledger 54 line 043: Neri carried the blue token past marker 5547eb965908. Mara watched the eastern gate until dawn.

Ledger 54 line 044: Neri carried the blue token past marker edfcecc79af0. Mara watched the eastern gate until dawn.

Ledger 54 line 045: Neri carried the blue token past marker 644d33e7a9ec. Mara watched the eastern gate until dawn.

Ledger 54 line 046: Neri carried the blue token past marker 51e82968a0ea. Mara watched the eastern gate until dawn.

Ledger 54 line 047: Neri carried the blue token past marker a79e42e6eb13. Mara watched the eastern gate until dawn.

Ledger 54 line 048: Neri carried the blue token past marker 380cce9152ff. Mara watched the eastern gate until dawn.

Ledger 54 line 049: Neri carried the blue token past marker e65db6c97728. Mara watched the eastern gate until dawn.

Ledger 54 line 050: Neri carried the blue token past marker 004048e3e065. Mara watched the eastern gate until dawn.

Ledger 54 line 051: Neri carried the blue token past marker e1356034889f. Mara watched the eastern gate until dawn.

Ledger 54 line 052: Neri carried the blue token past marker 76fe82723b8e. Mara watched the eastern gate until dawn.

Ledger 54 line 053: Neri carried the blue token past marker 05a9b882066c. Mara watched the eastern gate until dawn.

Ledger 54 line 054: Neri carried the blue token past marker d164fcdde90d. Mara watched the eastern gate until dawn.

Ledger 54 line 055: Neri carried the blue token past marker 689da3cd15eb. Mara watched the eastern gate until dawn.

Ledger 54 line 056: Neri carried the blue token past marker e6ad93ffc9b4. Mara watched the eastern gate until dawn.

Ledger 54 line 057: Neri carried the blue token past marker d9382dab275a. Mara watched the eastern gate until dawn.

Ledger 54 line 058: Neri carried the blue token past marker 111e56b7de54. Mara watched the eastern gate until dawn.

Ledger 54 line 059: Neri carried the blue token past marker 3969b5663b44. Mara watched the eastern gate until dawn.

Ledger 54 line 060: Neri carried the blue token past marker 0eb4848960e6. Mara watched the eastern gate until dawn.

Ledger 54 line 061: Neri carried the blue token past marker 84c328ac31b8. Mara watched the eastern gate until dawn.

Ledger 54 line 062: Neri carried the blue token past marker 8903764a208f. Mara watched the eastern gate until dawn.

Ledger 54 line 063: Neri carried the blue token past marker 66d599343c13. Mara watched the eastern gate until dawn.

Ledger 54 line 064: Neri carried the blue token past marker 4fd3510a1801. Mara watched the eastern gate until dawn.

Ledger 54 line 065: Neri carried the blue token past marker 00f2f0723180. Mara watched the eastern gate until dawn.

Ledger 54 line 066: Neri carried the blue token past marker bcb3960b82c9. Mara watched the eastern gate until dawn.

Ledger 54 line 067: Neri carried the blue token past marker d4c06f37243c. Mara watched the eastern gate until dawn.

Ledger 54 line 068: Neri carried the blue token past marker ba9dd92a12c8. Mara watched the eastern gate until dawn.

Ledger 54 line 069: Neri carried the blue token past marker 130d3a27c3fb. Mara watched the eastern gate until dawn.

Ledger 54 line 070: Neri carried the blue token past marker 4dac5d1a9fd2. Mara watched the eastern gate until dawn.

Ledger 54 line 071: Neri carried the blue token past marker 6b5315c73ca3. Mara watched the eastern gate until dawn.

Ledger 54 line 072: Neri carried the blue token past marker 5cfe48cbf15c. Mara watched the eastern gate until dawn.

Ledger 54 line 073: Neri carried the blue token past marker ef5349f12e82. Mara watched the eastern gate until dawn.

Ledger 54 line 074: Neri carried the blue token past marker a045166e929d. Mara watched the eastern gate until dawn.

Ledger 54 line 075: Neri carried the blue token past marker 2531472d1046. Mara watched the eastern gate until dawn.

Ledger 54 line 076: Neri carried the blue token past marker 62f0f8ce6570. Mara watched the eastern gate until dawn.

Ledger 54 line 077: Neri carried the blue token past marker a72f4e75903f. Mara watched the eastern gate until dawn.

Ledger 54 line 078: Neri carried the blue token past marker 022eaf55d8ca. Mara watched the eastern gate until dawn.

Ledger 54 line 079: Neri carried the blue token past marker b808a9373a64. Mara watched the eastern gate until dawn.

Ledger 54 line 080: Neri carried the blue token past marker 1f4e353aa9f6. Mara watched the eastern gate until dawn.

Ledger 54 line 081: Neri carried the blue token past marker 145eda39c442. Mara watched the eastern gate until dawn.

Ledger 54 line 082: Neri carried the blue token past marker 60dc7d9cb8d8. Mara watched the eastern gate until dawn.

Ledger 54 line 083: Neri carried the blue token past marker 34a8bf1719a9. Mara watched the eastern gate until dawn.

Ledger 54 line 084: Neri carried the blue token past marker 25c20200c05e. Mara watched the eastern gate until dawn.

Ledger 54 line 085: Neri carried the blue token past marker 7c23592b4c8c. Mara watched the eastern gate until dawn.

Ledger 54 line 086: Neri carried the blue token past marker deede1610417. Mara watched the eastern gate until dawn.

Ledger 54 line 087: Neri carried the blue token past marker 51c242abf2ac. Mara watched the eastern gate until dawn.

Ledger 54 line 088: Neri carried the blue token past marker 2f8542f85a81. Mara watched the eastern gate until dawn.

Ledger 54 line 089: Neri carried the blue token past marker d1242792003c. Mara watched the eastern gate until dawn.

Ledger 54 line 090: Neri carried the blue token past marker 0eb8b0b15259. Mara watched the eastern gate until dawn.

Ledger 54 line 091: Neri carried the blue token past marker c97259f2f1f3. Mara watched the eastern gate until dawn.

Ledger 54 line 092: Neri carried the blue token past marker dc2883d7ea0a. Mara watched the eastern gate until dawn.

Ledger 54 line 093: Neri carried the blue token past marker ba640db8e918. Mara watched the eastern gate until dawn.

Ledger 54 line 094: Neri carried the blue token past marker 4b443a81e24c. Mara watched the eastern gate until dawn.

Ledger 54 line 095: Neri carried the blue token past marker 2016fd87d34c. Mara watched the eastern gate until dawn.

Ledger 54 line 096: Neri carried the blue token past marker 75ba79cd96a5. Mara watched the eastern gate until dawn.

Ledger 54 line 097: Neri carried the blue token past marker 5fe385e5fa1d. Mara watched the eastern gate until dawn.

Ledger 54 line 098: Neri carried the blue token past marker de7c5562d715. Mara watched the eastern gate until dawn.

Ledger 54 line 099: Neri carried the blue token past marker 3586929be997. Mara watched the eastern gate until dawn.

Ledger 54 line 100: Neri carried the blue token past marker f2601564296c. Mara watched the eastern gate until dawn.

Ledger 54 line 101: Neri carried the blue token past marker bb74747f5316. Mara watched the eastern gate until dawn.

Ledger 54 line 102: Neri carried the blue token past marker 72f8d3eb628e. Mara watched the eastern gate until dawn.

Ledger 54 line 103: Neri carried the blue token past marker 44eb87ea9c6c. Mara watched the eastern gate until dawn.

Ledger 54 line 104: Neri carried the blue token past marker 9d07ee5ef40f. Mara watched the eastern gate until dawn.

Ledger 54 line 105: Neri carried the blue token past marker 7cc24d80dce2. Mara watched the eastern gate until dawn.

Ledger 54 line 106: Neri carried the blue token past marker 595244239c55. Mara watched the eastern gate until dawn.

Ledger 54 line 107: Neri carried the blue token past marker 76f2a4231a8c. Mara watched the eastern gate until dawn.

Ledger 54 line 108: Neri carried the blue token past marker 35cfa5f1b8f3. Mara watched the eastern gate until dawn.

Ledger 54 line 109: Neri carried the blue token past marker 0803e0a70238. Mara watched the eastern gate until dawn.

Ledger 54 line 110: Neri carried the blue token past marker 9a259ecd9cda. Mara watched the eastern gate until dawn.

Ledger 54 line 111: Neri carried the blue token past marker 902d97ae5a99. Mara watched the eastern gate until dawn.

Ledger 54 line 112: Neri carried the blue token past marker ee011495d7a8. Mara watched the eastern gate until dawn.

Ledger 54 line 113: Neri carried the blue token past marker c087ad1d3343. Mara watched the eastern gate until dawn.

Ledger 54 line 114: Neri carried the blue token past marker 461c0bfb5b08. Mara watched the eastern gate until dawn.

Ledger 54 line 115: Neri carried the blue token past marker a77ad0cab59a. Mara watched the eastern gate until dawn.

Ledger 54 line 116: Neri carried the blue token past marker 9eaa2b594c59. Mara watched the eastern gate until dawn.

Ledger 54 line 117: Neri carried the blue token past marker 1a641369e804. Mara watched the eastern gate until dawn.

Ledger 54 line 118: Neri carried the blue token past marker ab588c3becce. Mara watched the eastern gate until dawn.

Ledger 54 line 119: Neri carried the blue token past marker 3dc33af4b2e7. Mara watched the eastern gate until dawn.

Ledger 54 line 120: Neri carried the blue token past marker 30d16355360f. Mara watched the eastern gate until dawn.

Ledger 54 line 121: Neri carried the blue token past marker a4d30a083d75. Mara watched the eastern gate until dawn.

Ledger 54 line 122: Neri carried the blue token past marker b0f6ecc92012. Mara watched the eastern gate until dawn.

Ledger 54 line 123: Neri carried the blue token past marker b7cbabd822bf. Mara watched the eastern gate until dawn.

Ledger 54 line 124: Neri carried the blue token past marker b65443a47c20. Mara watched the eastern gate until dawn.

Ledger 54 line 125: Neri carried the blue token past marker f11a79819a3d. Mara watched the eastern gate until dawn.

Ledger 54 line 126: Neri carried the blue token past marker 4b6f6b9f9d6f. Mara watched the eastern gate until dawn.

Ledger 54 line 127: Neri carried the blue token past marker 9ab57346ab84. Mara watched the eastern gate until dawn.

Ledger 54 line 128: Neri carried the blue token past marker 0a0227c5402a. Mara watched the eastern gate until dawn.

Ledger 54 line 129: Neri carried the blue token past marker 75dcf7f7ef6d. Mara watched the eastern gate until dawn.

Ledger 54 line 130: Neri carried the blue token past marker 501eb0369c2b. Mara watched the eastern gate until dawn.

Ledger 54 line 131: Neri carried the blue token past marker 18506122832b. Mara watched the eastern gate until dawn.

Ledger 54 line 132: Neri carried the blue token past marker 4cac38723a8d. Mara watched the eastern gate until dawn.

Ledger 54 line 133: Neri carried the blue token past marker 5eda6f9d1066. Mara watched the eastern gate until dawn.

Ledger 54 line 134: Neri carried the blue token past marker f0a0d6360155. Mara watched the eastern gate until dawn.

Ledger 54 line 135: Neri carried the blue token past marker 837d52355300. Mara watched the eastern gate until dawn.

Ledger 54 line 136: Neri carried the blue token past marker 7e478e0fca50. Mara watched the eastern gate until dawn.

Ledger 54 line 137: Neri carried the blue token past marker 2ebf059c7475. Mara watched the eastern gate until dawn.

Ledger 54 line 138: Neri carried the blue token past marker 0ba44e10839a. Mara watched the eastern gate until dawn.

Ledger 54 line 139: Neri carried the blue token past marker 64d39239ac73. Mara watched the eastern gate until dawn.

Ledger 54 line 140: Neri carried the blue token past marker 6e836241e276. Mara watched the eastern gate until dawn.
