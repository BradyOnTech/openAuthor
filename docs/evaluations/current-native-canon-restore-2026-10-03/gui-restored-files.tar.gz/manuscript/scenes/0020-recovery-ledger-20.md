---
id: scene-0020
title: Recovery ledger 20
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.162975+00:00
updated_at: 2026-10-03T12:14:52.162975+00:00
---

Ledger 20 line 001: Neri carried the blue token past marker bdab9b0144d2. Mara watched the eastern gate until dawn.

Ledger 20 line 002: Neri carried the blue token past marker 9feaa5f4c184. Mara watched the eastern gate until dawn.

Ledger 20 line 003: Neri carried the blue token past marker c1cebf2471fd. Mara watched the eastern gate until dawn.

Ledger 20 line 004: Neri carried the blue token past marker ceb20e519162. Mara watched the eastern gate until dawn.

Ledger 20 line 005: Neri carried the blue token past marker 5acde803aeda. Mara watched the eastern gate until dawn.

Ledger 20 line 006: Neri carried the blue token past marker 803961246f2c. Mara watched the eastern gate until dawn.

Ledger 20 line 007: Neri carried the blue token past marker 37a3d0603889. Mara watched the eastern gate until dawn.

Ledger 20 line 008: Neri carried the blue token past marker 0cd356a04532. Mara watched the eastern gate until dawn.

Ledger 20 line 009: Neri carried the blue token past marker c1213e194efb. Mara watched the eastern gate until dawn.

Ledger 20 line 010: Neri carried the blue token past marker 16a29e36235f. Mara watched the eastern gate until dawn.

Ledger 20 line 011: Neri carried the blue token past marker 3bccad370eab. Mara watched the eastern gate until dawn.

Ledger 20 line 012: Neri carried the blue token past marker 83163aae8534. Mara watched the eastern gate until dawn.

Ledger 20 line 013: Neri carried the blue token past marker 374bfa2418c3. Mara watched the eastern gate until dawn.

Ledger 20 line 014: Neri carried the blue token past marker 39292a926209. Mara watched the eastern gate until dawn.

Ledger 20 line 015: Neri carried the blue token past marker 48d0dec29ec6. Mara watched the eastern gate until dawn.

Ledger 20 line 016: Neri carried the blue token past marker f0646514660c. Mara watched the eastern gate until dawn.

Ledger 20 line 017: Neri carried the blue token past marker 0981e339f14a. Mara watched the eastern gate until dawn.

Ledger 20 line 018: Neri carried the blue token past marker ba804a60f7a9. Mara watched the eastern gate until dawn.

Ledger 20 line 019: Neri carried the blue token past marker 8f099b4e2c2a. Mara watched the eastern gate until dawn.

Ledger 20 line 020: Neri carried the blue token past marker e9ff197e0b89. Mara watched the eastern gate until dawn.

Ledger 20 line 021: Neri carried the blue token past marker d8edd12e4419. Mara watched the eastern gate until dawn.

Ledger 20 line 022: Neri carried the blue token past marker 96e0d95941c6. Mara watched the eastern gate until dawn.

Ledger 20 line 023: Neri carried the blue token past marker b820e266b682. Mara watched the eastern gate until dawn.

Ledger 20 line 024: Neri carried the blue token past marker 9941afdb0af6. Mara watched the eastern gate until dawn.

Ledger 20 line 025: Neri carried the blue token past marker 35ed25a7c9f7. Mara watched the eastern gate until dawn.

Ledger 20 line 026: Neri carried the blue token past marker bb0368979f70. Mara watched the eastern gate until dawn.

Ledger 20 line 027: Neri carried the blue token past marker c169635b60e0. Mara watched the eastern gate until dawn.

Ledger 20 line 028: Neri carried the blue token past marker 6599eb0cdbda. Mara watched the eastern gate until dawn.

Ledger 20 line 029: Neri carried the blue token past marker e3f2d0799413. Mara watched the eastern gate until dawn.

Ledger 20 line 030: Neri carried the blue token past marker 078639db9de5. Mara watched the eastern gate until dawn.

Ledger 20 line 031: Neri carried the blue token past marker 788be5821394. Mara watched the eastern gate until dawn.

Ledger 20 line 032: Neri carried the blue token past marker bb8d694991e5. Mara watched the eastern gate until dawn.

Ledger 20 line 033: Neri carried the blue token past marker adbfbc97353d. Mara watched the eastern gate until dawn.

Ledger 20 line 034: Neri carried the blue token past marker 3ecc9074125f. Mara watched the eastern gate until dawn.

Ledger 20 line 035: Neri carried the blue token past marker 09e127089526. Mara watched the eastern gate until dawn.

Ledger 20 line 036: Neri carried the blue token past marker ae72fdcbfa01. Mara watched the eastern gate until dawn.

Ledger 20 line 037: Neri carried the blue token past marker 0f7d94e32d56. Mara watched the eastern gate until dawn.

Ledger 20 line 038: Neri carried the blue token past marker 00f1200d25e7. Mara watched the eastern gate until dawn.

Ledger 20 line 039: Neri carried the blue token past marker 040924e02ad8. Mara watched the eastern gate until dawn.

Ledger 20 line 040: Neri carried the blue token past marker b7eb030820aa. Mara watched the eastern gate until dawn.

Ledger 20 line 041: Neri carried the blue token past marker e85868524aa8. Mara watched the eastern gate until dawn.

Ledger 20 line 042: Neri carried the blue token past marker 9f2fd51d5b02. Mara watched the eastern gate until dawn.

Ledger 20 line 043: Neri carried the blue token past marker 66a8ec7ef29f. Mara watched the eastern gate until dawn.

Ledger 20 line 044: Neri carried the blue token past marker 83f2d994ca81. Mara watched the eastern gate until dawn.

Ledger 20 line 045: Neri carried the blue token past marker b2a4b19b8d18. Mara watched the eastern gate until dawn.

Ledger 20 line 046: Neri carried the blue token past marker 03f59e0f113c. Mara watched the eastern gate until dawn.

Ledger 20 line 047: Neri carried the blue token past marker 8d624fe76e7d. Mara watched the eastern gate until dawn.

Ledger 20 line 048: Neri carried the blue token past marker 2c07985a0846. Mara watched the eastern gate until dawn.

Ledger 20 line 049: Neri carried the blue token past marker 51f5cd0236e7. Mara watched the eastern gate until dawn.

Ledger 20 line 050: Neri carried the blue token past marker 0e27500c65a9. Mara watched the eastern gate until dawn.

Ledger 20 line 051: Neri carried the blue token past marker 2e0367c0dde1. Mara watched the eastern gate until dawn.

Ledger 20 line 052: Neri carried the blue token past marker 3649806eaae8. Mara watched the eastern gate until dawn.

Ledger 20 line 053: Neri carried the blue token past marker eba848aae467. Mara watched the eastern gate until dawn.

Ledger 20 line 054: Neri carried the blue token past marker c5a7a808cf12. Mara watched the eastern gate until dawn.

Ledger 20 line 055: Neri carried the blue token past marker 3ad1496b1d6a. Mara watched the eastern gate until dawn.

Ledger 20 line 056: Neri carried the blue token past marker 028b49a24eef. Mara watched the eastern gate until dawn.

Ledger 20 line 057: Neri carried the blue token past marker 3fd5cad97164. Mara watched the eastern gate until dawn.

Ledger 20 line 058: Neri carried the blue token past marker e83a7dfa963d. Mara watched the eastern gate until dawn.

Ledger 20 line 059: Neri carried the blue token past marker ae8df36fcc12. Mara watched the eastern gate until dawn.

Ledger 20 line 060: Neri carried the blue token past marker 1491cb986242. Mara watched the eastern gate until dawn.

Ledger 20 line 061: Neri carried the blue token past marker dd31ddbec71e. Mara watched the eastern gate until dawn.

Ledger 20 line 062: Neri carried the blue token past marker 1d6069a930d7. Mara watched the eastern gate until dawn.

Ledger 20 line 063: Neri carried the blue token past marker b4cb4466d948. Mara watched the eastern gate until dawn.

Ledger 20 line 064: Neri carried the blue token past marker fe4ec0ef06ef. Mara watched the eastern gate until dawn.

Ledger 20 line 065: Neri carried the blue token past marker aee1dd055a3c. Mara watched the eastern gate until dawn.

Ledger 20 line 066: Neri carried the blue token past marker 0f11d16afa65. Mara watched the eastern gate until dawn.

Ledger 20 line 067: Neri carried the blue token past marker 8a19e2534fcb. Mara watched the eastern gate until dawn.

Ledger 20 line 068: Neri carried the blue token past marker 456711167dd0. Mara watched the eastern gate until dawn.

Ledger 20 line 069: Neri carried the blue token past marker c8ead9038ef8. Mara watched the eastern gate until dawn.

Ledger 20 line 070: Neri carried the blue token past marker 8e07b4d565a8. Mara watched the eastern gate until dawn.

Ledger 20 line 071: Neri carried the blue token past marker cfb31fcd8a1b. Mara watched the eastern gate until dawn.

Ledger 20 line 072: Neri carried the blue token past marker ce946cd709ec. Mara watched the eastern gate until dawn.

Ledger 20 line 073: Neri carried the blue token past marker 05244d8c0399. Mara watched the eastern gate until dawn.

Ledger 20 line 074: Neri carried the blue token past marker 770b734c0b4c. Mara watched the eastern gate until dawn.

Ledger 20 line 075: Neri carried the blue token past marker 7a8370b958b0. Mara watched the eastern gate until dawn.

Ledger 20 line 076: Neri carried the blue token past marker 0d746193d499. Mara watched the eastern gate until dawn.

Ledger 20 line 077: Neri carried the blue token past marker ec4fce83b765. Mara watched the eastern gate until dawn.

Ledger 20 line 078: Neri carried the blue token past marker 87dd29077f89. Mara watched the eastern gate until dawn.

Ledger 20 line 079: Neri carried the blue token past marker 40830740c647. Mara watched the eastern gate until dawn.

Ledger 20 line 080: Neri carried the blue token past marker ef0e2664f096. Mara watched the eastern gate until dawn.

Ledger 20 line 081: Neri carried the blue token past marker 39974dfb595a. Mara watched the eastern gate until dawn.

Ledger 20 line 082: Neri carried the blue token past marker c4729b71dbe6. Mara watched the eastern gate until dawn.

Ledger 20 line 083: Neri carried the blue token past marker 61382d7dfeba. Mara watched the eastern gate until dawn.

Ledger 20 line 084: Neri carried the blue token past marker 72de5230382a. Mara watched the eastern gate until dawn.

Ledger 20 line 085: Neri carried the blue token past marker ab48a214d03d. Mara watched the eastern gate until dawn.

Ledger 20 line 086: Neri carried the blue token past marker 442f10cdd908. Mara watched the eastern gate until dawn.

Ledger 20 line 087: Neri carried the blue token past marker 29c4226b37f5. Mara watched the eastern gate until dawn.

Ledger 20 line 088: Neri carried the blue token past marker b3ec492600e8. Mara watched the eastern gate until dawn.

Ledger 20 line 089: Neri carried the blue token past marker 5eb622687b34. Mara watched the eastern gate until dawn.

Ledger 20 line 090: Neri carried the blue token past marker 5f2a9b1c1727. Mara watched the eastern gate until dawn.

Ledger 20 line 091: Neri carried the blue token past marker 07b9a109cdca. Mara watched the eastern gate until dawn.

Ledger 20 line 092: Neri carried the blue token past marker 761ade5db8d9. Mara watched the eastern gate until dawn.

Ledger 20 line 093: Neri carried the blue token past marker 797fdd2a4598. Mara watched the eastern gate until dawn.

Ledger 20 line 094: Neri carried the blue token past marker 41b18085083a. Mara watched the eastern gate until dawn.

Ledger 20 line 095: Neri carried the blue token past marker 4e15344cc15c. Mara watched the eastern gate until dawn.

Ledger 20 line 096: Neri carried the blue token past marker 70b66786e2b5. Mara watched the eastern gate until dawn.

Ledger 20 line 097: Neri carried the blue token past marker 2534284cf19c. Mara watched the eastern gate until dawn.

Ledger 20 line 098: Neri carried the blue token past marker 38d6e7b6623d. Mara watched the eastern gate until dawn.

Ledger 20 line 099: Neri carried the blue token past marker bbc9527931bb. Mara watched the eastern gate until dawn.

Ledger 20 line 100: Neri carried the blue token past marker fc6c774fa113. Mara watched the eastern gate until dawn.

Ledger 20 line 101: Neri carried the blue token past marker b2b960b3234c. Mara watched the eastern gate until dawn.

Ledger 20 line 102: Neri carried the blue token past marker 4d5af963b2dd. Mara watched the eastern gate until dawn.

Ledger 20 line 103: Neri carried the blue token past marker 4f0153b134a5. Mara watched the eastern gate until dawn.

Ledger 20 line 104: Neri carried the blue token past marker 49a8aef8f63b. Mara watched the eastern gate until dawn.

Ledger 20 line 105: Neri carried the blue token past marker b40d85a2f900. Mara watched the eastern gate until dawn.

Ledger 20 line 106: Neri carried the blue token past marker fd82df7ec604. Mara watched the eastern gate until dawn.

Ledger 20 line 107: Neri carried the blue token past marker 7db8aec303d3. Mara watched the eastern gate until dawn.

Ledger 20 line 108: Neri carried the blue token past marker 9ba939fcc9df. Mara watched the eastern gate until dawn.

Ledger 20 line 109: Neri carried the blue token past marker 780d5ef27c70. Mara watched the eastern gate until dawn.

Ledger 20 line 110: Neri carried the blue token past marker 20ef7f9498b3. Mara watched the eastern gate until dawn.

Ledger 20 line 111: Neri carried the blue token past marker 2600ba3caa79. Mara watched the eastern gate until dawn.

Ledger 20 line 112: Neri carried the blue token past marker 95c50cb2fe08. Mara watched the eastern gate until dawn.

Ledger 20 line 113: Neri carried the blue token past marker d71a25b6f303. Mara watched the eastern gate until dawn.

Ledger 20 line 114: Neri carried the blue token past marker 7a42a1de7a97. Mara watched the eastern gate until dawn.

Ledger 20 line 115: Neri carried the blue token past marker d14fa2dad416. Mara watched the eastern gate until dawn.

Ledger 20 line 116: Neri carried the blue token past marker d29d56a84f5a. Mara watched the eastern gate until dawn.

Ledger 20 line 117: Neri carried the blue token past marker 2c8891ea67c2. Mara watched the eastern gate until dawn.

Ledger 20 line 118: Neri carried the blue token past marker 6901f434d326. Mara watched the eastern gate until dawn.

Ledger 20 line 119: Neri carried the blue token past marker 6b482a5db142. Mara watched the eastern gate until dawn.

Ledger 20 line 120: Neri carried the blue token past marker eba4b44b0873. Mara watched the eastern gate until dawn.

Ledger 20 line 121: Neri carried the blue token past marker 823672c88255. Mara watched the eastern gate until dawn.

Ledger 20 line 122: Neri carried the blue token past marker 9b4e2f9dd33f. Mara watched the eastern gate until dawn.

Ledger 20 line 123: Neri carried the blue token past marker b09df616c494. Mara watched the eastern gate until dawn.

Ledger 20 line 124: Neri carried the blue token past marker e38e1d4784cc. Mara watched the eastern gate until dawn.

Ledger 20 line 125: Neri carried the blue token past marker 35ec56e31408. Mara watched the eastern gate until dawn.

Ledger 20 line 126: Neri carried the blue token past marker 7f387e0d3621. Mara watched the eastern gate until dawn.

Ledger 20 line 127: Neri carried the blue token past marker 53a40e578055. Mara watched the eastern gate until dawn.

Ledger 20 line 128: Neri carried the blue token past marker ebff2cb2c8af. Mara watched the eastern gate until dawn.

Ledger 20 line 129: Neri carried the blue token past marker d64164f3f461. Mara watched the eastern gate until dawn.

Ledger 20 line 130: Neri carried the blue token past marker 42d111484283. Mara watched the eastern gate until dawn.

Ledger 20 line 131: Neri carried the blue token past marker 5471b951a00b. Mara watched the eastern gate until dawn.

Ledger 20 line 132: Neri carried the blue token past marker 8019c1b01236. Mara watched the eastern gate until dawn.

Ledger 20 line 133: Neri carried the blue token past marker e4d710d9f5e4. Mara watched the eastern gate until dawn.

Ledger 20 line 134: Neri carried the blue token past marker 2d834d391cbd. Mara watched the eastern gate until dawn.

Ledger 20 line 135: Neri carried the blue token past marker f6778814f11f. Mara watched the eastern gate until dawn.

Ledger 20 line 136: Neri carried the blue token past marker a9c2725f5fde. Mara watched the eastern gate until dawn.

Ledger 20 line 137: Neri carried the blue token past marker 3f6f996fce5f. Mara watched the eastern gate until dawn.

Ledger 20 line 138: Neri carried the blue token past marker ae83dd00599a. Mara watched the eastern gate until dawn.

Ledger 20 line 139: Neri carried the blue token past marker 9ec7ddb0e5cb. Mara watched the eastern gate until dawn.

Ledger 20 line 140: Neri carried the blue token past marker 0380ab32c29a. Mara watched the eastern gate until dawn.
