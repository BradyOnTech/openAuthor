---
id: scene-0003
title: Recovery ledger 03
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.154350+00:00
updated_at: 2026-10-03T12:14:52.154350+00:00
---

Ledger 03 line 001: Neri carried the blue token past marker 02925afd44e2. Mara watched the eastern gate until dawn.

Ledger 03 line 002: Neri carried the blue token past marker 6d27ca189b30. Mara watched the eastern gate until dawn.

Ledger 03 line 003: Neri carried the blue token past marker e86574df7434. Mara watched the eastern gate until dawn.

Ledger 03 line 004: Neri carried the blue token past marker 5132a2037941. Mara watched the eastern gate until dawn.

Ledger 03 line 005: Neri carried the blue token past marker e8692ca200b5. Mara watched the eastern gate until dawn.

Ledger 03 line 006: Neri carried the blue token past marker a786dd9eb664. Mara watched the eastern gate until dawn.

Ledger 03 line 007: Neri carried the blue token past marker d016d339874f. Mara watched the eastern gate until dawn.

Ledger 03 line 008: Neri carried the blue token past marker 896af01783cc. Mara watched the eastern gate until dawn.

Ledger 03 line 009: Neri carried the blue token past marker b81416295c41. Mara watched the eastern gate until dawn.

Ledger 03 line 010: Neri carried the blue token past marker 088ae5cc7815. Mara watched the eastern gate until dawn.

Ledger 03 line 011: Neri carried the blue token past marker 3eadd86d2622. Mara watched the eastern gate until dawn.

Ledger 03 line 012: Neri carried the blue token past marker f2e2205ac894. Mara watched the eastern gate until dawn.

Ledger 03 line 013: Neri carried the blue token past marker 0a74839d7549. Mara watched the eastern gate until dawn.

Ledger 03 line 014: Neri carried the blue token past marker 312e4fd94e4a. Mara watched the eastern gate until dawn.

Ledger 03 line 015: Neri carried the blue token past marker 1da322b07489. Mara watched the eastern gate until dawn.

Ledger 03 line 016: Neri carried the blue token past marker b9aca0d34018. Mara watched the eastern gate until dawn.

Ledger 03 line 017: Neri carried the blue token past marker 9c681e51eadc. Mara watched the eastern gate until dawn.

Ledger 03 line 018: Neri carried the blue token past marker 9230162f07bb. Mara watched the eastern gate until dawn.

Ledger 03 line 019: Neri carried the blue token past marker d911a78dcb32. Mara watched the eastern gate until dawn.

Ledger 03 line 020: Neri carried the blue token past marker 1a3d28e3e8b5. Mara watched the eastern gate until dawn.

Ledger 03 line 021: Neri carried the blue token past marker 2b6ae957cd39. Mara watched the eastern gate until dawn.

Ledger 03 line 022: Neri carried the blue token past marker fcfcf9c8371c. Mara watched the eastern gate until dawn.

Ledger 03 line 023: Neri carried the blue token past marker d68b48a52371. Mara watched the eastern gate until dawn.

Ledger 03 line 024: Neri carried the blue token past marker 7aa552a42f5c. Mara watched the eastern gate until dawn.

Ledger 03 line 025: Neri carried the blue token past marker fe6e83cdf424. Mara watched the eastern gate until dawn.

Ledger 03 line 026: Neri carried the blue token past marker 38d02ceabc07. Mara watched the eastern gate until dawn.

Ledger 03 line 027: Neri carried the blue token past marker 7929ad7193f3. Mara watched the eastern gate until dawn.

Ledger 03 line 028: Neri carried the blue token past marker fa2276bb6ed4. Mara watched the eastern gate until dawn.

Ledger 03 line 029: Neri carried the blue token past marker 209d1ae937fd. Mara watched the eastern gate until dawn.

Ledger 03 line 030: Neri carried the blue token past marker 07d213b783bb. Mara watched the eastern gate until dawn.

Ledger 03 line 031: Neri carried the blue token past marker b78e05a91f9e. Mara watched the eastern gate until dawn.

Ledger 03 line 032: Neri carried the blue token past marker 17661ab265fd. Mara watched the eastern gate until dawn.

Ledger 03 line 033: Neri carried the blue token past marker 9183b941afb9. Mara watched the eastern gate until dawn.

Ledger 03 line 034: Neri carried the blue token past marker b964edddaeb7. Mara watched the eastern gate until dawn.

Ledger 03 line 035: Neri carried the blue token past marker bc90935f6749. Mara watched the eastern gate until dawn.

Ledger 03 line 036: Neri carried the blue token past marker 680e5a28fce8. Mara watched the eastern gate until dawn.

Ledger 03 line 037: Neri carried the blue token past marker 4238f602c1ec. Mara watched the eastern gate until dawn.

Ledger 03 line 038: Neri carried the blue token past marker d42b307bf333. Mara watched the eastern gate until dawn.

Ledger 03 line 039: Neri carried the blue token past marker 0f6f44abdd5f. Mara watched the eastern gate until dawn.

Ledger 03 line 040: Neri carried the blue token past marker 28ed784a507f. Mara watched the eastern gate until dawn.

Ledger 03 line 041: Neri carried the blue token past marker 0fe1d644f269. Mara watched the eastern gate until dawn.

Ledger 03 line 042: Neri carried the blue token past marker 0601197576bb. Mara watched the eastern gate until dawn.

Ledger 03 line 043: Neri carried the blue token past marker c5a8b70de29f. Mara watched the eastern gate until dawn.

Ledger 03 line 044: Neri carried the blue token past marker 41da87a9c46d. Mara watched the eastern gate until dawn.

Ledger 03 line 045: Neri carried the blue token past marker 3e227e7fc4ba. Mara watched the eastern gate until dawn.

Ledger 03 line 046: Neri carried the blue token past marker 11bb7970b77d. Mara watched the eastern gate until dawn.

Ledger 03 line 047: Neri carried the blue token past marker ae75e031137e. Mara watched the eastern gate until dawn.

Ledger 03 line 048: Neri carried the blue token past marker 138edee1cfa9. Mara watched the eastern gate until dawn.

Ledger 03 line 049: Neri carried the blue token past marker 2d62f07589ab. Mara watched the eastern gate until dawn.

Ledger 03 line 050: Neri carried the blue token past marker 7909ffbc5185. Mara watched the eastern gate until dawn.

Ledger 03 line 051: Neri carried the blue token past marker 1b335e77bd34. Mara watched the eastern gate until dawn.

Ledger 03 line 052: Neri carried the blue token past marker 0d6a0ea2ff2a. Mara watched the eastern gate until dawn.

Ledger 03 line 053: Neri carried the blue token past marker 73001d1fa94d. Mara watched the eastern gate until dawn.

Ledger 03 line 054: Neri carried the blue token past marker 42b3a799dbb6. Mara watched the eastern gate until dawn.

Ledger 03 line 055: Neri carried the blue token past marker 8817e0226389. Mara watched the eastern gate until dawn.

Ledger 03 line 056: Neri carried the blue token past marker 2aa7493f1a54. Mara watched the eastern gate until dawn.

Ledger 03 line 057: Neri carried the blue token past marker 6939ef8f4e31. Mara watched the eastern gate until dawn.

Ledger 03 line 058: Neri carried the blue token past marker 53ffda458d8d. Mara watched the eastern gate until dawn.

Ledger 03 line 059: Neri carried the blue token past marker a9814b39dcc6. Mara watched the eastern gate until dawn.

Ledger 03 line 060: Neri carried the blue token past marker 8edc8f2e8e46. Mara watched the eastern gate until dawn.

Ledger 03 line 061: Neri carried the blue token past marker 1632888e9710. Mara watched the eastern gate until dawn.

Ledger 03 line 062: Neri carried the blue token past marker d610210880d9. Mara watched the eastern gate until dawn.

Ledger 03 line 063: Neri carried the blue token past marker 862a464935f1. Mara watched the eastern gate until dawn.

Ledger 03 line 064: Neri carried the blue token past marker 3e4f98b52873. Mara watched the eastern gate until dawn.

Ledger 03 line 065: Neri carried the blue token past marker f8b811cac713. Mara watched the eastern gate until dawn.

Ledger 03 line 066: Neri carried the blue token past marker 1e519ef22dae. Mara watched the eastern gate until dawn.

Ledger 03 line 067: Neri carried the blue token past marker d7391ea8c807. Mara watched the eastern gate until dawn.

Ledger 03 line 068: Neri carried the blue token past marker 5fb807e302e1. Mara watched the eastern gate until dawn.

Ledger 03 line 069: Neri carried the blue token past marker e733cc817dc3. Mara watched the eastern gate until dawn.

Ledger 03 line 070: Neri carried the blue token past marker 8e7e5cebf8ea. Mara watched the eastern gate until dawn.

Ledger 03 line 071: Neri carried the blue token past marker 1f7c6c98d1d1. Mara watched the eastern gate until dawn.

Ledger 03 line 072: Neri carried the blue token past marker 73ff4cd0cc26. Mara watched the eastern gate until dawn.

Ledger 03 line 073: Neri carried the blue token past marker dc1fbde40b44. Mara watched the eastern gate until dawn.

Ledger 03 line 074: Neri carried the blue token past marker 5b9d7d96fe43. Mara watched the eastern gate until dawn.

Ledger 03 line 075: Neri carried the blue token past marker 1e4a122e57f1. Mara watched the eastern gate until dawn.

Ledger 03 line 076: Neri carried the blue token past marker 7234abaf53d8. Mara watched the eastern gate until dawn.

Ledger 03 line 077: Neri carried the blue token past marker 670fcba6db69. Mara watched the eastern gate until dawn.

Ledger 03 line 078: Neri carried the blue token past marker 217ad06ce7a1. Mara watched the eastern gate until dawn.

Ledger 03 line 079: Neri carried the blue token past marker 113d6689f91a. Mara watched the eastern gate until dawn.

Ledger 03 line 080: Neri carried the blue token past marker 6114383ecad7. Mara watched the eastern gate until dawn.

Ledger 03 line 081: Neri carried the blue token past marker 0f9fa8f33191. Mara watched the eastern gate until dawn.

Ledger 03 line 082: Neri carried the blue token past marker 799ae5ce7a13. Mara watched the eastern gate until dawn.

Ledger 03 line 083: Neri carried the blue token past marker 2bedd0d5424b. Mara watched the eastern gate until dawn.

Ledger 03 line 084: Neri carried the blue token past marker 3b6f6db2b54d. Mara watched the eastern gate until dawn.

Ledger 03 line 085: Neri carried the blue token past marker a0ecf18d87b2. Mara watched the eastern gate until dawn.

Ledger 03 line 086: Neri carried the blue token past marker 209c58ef581d. Mara watched the eastern gate until dawn.

Ledger 03 line 087: Neri carried the blue token past marker 4ad61e61c76f. Mara watched the eastern gate until dawn.

Ledger 03 line 088: Neri carried the blue token past marker ff5881dd2d9e. Mara watched the eastern gate until dawn.

Ledger 03 line 089: Neri carried the blue token past marker ec4c75687e42. Mara watched the eastern gate until dawn.

Ledger 03 line 090: Neri carried the blue token past marker 4170e9d3ecd9. Mara watched the eastern gate until dawn.

Ledger 03 line 091: Neri carried the blue token past marker 5b2c39dd6489. Mara watched the eastern gate until dawn.

Ledger 03 line 092: Neri carried the blue token past marker 723bbebc009d. Mara watched the eastern gate until dawn.

Ledger 03 line 093: Neri carried the blue token past marker 937588463d66. Mara watched the eastern gate until dawn.

Ledger 03 line 094: Neri carried the blue token past marker 2bc9373bde49. Mara watched the eastern gate until dawn.

Ledger 03 line 095: Neri carried the blue token past marker db247b8599a2. Mara watched the eastern gate until dawn.

Ledger 03 line 096: Neri carried the blue token past marker 50745b0b28d3. Mara watched the eastern gate until dawn.

Ledger 03 line 097: Neri carried the blue token past marker ee59b7dca5a2. Mara watched the eastern gate until dawn.

Ledger 03 line 098: Neri carried the blue token past marker fb8e5fe0c0e1. Mara watched the eastern gate until dawn.

Ledger 03 line 099: Neri carried the blue token past marker 2010efe35203. Mara watched the eastern gate until dawn.

Ledger 03 line 100: Neri carried the blue token past marker 4102b7922a24. Mara watched the eastern gate until dawn.

Ledger 03 line 101: Neri carried the blue token past marker cb62fa9efd17. Mara watched the eastern gate until dawn.

Ledger 03 line 102: Neri carried the blue token past marker ee33eb806e0d. Mara watched the eastern gate until dawn.

Ledger 03 line 103: Neri carried the blue token past marker 505be3183084. Mara watched the eastern gate until dawn.

Ledger 03 line 104: Neri carried the blue token past marker ed9b40fdf7e3. Mara watched the eastern gate until dawn.

Ledger 03 line 105: Neri carried the blue token past marker 29a6c41cf15f. Mara watched the eastern gate until dawn.

Ledger 03 line 106: Neri carried the blue token past marker bc613316d011. Mara watched the eastern gate until dawn.

Ledger 03 line 107: Neri carried the blue token past marker 22a6c9909c65. Mara watched the eastern gate until dawn.

Ledger 03 line 108: Neri carried the blue token past marker 31806be5b4cc. Mara watched the eastern gate until dawn.

Ledger 03 line 109: Neri carried the blue token past marker f72583fcb8d2. Mara watched the eastern gate until dawn.

Ledger 03 line 110: Neri carried the blue token past marker c8f47110c793. Mara watched the eastern gate until dawn.

Ledger 03 line 111: Neri carried the blue token past marker dec9d28689e2. Mara watched the eastern gate until dawn.

Ledger 03 line 112: Neri carried the blue token past marker 0d1a736bb9d8. Mara watched the eastern gate until dawn.

Ledger 03 line 113: Neri carried the blue token past marker 0a9c4b7b8337. Mara watched the eastern gate until dawn.

Ledger 03 line 114: Neri carried the blue token past marker b8916813d431. Mara watched the eastern gate until dawn.

Ledger 03 line 115: Neri carried the blue token past marker 459f2d5c5466. Mara watched the eastern gate until dawn.

Ledger 03 line 116: Neri carried the blue token past marker e08a7489eaa3. Mara watched the eastern gate until dawn.

Ledger 03 line 117: Neri carried the blue token past marker d1241063a6aa. Mara watched the eastern gate until dawn.

Ledger 03 line 118: Neri carried the blue token past marker d6c494da3cfe. Mara watched the eastern gate until dawn.

Ledger 03 line 119: Neri carried the blue token past marker 90ef294d379d. Mara watched the eastern gate until dawn.

Ledger 03 line 120: Neri carried the blue token past marker 1aa0de0befe5. Mara watched the eastern gate until dawn.

Ledger 03 line 121: Neri carried the blue token past marker 8c08c45d41c4. Mara watched the eastern gate until dawn.

Ledger 03 line 122: Neri carried the blue token past marker 7a259ef21b27. Mara watched the eastern gate until dawn.

Ledger 03 line 123: Neri carried the blue token past marker aab13fedade1. Mara watched the eastern gate until dawn.

Ledger 03 line 124: Neri carried the blue token past marker aec5a914159e. Mara watched the eastern gate until dawn.

Ledger 03 line 125: Neri carried the blue token past marker 2e2b30c61e2d. Mara watched the eastern gate until dawn.

Ledger 03 line 126: Neri carried the blue token past marker c924776018ca. Mara watched the eastern gate until dawn.

Ledger 03 line 127: Neri carried the blue token past marker bacdb4a1476b. Mara watched the eastern gate until dawn.

Ledger 03 line 128: Neri carried the blue token past marker 16d1b193134a. Mara watched the eastern gate until dawn.

Ledger 03 line 129: Neri carried the blue token past marker 902d46f61a27. Mara watched the eastern gate until dawn.

Ledger 03 line 130: Neri carried the blue token past marker 46b251bbf24c. Mara watched the eastern gate until dawn.

Ledger 03 line 131: Neri carried the blue token past marker 3e0a37aa9ebd. Mara watched the eastern gate until dawn.

Ledger 03 line 132: Neri carried the blue token past marker 96db2cfcfc08. Mara watched the eastern gate until dawn.

Ledger 03 line 133: Neri carried the blue token past marker 62b50ab8417d. Mara watched the eastern gate until dawn.

Ledger 03 line 134: Neri carried the blue token past marker fa6d5ea5c315. Mara watched the eastern gate until dawn.

Ledger 03 line 135: Neri carried the blue token past marker 84e851d8d1a5. Mara watched the eastern gate until dawn.

Ledger 03 line 136: Neri carried the blue token past marker 25fddeeebdc3. Mara watched the eastern gate until dawn.

Ledger 03 line 137: Neri carried the blue token past marker fc6e3d1944b8. Mara watched the eastern gate until dawn.

Ledger 03 line 138: Neri carried the blue token past marker 9243d97029b4. Mara watched the eastern gate until dawn.

Ledger 03 line 139: Neri carried the blue token past marker 36f7bbbae0bd. Mara watched the eastern gate until dawn.

Ledger 03 line 140: Neri carried the blue token past marker 21eb36eaf4da. Mara watched the eastern gate until dawn.
