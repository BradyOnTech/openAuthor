---
id: scene-0024
title: Recovery ledger 24
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.165438+00:00
updated_at: 2026-10-03T12:14:52.165438+00:00
---

Ledger 24 line 001: Neri carried the blue token past marker e14747bfb6f1. Mara watched the eastern gate until dawn.

Ledger 24 line 002: Neri carried the blue token past marker f7ca5c6a6126. Mara watched the eastern gate until dawn.

Ledger 24 line 003: Neri carried the blue token past marker 5327e134f7e7. Mara watched the eastern gate until dawn.

Ledger 24 line 004: Neri carried the blue token past marker 5b0e16dc06d0. Mara watched the eastern gate until dawn.

Ledger 24 line 005: Neri carried the blue token past marker aa3bb46d25ae. Mara watched the eastern gate until dawn.

Ledger 24 line 006: Neri carried the blue token past marker dddfbc81cfeb. Mara watched the eastern gate until dawn.

Ledger 24 line 007: Neri carried the blue token past marker 4d8974777af1. Mara watched the eastern gate until dawn.

Ledger 24 line 008: Neri carried the blue token past marker a2582a70d577. Mara watched the eastern gate until dawn.

Ledger 24 line 009: Neri carried the blue token past marker 6373e6d920e1. Mara watched the eastern gate until dawn.

Ledger 24 line 010: Neri carried the blue token past marker 03a36b3e90e3. Mara watched the eastern gate until dawn.

Ledger 24 line 011: Neri carried the blue token past marker 0e9e99055ec6. Mara watched the eastern gate until dawn.

Ledger 24 line 012: Neri carried the blue token past marker 8fe49fdb77ef. Mara watched the eastern gate until dawn.

Ledger 24 line 013: Neri carried the blue token past marker 0cb0924a8175. Mara watched the eastern gate until dawn.

Ledger 24 line 014: Neri carried the blue token past marker 7f5f8d2c2a4d. Mara watched the eastern gate until dawn.

Ledger 24 line 015: Neri carried the blue token past marker 0f707a9bcf7e. Mara watched the eastern gate until dawn.

Ledger 24 line 016: Neri carried the blue token past marker 9f18020448f4. Mara watched the eastern gate until dawn.

Ledger 24 line 017: Neri carried the blue token past marker cdd644d76ccb. Mara watched the eastern gate until dawn.

Ledger 24 line 018: Neri carried the blue token past marker d4b59236a3ef. Mara watched the eastern gate until dawn.

Ledger 24 line 019: Neri carried the blue token past marker 93ea98b536f7. Mara watched the eastern gate until dawn.

Ledger 24 line 020: Neri carried the blue token past marker a566edc58141. Mara watched the eastern gate until dawn.

Ledger 24 line 021: Neri carried the blue token past marker e52be35490b2. Mara watched the eastern gate until dawn.

Ledger 24 line 022: Neri carried the blue token past marker 6d63b29b2da4. Mara watched the eastern gate until dawn.

Ledger 24 line 023: Neri carried the blue token past marker 1d499c7b7dd1. Mara watched the eastern gate until dawn.

Ledger 24 line 024: Neri carried the blue token past marker a274a2789dd1. Mara watched the eastern gate until dawn.

Ledger 24 line 025: Neri carried the blue token past marker dcd0d68f7eeb. Mara watched the eastern gate until dawn.

Ledger 24 line 026: Neri carried the blue token past marker 7be9abcbd970. Mara watched the eastern gate until dawn.

Ledger 24 line 027: Neri carried the blue token past marker f12ffc03f599. Mara watched the eastern gate until dawn.

Ledger 24 line 028: Neri carried the blue token past marker 3ad3b420c52b. Mara watched the eastern gate until dawn.

Ledger 24 line 029: Neri carried the blue token past marker ba8648fd30e1. Mara watched the eastern gate until dawn.

Ledger 24 line 030: Neri carried the blue token past marker 998e09917c94. Mara watched the eastern gate until dawn.

Ledger 24 line 031: Neri carried the blue token past marker 43070fd2094b. Mara watched the eastern gate until dawn.

Ledger 24 line 032: Neri carried the blue token past marker 846c57d54cf5. Mara watched the eastern gate until dawn.

Ledger 24 line 033: Neri carried the blue token past marker 0fcb8f61f79f. Mara watched the eastern gate until dawn.

Ledger 24 line 034: Neri carried the blue token past marker fee58b03fe4e. Mara watched the eastern gate until dawn.

Ledger 24 line 035: Neri carried the blue token past marker 456924086ee1. Mara watched the eastern gate until dawn.

Ledger 24 line 036: Neri carried the blue token past marker 97b9332cbcde. Mara watched the eastern gate until dawn.

Ledger 24 line 037: Neri carried the blue token past marker 208406b9152b. Mara watched the eastern gate until dawn.

Ledger 24 line 038: Neri carried the blue token past marker a3ec4ea0bbfb. Mara watched the eastern gate until dawn.

Ledger 24 line 039: Neri carried the blue token past marker bc688cc6b2e4. Mara watched the eastern gate until dawn.

Ledger 24 line 040: Neri carried the blue token past marker 68328522b8d9. Mara watched the eastern gate until dawn.

Ledger 24 line 041: Neri carried the blue token past marker 5909b6496312. Mara watched the eastern gate until dawn.

Ledger 24 line 042: Neri carried the blue token past marker 6a3fa062d922. Mara watched the eastern gate until dawn.

Ledger 24 line 043: Neri carried the blue token past marker 3d6c274cc81c. Mara watched the eastern gate until dawn.

Ledger 24 line 044: Neri carried the blue token past marker cf47af9ac9c0. Mara watched the eastern gate until dawn.

Ledger 24 line 045: Neri carried the blue token past marker b65dcf6cdd40. Mara watched the eastern gate until dawn.

Ledger 24 line 046: Neri carried the blue token past marker 8b0ebb7a4e23. Mara watched the eastern gate until dawn.

Ledger 24 line 047: Neri carried the blue token past marker 765415747c98. Mara watched the eastern gate until dawn.

Ledger 24 line 048: Neri carried the blue token past marker 6f811e446b3b. Mara watched the eastern gate until dawn.

Ledger 24 line 049: Neri carried the blue token past marker 8a018d40a402. Mara watched the eastern gate until dawn.

Ledger 24 line 050: Neri carried the blue token past marker 96dee6780f2a. Mara watched the eastern gate until dawn.

Ledger 24 line 051: Neri carried the blue token past marker dac967a19073. Mara watched the eastern gate until dawn.

Ledger 24 line 052: Neri carried the blue token past marker 331e1b90d5a1. Mara watched the eastern gate until dawn.

Ledger 24 line 053: Neri carried the blue token past marker e4091b0a16d3. Mara watched the eastern gate until dawn.

Ledger 24 line 054: Neri carried the blue token past marker 70d1f6420d54. Mara watched the eastern gate until dawn.

Ledger 24 line 055: Neri carried the blue token past marker 72dc274d4227. Mara watched the eastern gate until dawn.

Ledger 24 line 056: Neri carried the blue token past marker 4e6f9095927d. Mara watched the eastern gate until dawn.

Ledger 24 line 057: Neri carried the blue token past marker 47031d37cc2c. Mara watched the eastern gate until dawn.

Ledger 24 line 058: Neri carried the blue token past marker 3211423f4917. Mara watched the eastern gate until dawn.

Ledger 24 line 059: Neri carried the blue token past marker ac1cbeef67ab. Mara watched the eastern gate until dawn.

Ledger 24 line 060: Neri carried the blue token past marker 907781b1d400. Mara watched the eastern gate until dawn.

Ledger 24 line 061: Neri carried the blue token past marker a6fac0fcbe1a. Mara watched the eastern gate until dawn.

Ledger 24 line 062: Neri carried the blue token past marker 2451d689d331. Mara watched the eastern gate until dawn.

Ledger 24 line 063: Neri carried the blue token past marker 060dd92dd63d. Mara watched the eastern gate until dawn.

Ledger 24 line 064: Neri carried the blue token past marker e9e4fdb6d8e5. Mara watched the eastern gate until dawn.

Ledger 24 line 065: Neri carried the blue token past marker 785dcc10298e. Mara watched the eastern gate until dawn.

Ledger 24 line 066: Neri carried the blue token past marker a7e70b17fe45. Mara watched the eastern gate until dawn.

Ledger 24 line 067: Neri carried the blue token past marker 4785fb1f742f. Mara watched the eastern gate until dawn.

Ledger 24 line 068: Neri carried the blue token past marker 8b7bb35f46e2. Mara watched the eastern gate until dawn.

Ledger 24 line 069: Neri carried the blue token past marker 26631a76a7d5. Mara watched the eastern gate until dawn.

Ledger 24 line 070: Neri carried the blue token past marker db5eb3ee6c7c. Mara watched the eastern gate until dawn.

Ledger 24 line 071: Neri carried the blue token past marker b0709ef0ac03. Mara watched the eastern gate until dawn.

Ledger 24 line 072: Neri carried the blue token past marker 2bfa6879fb24. Mara watched the eastern gate until dawn.

Ledger 24 line 073: Neri carried the blue token past marker 4115818525a8. Mara watched the eastern gate until dawn.

Ledger 24 line 074: Neri carried the blue token past marker 3aeb924b0ba7. Mara watched the eastern gate until dawn.

Ledger 24 line 075: Neri carried the blue token past marker 6b34edceac3f. Mara watched the eastern gate until dawn.

Ledger 24 line 076: Neri carried the blue token past marker 6d0ddc6a0a49. Mara watched the eastern gate until dawn.

Ledger 24 line 077: Neri carried the blue token past marker b06e04588f74. Mara watched the eastern gate until dawn.

Ledger 24 line 078: Neri carried the blue token past marker 3ac381875fc5. Mara watched the eastern gate until dawn.

Ledger 24 line 079: Neri carried the blue token past marker 922976ea12d6. Mara watched the eastern gate until dawn.

Ledger 24 line 080: Neri carried the blue token past marker aaf0f09b18a4. Mara watched the eastern gate until dawn.

Ledger 24 line 081: Neri carried the blue token past marker 0ecaf665e496. Mara watched the eastern gate until dawn.

Ledger 24 line 082: Neri carried the blue token past marker e1988bc9bc7f. Mara watched the eastern gate until dawn.

Ledger 24 line 083: Neri carried the blue token past marker ed59620d4ce7. Mara watched the eastern gate until dawn.

Ledger 24 line 084: Neri carried the blue token past marker 7ee5a4652093. Mara watched the eastern gate until dawn.

Ledger 24 line 085: Neri carried the blue token past marker d02770b01c31. Mara watched the eastern gate until dawn.

Ledger 24 line 086: Neri carried the blue token past marker 7b18647d0c82. Mara watched the eastern gate until dawn.

Ledger 24 line 087: Neri carried the blue token past marker 4b157bedceb1. Mara watched the eastern gate until dawn.

Ledger 24 line 088: Neri carried the blue token past marker 6e6e682ac566. Mara watched the eastern gate until dawn.

Ledger 24 line 089: Neri carried the blue token past marker bf4546536433. Mara watched the eastern gate until dawn.

Ledger 24 line 090: Neri carried the blue token past marker 5f0504f1343e. Mara watched the eastern gate until dawn.

Ledger 24 line 091: Neri carried the blue token past marker aa1d7b4986cc. Mara watched the eastern gate until dawn.

Ledger 24 line 092: Neri carried the blue token past marker 8003f3c0dd2f. Mara watched the eastern gate until dawn.

Ledger 24 line 093: Neri carried the blue token past marker 1d0bf5e54bb7. Mara watched the eastern gate until dawn.

Ledger 24 line 094: Neri carried the blue token past marker cadfbd667195. Mara watched the eastern gate until dawn.

Ledger 24 line 095: Neri carried the blue token past marker 612fc6188e2c. Mara watched the eastern gate until dawn.

Ledger 24 line 096: Neri carried the blue token past marker 9cddd78ed920. Mara watched the eastern gate until dawn.

Ledger 24 line 097: Neri carried the blue token past marker 0b973ef31289. Mara watched the eastern gate until dawn.

Ledger 24 line 098: Neri carried the blue token past marker 67cbd49f38d7. Mara watched the eastern gate until dawn.

Ledger 24 line 099: Neri carried the blue token past marker 340137ce35d6. Mara watched the eastern gate until dawn.

Ledger 24 line 100: Neri carried the blue token past marker d47cf4f3e17e. Mara watched the eastern gate until dawn.

Ledger 24 line 101: Neri carried the blue token past marker 949e7e626e43. Mara watched the eastern gate until dawn.

Ledger 24 line 102: Neri carried the blue token past marker 1203369c398f. Mara watched the eastern gate until dawn.

Ledger 24 line 103: Neri carried the blue token past marker 7ba9cf359f0e. Mara watched the eastern gate until dawn.

Ledger 24 line 104: Neri carried the blue token past marker f4569cd7a710. Mara watched the eastern gate until dawn.

Ledger 24 line 105: Neri carried the blue token past marker f0946b1629c9. Mara watched the eastern gate until dawn.

Ledger 24 line 106: Neri carried the blue token past marker 7e2faeb40e39. Mara watched the eastern gate until dawn.

Ledger 24 line 107: Neri carried the blue token past marker ce1dd6d8dc22. Mara watched the eastern gate until dawn.

Ledger 24 line 108: Neri carried the blue token past marker 6cc11daa2c90. Mara watched the eastern gate until dawn.

Ledger 24 line 109: Neri carried the blue token past marker 2106f52a5861. Mara watched the eastern gate until dawn.

Ledger 24 line 110: Neri carried the blue token past marker 618c8134c273. Mara watched the eastern gate until dawn.

Ledger 24 line 111: Neri carried the blue token past marker dd6c7ba6abcc. Mara watched the eastern gate until dawn.

Ledger 24 line 112: Neri carried the blue token past marker c7d2e5b78a42. Mara watched the eastern gate until dawn.

Ledger 24 line 113: Neri carried the blue token past marker ba8565bb4dc2. Mara watched the eastern gate until dawn.

Ledger 24 line 114: Neri carried the blue token past marker 8f13e8dd3b89. Mara watched the eastern gate until dawn.

Ledger 24 line 115: Neri carried the blue token past marker d221d64d42c4. Mara watched the eastern gate until dawn.

Ledger 24 line 116: Neri carried the blue token past marker 408b7391fc17. Mara watched the eastern gate until dawn.

Ledger 24 line 117: Neri carried the blue token past marker d7e377016670. Mara watched the eastern gate until dawn.

Ledger 24 line 118: Neri carried the blue token past marker 6f72a1a25427. Mara watched the eastern gate until dawn.

Ledger 24 line 119: Neri carried the blue token past marker eecef323759a. Mara watched the eastern gate until dawn.

Ledger 24 line 120: Neri carried the blue token past marker 0db946acff83. Mara watched the eastern gate until dawn.

Ledger 24 line 121: Neri carried the blue token past marker 54ab663139ca. Mara watched the eastern gate until dawn.

Ledger 24 line 122: Neri carried the blue token past marker baedf857c202. Mara watched the eastern gate until dawn.

Ledger 24 line 123: Neri carried the blue token past marker 329ab67680da. Mara watched the eastern gate until dawn.

Ledger 24 line 124: Neri carried the blue token past marker 1c888f71c294. Mara watched the eastern gate until dawn.

Ledger 24 line 125: Neri carried the blue token past marker af45a7ecbd25. Mara watched the eastern gate until dawn.

Ledger 24 line 126: Neri carried the blue token past marker f0ffa88fe224. Mara watched the eastern gate until dawn.

Ledger 24 line 127: Neri carried the blue token past marker a5d19e1317a4. Mara watched the eastern gate until dawn.

Ledger 24 line 128: Neri carried the blue token past marker 1370acc9cbf1. Mara watched the eastern gate until dawn.

Ledger 24 line 129: Neri carried the blue token past marker 1a84ab3d04fa. Mara watched the eastern gate until dawn.

Ledger 24 line 130: Neri carried the blue token past marker dc22301b74bf. Mara watched the eastern gate until dawn.

Ledger 24 line 131: Neri carried the blue token past marker 2172939e5156. Mara watched the eastern gate until dawn.

Ledger 24 line 132: Neri carried the blue token past marker e258a0e07606. Mara watched the eastern gate until dawn.

Ledger 24 line 133: Neri carried the blue token past marker 1f15f27db98b. Mara watched the eastern gate until dawn.

Ledger 24 line 134: Neri carried the blue token past marker 4e6bea41b9ce. Mara watched the eastern gate until dawn.

Ledger 24 line 135: Neri carried the blue token past marker d02c5e18544d. Mara watched the eastern gate until dawn.

Ledger 24 line 136: Neri carried the blue token past marker eaf0888d44b5. Mara watched the eastern gate until dawn.

Ledger 24 line 137: Neri carried the blue token past marker 13bffff02a9b. Mara watched the eastern gate until dawn.

Ledger 24 line 138: Neri carried the blue token past marker 2dbc50331776. Mara watched the eastern gate until dawn.

Ledger 24 line 139: Neri carried the blue token past marker 8b879d223133. Mara watched the eastern gate until dawn.

Ledger 24 line 140: Neri carried the blue token past marker 26842e3e44f1. Mara watched the eastern gate until dawn.
