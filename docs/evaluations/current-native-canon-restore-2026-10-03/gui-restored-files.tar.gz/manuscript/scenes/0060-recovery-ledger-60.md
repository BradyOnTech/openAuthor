---
id: scene-0060
title: Recovery ledger 60
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.184962+00:00
updated_at: 2026-10-03T12:14:52.184962+00:00
---

Ledger 60 line 001: Neri carried the blue token past marker 4064f189ec76. Mara watched the eastern gate until dawn.

Ledger 60 line 002: Neri carried the blue token past marker d0f29e77d698. Mara watched the eastern gate until dawn.

Ledger 60 line 003: Neri carried the blue token past marker de8af25e7bef. Mara watched the eastern gate until dawn.

Ledger 60 line 004: Neri carried the blue token past marker f519a5325d72. Mara watched the eastern gate until dawn.

Ledger 60 line 005: Neri carried the blue token past marker fa7f1986967a. Mara watched the eastern gate until dawn.

Ledger 60 line 006: Neri carried the blue token past marker a82396afa6d8. Mara watched the eastern gate until dawn.

Ledger 60 line 007: Neri carried the blue token past marker fe94722009be. Mara watched the eastern gate until dawn.

Ledger 60 line 008: Neri carried the blue token past marker e62b6126a62f. Mara watched the eastern gate until dawn.

Ledger 60 line 009: Neri carried the blue token past marker 66f9f726065f. Mara watched the eastern gate until dawn.

Ledger 60 line 010: Neri carried the blue token past marker 6ac47ce420e9. Mara watched the eastern gate until dawn.

Ledger 60 line 011: Neri carried the blue token past marker 6264d8c96943. Mara watched the eastern gate until dawn.

Ledger 60 line 012: Neri carried the blue token past marker 16f093cc98b1. Mara watched the eastern gate until dawn.

Ledger 60 line 013: Neri carried the blue token past marker 29cb1fc110fc. Mara watched the eastern gate until dawn.

Ledger 60 line 014: Neri carried the blue token past marker d8bcedd63ffd. Mara watched the eastern gate until dawn.

Ledger 60 line 015: Neri carried the blue token past marker a6a71e24866d. Mara watched the eastern gate until dawn.

Ledger 60 line 016: Neri carried the blue token past marker 9b51550ee7ff. Mara watched the eastern gate until dawn.

Ledger 60 line 017: Neri carried the blue token past marker c9eea05d6595. Mara watched the eastern gate until dawn.

Ledger 60 line 018: Neri carried the blue token past marker 2d2bcaa44ff2. Mara watched the eastern gate until dawn.

Ledger 60 line 019: Neri carried the blue token past marker ca48f31d6b90. Mara watched the eastern gate until dawn.

Ledger 60 line 020: Neri carried the blue token past marker d973cf4b04c4. Mara watched the eastern gate until dawn.

Ledger 60 line 021: Neri carried the blue token past marker d6c4f5d23f0a. Mara watched the eastern gate until dawn.

Ledger 60 line 022: Neri carried the blue token past marker c3e02dfb55b5. Mara watched the eastern gate until dawn.

Ledger 60 line 023: Neri carried the blue token past marker a47de23533c8. Mara watched the eastern gate until dawn.

Ledger 60 line 024: Neri carried the blue token past marker 77426e00cd68. Mara watched the eastern gate until dawn.

Ledger 60 line 025: Neri carried the blue token past marker 33afb7aedc78. Mara watched the eastern gate until dawn.

Ledger 60 line 026: Neri carried the blue token past marker 3bc4d87d97ee. Mara watched the eastern gate until dawn.

Ledger 60 line 027: Neri carried the blue token past marker cae17bef22af. Mara watched the eastern gate until dawn.

Ledger 60 line 028: Neri carried the blue token past marker c3dbde1b4d0b. Mara watched the eastern gate until dawn.

Ledger 60 line 029: Neri carried the blue token past marker cba4f773fa50. Mara watched the eastern gate until dawn.

Ledger 60 line 030: Neri carried the blue token past marker 360fe9510c4e. Mara watched the eastern gate until dawn.

Ledger 60 line 031: Neri carried the blue token past marker 5436ead8c3de. Mara watched the eastern gate until dawn.

Ledger 60 line 032: Neri carried the blue token past marker 095cd563887e. Mara watched the eastern gate until dawn.

Ledger 60 line 033: Neri carried the blue token past marker 82c3277aab99. Mara watched the eastern gate until dawn.

Ledger 60 line 034: Neri carried the blue token past marker c169b6d55421. Mara watched the eastern gate until dawn.

Ledger 60 line 035: Neri carried the blue token past marker d80024eb716b. Mara watched the eastern gate until dawn.

Ledger 60 line 036: Neri carried the blue token past marker 92f9420231e8. Mara watched the eastern gate until dawn.

Ledger 60 line 037: Neri carried the blue token past marker 8c91f6b11665. Mara watched the eastern gate until dawn.

Ledger 60 line 038: Neri carried the blue token past marker fd1797027f5b. Mara watched the eastern gate until dawn.

Ledger 60 line 039: Neri carried the blue token past marker 058ea148542b. Mara watched the eastern gate until dawn.

Ledger 60 line 040: Neri carried the blue token past marker 812071cfef4c. Mara watched the eastern gate until dawn.

Ledger 60 line 041: Neri carried the blue token past marker 20bb574bf4ed. Mara watched the eastern gate until dawn.

Ledger 60 line 042: Neri carried the blue token past marker 45135e79de08. Mara watched the eastern gate until dawn.

Ledger 60 line 043: Neri carried the blue token past marker 7e0fa74e28e9. Mara watched the eastern gate until dawn.

Ledger 60 line 044: Neri carried the blue token past marker 332fc390f2a8. Mara watched the eastern gate until dawn.

Ledger 60 line 045: Neri carried the blue token past marker 23e9eae6686d. Mara watched the eastern gate until dawn.

Ledger 60 line 046: Neri carried the blue token past marker 2e8c9391edaf. Mara watched the eastern gate until dawn.

Ledger 60 line 047: Neri carried the blue token past marker 345691c412ea. Mara watched the eastern gate until dawn.

Ledger 60 line 048: Neri carried the blue token past marker 33172d351135. Mara watched the eastern gate until dawn.

Ledger 60 line 049: Neri carried the blue token past marker b94f6f7862b7. Mara watched the eastern gate until dawn.

Ledger 60 line 050: Neri carried the blue token past marker 772a605c24ba. Mara watched the eastern gate until dawn.

Ledger 60 line 051: Neri carried the blue token past marker 962aac5ff648. Mara watched the eastern gate until dawn.

Ledger 60 line 052: Neri carried the blue token past marker 23f4f106b9b2. Mara watched the eastern gate until dawn.

Ledger 60 line 053: Neri carried the blue token past marker 714671542ea5. Mara watched the eastern gate until dawn.

Ledger 60 line 054: Neri carried the blue token past marker 9b75439fb94f. Mara watched the eastern gate until dawn.

Ledger 60 line 055: Neri carried the blue token past marker 399d98c05950. Mara watched the eastern gate until dawn.

Ledger 60 line 056: Neri carried the blue token past marker 0a149d79203d. Mara watched the eastern gate until dawn.

Ledger 60 line 057: Neri carried the blue token past marker c1bf45c19b90. Mara watched the eastern gate until dawn.

Ledger 60 line 058: Neri carried the blue token past marker 89f93f743367. Mara watched the eastern gate until dawn.

Ledger 60 line 059: Neri carried the blue token past marker ed0312375a11. Mara watched the eastern gate until dawn.

Ledger 60 line 060: Neri carried the blue token past marker aaf7cb16b68b. Mara watched the eastern gate until dawn.

Ledger 60 line 061: Neri carried the blue token past marker 372e5a80caf7. Mara watched the eastern gate until dawn.

Ledger 60 line 062: Neri carried the blue token past marker 675463067f34. Mara watched the eastern gate until dawn.

Ledger 60 line 063: Neri carried the blue token past marker 63a2bfb5335f. Mara watched the eastern gate until dawn.

Ledger 60 line 064: Neri carried the blue token past marker a761bb238da1. Mara watched the eastern gate until dawn.

Ledger 60 line 065: Neri carried the blue token past marker 4838a2da21e5. Mara watched the eastern gate until dawn.

Ledger 60 line 066: Neri carried the blue token past marker dc2dee284933. Mara watched the eastern gate until dawn.

Ledger 60 line 067: Neri carried the blue token past marker d4b0880a6dbd. Mara watched the eastern gate until dawn.

Ledger 60 line 068: Neri carried the blue token past marker 149246e4f113. Mara watched the eastern gate until dawn.

Ledger 60 line 069: Neri carried the blue token past marker cbc299ee9ba6. Mara watched the eastern gate until dawn.

Ledger 60 line 070: Neri carried the blue token past marker a13fdba56413. Mara watched the eastern gate until dawn.

Ledger 60 line 071: Neri carried the blue token past marker 4d2b04ca4c26. Mara watched the eastern gate until dawn.

Ledger 60 line 072: Neri carried the blue token past marker fa587c253394. Mara watched the eastern gate until dawn.

Ledger 60 line 073: Neri carried the blue token past marker 9429e026b0c8. Mara watched the eastern gate until dawn.

Ledger 60 line 074: Neri carried the blue token past marker 5dcbe1f6683d. Mara watched the eastern gate until dawn.

Ledger 60 line 075: Neri carried the blue token past marker 3828cfb7043c. Mara watched the eastern gate until dawn.

Ledger 60 line 076: Neri carried the blue token past marker aab6ae93b44d. Mara watched the eastern gate until dawn.

Ledger 60 line 077: Neri carried the blue token past marker a9f3761d32ee. Mara watched the eastern gate until dawn.

Ledger 60 line 078: Neri carried the blue token past marker 8ff2f50891f3. Mara watched the eastern gate until dawn.

Ledger 60 line 079: Neri carried the blue token past marker 90974d42510d. Mara watched the eastern gate until dawn.

Ledger 60 line 080: Neri carried the blue token past marker 4a032959f283. Mara watched the eastern gate until dawn.

Ledger 60 line 081: Neri carried the blue token past marker 9de0556f8d16. Mara watched the eastern gate until dawn.

Ledger 60 line 082: Neri carried the blue token past marker 0748d32aebc0. Mara watched the eastern gate until dawn.

Ledger 60 line 083: Neri carried the blue token past marker d5eefe8d07cc. Mara watched the eastern gate until dawn.

Ledger 60 line 084: Neri carried the blue token past marker e7907dfad84c. Mara watched the eastern gate until dawn.

Ledger 60 line 085: Neri carried the blue token past marker 0f411c5d4693. Mara watched the eastern gate until dawn.

Ledger 60 line 086: Neri carried the blue token past marker ecda9abd3d56. Mara watched the eastern gate until dawn.

Ledger 60 line 087: Neri carried the blue token past marker a0d7e19e7356. Mara watched the eastern gate until dawn.

Ledger 60 line 088: Neri carried the blue token past marker 7fdf980ac6b4. Mara watched the eastern gate until dawn.

Ledger 60 line 089: Neri carried the blue token past marker 7c4a124c39c6. Mara watched the eastern gate until dawn.

Ledger 60 line 090: Neri carried the blue token past marker 969d7c53639f. Mara watched the eastern gate until dawn.

Ledger 60 line 091: Neri carried the blue token past marker 079cd548c75c. Mara watched the eastern gate until dawn.

Ledger 60 line 092: Neri carried the blue token past marker 5bdfe2a7ce0c. Mara watched the eastern gate until dawn.

Ledger 60 line 093: Neri carried the blue token past marker f0936ec1dc11. Mara watched the eastern gate until dawn.

Ledger 60 line 094: Neri carried the blue token past marker 3d508295284b. Mara watched the eastern gate until dawn.

Ledger 60 line 095: Neri carried the blue token past marker 038b7f77d139. Mara watched the eastern gate until dawn.

Ledger 60 line 096: Neri carried the blue token past marker 1511fd5558cd. Mara watched the eastern gate until dawn.

Ledger 60 line 097: Neri carried the blue token past marker 713847c6940c. Mara watched the eastern gate until dawn.

Ledger 60 line 098: Neri carried the blue token past marker 1306ff962e6d. Mara watched the eastern gate until dawn.

Ledger 60 line 099: Neri carried the blue token past marker e4a3e686b7e1. Mara watched the eastern gate until dawn.

Ledger 60 line 100: Neri carried the blue token past marker cc2576539c4d. Mara watched the eastern gate until dawn.

Ledger 60 line 101: Neri carried the blue token past marker a2de7925a98e. Mara watched the eastern gate until dawn.

Ledger 60 line 102: Neri carried the blue token past marker 27441f2afd6f. Mara watched the eastern gate until dawn.

Ledger 60 line 103: Neri carried the blue token past marker 302cb44be16a. Mara watched the eastern gate until dawn.

Ledger 60 line 104: Neri carried the blue token past marker 97546250e85b. Mara watched the eastern gate until dawn.

Ledger 60 line 105: Neri carried the blue token past marker 5150fd12e9f8. Mara watched the eastern gate until dawn.

Ledger 60 line 106: Neri carried the blue token past marker 095223e899ab. Mara watched the eastern gate until dawn.

Ledger 60 line 107: Neri carried the blue token past marker 06b92349196c. Mara watched the eastern gate until dawn.

Ledger 60 line 108: Neri carried the blue token past marker c41b30a835a8. Mara watched the eastern gate until dawn.

Ledger 60 line 109: Neri carried the blue token past marker 47f35a1b9ee9. Mara watched the eastern gate until dawn.

Ledger 60 line 110: Neri carried the blue token past marker d9218cbb6dff. Mara watched the eastern gate until dawn.

Ledger 60 line 111: Neri carried the blue token past marker e93e61d1f5e4. Mara watched the eastern gate until dawn.

Ledger 60 line 112: Neri carried the blue token past marker 7e99d34a4843. Mara watched the eastern gate until dawn.

Ledger 60 line 113: Neri carried the blue token past marker 8462640cf2fe. Mara watched the eastern gate until dawn.

Ledger 60 line 114: Neri carried the blue token past marker 98f32bf26055. Mara watched the eastern gate until dawn.

Ledger 60 line 115: Neri carried the blue token past marker e20997314eff. Mara watched the eastern gate until dawn.

Ledger 60 line 116: Neri carried the blue token past marker d770de76bbe0. Mara watched the eastern gate until dawn.

Ledger 60 line 117: Neri carried the blue token past marker 09bdfc2d01c3. Mara watched the eastern gate until dawn.

Ledger 60 line 118: Neri carried the blue token past marker e82ad33fc272. Mara watched the eastern gate until dawn.

Ledger 60 line 119: Neri carried the blue token past marker 519c1380b220. Mara watched the eastern gate until dawn.

Ledger 60 line 120: Neri carried the blue token past marker 492446b3be9c. Mara watched the eastern gate until dawn.

Ledger 60 line 121: Neri carried the blue token past marker c6467f7c9cdd. Mara watched the eastern gate until dawn.

Ledger 60 line 122: Neri carried the blue token past marker 61fe6949f66b. Mara watched the eastern gate until dawn.

Ledger 60 line 123: Neri carried the blue token past marker 7cbac6429c9b. Mara watched the eastern gate until dawn.

Ledger 60 line 124: Neri carried the blue token past marker 8039dfcc62cb. Mara watched the eastern gate until dawn.

Ledger 60 line 125: Neri carried the blue token past marker b9172d7a2c79. Mara watched the eastern gate until dawn.

Ledger 60 line 126: Neri carried the blue token past marker c36e457ef73e. Mara watched the eastern gate until dawn.

Ledger 60 line 127: Neri carried the blue token past marker 7415f389fd3b. Mara watched the eastern gate until dawn.

Ledger 60 line 128: Neri carried the blue token past marker c14bf196f904. Mara watched the eastern gate until dawn.

Ledger 60 line 129: Neri carried the blue token past marker 31c482e736e4. Mara watched the eastern gate until dawn.

Ledger 60 line 130: Neri carried the blue token past marker b14cfef28294. Mara watched the eastern gate until dawn.

Ledger 60 line 131: Neri carried the blue token past marker 59c0a596e6ca. Mara watched the eastern gate until dawn.

Ledger 60 line 132: Neri carried the blue token past marker eaccf2449cf6. Mara watched the eastern gate until dawn.

Ledger 60 line 133: Neri carried the blue token past marker b318dec7798b. Mara watched the eastern gate until dawn.

Ledger 60 line 134: Neri carried the blue token past marker 4a4b29c9800c. Mara watched the eastern gate until dawn.

Ledger 60 line 135: Neri carried the blue token past marker bfe787c56975. Mara watched the eastern gate until dawn.

Ledger 60 line 136: Neri carried the blue token past marker 66d98ca869ee. Mara watched the eastern gate until dawn.

Ledger 60 line 137: Neri carried the blue token past marker f4641d0ac069. Mara watched the eastern gate until dawn.

Ledger 60 line 138: Neri carried the blue token past marker 1de349893d2b. Mara watched the eastern gate until dawn.

Ledger 60 line 139: Neri carried the blue token past marker 5b42f191a015. Mara watched the eastern gate until dawn.

Ledger 60 line 140: Neri carried the blue token past marker 1b5d2e7be259. Mara watched the eastern gate until dawn.
