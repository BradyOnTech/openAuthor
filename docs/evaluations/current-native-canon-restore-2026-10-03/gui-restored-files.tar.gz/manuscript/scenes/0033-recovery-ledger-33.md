---
id: scene-0033
title: Recovery ledger 33
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.170185+00:00
updated_at: 2026-10-03T12:14:52.170185+00:00
---

Ledger 33 line 001: Neri carried the blue token past marker 86ac89120996. Mara watched the eastern gate until dawn.

Ledger 33 line 002: Neri carried the blue token past marker 176ed8a4a37a. Mara watched the eastern gate until dawn.

Ledger 33 line 003: Neri carried the blue token past marker 88775a6c6ebb. Mara watched the eastern gate until dawn.

Ledger 33 line 004: Neri carried the blue token past marker 5d463f99733c. Mara watched the eastern gate until dawn.

Ledger 33 line 005: Neri carried the blue token past marker 8d306d769747. Mara watched the eastern gate until dawn.

Ledger 33 line 006: Neri carried the blue token past marker fb023b98b93a. Mara watched the eastern gate until dawn.

Ledger 33 line 007: Neri carried the blue token past marker 17123361cfc2. Mara watched the eastern gate until dawn.

Ledger 33 line 008: Neri carried the blue token past marker b29189037545. Mara watched the eastern gate until dawn.

Ledger 33 line 009: Neri carried the blue token past marker 67dc84f0635b. Mara watched the eastern gate until dawn.

Ledger 33 line 010: Neri carried the blue token past marker e7ff1c01c661. Mara watched the eastern gate until dawn.

Ledger 33 line 011: Neri carried the blue token past marker 61093841bce6. Mara watched the eastern gate until dawn.

Ledger 33 line 012: Neri carried the blue token past marker 69d32a7487cd. Mara watched the eastern gate until dawn.

Ledger 33 line 013: Neri carried the blue token past marker c3fa8c53b066. Mara watched the eastern gate until dawn.

Ledger 33 line 014: Neri carried the blue token past marker 4fe5a5ca18c0. Mara watched the eastern gate until dawn.

Ledger 33 line 015: Neri carried the blue token past marker d0c08d0cbda1. Mara watched the eastern gate until dawn.

Ledger 33 line 016: Neri carried the blue token past marker 27d158a7e8a7. Mara watched the eastern gate until dawn.

Ledger 33 line 017: Neri carried the blue token past marker 106a65bd0ff6. Mara watched the eastern gate until dawn.

Ledger 33 line 018: Neri carried the blue token past marker 832c4374ee6d. Mara watched the eastern gate until dawn.

Ledger 33 line 019: Neri carried the blue token past marker 2f62008e7812. Mara watched the eastern gate until dawn.

Ledger 33 line 020: Neri carried the blue token past marker 2426570ccf72. Mara watched the eastern gate until dawn.

Ledger 33 line 021: Neri carried the blue token past marker d5ff1ffa119d. Mara watched the eastern gate until dawn.

Ledger 33 line 022: Neri carried the blue token past marker a9811e728d1e. Mara watched the eastern gate until dawn.

Ledger 33 line 023: Neri carried the blue token past marker 72732836174a. Mara watched the eastern gate until dawn.

Ledger 33 line 024: Neri carried the blue token past marker dfa9c0904cb0. Mara watched the eastern gate until dawn.

Ledger 33 line 025: Neri carried the blue token past marker 43fbd5e22a92. Mara watched the eastern gate until dawn.

Ledger 33 line 026: Neri carried the blue token past marker 90938b0e63b6. Mara watched the eastern gate until dawn.

Ledger 33 line 027: Neri carried the blue token past marker 1adbc2bdd855. Mara watched the eastern gate until dawn.

Ledger 33 line 028: Neri carried the blue token past marker 0b403447dcfa. Mara watched the eastern gate until dawn.

Ledger 33 line 029: Neri carried the blue token past marker 9e8dac8d434c. Mara watched the eastern gate until dawn.

Ledger 33 line 030: Neri carried the blue token past marker a56f9751f9d1. Mara watched the eastern gate until dawn.

Ledger 33 line 031: Neri carried the blue token past marker c4738f6ddad8. Mara watched the eastern gate until dawn.

Ledger 33 line 032: Neri carried the blue token past marker 6b4861d88955. Mara watched the eastern gate until dawn.

Ledger 33 line 033: Neri carried the blue token past marker 49afd654698b. Mara watched the eastern gate until dawn.

Ledger 33 line 034: Neri carried the blue token past marker 5e103f8cbce3. Mara watched the eastern gate until dawn.

Ledger 33 line 035: Neri carried the blue token past marker b872cb536b11. Mara watched the eastern gate until dawn.

Ledger 33 line 036: Neri carried the blue token past marker 6b6801628cd3. Mara watched the eastern gate until dawn.

Ledger 33 line 037: Neri carried the blue token past marker 8c59caea8b3b. Mara watched the eastern gate until dawn.

Ledger 33 line 038: Neri carried the blue token past marker 159510fc4335. Mara watched the eastern gate until dawn.

Ledger 33 line 039: Neri carried the blue token past marker 9dfd7b2b997c. Mara watched the eastern gate until dawn.

Ledger 33 line 040: Neri carried the blue token past marker 966c3ff04146. Mara watched the eastern gate until dawn.

Ledger 33 line 041: Neri carried the blue token past marker 1d17c60db08d. Mara watched the eastern gate until dawn.

Ledger 33 line 042: Neri carried the blue token past marker 32827f53636f. Mara watched the eastern gate until dawn.

Ledger 33 line 043: Neri carried the blue token past marker cb6e86ad9dca. Mara watched the eastern gate until dawn.

Ledger 33 line 044: Neri carried the blue token past marker 1ca58b7e0fd8. Mara watched the eastern gate until dawn.

Ledger 33 line 045: Neri carried the blue token past marker 7b53ec9c15af. Mara watched the eastern gate until dawn.

Ledger 33 line 046: Neri carried the blue token past marker 15e805f654d5. Mara watched the eastern gate until dawn.

Ledger 33 line 047: Neri carried the blue token past marker 64ace74d21c0. Mara watched the eastern gate until dawn.

Ledger 33 line 048: Neri carried the blue token past marker 8d76f57c5c17. Mara watched the eastern gate until dawn.

Ledger 33 line 049: Neri carried the blue token past marker 09bd6153a8fa. Mara watched the eastern gate until dawn.

Ledger 33 line 050: Neri carried the blue token past marker 2c228c2d326c. Mara watched the eastern gate until dawn.

Ledger 33 line 051: Neri carried the blue token past marker 6195b17c1955. Mara watched the eastern gate until dawn.

Ledger 33 line 052: Neri carried the blue token past marker 177ea80b93a4. Mara watched the eastern gate until dawn.

Ledger 33 line 053: Neri carried the blue token past marker 96fa18eb01ca. Mara watched the eastern gate until dawn.

Ledger 33 line 054: Neri carried the blue token past marker f26288bc652b. Mara watched the eastern gate until dawn.

Ledger 33 line 055: Neri carried the blue token past marker c45c8b1122c6. Mara watched the eastern gate until dawn.

Ledger 33 line 056: Neri carried the blue token past marker b7ebdc931e03. Mara watched the eastern gate until dawn.

Ledger 33 line 057: Neri carried the blue token past marker 989d065f49fe. Mara watched the eastern gate until dawn.

Ledger 33 line 058: Neri carried the blue token past marker 1bb514aa9f04. Mara watched the eastern gate until dawn.

Ledger 33 line 059: Neri carried the blue token past marker 65224610175f. Mara watched the eastern gate until dawn.

Ledger 33 line 060: Neri carried the blue token past marker 0c3d9df4d2fa. Mara watched the eastern gate until dawn.

Ledger 33 line 061: Neri carried the blue token past marker 3292f4758c20. Mara watched the eastern gate until dawn.

Ledger 33 line 062: Neri carried the blue token past marker cf1b88f383e0. Mara watched the eastern gate until dawn.

Ledger 33 line 063: Neri carried the blue token past marker d4e7e9d24d5e. Mara watched the eastern gate until dawn.

Ledger 33 line 064: Neri carried the blue token past marker 0eb2e4c2b62c. Mara watched the eastern gate until dawn.

Ledger 33 line 065: Neri carried the blue token past marker 20e70ce8e5a6. Mara watched the eastern gate until dawn.

Ledger 33 line 066: Neri carried the blue token past marker d81413877edb. Mara watched the eastern gate until dawn.

Ledger 33 line 067: Neri carried the blue token past marker aa579fb9d988. Mara watched the eastern gate until dawn.

Ledger 33 line 068: Neri carried the blue token past marker f7c950ce8b05. Mara watched the eastern gate until dawn.

Ledger 33 line 069: Neri carried the blue token past marker 063ffa83fd36. Mara watched the eastern gate until dawn.

Ledger 33 line 070: Neri carried the blue token past marker 00640d7b47ac. Mara watched the eastern gate until dawn.

Ledger 33 line 071: Neri carried the blue token past marker 963ea791dd91. Mara watched the eastern gate until dawn.

Ledger 33 line 072: Neri carried the blue token past marker 1970e6ed6713. Mara watched the eastern gate until dawn.

Ledger 33 line 073: Neri carried the blue token past marker 593b34aba52e. Mara watched the eastern gate until dawn.

Ledger 33 line 074: Neri carried the blue token past marker 0138531bf43f. Mara watched the eastern gate until dawn.

Ledger 33 line 075: Neri carried the blue token past marker cc7770bc5753. Mara watched the eastern gate until dawn.

Ledger 33 line 076: Neri carried the blue token past marker 3193620aa31b. Mara watched the eastern gate until dawn.

Ledger 33 line 077: Neri carried the blue token past marker 1db2c07ac781. Mara watched the eastern gate until dawn.

Ledger 33 line 078: Neri carried the blue token past marker eb7f9d177324. Mara watched the eastern gate until dawn.

Ledger 33 line 079: Neri carried the blue token past marker b4e88ef92cc5. Mara watched the eastern gate until dawn.

Ledger 33 line 080: Neri carried the blue token past marker 3957a8a027cd. Mara watched the eastern gate until dawn.

Ledger 33 line 081: Neri carried the blue token past marker 16a3a73e4366. Mara watched the eastern gate until dawn.

Ledger 33 line 082: Neri carried the blue token past marker d3948899a98c. Mara watched the eastern gate until dawn.

Ledger 33 line 083: Neri carried the blue token past marker 5c8d54267cd3. Mara watched the eastern gate until dawn.

Ledger 33 line 084: Neri carried the blue token past marker 9f6703f0533c. Mara watched the eastern gate until dawn.

Ledger 33 line 085: Neri carried the blue token past marker c14776eca855. Mara watched the eastern gate until dawn.

Ledger 33 line 086: Neri carried the blue token past marker 03e355c9274c. Mara watched the eastern gate until dawn.

Ledger 33 line 087: Neri carried the blue token past marker 0d3af05f1e3a. Mara watched the eastern gate until dawn.

Ledger 33 line 088: Neri carried the blue token past marker 834c98f72ac6. Mara watched the eastern gate until dawn.

Ledger 33 line 089: Neri carried the blue token past marker 394de1586ca8. Mara watched the eastern gate until dawn.

Ledger 33 line 090: Neri carried the blue token past marker 8ccf3da69488. Mara watched the eastern gate until dawn.

Ledger 33 line 091: Neri carried the blue token past marker e48ce92d6194. Mara watched the eastern gate until dawn.

Ledger 33 line 092: Neri carried the blue token past marker a71cf68eed2a. Mara watched the eastern gate until dawn.

Ledger 33 line 093: Neri carried the blue token past marker 122bff470b14. Mara watched the eastern gate until dawn.

Ledger 33 line 094: Neri carried the blue token past marker b7cdb5d16f4e. Mara watched the eastern gate until dawn.

Ledger 33 line 095: Neri carried the blue token past marker c8a8785d2e06. Mara watched the eastern gate until dawn.

Ledger 33 line 096: Neri carried the blue token past marker b9df3508b6c9. Mara watched the eastern gate until dawn.

Ledger 33 line 097: Neri carried the blue token past marker 1a5355aac121. Mara watched the eastern gate until dawn.

Ledger 33 line 098: Neri carried the blue token past marker f5876e8ad711. Mara watched the eastern gate until dawn.

Ledger 33 line 099: Neri carried the blue token past marker bc2864115121. Mara watched the eastern gate until dawn.

Ledger 33 line 100: Neri carried the blue token past marker 0aeb6f78e19f. Mara watched the eastern gate until dawn.

Ledger 33 line 101: Neri carried the blue token past marker 89b36c568660. Mara watched the eastern gate until dawn.

Ledger 33 line 102: Neri carried the blue token past marker df38b96bde6f. Mara watched the eastern gate until dawn.

Ledger 33 line 103: Neri carried the blue token past marker 58e6e98d6b1d. Mara watched the eastern gate until dawn.

Ledger 33 line 104: Neri carried the blue token past marker 09b4b7b5b303. Mara watched the eastern gate until dawn.

Ledger 33 line 105: Neri carried the blue token past marker f288c1781e16. Mara watched the eastern gate until dawn.

Ledger 33 line 106: Neri carried the blue token past marker c3b524016e01. Mara watched the eastern gate until dawn.

Ledger 33 line 107: Neri carried the blue token past marker 9e672fadb978. Mara watched the eastern gate until dawn.

Ledger 33 line 108: Neri carried the blue token past marker 94cafb233907. Mara watched the eastern gate until dawn.

Ledger 33 line 109: Neri carried the blue token past marker 5d19c752ad37. Mara watched the eastern gate until dawn.

Ledger 33 line 110: Neri carried the blue token past marker 37fc6ca9b113. Mara watched the eastern gate until dawn.

Ledger 33 line 111: Neri carried the blue token past marker dbb07b07c0a5. Mara watched the eastern gate until dawn.

Ledger 33 line 112: Neri carried the blue token past marker 1de6dd04b1d7. Mara watched the eastern gate until dawn.

Ledger 33 line 113: Neri carried the blue token past marker 083232a8791a. Mara watched the eastern gate until dawn.

Ledger 33 line 114: Neri carried the blue token past marker e367b98bcae6. Mara watched the eastern gate until dawn.

Ledger 33 line 115: Neri carried the blue token past marker 40f323588b49. Mara watched the eastern gate until dawn.

Ledger 33 line 116: Neri carried the blue token past marker df264e9f97f5. Mara watched the eastern gate until dawn.

Ledger 33 line 117: Neri carried the blue token past marker 8d2a70cc1ba7. Mara watched the eastern gate until dawn.

Ledger 33 line 118: Neri carried the blue token past marker 6fad307c31c2. Mara watched the eastern gate until dawn.

Ledger 33 line 119: Neri carried the blue token past marker 5585c26caf1d. Mara watched the eastern gate until dawn.

Ledger 33 line 120: Neri carried the blue token past marker 74827fce4b31. Mara watched the eastern gate until dawn.

Ledger 33 line 121: Neri carried the blue token past marker 82acb75bb0b6. Mara watched the eastern gate until dawn.

Ledger 33 line 122: Neri carried the blue token past marker 07c89b4b659d. Mara watched the eastern gate until dawn.

Ledger 33 line 123: Neri carried the blue token past marker d841431c6b3d. Mara watched the eastern gate until dawn.

Ledger 33 line 124: Neri carried the blue token past marker c250abe68bd7. Mara watched the eastern gate until dawn.

Ledger 33 line 125: Neri carried the blue token past marker 1d5ee9b4fd1c. Mara watched the eastern gate until dawn.

Ledger 33 line 126: Neri carried the blue token past marker c3607c4bca02. Mara watched the eastern gate until dawn.

Ledger 33 line 127: Neri carried the blue token past marker d986978c51a9. Mara watched the eastern gate until dawn.

Ledger 33 line 128: Neri carried the blue token past marker fa4041428938. Mara watched the eastern gate until dawn.

Ledger 33 line 129: Neri carried the blue token past marker 8f7a9fbfe10b. Mara watched the eastern gate until dawn.

Ledger 33 line 130: Neri carried the blue token past marker 7514538213e8. Mara watched the eastern gate until dawn.

Ledger 33 line 131: Neri carried the blue token past marker cd5e9e65cb17. Mara watched the eastern gate until dawn.

Ledger 33 line 132: Neri carried the blue token past marker b3165b110395. Mara watched the eastern gate until dawn.

Ledger 33 line 133: Neri carried the blue token past marker 97a3078cceed. Mara watched the eastern gate until dawn.

Ledger 33 line 134: Neri carried the blue token past marker 2f75e6ff5643. Mara watched the eastern gate until dawn.

Ledger 33 line 135: Neri carried the blue token past marker 74589c44e49e. Mara watched the eastern gate until dawn.

Ledger 33 line 136: Neri carried the blue token past marker b3ad3d7d90f6. Mara watched the eastern gate until dawn.

Ledger 33 line 137: Neri carried the blue token past marker 263c4194565e. Mara watched the eastern gate until dawn.

Ledger 33 line 138: Neri carried the blue token past marker 407cb8d0485b. Mara watched the eastern gate until dawn.

Ledger 33 line 139: Neri carried the blue token past marker 717b837e26b5. Mara watched the eastern gate until dawn.

Ledger 33 line 140: Neri carried the blue token past marker c5a8cd90682e. Mara watched the eastern gate until dawn.
