---
id: scene-0059
title: Recovery ledger 59
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.184420+00:00
updated_at: 2026-10-03T12:14:52.184420+00:00
---

Ledger 59 line 001: Neri carried the blue token past marker 429b475a35c1. Mara watched the eastern gate until dawn.

Ledger 59 line 002: Neri carried the blue token past marker cf486ba0145b. Mara watched the eastern gate until dawn.

Ledger 59 line 003: Neri carried the blue token past marker 3e912f336e29. Mara watched the eastern gate until dawn.

Ledger 59 line 004: Neri carried the blue token past marker 48ad879e2b30. Mara watched the eastern gate until dawn.

Ledger 59 line 005: Neri carried the blue token past marker f483b840f2ba. Mara watched the eastern gate until dawn.

Ledger 59 line 006: Neri carried the blue token past marker f184f1fbf954. Mara watched the eastern gate until dawn.

Ledger 59 line 007: Neri carried the blue token past marker 7c0a7c193626. Mara watched the eastern gate until dawn.

Ledger 59 line 008: Neri carried the blue token past marker 9065edb8229a. Mara watched the eastern gate until dawn.

Ledger 59 line 009: Neri carried the blue token past marker 6081d8fa6261. Mara watched the eastern gate until dawn.

Ledger 59 line 010: Neri carried the blue token past marker 46a1a39d639d. Mara watched the eastern gate until dawn.

Ledger 59 line 011: Neri carried the blue token past marker ffc86b822035. Mara watched the eastern gate until dawn.

Ledger 59 line 012: Neri carried the blue token past marker 31d382aecb32. Mara watched the eastern gate until dawn.

Ledger 59 line 013: Neri carried the blue token past marker 921c757f21f7. Mara watched the eastern gate until dawn.

Ledger 59 line 014: Neri carried the blue token past marker b7144f830cf0. Mara watched the eastern gate until dawn.

Ledger 59 line 015: Neri carried the blue token past marker 408f8d6d2218. Mara watched the eastern gate until dawn.

Ledger 59 line 016: Neri carried the blue token past marker 862666779cf4. Mara watched the eastern gate until dawn.

Ledger 59 line 017: Neri carried the blue token past marker 60363315c8a9. Mara watched the eastern gate until dawn.

Ledger 59 line 018: Neri carried the blue token past marker 0352802939c5. Mara watched the eastern gate until dawn.

Ledger 59 line 019: Neri carried the blue token past marker f78fbc20bef5. Mara watched the eastern gate until dawn.

Ledger 59 line 020: Neri carried the blue token past marker 198b1275532b. Mara watched the eastern gate until dawn.

Ledger 59 line 021: Neri carried the blue token past marker 7286e989d640. Mara watched the eastern gate until dawn.

Ledger 59 line 022: Neri carried the blue token past marker 04edb4669f23. Mara watched the eastern gate until dawn.

Ledger 59 line 023: Neri carried the blue token past marker 5020f44df10d. Mara watched the eastern gate until dawn.

Ledger 59 line 024: Neri carried the blue token past marker c562d36b2313. Mara watched the eastern gate until dawn.

Ledger 59 line 025: Neri carried the blue token past marker b9560f6903fc. Mara watched the eastern gate until dawn.

Ledger 59 line 026: Neri carried the blue token past marker 1fa2945bab46. Mara watched the eastern gate until dawn.

Ledger 59 line 027: Neri carried the blue token past marker cb10f3c853e2. Mara watched the eastern gate until dawn.

Ledger 59 line 028: Neri carried the blue token past marker 19d83c85e871. Mara watched the eastern gate until dawn.

Ledger 59 line 029: Neri carried the blue token past marker 99714cd414d7. Mara watched the eastern gate until dawn.

Ledger 59 line 030: Neri carried the blue token past marker 902b6bba15d9. Mara watched the eastern gate until dawn.

Ledger 59 line 031: Neri carried the blue token past marker 26dffd498fb1. Mara watched the eastern gate until dawn.

Ledger 59 line 032: Neri carried the blue token past marker ad7971a4c525. Mara watched the eastern gate until dawn.

Ledger 59 line 033: Neri carried the blue token past marker 42de6c64507e. Mara watched the eastern gate until dawn.

Ledger 59 line 034: Neri carried the blue token past marker 75c9db3b3521. Mara watched the eastern gate until dawn.

Ledger 59 line 035: Neri carried the blue token past marker 4b478b3a2f58. Mara watched the eastern gate until dawn.

Ledger 59 line 036: Neri carried the blue token past marker 368b43ef09e6. Mara watched the eastern gate until dawn.

Ledger 59 line 037: Neri carried the blue token past marker 54f4e187156c. Mara watched the eastern gate until dawn.

Ledger 59 line 038: Neri carried the blue token past marker 9515cab2751c. Mara watched the eastern gate until dawn.

Ledger 59 line 039: Neri carried the blue token past marker a69e6c5392df. Mara watched the eastern gate until dawn.

Ledger 59 line 040: Neri carried the blue token past marker af484fd6a1f5. Mara watched the eastern gate until dawn.

Ledger 59 line 041: Neri carried the blue token past marker aa42298ac668. Mara watched the eastern gate until dawn.

Ledger 59 line 042: Neri carried the blue token past marker af09efc4ba9f. Mara watched the eastern gate until dawn.

Ledger 59 line 043: Neri carried the blue token past marker fb30dc583f85. Mara watched the eastern gate until dawn.

Ledger 59 line 044: Neri carried the blue token past marker 41e26cb44d09. Mara watched the eastern gate until dawn.

Ledger 59 line 045: Neri carried the blue token past marker 773b95e4e7eb. Mara watched the eastern gate until dawn.

Ledger 59 line 046: Neri carried the blue token past marker 70bd806927fc. Mara watched the eastern gate until dawn.

Ledger 59 line 047: Neri carried the blue token past marker 3d10ef7cd0da. Mara watched the eastern gate until dawn.

Ledger 59 line 048: Neri carried the blue token past marker 40d69ba3418c. Mara watched the eastern gate until dawn.

Ledger 59 line 049: Neri carried the blue token past marker 4e7830c0920e. Mara watched the eastern gate until dawn.

Ledger 59 line 050: Neri carried the blue token past marker 25fe5b80f475. Mara watched the eastern gate until dawn.

Ledger 59 line 051: Neri carried the blue token past marker 326504b02827. Mara watched the eastern gate until dawn.

Ledger 59 line 052: Neri carried the blue token past marker 20541b44ae40. Mara watched the eastern gate until dawn.

Ledger 59 line 053: Neri carried the blue token past marker 82d362f0e31c. Mara watched the eastern gate until dawn.

Ledger 59 line 054: Neri carried the blue token past marker f4876c3c28c3. Mara watched the eastern gate until dawn.

Ledger 59 line 055: Neri carried the blue token past marker 07fc51de0809. Mara watched the eastern gate until dawn.

Ledger 59 line 056: Neri carried the blue token past marker f8db5f7144f9. Mara watched the eastern gate until dawn.

Ledger 59 line 057: Neri carried the blue token past marker 3b3201e6eb4b. Mara watched the eastern gate until dawn.

Ledger 59 line 058: Neri carried the blue token past marker e77c5147d962. Mara watched the eastern gate until dawn.

Ledger 59 line 059: Neri carried the blue token past marker a19f52629f91. Mara watched the eastern gate until dawn.

Ledger 59 line 060: Neri carried the blue token past marker 180c9d8e4bb3. Mara watched the eastern gate until dawn.

Ledger 59 line 061: Neri carried the blue token past marker b0b6b4f28128. Mara watched the eastern gate until dawn.

Ledger 59 line 062: Neri carried the blue token past marker fb77bf8b060e. Mara watched the eastern gate until dawn.

Ledger 59 line 063: Neri carried the blue token past marker 4a80bf5a795e. Mara watched the eastern gate until dawn.

Ledger 59 line 064: Neri carried the blue token past marker 226354ff3782. Mara watched the eastern gate until dawn.

Ledger 59 line 065: Neri carried the blue token past marker ed84e29e39b1. Mara watched the eastern gate until dawn.

Ledger 59 line 066: Neri carried the blue token past marker c5509c0f7c4a. Mara watched the eastern gate until dawn.

Ledger 59 line 067: Neri carried the blue token past marker 4b2dcb225228. Mara watched the eastern gate until dawn.

Ledger 59 line 068: Neri carried the blue token past marker ff0836206d78. Mara watched the eastern gate until dawn.

Ledger 59 line 069: Neri carried the blue token past marker ebb06760de96. Mara watched the eastern gate until dawn.

Ledger 59 line 070: Neri carried the blue token past marker 3875a493ef61. Mara watched the eastern gate until dawn.

Ledger 59 line 071: Neri carried the blue token past marker 595145c468c7. Mara watched the eastern gate until dawn.

Ledger 59 line 072: Neri carried the blue token past marker 09c2e1083208. Mara watched the eastern gate until dawn.

Ledger 59 line 073: Neri carried the blue token past marker aecd75880102. Mara watched the eastern gate until dawn.

Ledger 59 line 074: Neri carried the blue token past marker b8cfa08d56a0. Mara watched the eastern gate until dawn.

Ledger 59 line 075: Neri carried the blue token past marker 0ce64cb47f3c. Mara watched the eastern gate until dawn.

Ledger 59 line 076: Neri carried the blue token past marker 4ded4e79f298. Mara watched the eastern gate until dawn.

Ledger 59 line 077: Neri carried the blue token past marker 7f99102a4c71. Mara watched the eastern gate until dawn.

Ledger 59 line 078: Neri carried the blue token past marker 028f623dd815. Mara watched the eastern gate until dawn.

Ledger 59 line 079: Neri carried the blue token past marker 9dcf3204a406. Mara watched the eastern gate until dawn.

Ledger 59 line 080: Neri carried the blue token past marker c3cfc1a2439f. Mara watched the eastern gate until dawn.

Ledger 59 line 081: Neri carried the blue token past marker 8d5601c1ee39. Mara watched the eastern gate until dawn.

Ledger 59 line 082: Neri carried the blue token past marker 5a05a49811e9. Mara watched the eastern gate until dawn.

Ledger 59 line 083: Neri carried the blue token past marker 63ada89f60e1. Mara watched the eastern gate until dawn.

Ledger 59 line 084: Neri carried the blue token past marker 7b41ee08990f. Mara watched the eastern gate until dawn.

Ledger 59 line 085: Neri carried the blue token past marker 131b8c881fe4. Mara watched the eastern gate until dawn.

Ledger 59 line 086: Neri carried the blue token past marker cb0afa70e407. Mara watched the eastern gate until dawn.

Ledger 59 line 087: Neri carried the blue token past marker 19ef7dfd01ee. Mara watched the eastern gate until dawn.

Ledger 59 line 088: Neri carried the blue token past marker 35db2b115f87. Mara watched the eastern gate until dawn.

Ledger 59 line 089: Neri carried the blue token past marker a186e7f00c14. Mara watched the eastern gate until dawn.

Ledger 59 line 090: Neri carried the blue token past marker 3c0dafdc96aa. Mara watched the eastern gate until dawn.

Ledger 59 line 091: Neri carried the blue token past marker 5c063146568a. Mara watched the eastern gate until dawn.

Ledger 59 line 092: Neri carried the blue token past marker 1b1406f3e5cd. Mara watched the eastern gate until dawn.

Ledger 59 line 093: Neri carried the blue token past marker e10e2051afe1. Mara watched the eastern gate until dawn.

Ledger 59 line 094: Neri carried the blue token past marker 6568b0f99f34. Mara watched the eastern gate until dawn.

Ledger 59 line 095: Neri carried the blue token past marker 3d7e41006671. Mara watched the eastern gate until dawn.

Ledger 59 line 096: Neri carried the blue token past marker 02067cfa5d98. Mara watched the eastern gate until dawn.

Ledger 59 line 097: Neri carried the blue token past marker 5cdd8a6cb394. Mara watched the eastern gate until dawn.

Ledger 59 line 098: Neri carried the blue token past marker 4c48994a09bd. Mara watched the eastern gate until dawn.

Ledger 59 line 099: Neri carried the blue token past marker 4d4e6c158cc8. Mara watched the eastern gate until dawn.

Ledger 59 line 100: Neri carried the blue token past marker 8f45eec150f2. Mara watched the eastern gate until dawn.

Ledger 59 line 101: Neri carried the blue token past marker ea62171694cc. Mara watched the eastern gate until dawn.

Ledger 59 line 102: Neri carried the blue token past marker 072362664011. Mara watched the eastern gate until dawn.

Ledger 59 line 103: Neri carried the blue token past marker 146dff2a83ad. Mara watched the eastern gate until dawn.

Ledger 59 line 104: Neri carried the blue token past marker f4b9477dd38e. Mara watched the eastern gate until dawn.

Ledger 59 line 105: Neri carried the blue token past marker f1277ef323c3. Mara watched the eastern gate until dawn.

Ledger 59 line 106: Neri carried the blue token past marker 86da09d3924c. Mara watched the eastern gate until dawn.

Ledger 59 line 107: Neri carried the blue token past marker 0a8bc17962d8. Mara watched the eastern gate until dawn.

Ledger 59 line 108: Neri carried the blue token past marker 04a70a8e3124. Mara watched the eastern gate until dawn.

Ledger 59 line 109: Neri carried the blue token past marker 610f9c8ed03c. Mara watched the eastern gate until dawn.

Ledger 59 line 110: Neri carried the blue token past marker d4fd985cc36c. Mara watched the eastern gate until dawn.

Ledger 59 line 111: Neri carried the blue token past marker f50cd073e633. Mara watched the eastern gate until dawn.

Ledger 59 line 112: Neri carried the blue token past marker 50c7ded5566c. Mara watched the eastern gate until dawn.

Ledger 59 line 113: Neri carried the blue token past marker 29f6b5713bb5. Mara watched the eastern gate until dawn.

Ledger 59 line 114: Neri carried the blue token past marker 43957e22ad95. Mara watched the eastern gate until dawn.

Ledger 59 line 115: Neri carried the blue token past marker c334a0f182bb. Mara watched the eastern gate until dawn.

Ledger 59 line 116: Neri carried the blue token past marker 0fb6233731e4. Mara watched the eastern gate until dawn.

Ledger 59 line 117: Neri carried the blue token past marker e2c4f2ed2e23. Mara watched the eastern gate until dawn.

Ledger 59 line 118: Neri carried the blue token past marker b36a65f5b0ec. Mara watched the eastern gate until dawn.

Ledger 59 line 119: Neri carried the blue token past marker 5a29294e43bf. Mara watched the eastern gate until dawn.

Ledger 59 line 120: Neri carried the blue token past marker 17c51b0e6e04. Mara watched the eastern gate until dawn.

Ledger 59 line 121: Neri carried the blue token past marker 61924c2a2bda. Mara watched the eastern gate until dawn.

Ledger 59 line 122: Neri carried the blue token past marker b4ef4528d783. Mara watched the eastern gate until dawn.

Ledger 59 line 123: Neri carried the blue token past marker c41e144c0288. Mara watched the eastern gate until dawn.

Ledger 59 line 124: Neri carried the blue token past marker 30ee3edb36e8. Mara watched the eastern gate until dawn.

Ledger 59 line 125: Neri carried the blue token past marker 13d02ca08428. Mara watched the eastern gate until dawn.

Ledger 59 line 126: Neri carried the blue token past marker 5354b5084a5f. Mara watched the eastern gate until dawn.

Ledger 59 line 127: Neri carried the blue token past marker e47dfa5af824. Mara watched the eastern gate until dawn.

Ledger 59 line 128: Neri carried the blue token past marker a9962549e882. Mara watched the eastern gate until dawn.

Ledger 59 line 129: Neri carried the blue token past marker 483715d49d14. Mara watched the eastern gate until dawn.

Ledger 59 line 130: Neri carried the blue token past marker d2cdce6b018d. Mara watched the eastern gate until dawn.

Ledger 59 line 131: Neri carried the blue token past marker 82f87d19fde0. Mara watched the eastern gate until dawn.

Ledger 59 line 132: Neri carried the blue token past marker 7ed03ec7dd56. Mara watched the eastern gate until dawn.

Ledger 59 line 133: Neri carried the blue token past marker 7d718bd1652f. Mara watched the eastern gate until dawn.

Ledger 59 line 134: Neri carried the blue token past marker 886f654d21ea. Mara watched the eastern gate until dawn.

Ledger 59 line 135: Neri carried the blue token past marker bcc935974681. Mara watched the eastern gate until dawn.

Ledger 59 line 136: Neri carried the blue token past marker 57846f374d10. Mara watched the eastern gate until dawn.

Ledger 59 line 137: Neri carried the blue token past marker a3d12bf71dfb. Mara watched the eastern gate until dawn.

Ledger 59 line 138: Neri carried the blue token past marker 4bee36b69b78. Mara watched the eastern gate until dawn.

Ledger 59 line 139: Neri carried the blue token past marker 970a3b96c396. Mara watched the eastern gate until dawn.

Ledger 59 line 140: Neri carried the blue token past marker 18699fce3a1d. Mara watched the eastern gate until dawn.
