---
id: scene-0002
title: Recovery ledger 02
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.153854+00:00
updated_at: 2026-10-03T12:14:52.153854+00:00
---

Ledger 02 line 001: Neri carried the blue token past marker 1d800ad9f4e9. Mara watched the eastern gate until dawn.

Ledger 02 line 002: Neri carried the blue token past marker 58c0e7476a0d. Mara watched the eastern gate until dawn.

Ledger 02 line 003: Neri carried the blue token past marker 484aa6ccd17c. Mara watched the eastern gate until dawn.

Ledger 02 line 004: Neri carried the blue token past marker 401133a5a312. Mara watched the eastern gate until dawn.

Ledger 02 line 005: Neri carried the blue token past marker 0b9db2ecfb8d. Mara watched the eastern gate until dawn.

Ledger 02 line 006: Neri carried the blue token past marker 82ba318b1c86. Mara watched the eastern gate until dawn.

Ledger 02 line 007: Neri carried the blue token past marker 55ba88e4b692. Mara watched the eastern gate until dawn.

Ledger 02 line 008: Neri carried the blue token past marker 8c22d1a5d397. Mara watched the eastern gate until dawn.

Ledger 02 line 009: Neri carried the blue token past marker 185b24d9b657. Mara watched the eastern gate until dawn.

Ledger 02 line 010: Neri carried the blue token past marker 2d866606585a. Mara watched the eastern gate until dawn.

Ledger 02 line 011: Neri carried the blue token past marker 4b847c112cde. Mara watched the eastern gate until dawn.

Ledger 02 line 012: Neri carried the blue token past marker aaf23a1a08e1. Mara watched the eastern gate until dawn.

Ledger 02 line 013: Neri carried the blue token past marker c0ea3e7b8643. Mara watched the eastern gate until dawn.

Ledger 02 line 014: Neri carried the blue token past marker 447b307380b5. Mara watched the eastern gate until dawn.

Ledger 02 line 015: Neri carried the blue token past marker 3d9e0949dfd8. Mara watched the eastern gate until dawn.

Ledger 02 line 016: Neri carried the blue token past marker f6074f557a7d. Mara watched the eastern gate until dawn.

Ledger 02 line 017: Neri carried the blue token past marker adee68a72960. Mara watched the eastern gate until dawn.

Ledger 02 line 018: Neri carried the blue token past marker 1a0f17454da9. Mara watched the eastern gate until dawn.

Ledger 02 line 019: Neri carried the blue token past marker 8d42f649df93. Mara watched the eastern gate until dawn.

Ledger 02 line 020: Neri carried the blue token past marker 3953d3bd6bf4. Mara watched the eastern gate until dawn.

Ledger 02 line 021: Neri carried the blue token past marker 9944028b3bfb. Mara watched the eastern gate until dawn.

Ledger 02 line 022: Neri carried the blue token past marker ff057a2e711c. Mara watched the eastern gate until dawn.

Ledger 02 line 023: Neri carried the blue token past marker 0f8fe5ffa646. Mara watched the eastern gate until dawn.

Ledger 02 line 024: Neri carried the blue token past marker 5f7c754816da. Mara watched the eastern gate until dawn.

Ledger 02 line 025: Neri carried the blue token past marker d6082468d0ca. Mara watched the eastern gate until dawn.

Ledger 02 line 026: Neri carried the blue token past marker b98740136848. Mara watched the eastern gate until dawn.

Ledger 02 line 027: Neri carried the blue token past marker 59a52ff82b48. Mara watched the eastern gate until dawn.

Ledger 02 line 028: Neri carried the blue token past marker dbc091bce4a6. Mara watched the eastern gate until dawn.

Ledger 02 line 029: Neri carried the blue token past marker 4e9d4260b2c7. Mara watched the eastern gate until dawn.

Ledger 02 line 030: Neri carried the blue token past marker 4ecc31ce3c96. Mara watched the eastern gate until dawn.

Ledger 02 line 031: Neri carried the blue token past marker fe05f4896117. Mara watched the eastern gate until dawn.

Ledger 02 line 032: Neri carried the blue token past marker 11f3f63a7788. Mara watched the eastern gate until dawn.

Ledger 02 line 033: Neri carried the blue token past marker 93ae48d6cf42. Mara watched the eastern gate until dawn.

Ledger 02 line 034: Neri carried the blue token past marker 91d6a3a3c54c. Mara watched the eastern gate until dawn.

Ledger 02 line 035: Neri carried the blue token past marker a46b6190b38b. Mara watched the eastern gate until dawn.

Ledger 02 line 036: Neri carried the blue token past marker 5698d6ce09b9. Mara watched the eastern gate until dawn.

Ledger 02 line 037: Neri carried the blue token past marker 6d8762ac93a8. Mara watched the eastern gate until dawn.

Ledger 02 line 038: Neri carried the blue token past marker 130dd042b698. Mara watched the eastern gate until dawn.

Ledger 02 line 039: Neri carried the blue token past marker d09418eb04b4. Mara watched the eastern gate until dawn.

Ledger 02 line 040: Neri carried the blue token past marker ae76cf315214. Mara watched the eastern gate until dawn.

Ledger 02 line 041: Neri carried the blue token past marker 747e9d1334d8. Mara watched the eastern gate until dawn.

Ledger 02 line 042: Neri carried the blue token past marker 04a46f1a9382. Mara watched the eastern gate until dawn.

Ledger 02 line 043: Neri carried the blue token past marker cd0b9e58608f. Mara watched the eastern gate until dawn.

Ledger 02 line 044: Neri carried the blue token past marker fc600bb52649. Mara watched the eastern gate until dawn.

Ledger 02 line 045: Neri carried the blue token past marker 70fc2df036cb. Mara watched the eastern gate until dawn.

Ledger 02 line 046: Neri carried the blue token past marker 5652275492fb. Mara watched the eastern gate until dawn.

Ledger 02 line 047: Neri carried the blue token past marker 1f52f76d4ebf. Mara watched the eastern gate until dawn.

Ledger 02 line 048: Neri carried the blue token past marker 083849c13c5a. Mara watched the eastern gate until dawn.

Ledger 02 line 049: Neri carried the blue token past marker 2be3ad9ac729. Mara watched the eastern gate until dawn.

Ledger 02 line 050: Neri carried the blue token past marker 6a0453c7201e. Mara watched the eastern gate until dawn.

Ledger 02 line 051: Neri carried the blue token past marker 3fd49cbb3cc6. Mara watched the eastern gate until dawn.

Ledger 02 line 052: Neri carried the blue token past marker f03f0270a6d1. Mara watched the eastern gate until dawn.

Ledger 02 line 053: Neri carried the blue token past marker d51cecf0d12c. Mara watched the eastern gate until dawn.

Ledger 02 line 054: Neri carried the blue token past marker 7127a03e7493. Mara watched the eastern gate until dawn.

Ledger 02 line 055: Neri carried the blue token past marker 2284ff60434d. Mara watched the eastern gate until dawn.

Ledger 02 line 056: Neri carried the blue token past marker 99f653dbb835. Mara watched the eastern gate until dawn.

Ledger 02 line 057: Neri carried the blue token past marker d68de98edaa7. Mara watched the eastern gate until dawn.

Ledger 02 line 058: Neri carried the blue token past marker f8dcfc3a079c. Mara watched the eastern gate until dawn.

Ledger 02 line 059: Neri carried the blue token past marker ff3aff824348. Mara watched the eastern gate until dawn.

Ledger 02 line 060: Neri carried the blue token past marker 06fdc01155ad. Mara watched the eastern gate until dawn.

Ledger 02 line 061: Neri carried the blue token past marker 4da4e40b3548. Mara watched the eastern gate until dawn.

Ledger 02 line 062: Neri carried the blue token past marker 441339650270. Mara watched the eastern gate until dawn.

Ledger 02 line 063: Neri carried the blue token past marker ec31d3228cea. Mara watched the eastern gate until dawn.

Ledger 02 line 064: Neri carried the blue token past marker 859af82228b2. Mara watched the eastern gate until dawn.

Ledger 02 line 065: Neri carried the blue token past marker f834450dacb6. Mara watched the eastern gate until dawn.

Ledger 02 line 066: Neri carried the blue token past marker 58bf7b9e28dd. Mara watched the eastern gate until dawn.

Ledger 02 line 067: Neri carried the blue token past marker 768335487e91. Mara watched the eastern gate until dawn.

Ledger 02 line 068: Neri carried the blue token past marker 36574017a56c. Mara watched the eastern gate until dawn.

Ledger 02 line 069: Neri carried the blue token past marker 24dbe0e6574a. Mara watched the eastern gate until dawn.

Ledger 02 line 070: Neri carried the blue token past marker 38303df77bca. Mara watched the eastern gate until dawn.

Ledger 02 line 071: Neri carried the blue token past marker 5305edb33d9e. Mara watched the eastern gate until dawn.

Ledger 02 line 072: Neri carried the blue token past marker 11369c3ff867. Mara watched the eastern gate until dawn.

Ledger 02 line 073: Neri carried the blue token past marker e5568c91a8c4. Mara watched the eastern gate until dawn.

Ledger 02 line 074: Neri carried the blue token past marker 88d4e6bbb76e. Mara watched the eastern gate until dawn.

Ledger 02 line 075: Neri carried the blue token past marker ac78c3d2b3c7. Mara watched the eastern gate until dawn.

Ledger 02 line 076: Neri carried the blue token past marker c8423f27d27a. Mara watched the eastern gate until dawn.

Ledger 02 line 077: Neri carried the blue token past marker 1e2217e0e719. Mara watched the eastern gate until dawn.

Ledger 02 line 078: Neri carried the blue token past marker 4d556b3dc531. Mara watched the eastern gate until dawn.

Ledger 02 line 079: Neri carried the blue token past marker c5fdd69bf052. Mara watched the eastern gate until dawn.

Ledger 02 line 080: Neri carried the blue token past marker 1c2ecba8f838. Mara watched the eastern gate until dawn.

Ledger 02 line 081: Neri carried the blue token past marker 905c5ca1d7ec. Mara watched the eastern gate until dawn.

Ledger 02 line 082: Neri carried the blue token past marker 68fbd45bf610. Mara watched the eastern gate until dawn.

Ledger 02 line 083: Neri carried the blue token past marker c92e6aeafe48. Mara watched the eastern gate until dawn.

Ledger 02 line 084: Neri carried the blue token past marker 35f0e82f4bd6. Mara watched the eastern gate until dawn.

Ledger 02 line 085: Neri carried the blue token past marker 1de016d8240d. Mara watched the eastern gate until dawn.

Ledger 02 line 086: Neri carried the blue token past marker 11c9e56de835. Mara watched the eastern gate until dawn.

Ledger 02 line 087: Neri carried the blue token past marker 8e7d67a9ee72. Mara watched the eastern gate until dawn.

Ledger 02 line 088: Neri carried the blue token past marker 150992385b8f. Mara watched the eastern gate until dawn.

Ledger 02 line 089: Neri carried the blue token past marker 0703249143e2. Mara watched the eastern gate until dawn.

Ledger 02 line 090: Neri carried the blue token past marker df9d5dd681f5. Mara watched the eastern gate until dawn.

Ledger 02 line 091: Neri carried the blue token past marker 8ea5d4f15454. Mara watched the eastern gate until dawn.

Ledger 02 line 092: Neri carried the blue token past marker 583c972a302f. Mara watched the eastern gate until dawn.

Ledger 02 line 093: Neri carried the blue token past marker 7d81f6d0331b. Mara watched the eastern gate until dawn.

Ledger 02 line 094: Neri carried the blue token past marker b8d8ee11a865. Mara watched the eastern gate until dawn.

Ledger 02 line 095: Neri carried the blue token past marker d586317f59b6. Mara watched the eastern gate until dawn.

Ledger 02 line 096: Neri carried the blue token past marker 019496401c65. Mara watched the eastern gate until dawn.

Ledger 02 line 097: Neri carried the blue token past marker cd4a8abd723f. Mara watched the eastern gate until dawn.

Ledger 02 line 098: Neri carried the blue token past marker d30f46f38f9c. Mara watched the eastern gate until dawn.

Ledger 02 line 099: Neri carried the blue token past marker e2b59dada621. Mara watched the eastern gate until dawn.

Ledger 02 line 100: Neri carried the blue token past marker 53453170bfe7. Mara watched the eastern gate until dawn.

Ledger 02 line 101: Neri carried the blue token past marker 013fae145d69. Mara watched the eastern gate until dawn.

Ledger 02 line 102: Neri carried the blue token past marker d07f117fbf4e. Mara watched the eastern gate until dawn.

Ledger 02 line 103: Neri carried the blue token past marker 0f57aeb8dbe9. Mara watched the eastern gate until dawn.

Ledger 02 line 104: Neri carried the blue token past marker b38bb9d2c277. Mara watched the eastern gate until dawn.

Ledger 02 line 105: Neri carried the blue token past marker 98b28cb13011. Mara watched the eastern gate until dawn.

Ledger 02 line 106: Neri carried the blue token past marker 2c04fd316744. Mara watched the eastern gate until dawn.

Ledger 02 line 107: Neri carried the blue token past marker 674cb621ae8e. Mara watched the eastern gate until dawn.

Ledger 02 line 108: Neri carried the blue token past marker 52bbef196079. Mara watched the eastern gate until dawn.

Ledger 02 line 109: Neri carried the blue token past marker a73c8aeb71c8. Mara watched the eastern gate until dawn.

Ledger 02 line 110: Neri carried the blue token past marker a765ce048a21. Mara watched the eastern gate until dawn.

Ledger 02 line 111: Neri carried the blue token past marker 96e7ae144ea0. Mara watched the eastern gate until dawn.

Ledger 02 line 112: Neri carried the blue token past marker 9b5cd7212d4b. Mara watched the eastern gate until dawn.

Ledger 02 line 113: Neri carried the blue token past marker 4a63501859fb. Mara watched the eastern gate until dawn.

Ledger 02 line 114: Neri carried the blue token past marker e540169eeecc. Mara watched the eastern gate until dawn.

Ledger 02 line 115: Neri carried the blue token past marker 3582d647fe63. Mara watched the eastern gate until dawn.

Ledger 02 line 116: Neri carried the blue token past marker 9e9efe3f3315. Mara watched the eastern gate until dawn.

Ledger 02 line 117: Neri carried the blue token past marker cdbb7219a500. Mara watched the eastern gate until dawn.

Ledger 02 line 118: Neri carried the blue token past marker c7207e8fbe24. Mara watched the eastern gate until dawn.

Ledger 02 line 119: Neri carried the blue token past marker a337319adc09. Mara watched the eastern gate until dawn.

Ledger 02 line 120: Neri carried the blue token past marker 0166a8564483. Mara watched the eastern gate until dawn.

Ledger 02 line 121: Neri carried the blue token past marker b8dae79792d9. Mara watched the eastern gate until dawn.

Ledger 02 line 122: Neri carried the blue token past marker f234b9b134b6. Mara watched the eastern gate until dawn.

Ledger 02 line 123: Neri carried the blue token past marker 4d3e82d9de0b. Mara watched the eastern gate until dawn.

Ledger 02 line 124: Neri carried the blue token past marker be84c4f0b78a. Mara watched the eastern gate until dawn.

Ledger 02 line 125: Neri carried the blue token past marker b8db18ecc378. Mara watched the eastern gate until dawn.

Ledger 02 line 126: Neri carried the blue token past marker 3b136255344c. Mara watched the eastern gate until dawn.

Ledger 02 line 127: Neri carried the blue token past marker dda729513bd7. Mara watched the eastern gate until dawn.

Ledger 02 line 128: Neri carried the blue token past marker be75102a494a. Mara watched the eastern gate until dawn.

Ledger 02 line 129: Neri carried the blue token past marker 2aa68ad069f8. Mara watched the eastern gate until dawn.

Ledger 02 line 130: Neri carried the blue token past marker a0a460421dbf. Mara watched the eastern gate until dawn.

Ledger 02 line 131: Neri carried the blue token past marker 5d8b9ccad207. Mara watched the eastern gate until dawn.

Ledger 02 line 132: Neri carried the blue token past marker 1c7e758eed7d. Mara watched the eastern gate until dawn.

Ledger 02 line 133: Neri carried the blue token past marker d335696b80b6. Mara watched the eastern gate until dawn.

Ledger 02 line 134: Neri carried the blue token past marker 5deb6a47f74e. Mara watched the eastern gate until dawn.

Ledger 02 line 135: Neri carried the blue token past marker 8445b0fa80e6. Mara watched the eastern gate until dawn.

Ledger 02 line 136: Neri carried the blue token past marker 8ecf202d9c8d. Mara watched the eastern gate until dawn.

Ledger 02 line 137: Neri carried the blue token past marker 6327169d2e31. Mara watched the eastern gate until dawn.

Ledger 02 line 138: Neri carried the blue token past marker f7e660a1e66e. Mara watched the eastern gate until dawn.

Ledger 02 line 139: Neri carried the blue token past marker d091e283cfd4. Mara watched the eastern gate until dawn.

Ledger 02 line 140: Neri carried the blue token past marker c56a37041435. Mara watched the eastern gate until dawn.
