---
id: scene-0013
title: Recovery ledger 13
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.159420+00:00
updated_at: 2026-10-03T12:14:52.159420+00:00
---

Ledger 13 line 001: Neri carried the blue token past marker f0d9a6798b3c. Mara watched the eastern gate until dawn.

Ledger 13 line 002: Neri carried the blue token past marker 30182b97b6f6. Mara watched the eastern gate until dawn.

Ledger 13 line 003: Neri carried the blue token past marker b19c4029b088. Mara watched the eastern gate until dawn.

Ledger 13 line 004: Neri carried the blue token past marker 3fda0a5e1d6d. Mara watched the eastern gate until dawn.

Ledger 13 line 005: Neri carried the blue token past marker 2b593dd17956. Mara watched the eastern gate until dawn.

Ledger 13 line 006: Neri carried the blue token past marker 3adbce113380. Mara watched the eastern gate until dawn.

Ledger 13 line 007: Neri carried the blue token past marker 9bd71153d636. Mara watched the eastern gate until dawn.

Ledger 13 line 008: Neri carried the blue token past marker aa6d390feb1b. Mara watched the eastern gate until dawn.

Ledger 13 line 009: Neri carried the blue token past marker bfe348545647. Mara watched the eastern gate until dawn.

Ledger 13 line 010: Neri carried the blue token past marker c4ca105d9cd7. Mara watched the eastern gate until dawn.

Ledger 13 line 011: Neri carried the blue token past marker 54fbd4d93052. Mara watched the eastern gate until dawn.

Ledger 13 line 012: Neri carried the blue token past marker b83def60abd8. Mara watched the eastern gate until dawn.

Ledger 13 line 013: Neri carried the blue token past marker 5966ca504e45. Mara watched the eastern gate until dawn.

Ledger 13 line 014: Neri carried the blue token past marker 3632fffb4a6d. Mara watched the eastern gate until dawn.

Ledger 13 line 015: Neri carried the blue token past marker 5692f1cf872d. Mara watched the eastern gate until dawn.

Ledger 13 line 016: Neri carried the blue token past marker 57a9b3adb143. Mara watched the eastern gate until dawn.

Ledger 13 line 017: Neri carried the blue token past marker c0a10a11cd6d. Mara watched the eastern gate until dawn.

Ledger 13 line 018: Neri carried the blue token past marker 653533ed4461. Mara watched the eastern gate until dawn.

Ledger 13 line 019: Neri carried the blue token past marker e4aab8bf8ef4. Mara watched the eastern gate until dawn.

Ledger 13 line 020: Neri carried the blue token past marker d46cf2307e7c. Mara watched the eastern gate until dawn.

Ledger 13 line 021: Neri carried the blue token past marker 4cb1e520d7f9. Mara watched the eastern gate until dawn.

Ledger 13 line 022: Neri carried the blue token past marker 47c453d985d6. Mara watched the eastern gate until dawn.

Ledger 13 line 023: Neri carried the blue token past marker 864119b01d06. Mara watched the eastern gate until dawn.

Ledger 13 line 024: Neri carried the blue token past marker 902305105b05. Mara watched the eastern gate until dawn.

Ledger 13 line 025: Neri carried the blue token past marker d0b0c5b0db5c. Mara watched the eastern gate until dawn.

Ledger 13 line 026: Neri carried the blue token past marker 5a6bc2d9db56. Mara watched the eastern gate until dawn.

Ledger 13 line 027: Neri carried the blue token past marker 1af4fcc625b4. Mara watched the eastern gate until dawn.

Ledger 13 line 028: Neri carried the blue token past marker e3291ff53c16. Mara watched the eastern gate until dawn.

Ledger 13 line 029: Neri carried the blue token past marker 31df47ff6cda. Mara watched the eastern gate until dawn.

Ledger 13 line 030: Neri carried the blue token past marker 5c892eb9386f. Mara watched the eastern gate until dawn.

Ledger 13 line 031: Neri carried the blue token past marker 48c3922c6774. Mara watched the eastern gate until dawn.

Ledger 13 line 032: Neri carried the blue token past marker 149504d96bdb. Mara watched the eastern gate until dawn.

Ledger 13 line 033: Neri carried the blue token past marker 65c34656e428. Mara watched the eastern gate until dawn.

Ledger 13 line 034: Neri carried the blue token past marker 4f728d21d561. Mara watched the eastern gate until dawn.

Ledger 13 line 035: Neri carried the blue token past marker 76df45841b6d. Mara watched the eastern gate until dawn.

Ledger 13 line 036: Neri carried the blue token past marker 8f7bec88c57e. Mara watched the eastern gate until dawn.

Ledger 13 line 037: Neri carried the blue token past marker 6ef0f8d6c13d. Mara watched the eastern gate until dawn.

Ledger 13 line 038: Neri carried the blue token past marker 52d45a377b39. Mara watched the eastern gate until dawn.

Ledger 13 line 039: Neri carried the blue token past marker 14af80ba3618. Mara watched the eastern gate until dawn.

Ledger 13 line 040: Neri carried the blue token past marker 440d2522b331. Mara watched the eastern gate until dawn.

Ledger 13 line 041: Neri carried the blue token past marker 57674379ebaa. Mara watched the eastern gate until dawn.

Ledger 13 line 042: Neri carried the blue token past marker 8cc8195e42a4. Mara watched the eastern gate until dawn.

Ledger 13 line 043: Neri carried the blue token past marker b61437b57491. Mara watched the eastern gate until dawn.

Ledger 13 line 044: Neri carried the blue token past marker 34fccd6ecc33. Mara watched the eastern gate until dawn.

Ledger 13 line 045: Neri carried the blue token past marker b7e2a419db74. Mara watched the eastern gate until dawn.

Ledger 13 line 046: Neri carried the blue token past marker b9d828ad23a1. Mara watched the eastern gate until dawn.

Ledger 13 line 047: Neri carried the blue token past marker 41850b5892a9. Mara watched the eastern gate until dawn.

Ledger 13 line 048: Neri carried the blue token past marker bcc1ab1855ed. Mara watched the eastern gate until dawn.

Ledger 13 line 049: Neri carried the blue token past marker 11845c850c2d. Mara watched the eastern gate until dawn.

Ledger 13 line 050: Neri carried the blue token past marker 83d8be640480. Mara watched the eastern gate until dawn.

Ledger 13 line 051: Neri carried the blue token past marker e5387d4dcbd2. Mara watched the eastern gate until dawn.

Ledger 13 line 052: Neri carried the blue token past marker e90dc96c453f. Mara watched the eastern gate until dawn.

Ledger 13 line 053: Neri carried the blue token past marker 1a549dfdac5a. Mara watched the eastern gate until dawn.

Ledger 13 line 054: Neri carried the blue token past marker f87aaee3483d. Mara watched the eastern gate until dawn.

Ledger 13 line 055: Neri carried the blue token past marker 24ab3d7ee697. Mara watched the eastern gate until dawn.

Ledger 13 line 056: Neri carried the blue token past marker eeed0439e20c. Mara watched the eastern gate until dawn.

Ledger 13 line 057: Neri carried the blue token past marker 894f0fcbd82f. Mara watched the eastern gate until dawn.

Ledger 13 line 058: Neri carried the blue token past marker 25aba2040a4e. Mara watched the eastern gate until dawn.

Ledger 13 line 059: Neri carried the blue token past marker b5c5d228f2cf. Mara watched the eastern gate until dawn.

Ledger 13 line 060: Neri carried the blue token past marker 4a34decdf87b. Mara watched the eastern gate until dawn.

Ledger 13 line 061: Neri carried the blue token past marker 487c82f4e2ba. Mara watched the eastern gate until dawn.

Ledger 13 line 062: Neri carried the blue token past marker fd7deb86f4a6. Mara watched the eastern gate until dawn.

Ledger 13 line 063: Neri carried the blue token past marker 409367657da9. Mara watched the eastern gate until dawn.

Ledger 13 line 064: Neri carried the blue token past marker 46a2010afc96. Mara watched the eastern gate until dawn.

Ledger 13 line 065: Neri carried the blue token past marker 590bdae4f5c4. Mara watched the eastern gate until dawn.

Ledger 13 line 066: Neri carried the blue token past marker 851250d56bf3. Mara watched the eastern gate until dawn.

Ledger 13 line 067: Neri carried the blue token past marker 6e75b428868a. Mara watched the eastern gate until dawn.

Ledger 13 line 068: Neri carried the blue token past marker 47d1aa2812d2. Mara watched the eastern gate until dawn.

Ledger 13 line 069: Neri carried the blue token past marker 4136f2f3c763. Mara watched the eastern gate until dawn.

Ledger 13 line 070: Neri carried the blue token past marker 799cb0a84bfa. Mara watched the eastern gate until dawn.

Ledger 13 line 071: Neri carried the blue token past marker 0921712fe801. Mara watched the eastern gate until dawn.

Ledger 13 line 072: Neri carried the blue token past marker 77a87bd5f623. Mara watched the eastern gate until dawn.

Ledger 13 line 073: Neri carried the blue token past marker afd03550c439. Mara watched the eastern gate until dawn.

Ledger 13 line 074: Neri carried the blue token past marker 6cdf36768c98. Mara watched the eastern gate until dawn.

Ledger 13 line 075: Neri carried the blue token past marker 1cd46f54888a. Mara watched the eastern gate until dawn.

Ledger 13 line 076: Neri carried the blue token past marker 5359435b6d23. Mara watched the eastern gate until dawn.

Ledger 13 line 077: Neri carried the blue token past marker 4eec8efae170. Mara watched the eastern gate until dawn.

Ledger 13 line 078: Neri carried the blue token past marker f0e57830342a. Mara watched the eastern gate until dawn.

Ledger 13 line 079: Neri carried the blue token past marker 5f2bb80a2c29. Mara watched the eastern gate until dawn.

Ledger 13 line 080: Neri carried the blue token past marker d29700b0ba04. Mara watched the eastern gate until dawn.

Ledger 13 line 081: Neri carried the blue token past marker f024d160220c. Mara watched the eastern gate until dawn.

Ledger 13 line 082: Neri carried the blue token past marker f16ef9f5706b. Mara watched the eastern gate until dawn.

Ledger 13 line 083: Neri carried the blue token past marker 212535b4aea6. Mara watched the eastern gate until dawn.

Ledger 13 line 084: Neri carried the blue token past marker 5cc63d30d70f. Mara watched the eastern gate until dawn.

Ledger 13 line 085: Neri carried the blue token past marker d08dc42f4e99. Mara watched the eastern gate until dawn.

Ledger 13 line 086: Neri carried the blue token past marker 56d9359d0450. Mara watched the eastern gate until dawn.

Ledger 13 line 087: Neri carried the blue token past marker e50011115043. Mara watched the eastern gate until dawn.

Ledger 13 line 088: Neri carried the blue token past marker 9d4da81747f8. Mara watched the eastern gate until dawn.

Ledger 13 line 089: Neri carried the blue token past marker 78651501aafe. Mara watched the eastern gate until dawn.

Ledger 13 line 090: Neri carried the blue token past marker daab34fa28da. Mara watched the eastern gate until dawn.

Ledger 13 line 091: Neri carried the blue token past marker ce567650f22f. Mara watched the eastern gate until dawn.

Ledger 13 line 092: Neri carried the blue token past marker 697bd87eac1d. Mara watched the eastern gate until dawn.

Ledger 13 line 093: Neri carried the blue token past marker bf415d88cbba. Mara watched the eastern gate until dawn.

Ledger 13 line 094: Neri carried the blue token past marker d81c78f384be. Mara watched the eastern gate until dawn.

Ledger 13 line 095: Neri carried the blue token past marker 204d3f4d2176. Mara watched the eastern gate until dawn.

Ledger 13 line 096: Neri carried the blue token past marker fda8c0ecc28b. Mara watched the eastern gate until dawn.

Ledger 13 line 097: Neri carried the blue token past marker baaba7460829. Mara watched the eastern gate until dawn.

Ledger 13 line 098: Neri carried the blue token past marker d66191a277e1. Mara watched the eastern gate until dawn.

Ledger 13 line 099: Neri carried the blue token past marker daf74e486e52. Mara watched the eastern gate until dawn.

Ledger 13 line 100: Neri carried the blue token past marker 3c37ffb4749b. Mara watched the eastern gate until dawn.

Ledger 13 line 101: Neri carried the blue token past marker 9f634dff84c2. Mara watched the eastern gate until dawn.

Ledger 13 line 102: Neri carried the blue token past marker fe6aaee60c08. Mara watched the eastern gate until dawn.

Ledger 13 line 103: Neri carried the blue token past marker 7c24074d4c07. Mara watched the eastern gate until dawn.

Ledger 13 line 104: Neri carried the blue token past marker 77de0456f200. Mara watched the eastern gate until dawn.

Ledger 13 line 105: Neri carried the blue token past marker bc45ce04d3bd. Mara watched the eastern gate until dawn.

Ledger 13 line 106: Neri carried the blue token past marker b9edb206ae7a. Mara watched the eastern gate until dawn.

Ledger 13 line 107: Neri carried the blue token past marker 951075a5c422. Mara watched the eastern gate until dawn.

Ledger 13 line 108: Neri carried the blue token past marker 5eb684278f0c. Mara watched the eastern gate until dawn.

Ledger 13 line 109: Neri carried the blue token past marker de51b1ec0968. Mara watched the eastern gate until dawn.

Ledger 13 line 110: Neri carried the blue token past marker c3cb32907de4. Mara watched the eastern gate until dawn.

Ledger 13 line 111: Neri carried the blue token past marker c534b10ae747. Mara watched the eastern gate until dawn.

Ledger 13 line 112: Neri carried the blue token past marker 429046f921b4. Mara watched the eastern gate until dawn.

Ledger 13 line 113: Neri carried the blue token past marker 7a0d9dca8929. Mara watched the eastern gate until dawn.

Ledger 13 line 114: Neri carried the blue token past marker 7c5ab9b3b79b. Mara watched the eastern gate until dawn.

Ledger 13 line 115: Neri carried the blue token past marker 4ce36f87d028. Mara watched the eastern gate until dawn.

Ledger 13 line 116: Neri carried the blue token past marker 7825bba511d0. Mara watched the eastern gate until dawn.

Ledger 13 line 117: Neri carried the blue token past marker b422bb53280b. Mara watched the eastern gate until dawn.

Ledger 13 line 118: Neri carried the blue token past marker e0dd522e3e26. Mara watched the eastern gate until dawn.

Ledger 13 line 119: Neri carried the blue token past marker 9a5a99e60187. Mara watched the eastern gate until dawn.

Ledger 13 line 120: Neri carried the blue token past marker ca4ce1a5c288. Mara watched the eastern gate until dawn.

Ledger 13 line 121: Neri carried the blue token past marker 0ff43d1a885b. Mara watched the eastern gate until dawn.

Ledger 13 line 122: Neri carried the blue token past marker cbbe9dc8253c. Mara watched the eastern gate until dawn.

Ledger 13 line 123: Neri carried the blue token past marker 65d9eb80b7a9. Mara watched the eastern gate until dawn.

Ledger 13 line 124: Neri carried the blue token past marker c55524a27bd5. Mara watched the eastern gate until dawn.

Ledger 13 line 125: Neri carried the blue token past marker 9e0489d7f577. Mara watched the eastern gate until dawn.

Ledger 13 line 126: Neri carried the blue token past marker 91fbfebf32cd. Mara watched the eastern gate until dawn.

Ledger 13 line 127: Neri carried the blue token past marker d5c3f63a7563. Mara watched the eastern gate until dawn.

Ledger 13 line 128: Neri carried the blue token past marker 9968403a05f8. Mara watched the eastern gate until dawn.

Ledger 13 line 129: Neri carried the blue token past marker c6ef885ef6c4. Mara watched the eastern gate until dawn.

Ledger 13 line 130: Neri carried the blue token past marker d74244e9c39f. Mara watched the eastern gate until dawn.

Ledger 13 line 131: Neri carried the blue token past marker 94349b79c316. Mara watched the eastern gate until dawn.

Ledger 13 line 132: Neri carried the blue token past marker 54449ac2e8dc. Mara watched the eastern gate until dawn.

Ledger 13 line 133: Neri carried the blue token past marker a58780f0d389. Mara watched the eastern gate until dawn.

Ledger 13 line 134: Neri carried the blue token past marker 9aff6c98d5c7. Mara watched the eastern gate until dawn.

Ledger 13 line 135: Neri carried the blue token past marker c22a90a4fa21. Mara watched the eastern gate until dawn.

Ledger 13 line 136: Neri carried the blue token past marker 01eba26d2981. Mara watched the eastern gate until dawn.

Ledger 13 line 137: Neri carried the blue token past marker 6e29daf57e38. Mara watched the eastern gate until dawn.

Ledger 13 line 138: Neri carried the blue token past marker b42ddbefcd07. Mara watched the eastern gate until dawn.

Ledger 13 line 139: Neri carried the blue token past marker 830454c39e47. Mara watched the eastern gate until dawn.

Ledger 13 line 140: Neri carried the blue token past marker d8c01c2f9e9f. Mara watched the eastern gate until dawn.
