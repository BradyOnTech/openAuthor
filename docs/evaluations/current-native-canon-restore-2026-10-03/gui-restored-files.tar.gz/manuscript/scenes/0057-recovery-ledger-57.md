---
id: scene-0057
title: Recovery ledger 57
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.182999+00:00
updated_at: 2026-10-03T12:14:52.182999+00:00
---

Ledger 57 line 001: Neri carried the blue token past marker 28bfc10f162c. Mara watched the eastern gate until dawn.

Ledger 57 line 002: Neri carried the blue token past marker fce0dc4a7049. Mara watched the eastern gate until dawn.

Ledger 57 line 003: Neri carried the blue token past marker acdf690f59f3. Mara watched the eastern gate until dawn.

Ledger 57 line 004: Neri carried the blue token past marker 20701e4ac776. Mara watched the eastern gate until dawn.

Ledger 57 line 005: Neri carried the blue token past marker f176962746a8. Mara watched the eastern gate until dawn.

Ledger 57 line 006: Neri carried the blue token past marker 495ac742d1e2. Mara watched the eastern gate until dawn.

Ledger 57 line 007: Neri carried the blue token past marker bf9c5a577698. Mara watched the eastern gate until dawn.

Ledger 57 line 008: Neri carried the blue token past marker 30da8ccd54cd. Mara watched the eastern gate until dawn.

Ledger 57 line 009: Neri carried the blue token past marker e8a3a15a4b71. Mara watched the eastern gate until dawn.

Ledger 57 line 010: Neri carried the blue token past marker 436f24aee062. Mara watched the eastern gate until dawn.

Ledger 57 line 011: Neri carried the blue token past marker 709314af8dcb. Mara watched the eastern gate until dawn.

Ledger 57 line 012: Neri carried the blue token past marker e06722d42ff8. Mara watched the eastern gate until dawn.

Ledger 57 line 013: Neri carried the blue token past marker 83ead6b8d731. Mara watched the eastern gate until dawn.

Ledger 57 line 014: Neri carried the blue token past marker da46e0590e5d. Mara watched the eastern gate until dawn.

Ledger 57 line 015: Neri carried the blue token past marker 24116957476b. Mara watched the eastern gate until dawn.

Ledger 57 line 016: Neri carried the blue token past marker 4eef5b81cad2. Mara watched the eastern gate until dawn.

Ledger 57 line 017: Neri carried the blue token past marker 6de345ccd153. Mara watched the eastern gate until dawn.

Ledger 57 line 018: Neri carried the blue token past marker b907812e213b. Mara watched the eastern gate until dawn.

Ledger 57 line 019: Neri carried the blue token past marker 8489221c8a0b. Mara watched the eastern gate until dawn.

Ledger 57 line 020: Neri carried the blue token past marker 211d5b82528d. Mara watched the eastern gate until dawn.

Ledger 57 line 021: Neri carried the blue token past marker 2ffa5e22d5c7. Mara watched the eastern gate until dawn.

Ledger 57 line 022: Neri carried the blue token past marker 4d383a656c94. Mara watched the eastern gate until dawn.

Ledger 57 line 023: Neri carried the blue token past marker 9a064d7756ef. Mara watched the eastern gate until dawn.

Ledger 57 line 024: Neri carried the blue token past marker af2dfb8b6bc2. Mara watched the eastern gate until dawn.

Ledger 57 line 025: Neri carried the blue token past marker 83470ea964a3. Mara watched the eastern gate until dawn.

Ledger 57 line 026: Neri carried the blue token past marker 66578bb133a3. Mara watched the eastern gate until dawn.

Ledger 57 line 027: Neri carried the blue token past marker f61c5e6d3299. Mara watched the eastern gate until dawn.

Ledger 57 line 028: Neri carried the blue token past marker dc82340036fa. Mara watched the eastern gate until dawn.

Ledger 57 line 029: Neri carried the blue token past marker 3e8395903df2. Mara watched the eastern gate until dawn.

Ledger 57 line 030: Neri carried the blue token past marker 65f4c5b9c99e. Mara watched the eastern gate until dawn.

Ledger 57 line 031: Neri carried the blue token past marker 5d471b06f214. Mara watched the eastern gate until dawn.

Ledger 57 line 032: Neri carried the blue token past marker eb6a27a3998c. Mara watched the eastern gate until dawn.

Ledger 57 line 033: Neri carried the blue token past marker 8b35da1ad294. Mara watched the eastern gate until dawn.

Ledger 57 line 034: Neri carried the blue token past marker 61e4beed7ed1. Mara watched the eastern gate until dawn.

Ledger 57 line 035: Neri carried the blue token past marker be9f3686b20d. Mara watched the eastern gate until dawn.

Ledger 57 line 036: Neri carried the blue token past marker bcfcfd3d188e. Mara watched the eastern gate until dawn.

Ledger 57 line 037: Neri carried the blue token past marker a2652c94e983. Mara watched the eastern gate until dawn.

Ledger 57 line 038: Neri carried the blue token past marker a73804bc257e. Mara watched the eastern gate until dawn.

Ledger 57 line 039: Neri carried the blue token past marker 54eb7103d5cb. Mara watched the eastern gate until dawn.

Ledger 57 line 040: Neri carried the blue token past marker f1005621d612. Mara watched the eastern gate until dawn.

Ledger 57 line 041: Neri carried the blue token past marker 3f347964b270. Mara watched the eastern gate until dawn.

Ledger 57 line 042: Neri carried the blue token past marker 71db358c0349. Mara watched the eastern gate until dawn.

Ledger 57 line 043: Neri carried the blue token past marker b3a30d5f01d1. Mara watched the eastern gate until dawn.

Ledger 57 line 044: Neri carried the blue token past marker 804d403859d4. Mara watched the eastern gate until dawn.

Ledger 57 line 045: Neri carried the blue token past marker b6527d3f2050. Mara watched the eastern gate until dawn.

Ledger 57 line 046: Neri carried the blue token past marker 37b05de51c55. Mara watched the eastern gate until dawn.

Ledger 57 line 047: Neri carried the blue token past marker ca0bedd0d351. Mara watched the eastern gate until dawn.

Ledger 57 line 048: Neri carried the blue token past marker 7209481c1beb. Mara watched the eastern gate until dawn.

Ledger 57 line 049: Neri carried the blue token past marker a4112263d0e2. Mara watched the eastern gate until dawn.

Ledger 57 line 050: Neri carried the blue token past marker 8ba1e67c0584. Mara watched the eastern gate until dawn.

Ledger 57 line 051: Neri carried the blue token past marker bc53f7b4d885. Mara watched the eastern gate until dawn.

Ledger 57 line 052: Neri carried the blue token past marker 7ebbc777c1de. Mara watched the eastern gate until dawn.

Ledger 57 line 053: Neri carried the blue token past marker 20ff3c224b70. Mara watched the eastern gate until dawn.

Ledger 57 line 054: Neri carried the blue token past marker 6a731e1e49cf. Mara watched the eastern gate until dawn.

Ledger 57 line 055: Neri carried the blue token past marker cf21fdbd3b53. Mara watched the eastern gate until dawn.

Ledger 57 line 056: Neri carried the blue token past marker bf4aaf325cfd. Mara watched the eastern gate until dawn.

Ledger 57 line 057: Neri carried the blue token past marker 6ef3a2476411. Mara watched the eastern gate until dawn.

Ledger 57 line 058: Neri carried the blue token past marker 9e344d57f048. Mara watched the eastern gate until dawn.

Ledger 57 line 059: Neri carried the blue token past marker 559467f65bed. Mara watched the eastern gate until dawn.

Ledger 57 line 060: Neri carried the blue token past marker baea114cd561. Mara watched the eastern gate until dawn.

Ledger 57 line 061: Neri carried the blue token past marker 360ab5668be0. Mara watched the eastern gate until dawn.

Ledger 57 line 062: Neri carried the blue token past marker 45057dbdba89. Mara watched the eastern gate until dawn.

Ledger 57 line 063: Neri carried the blue token past marker b6dfd4fbc670. Mara watched the eastern gate until dawn.

Ledger 57 line 064: Neri carried the blue token past marker 63a345ee2e4c. Mara watched the eastern gate until dawn.

Ledger 57 line 065: Neri carried the blue token past marker bcd8ac1a8bab. Mara watched the eastern gate until dawn.

Ledger 57 line 066: Neri carried the blue token past marker 618f53460792. Mara watched the eastern gate until dawn.

Ledger 57 line 067: Neri carried the blue token past marker bdcb6fba7ef8. Mara watched the eastern gate until dawn.

Ledger 57 line 068: Neri carried the blue token past marker 628d2aa6bc40. Mara watched the eastern gate until dawn.

Ledger 57 line 069: Neri carried the blue token past marker 134f5966d238. Mara watched the eastern gate until dawn.

Ledger 57 line 070: Neri carried the blue token past marker 607c0ac5e72f. Mara watched the eastern gate until dawn.

Ledger 57 line 071: Neri carried the blue token past marker b91acc36a6b5. Mara watched the eastern gate until dawn.

Ledger 57 line 072: Neri carried the blue token past marker 5c3db7040f25. Mara watched the eastern gate until dawn.

Ledger 57 line 073: Neri carried the blue token past marker d0839b6bbc0e. Mara watched the eastern gate until dawn.

Ledger 57 line 074: Neri carried the blue token past marker b418f90fa633. Mara watched the eastern gate until dawn.

Ledger 57 line 075: Neri carried the blue token past marker cb9ac81ceb00. Mara watched the eastern gate until dawn.

Ledger 57 line 076: Neri carried the blue token past marker 57b8bda92a5c. Mara watched the eastern gate until dawn.

Ledger 57 line 077: Neri carried the blue token past marker b4d43f6afbcc. Mara watched the eastern gate until dawn.

Ledger 57 line 078: Neri carried the blue token past marker 61968b5364ad. Mara watched the eastern gate until dawn.

Ledger 57 line 079: Neri carried the blue token past marker d0a457483604. Mara watched the eastern gate until dawn.

Ledger 57 line 080: Neri carried the blue token past marker 26a5d6f6adfe. Mara watched the eastern gate until dawn.

Ledger 57 line 081: Neri carried the blue token past marker e7aa172d4d95. Mara watched the eastern gate until dawn.

Ledger 57 line 082: Neri carried the blue token past marker 121e4972a111. Mara watched the eastern gate until dawn.

Ledger 57 line 083: Neri carried the blue token past marker 10dcb32b2f65. Mara watched the eastern gate until dawn.

Ledger 57 line 084: Neri carried the blue token past marker 1f445d004cab. Mara watched the eastern gate until dawn.

Ledger 57 line 085: Neri carried the blue token past marker 01e069ce5fec. Mara watched the eastern gate until dawn.

Ledger 57 line 086: Neri carried the blue token past marker 2b9a08e46177. Mara watched the eastern gate until dawn.

Ledger 57 line 087: Neri carried the blue token past marker 6c1101790eaf. Mara watched the eastern gate until dawn.

Ledger 57 line 088: Neri carried the blue token past marker f99678f7df52. Mara watched the eastern gate until dawn.

Ledger 57 line 089: Neri carried the blue token past marker 06adc97c6369. Mara watched the eastern gate until dawn.

Ledger 57 line 090: Neri carried the blue token past marker 363cf22dc074. Mara watched the eastern gate until dawn.

Ledger 57 line 091: Neri carried the blue token past marker af03c492bbfa. Mara watched the eastern gate until dawn.

Ledger 57 line 092: Neri carried the blue token past marker 10ae6457a68a. Mara watched the eastern gate until dawn.

Ledger 57 line 093: Neri carried the blue token past marker 2d11f3aa2a79. Mara watched the eastern gate until dawn.

Ledger 57 line 094: Neri carried the blue token past marker a22041ba3ebd. Mara watched the eastern gate until dawn.

Ledger 57 line 095: Neri carried the blue token past marker 9031b8188ffe. Mara watched the eastern gate until dawn.

Ledger 57 line 096: Neri carried the blue token past marker d7a4bf7b4a61. Mara watched the eastern gate until dawn.

Ledger 57 line 097: Neri carried the blue token past marker 57cb1cd3c2ee. Mara watched the eastern gate until dawn.

Ledger 57 line 098: Neri carried the blue token past marker ae34527285ef. Mara watched the eastern gate until dawn.

Ledger 57 line 099: Neri carried the blue token past marker fc836c8c0a6d. Mara watched the eastern gate until dawn.

Ledger 57 line 100: Neri carried the blue token past marker a43201277600. Mara watched the eastern gate until dawn.

Ledger 57 line 101: Neri carried the blue token past marker ebaa14360e0f. Mara watched the eastern gate until dawn.

Ledger 57 line 102: Neri carried the blue token past marker df969e99c1c5. Mara watched the eastern gate until dawn.

Ledger 57 line 103: Neri carried the blue token past marker d6bca75f51f8. Mara watched the eastern gate until dawn.

Ledger 57 line 104: Neri carried the blue token past marker 8028336b8f61. Mara watched the eastern gate until dawn.

Ledger 57 line 105: Neri carried the blue token past marker 4583bfa3aa79. Mara watched the eastern gate until dawn.

Ledger 57 line 106: Neri carried the blue token past marker 328d63eec1ae. Mara watched the eastern gate until dawn.

Ledger 57 line 107: Neri carried the blue token past marker 7bea9efce719. Mara watched the eastern gate until dawn.

Ledger 57 line 108: Neri carried the blue token past marker 4899bd4b6b2e. Mara watched the eastern gate until dawn.

Ledger 57 line 109: Neri carried the blue token past marker 7da99f4f9f46. Mara watched the eastern gate until dawn.

Ledger 57 line 110: Neri carried the blue token past marker 20785827f33a. Mara watched the eastern gate until dawn.

Ledger 57 line 111: Neri carried the blue token past marker 343c342f282c. Mara watched the eastern gate until dawn.

Ledger 57 line 112: Neri carried the blue token past marker 75df400fe954. Mara watched the eastern gate until dawn.

Ledger 57 line 113: Neri carried the blue token past marker c9782bbe35f6. Mara watched the eastern gate until dawn.

Ledger 57 line 114: Neri carried the blue token past marker 73eddecc3ae6. Mara watched the eastern gate until dawn.

Ledger 57 line 115: Neri carried the blue token past marker 5abe9891bed6. Mara watched the eastern gate until dawn.

Ledger 57 line 116: Neri carried the blue token past marker e05df641ec28. Mara watched the eastern gate until dawn.

Ledger 57 line 117: Neri carried the blue token past marker ebf005b37b1f. Mara watched the eastern gate until dawn.

Ledger 57 line 118: Neri carried the blue token past marker 9704a7a1e0c3. Mara watched the eastern gate until dawn.

Ledger 57 line 119: Neri carried the blue token past marker 46696fe7399d. Mara watched the eastern gate until dawn.

Ledger 57 line 120: Neri carried the blue token past marker e14e47452557. Mara watched the eastern gate until dawn.

Ledger 57 line 121: Neri carried the blue token past marker a82d227bda75. Mara watched the eastern gate until dawn.

Ledger 57 line 122: Neri carried the blue token past marker 1548069ff72f. Mara watched the eastern gate until dawn.

Ledger 57 line 123: Neri carried the blue token past marker 207ba553b791. Mara watched the eastern gate until dawn.

Ledger 57 line 124: Neri carried the blue token past marker 2faae21427b4. Mara watched the eastern gate until dawn.

Ledger 57 line 125: Neri carried the blue token past marker 7d7c375e6b20. Mara watched the eastern gate until dawn.

Ledger 57 line 126: Neri carried the blue token past marker 65d5ced82892. Mara watched the eastern gate until dawn.

Ledger 57 line 127: Neri carried the blue token past marker dc2872755a48. Mara watched the eastern gate until dawn.

Ledger 57 line 128: Neri carried the blue token past marker dff5c807b895. Mara watched the eastern gate until dawn.

Ledger 57 line 129: Neri carried the blue token past marker 574fe4edcf3d. Mara watched the eastern gate until dawn.

Ledger 57 line 130: Neri carried the blue token past marker 71c3c47a740e. Mara watched the eastern gate until dawn.

Ledger 57 line 131: Neri carried the blue token past marker 4baa1c195353. Mara watched the eastern gate until dawn.

Ledger 57 line 132: Neri carried the blue token past marker e8d5b0fc5326. Mara watched the eastern gate until dawn.

Ledger 57 line 133: Neri carried the blue token past marker b084cad5f9fe. Mara watched the eastern gate until dawn.

Ledger 57 line 134: Neri carried the blue token past marker aa992665edc1. Mara watched the eastern gate until dawn.

Ledger 57 line 135: Neri carried the blue token past marker 8dcdb7b58076. Mara watched the eastern gate until dawn.

Ledger 57 line 136: Neri carried the blue token past marker 3b00353abf83. Mara watched the eastern gate until dawn.

Ledger 57 line 137: Neri carried the blue token past marker 7f6dcc7f8d29. Mara watched the eastern gate until dawn.

Ledger 57 line 138: Neri carried the blue token past marker 85e6916da91c. Mara watched the eastern gate until dawn.

Ledger 57 line 139: Neri carried the blue token past marker 1238b3c2e65a. Mara watched the eastern gate until dawn.

Ledger 57 line 140: Neri carried the blue token past marker 987ce938f3df. Mara watched the eastern gate until dawn.
