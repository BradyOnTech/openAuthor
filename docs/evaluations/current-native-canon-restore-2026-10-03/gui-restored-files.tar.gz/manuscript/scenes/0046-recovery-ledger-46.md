---
id: scene-0046
title: Recovery ledger 46
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.177070+00:00
updated_at: 2026-10-03T12:14:52.177070+00:00
---

Ledger 46 line 001: Neri carried the blue token past marker 6c9f6c327597. Mara watched the eastern gate until dawn.

Ledger 46 line 002: Neri carried the blue token past marker ece04de35adf. Mara watched the eastern gate until dawn.

Ledger 46 line 003: Neri carried the blue token past marker 936f32da8465. Mara watched the eastern gate until dawn.

Ledger 46 line 004: Neri carried the blue token past marker 5f3fceb68231. Mara watched the eastern gate until dawn.

Ledger 46 line 005: Neri carried the blue token past marker e45075b1cffa. Mara watched the eastern gate until dawn.

Ledger 46 line 006: Neri carried the blue token past marker b30d7c02f599. Mara watched the eastern gate until dawn.

Ledger 46 line 007: Neri carried the blue token past marker 563c8fbc5b39. Mara watched the eastern gate until dawn.

Ledger 46 line 008: Neri carried the blue token past marker 8246304b60d8. Mara watched the eastern gate until dawn.

Ledger 46 line 009: Neri carried the blue token past marker 1710caea2a31. Mara watched the eastern gate until dawn.

Ledger 46 line 010: Neri carried the blue token past marker 9b0264afa7b5. Mara watched the eastern gate until dawn.

Ledger 46 line 011: Neri carried the blue token past marker 45ea94bdd052. Mara watched the eastern gate until dawn.

Ledger 46 line 012: Neri carried the blue token past marker 8a445b51f3ba. Mara watched the eastern gate until dawn.

Ledger 46 line 013: Neri carried the blue token past marker f9d6bacaade7. Mara watched the eastern gate until dawn.

Ledger 46 line 014: Neri carried the blue token past marker c49172e98de3. Mara watched the eastern gate until dawn.

Ledger 46 line 015: Neri carried the blue token past marker 2f946ce49e8d. Mara watched the eastern gate until dawn.

Ledger 46 line 016: Neri carried the blue token past marker b9b757cc1453. Mara watched the eastern gate until dawn.

Ledger 46 line 017: Neri carried the blue token past marker 948725d4ff29. Mara watched the eastern gate until dawn.

Ledger 46 line 018: Neri carried the blue token past marker cd4a0b19489b. Mara watched the eastern gate until dawn.

Ledger 46 line 019: Neri carried the blue token past marker 89f7730cd209. Mara watched the eastern gate until dawn.

Ledger 46 line 020: Neri carried the blue token past marker 5551f6754a53. Mara watched the eastern gate until dawn.

Ledger 46 line 021: Neri carried the blue token past marker f9039ea0f9c9. Mara watched the eastern gate until dawn.

Ledger 46 line 022: Neri carried the blue token past marker d2fbb6ae5df4. Mara watched the eastern gate until dawn.

Ledger 46 line 023: Neri carried the blue token past marker d04601aaa901. Mara watched the eastern gate until dawn.

Ledger 46 line 024: Neri carried the blue token past marker 510943118698. Mara watched the eastern gate until dawn.

Ledger 46 line 025: Neri carried the blue token past marker b46357769448. Mara watched the eastern gate until dawn.

Ledger 46 line 026: Neri carried the blue token past marker e44ed4480eae. Mara watched the eastern gate until dawn.

Ledger 46 line 027: Neri carried the blue token past marker 6aaaa1ecaab6. Mara watched the eastern gate until dawn.

Ledger 46 line 028: Neri carried the blue token past marker ba67bf38b274. Mara watched the eastern gate until dawn.

Ledger 46 line 029: Neri carried the blue token past marker 8fbfd13c1cb1. Mara watched the eastern gate until dawn.

Ledger 46 line 030: Neri carried the blue token past marker 859abc1a0a1e. Mara watched the eastern gate until dawn.

Ledger 46 line 031: Neri carried the blue token past marker d3aec40dab54. Mara watched the eastern gate until dawn.

Ledger 46 line 032: Neri carried the blue token past marker 069b20980ac6. Mara watched the eastern gate until dawn.

Ledger 46 line 033: Neri carried the blue token past marker 0d33823e9298. Mara watched the eastern gate until dawn.

Ledger 46 line 034: Neri carried the blue token past marker 117a36568fd5. Mara watched the eastern gate until dawn.

Ledger 46 line 035: Neri carried the blue token past marker 8c4fa3ecd0f6. Mara watched the eastern gate until dawn.

Ledger 46 line 036: Neri carried the blue token past marker aca2622fb7d0. Mara watched the eastern gate until dawn.

Ledger 46 line 037: Neri carried the blue token past marker cb437e3fc943. Mara watched the eastern gate until dawn.

Ledger 46 line 038: Neri carried the blue token past marker 805ce6b08cb2. Mara watched the eastern gate until dawn.

Ledger 46 line 039: Neri carried the blue token past marker 0da5f880ff7c. Mara watched the eastern gate until dawn.

Ledger 46 line 040: Neri carried the blue token past marker c7f529a38b02. Mara watched the eastern gate until dawn.

Ledger 46 line 041: Neri carried the blue token past marker e399fff85f4c. Mara watched the eastern gate until dawn.

Ledger 46 line 042: Neri carried the blue token past marker 8e5e0b018b70. Mara watched the eastern gate until dawn.

Ledger 46 line 043: Neri carried the blue token past marker 2456ec23ddb4. Mara watched the eastern gate until dawn.

Ledger 46 line 044: Neri carried the blue token past marker e31bd19a201f. Mara watched the eastern gate until dawn.

Ledger 46 line 045: Neri carried the blue token past marker c5f1c17df8ba. Mara watched the eastern gate until dawn.

Ledger 46 line 046: Neri carried the blue token past marker e9811e79810c. Mara watched the eastern gate until dawn.

Ledger 46 line 047: Neri carried the blue token past marker b4ccf9bb9c4a. Mara watched the eastern gate until dawn.

Ledger 46 line 048: Neri carried the blue token past marker e982bd20adbb. Mara watched the eastern gate until dawn.

Ledger 46 line 049: Neri carried the blue token past marker d77acc2a1290. Mara watched the eastern gate until dawn.

Ledger 46 line 050: Neri carried the blue token past marker 014d66518eec. Mara watched the eastern gate until dawn.

Ledger 46 line 051: Neri carried the blue token past marker 673ee5799b57. Mara watched the eastern gate until dawn.

Ledger 46 line 052: Neri carried the blue token past marker 080d18fc8cee. Mara watched the eastern gate until dawn.

Ledger 46 line 053: Neri carried the blue token past marker 46da9e2412a3. Mara watched the eastern gate until dawn.

Ledger 46 line 054: Neri carried the blue token past marker 7295cfa9093a. Mara watched the eastern gate until dawn.

Ledger 46 line 055: Neri carried the blue token past marker 6cd5aa88bed9. Mara watched the eastern gate until dawn.

Ledger 46 line 056: Neri carried the blue token past marker 5583d7d62550. Mara watched the eastern gate until dawn.

Ledger 46 line 057: Neri carried the blue token past marker a6b640963c78. Mara watched the eastern gate until dawn.

Ledger 46 line 058: Neri carried the blue token past marker c15d2ddb26cb. Mara watched the eastern gate until dawn.

Ledger 46 line 059: Neri carried the blue token past marker e776b20a5121. Mara watched the eastern gate until dawn.

Ledger 46 line 060: Neri carried the blue token past marker c983cefc43e4. Mara watched the eastern gate until dawn.

Ledger 46 line 061: Neri carried the blue token past marker 14a8d73ed88f. Mara watched the eastern gate until dawn.

Ledger 46 line 062: Neri carried the blue token past marker 93527b60033c. Mara watched the eastern gate until dawn.

Ledger 46 line 063: Neri carried the blue token past marker 2675513207df. Mara watched the eastern gate until dawn.

Ledger 46 line 064: Neri carried the blue token past marker bf810dbd4cda. Mara watched the eastern gate until dawn.

Ledger 46 line 065: Neri carried the blue token past marker e408d443a68d. Mara watched the eastern gate until dawn.

Ledger 46 line 066: Neri carried the blue token past marker 65c95e46c852. Mara watched the eastern gate until dawn.

Ledger 46 line 067: Neri carried the blue token past marker e13fad72265d. Mara watched the eastern gate until dawn.

Ledger 46 line 068: Neri carried the blue token past marker 135b4bf0aa0d. Mara watched the eastern gate until dawn.

Ledger 46 line 069: Neri carried the blue token past marker fa53eafae940. Mara watched the eastern gate until dawn.

Ledger 46 line 070: Neri carried the blue token past marker 29092f5f70bd. Mara watched the eastern gate until dawn.

Ledger 46 line 071: Neri carried the blue token past marker 7fc786b966dd. Mara watched the eastern gate until dawn.

Ledger 46 line 072: Neri carried the blue token past marker 52e71a5dc4f1. Mara watched the eastern gate until dawn.

Ledger 46 line 073: Neri carried the blue token past marker fc2ca4d7bb14. Mara watched the eastern gate until dawn.

Ledger 46 line 074: Neri carried the blue token past marker b8de9e4532d3. Mara watched the eastern gate until dawn.

Ledger 46 line 075: Neri carried the blue token past marker bf6ab94d1fce. Mara watched the eastern gate until dawn.

Ledger 46 line 076: Neri carried the blue token past marker 33be32c7a29a. Mara watched the eastern gate until dawn.

Ledger 46 line 077: Neri carried the blue token past marker d918c775ec7b. Mara watched the eastern gate until dawn.

Ledger 46 line 078: Neri carried the blue token past marker 967fe6a648f9. Mara watched the eastern gate until dawn.

Ledger 46 line 079: Neri carried the blue token past marker 9381614ec3f5. Mara watched the eastern gate until dawn.

Ledger 46 line 080: Neri carried the blue token past marker 8281b7de8067. Mara watched the eastern gate until dawn.

Ledger 46 line 081: Neri carried the blue token past marker 352cd2de60a0. Mara watched the eastern gate until dawn.

Ledger 46 line 082: Neri carried the blue token past marker 948a77b0346b. Mara watched the eastern gate until dawn.

Ledger 46 line 083: Neri carried the blue token past marker a3c52a42d3c4. Mara watched the eastern gate until dawn.

Ledger 46 line 084: Neri carried the blue token past marker c4fb96ae60bb. Mara watched the eastern gate until dawn.

Ledger 46 line 085: Neri carried the blue token past marker 5898f0d51de9. Mara watched the eastern gate until dawn.

Ledger 46 line 086: Neri carried the blue token past marker 6a67d8ec7f62. Mara watched the eastern gate until dawn.

Ledger 46 line 087: Neri carried the blue token past marker 28cab19a05ae. Mara watched the eastern gate until dawn.

Ledger 46 line 088: Neri carried the blue token past marker 49923a17b923. Mara watched the eastern gate until dawn.

Ledger 46 line 089: Neri carried the blue token past marker 7ab926e39390. Mara watched the eastern gate until dawn.

Ledger 46 line 090: Neri carried the blue token past marker 0ec1f84f0b46. Mara watched the eastern gate until dawn.

Ledger 46 line 091: Neri carried the blue token past marker 9a6be2926930. Mara watched the eastern gate until dawn.

Ledger 46 line 092: Neri carried the blue token past marker 3d039879ac60. Mara watched the eastern gate until dawn.

Ledger 46 line 093: Neri carried the blue token past marker d458493229c9. Mara watched the eastern gate until dawn.

Ledger 46 line 094: Neri carried the blue token past marker 8d524f1d0c90. Mara watched the eastern gate until dawn.

Ledger 46 line 095: Neri carried the blue token past marker ebc07c1f167c. Mara watched the eastern gate until dawn.

Ledger 46 line 096: Neri carried the blue token past marker 8188b0899b3d. Mara watched the eastern gate until dawn.

Ledger 46 line 097: Neri carried the blue token past marker d54bc3a93ccf. Mara watched the eastern gate until dawn.

Ledger 46 line 098: Neri carried the blue token past marker c197c2e6c092. Mara watched the eastern gate until dawn.

Ledger 46 line 099: Neri carried the blue token past marker 0e850b788400. Mara watched the eastern gate until dawn.

Ledger 46 line 100: Neri carried the blue token past marker 805f9de6cfd7. Mara watched the eastern gate until dawn.

Ledger 46 line 101: Neri carried the blue token past marker d6dc3c086d3d. Mara watched the eastern gate until dawn.

Ledger 46 line 102: Neri carried the blue token past marker 1444cc8cc14d. Mara watched the eastern gate until dawn.

Ledger 46 line 103: Neri carried the blue token past marker c13f6e6caf10. Mara watched the eastern gate until dawn.

Ledger 46 line 104: Neri carried the blue token past marker 84e06275e408. Mara watched the eastern gate until dawn.

Ledger 46 line 105: Neri carried the blue token past marker 6fe8b8b43e6f. Mara watched the eastern gate until dawn.

Ledger 46 line 106: Neri carried the blue token past marker 5c0d03af2739. Mara watched the eastern gate until dawn.

Ledger 46 line 107: Neri carried the blue token past marker 9042e5e11f92. Mara watched the eastern gate until dawn.

Ledger 46 line 108: Neri carried the blue token past marker 49611fed9751. Mara watched the eastern gate until dawn.

Ledger 46 line 109: Neri carried the blue token past marker 29c5f8dd1d86. Mara watched the eastern gate until dawn.

Ledger 46 line 110: Neri carried the blue token past marker 70bbbc0d6cbb. Mara watched the eastern gate until dawn.

Ledger 46 line 111: Neri carried the blue token past marker 01e6102575bf. Mara watched the eastern gate until dawn.

Ledger 46 line 112: Neri carried the blue token past marker 24a90882af55. Mara watched the eastern gate until dawn.

Ledger 46 line 113: Neri carried the blue token past marker 763cb174b830. Mara watched the eastern gate until dawn.

Ledger 46 line 114: Neri carried the blue token past marker defa35c10502. Mara watched the eastern gate until dawn.

Ledger 46 line 115: Neri carried the blue token past marker 69c33da8f8d1. Mara watched the eastern gate until dawn.

Ledger 46 line 116: Neri carried the blue token past marker f32e18d5406a. Mara watched the eastern gate until dawn.

Ledger 46 line 117: Neri carried the blue token past marker f789b8d699ae. Mara watched the eastern gate until dawn.

Ledger 46 line 118: Neri carried the blue token past marker 8fcf06247689. Mara watched the eastern gate until dawn.

Ledger 46 line 119: Neri carried the blue token past marker 458e999981d9. Mara watched the eastern gate until dawn.

Ledger 46 line 120: Neri carried the blue token past marker 2bbe8f529ecf. Mara watched the eastern gate until dawn.

Ledger 46 line 121: Neri carried the blue token past marker c331923213da. Mara watched the eastern gate until dawn.

Ledger 46 line 122: Neri carried the blue token past marker 99bc08116b78. Mara watched the eastern gate until dawn.

Ledger 46 line 123: Neri carried the blue token past marker 4cecf2317137. Mara watched the eastern gate until dawn.

Ledger 46 line 124: Neri carried the blue token past marker b05e7f6cc6ad. Mara watched the eastern gate until dawn.

Ledger 46 line 125: Neri carried the blue token past marker 65763ded62ec. Mara watched the eastern gate until dawn.

Ledger 46 line 126: Neri carried the blue token past marker c7be244ccbcc. Mara watched the eastern gate until dawn.

Ledger 46 line 127: Neri carried the blue token past marker 72fd4e31a7b9. Mara watched the eastern gate until dawn.

Ledger 46 line 128: Neri carried the blue token past marker 43dff073c983. Mara watched the eastern gate until dawn.

Ledger 46 line 129: Neri carried the blue token past marker 4bcb275e82b7. Mara watched the eastern gate until dawn.

Ledger 46 line 130: Neri carried the blue token past marker de0077a3f5b5. Mara watched the eastern gate until dawn.

Ledger 46 line 131: Neri carried the blue token past marker ba653e94a7eb. Mara watched the eastern gate until dawn.

Ledger 46 line 132: Neri carried the blue token past marker 7730e2f2bd15. Mara watched the eastern gate until dawn.

Ledger 46 line 133: Neri carried the blue token past marker 6d0c4a77b0c9. Mara watched the eastern gate until dawn.

Ledger 46 line 134: Neri carried the blue token past marker 3298ef931eee. Mara watched the eastern gate until dawn.

Ledger 46 line 135: Neri carried the blue token past marker b0c5d04bf353. Mara watched the eastern gate until dawn.

Ledger 46 line 136: Neri carried the blue token past marker dbdbe34834cc. Mara watched the eastern gate until dawn.

Ledger 46 line 137: Neri carried the blue token past marker 5be69fe7a350. Mara watched the eastern gate until dawn.

Ledger 46 line 138: Neri carried the blue token past marker 34d817f2e145. Mara watched the eastern gate until dawn.

Ledger 46 line 139: Neri carried the blue token past marker a6afd641464b. Mara watched the eastern gate until dawn.

Ledger 46 line 140: Neri carried the blue token past marker 679a1be8bfa1. Mara watched the eastern gate until dawn.
