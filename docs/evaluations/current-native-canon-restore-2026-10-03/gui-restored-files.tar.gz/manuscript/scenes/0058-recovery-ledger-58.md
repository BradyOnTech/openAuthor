---
id: scene-0058
title: Recovery ledger 58
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.183870+00:00
updated_at: 2026-10-03T12:14:52.183870+00:00
---

Ledger 58 line 001: Neri carried the blue token past marker 1b87f4fa4dc0. Mara watched the eastern gate until dawn.

Ledger 58 line 002: Neri carried the blue token past marker 8d4c09bf9219. Mara watched the eastern gate until dawn.

Ledger 58 line 003: Neri carried the blue token past marker dc4434c4744a. Mara watched the eastern gate until dawn.

Ledger 58 line 004: Neri carried the blue token past marker 39735d345563. Mara watched the eastern gate until dawn.

Ledger 58 line 005: Neri carried the blue token past marker 50f6a88ef681. Mara watched the eastern gate until dawn.

Ledger 58 line 006: Neri carried the blue token past marker 6b0dc3f11578. Mara watched the eastern gate until dawn.

Ledger 58 line 007: Neri carried the blue token past marker ea713afd4e8d. Mara watched the eastern gate until dawn.

Ledger 58 line 008: Neri carried the blue token past marker 39fe48d98e9a. Mara watched the eastern gate until dawn.

Ledger 58 line 009: Neri carried the blue token past marker cdde52d30c10. Mara watched the eastern gate until dawn.

Ledger 58 line 010: Neri carried the blue token past marker fa34f780c04e. Mara watched the eastern gate until dawn.

Ledger 58 line 011: Neri carried the blue token past marker d5f8cd54386e. Mara watched the eastern gate until dawn.

Ledger 58 line 012: Neri carried the blue token past marker 3b014999be93. Mara watched the eastern gate until dawn.

Ledger 58 line 013: Neri carried the blue token past marker f091e8b392b2. Mara watched the eastern gate until dawn.

Ledger 58 line 014: Neri carried the blue token past marker 063663d023fb. Mara watched the eastern gate until dawn.

Ledger 58 line 015: Neri carried the blue token past marker 917cc288dbd5. Mara watched the eastern gate until dawn.

Ledger 58 line 016: Neri carried the blue token past marker c8ac82b21595. Mara watched the eastern gate until dawn.

Ledger 58 line 017: Neri carried the blue token past marker 9786e75c5ef4. Mara watched the eastern gate until dawn.

Ledger 58 line 018: Neri carried the blue token past marker cc151a1b6057. Mara watched the eastern gate until dawn.

Ledger 58 line 019: Neri carried the blue token past marker 675b706b602a. Mara watched the eastern gate until dawn.

Ledger 58 line 020: Neri carried the blue token past marker b701481f5daf. Mara watched the eastern gate until dawn.

Ledger 58 line 021: Neri carried the blue token past marker d7d2338e1b09. Mara watched the eastern gate until dawn.

Ledger 58 line 022: Neri carried the blue token past marker 05bf9f3c3643. Mara watched the eastern gate until dawn.

Ledger 58 line 023: Neri carried the blue token past marker 6a43132c7814. Mara watched the eastern gate until dawn.

Ledger 58 line 024: Neri carried the blue token past marker 5063385de7e8. Mara watched the eastern gate until dawn.

Ledger 58 line 025: Neri carried the blue token past marker a8b885b130ac. Mara watched the eastern gate until dawn.

Ledger 58 line 026: Neri carried the blue token past marker 9bfd8c5c6e13. Mara watched the eastern gate until dawn.

Ledger 58 line 027: Neri carried the blue token past marker 9ea0acb19119. Mara watched the eastern gate until dawn.

Ledger 58 line 028: Neri carried the blue token past marker b8775e2b2811. Mara watched the eastern gate until dawn.

Ledger 58 line 029: Neri carried the blue token past marker 5886e1fa0b5b. Mara watched the eastern gate until dawn.

Ledger 58 line 030: Neri carried the blue token past marker 6d9de7376d81. Mara watched the eastern gate until dawn.

Ledger 58 line 031: Neri carried the blue token past marker 876ed86c217f. Mara watched the eastern gate until dawn.

Ledger 58 line 032: Neri carried the blue token past marker 20a57045ee08. Mara watched the eastern gate until dawn.

Ledger 58 line 033: Neri carried the blue token past marker 64836ab05845. Mara watched the eastern gate until dawn.

Ledger 58 line 034: Neri carried the blue token past marker 2015f76119a3. Mara watched the eastern gate until dawn.

Ledger 58 line 035: Neri carried the blue token past marker 6a7ce776c8c5. Mara watched the eastern gate until dawn.

Ledger 58 line 036: Neri carried the blue token past marker 3bc088f965cd. Mara watched the eastern gate until dawn.

Ledger 58 line 037: Neri carried the blue token past marker 319941be0f4a. Mara watched the eastern gate until dawn.

Ledger 58 line 038: Neri carried the blue token past marker 4c9274f28aef. Mara watched the eastern gate until dawn.

Ledger 58 line 039: Neri carried the blue token past marker 77b7c22fb0de. Mara watched the eastern gate until dawn.

Ledger 58 line 040: Neri carried the blue token past marker 376a3d745aac. Mara watched the eastern gate until dawn.

Ledger 58 line 041: Neri carried the blue token past marker 7adf067b0883. Mara watched the eastern gate until dawn.

Ledger 58 line 042: Neri carried the blue token past marker 42509b79b7dc. Mara watched the eastern gate until dawn.

Ledger 58 line 043: Neri carried the blue token past marker 6fc630f1058b. Mara watched the eastern gate until dawn.

Ledger 58 line 044: Neri carried the blue token past marker eb4654fe256f. Mara watched the eastern gate until dawn.

Ledger 58 line 045: Neri carried the blue token past marker 9416a685abf3. Mara watched the eastern gate until dawn.

Ledger 58 line 046: Neri carried the blue token past marker 002958cadaa5. Mara watched the eastern gate until dawn.

Ledger 58 line 047: Neri carried the blue token past marker 14484ba07100. Mara watched the eastern gate until dawn.

Ledger 58 line 048: Neri carried the blue token past marker 7df8a6812d5d. Mara watched the eastern gate until dawn.

Ledger 58 line 049: Neri carried the blue token past marker 0b2561ad8590. Mara watched the eastern gate until dawn.

Ledger 58 line 050: Neri carried the blue token past marker 56b74a811325. Mara watched the eastern gate until dawn.

Ledger 58 line 051: Neri carried the blue token past marker de78ab8fe974. Mara watched the eastern gate until dawn.

Ledger 58 line 052: Neri carried the blue token past marker 9605757f2f4a. Mara watched the eastern gate until dawn.

Ledger 58 line 053: Neri carried the blue token past marker 75fde56e01b0. Mara watched the eastern gate until dawn.

Ledger 58 line 054: Neri carried the blue token past marker 95c8e1afa574. Mara watched the eastern gate until dawn.

Ledger 58 line 055: Neri carried the blue token past marker 790672bf547c. Mara watched the eastern gate until dawn.

Ledger 58 line 056: Neri carried the blue token past marker 26b8d6828840. Mara watched the eastern gate until dawn.

Ledger 58 line 057: Neri carried the blue token past marker f803773484b9. Mara watched the eastern gate until dawn.

Ledger 58 line 058: Neri carried the blue token past marker 6c74b6919f41. Mara watched the eastern gate until dawn.

Ledger 58 line 059: Neri carried the blue token past marker 543af25fe8ff. Mara watched the eastern gate until dawn.

Ledger 58 line 060: Neri carried the blue token past marker 7a3ae918e3ab. Mara watched the eastern gate until dawn.

Ledger 58 line 061: Neri carried the blue token past marker e8d8461be37b. Mara watched the eastern gate until dawn.

Ledger 58 line 062: Neri carried the blue token past marker 00b3f97b9933. Mara watched the eastern gate until dawn.

Ledger 58 line 063: Neri carried the blue token past marker e1221142814b. Mara watched the eastern gate until dawn.

Ledger 58 line 064: Neri carried the blue token past marker f433fa18dcef. Mara watched the eastern gate until dawn.

Ledger 58 line 065: Neri carried the blue token past marker 99f7e892c7ac. Mara watched the eastern gate until dawn.

Ledger 58 line 066: Neri carried the blue token past marker 6fc784e0fe75. Mara watched the eastern gate until dawn.

Ledger 58 line 067: Neri carried the blue token past marker 325656a59123. Mara watched the eastern gate until dawn.

Ledger 58 line 068: Neri carried the blue token past marker 4f74ad34f68f. Mara watched the eastern gate until dawn.

Ledger 58 line 069: Neri carried the blue token past marker 6ca5d1347737. Mara watched the eastern gate until dawn.

Ledger 58 line 070: Neri carried the blue token past marker 23b100c75a2d. Mara watched the eastern gate until dawn.

Ledger 58 line 071: Neri carried the blue token past marker 94f277d184d1. Mara watched the eastern gate until dawn.

Ledger 58 line 072: Neri carried the blue token past marker c376f53131bc. Mara watched the eastern gate until dawn.

Ledger 58 line 073: Neri carried the blue token past marker d56712d2998a. Mara watched the eastern gate until dawn.

Ledger 58 line 074: Neri carried the blue token past marker 19404df1eba1. Mara watched the eastern gate until dawn.

Ledger 58 line 075: Neri carried the blue token past marker 6b412340b48c. Mara watched the eastern gate until dawn.

Ledger 58 line 076: Neri carried the blue token past marker 892fcc018a5b. Mara watched the eastern gate until dawn.

Ledger 58 line 077: Neri carried the blue token past marker 08cb0edaa11b. Mara watched the eastern gate until dawn.

Ledger 58 line 078: Neri carried the blue token past marker f38ba7d2708d. Mara watched the eastern gate until dawn.

Ledger 58 line 079: Neri carried the blue token past marker c711b2bdeba1. Mara watched the eastern gate until dawn.

Ledger 58 line 080: Neri carried the blue token past marker 07b870827f4a. Mara watched the eastern gate until dawn.

Ledger 58 line 081: Neri carried the blue token past marker c58ef948ee7b. Mara watched the eastern gate until dawn.

Ledger 58 line 082: Neri carried the blue token past marker 600725526065. Mara watched the eastern gate until dawn.

Ledger 58 line 083: Neri carried the blue token past marker 5d410129f130. Mara watched the eastern gate until dawn.

Ledger 58 line 084: Neri carried the blue token past marker f411803c49e7. Mara watched the eastern gate until dawn.

Ledger 58 line 085: Neri carried the blue token past marker de5888cd09fb. Mara watched the eastern gate until dawn.

Ledger 58 line 086: Neri carried the blue token past marker 328a3eab385b. Mara watched the eastern gate until dawn.

Ledger 58 line 087: Neri carried the blue token past marker 99ee4ba3b16f. Mara watched the eastern gate until dawn.

Ledger 58 line 088: Neri carried the blue token past marker 885714a1ef9c. Mara watched the eastern gate until dawn.

Ledger 58 line 089: Neri carried the blue token past marker c365f1215776. Mara watched the eastern gate until dawn.

Ledger 58 line 090: Neri carried the blue token past marker e97e71387e9a. Mara watched the eastern gate until dawn.

Ledger 58 line 091: Neri carried the blue token past marker e5e45b195c18. Mara watched the eastern gate until dawn.

Ledger 58 line 092: Neri carried the blue token past marker f283f5895396. Mara watched the eastern gate until dawn.

Ledger 58 line 093: Neri carried the blue token past marker 1132e1dbfadb. Mara watched the eastern gate until dawn.

Ledger 58 line 094: Neri carried the blue token past marker fedb338e12b3. Mara watched the eastern gate until dawn.

Ledger 58 line 095: Neri carried the blue token past marker bc1435c9ca85. Mara watched the eastern gate until dawn.

Ledger 58 line 096: Neri carried the blue token past marker dc4e0c329c04. Mara watched the eastern gate until dawn.

Ledger 58 line 097: Neri carried the blue token past marker d33a5b5d976a. Mara watched the eastern gate until dawn.

Ledger 58 line 098: Neri carried the blue token past marker c8acfe5fa7d1. Mara watched the eastern gate until dawn.

Ledger 58 line 099: Neri carried the blue token past marker 66c589526b92. Mara watched the eastern gate until dawn.

Ledger 58 line 100: Neri carried the blue token past marker 7fe685cbb572. Mara watched the eastern gate until dawn.

Ledger 58 line 101: Neri carried the blue token past marker be1620825e28. Mara watched the eastern gate until dawn.

Ledger 58 line 102: Neri carried the blue token past marker 87c27d16d03b. Mara watched the eastern gate until dawn.

Ledger 58 line 103: Neri carried the blue token past marker e570f4dba956. Mara watched the eastern gate until dawn.

Ledger 58 line 104: Neri carried the blue token past marker 2e38fe982d67. Mara watched the eastern gate until dawn.

Ledger 58 line 105: Neri carried the blue token past marker e0fba21ec98e. Mara watched the eastern gate until dawn.

Ledger 58 line 106: Neri carried the blue token past marker 8a034eb2c504. Mara watched the eastern gate until dawn.

Ledger 58 line 107: Neri carried the blue token past marker d7306b9de2d4. Mara watched the eastern gate until dawn.

Ledger 58 line 108: Neri carried the blue token past marker 8a606bb55f65. Mara watched the eastern gate until dawn.

Ledger 58 line 109: Neri carried the blue token past marker 784ba47ee27e. Mara watched the eastern gate until dawn.

Ledger 58 line 110: Neri carried the blue token past marker 6d4b29fe8a19. Mara watched the eastern gate until dawn.

Ledger 58 line 111: Neri carried the blue token past marker 5fcc847b2742. Mara watched the eastern gate until dawn.

Ledger 58 line 112: Neri carried the blue token past marker ceb58c28ab5f. Mara watched the eastern gate until dawn.

Ledger 58 line 113: Neri carried the blue token past marker dead421afd91. Mara watched the eastern gate until dawn.

Ledger 58 line 114: Neri carried the blue token past marker 2f5a64fe25c4. Mara watched the eastern gate until dawn.

Ledger 58 line 115: Neri carried the blue token past marker 6c709dbce610. Mara watched the eastern gate until dawn.

Ledger 58 line 116: Neri carried the blue token past marker 921ae2044e01. Mara watched the eastern gate until dawn.

Ledger 58 line 117: Neri carried the blue token past marker d03c9029b8df. Mara watched the eastern gate until dawn.

Ledger 58 line 118: Neri carried the blue token past marker e7c211a23ab0. Mara watched the eastern gate until dawn.

Ledger 58 line 119: Neri carried the blue token past marker b82c05fba32e. Mara watched the eastern gate until dawn.

Ledger 58 line 120: Neri carried the blue token past marker cda01da5ae7e. Mara watched the eastern gate until dawn.

Ledger 58 line 121: Neri carried the blue token past marker c28aa6ce0751. Mara watched the eastern gate until dawn.

Ledger 58 line 122: Neri carried the blue token past marker 91c105f312d8. Mara watched the eastern gate until dawn.

Ledger 58 line 123: Neri carried the blue token past marker b9611b919651. Mara watched the eastern gate until dawn.

Ledger 58 line 124: Neri carried the blue token past marker e608ebf39848. Mara watched the eastern gate until dawn.

Ledger 58 line 125: Neri carried the blue token past marker b3ae6c555d0f. Mara watched the eastern gate until dawn.

Ledger 58 line 126: Neri carried the blue token past marker 82699bac382e. Mara watched the eastern gate until dawn.

Ledger 58 line 127: Neri carried the blue token past marker b29627a73ad8. Mara watched the eastern gate until dawn.

Ledger 58 line 128: Neri carried the blue token past marker beea557449f3. Mara watched the eastern gate until dawn.

Ledger 58 line 129: Neri carried the blue token past marker 7175603034f2. Mara watched the eastern gate until dawn.

Ledger 58 line 130: Neri carried the blue token past marker 0a9240818ec3. Mara watched the eastern gate until dawn.

Ledger 58 line 131: Neri carried the blue token past marker 35884a17636f. Mara watched the eastern gate until dawn.

Ledger 58 line 132: Neri carried the blue token past marker 6f060c88ef13. Mara watched the eastern gate until dawn.

Ledger 58 line 133: Neri carried the blue token past marker 449cf1226e05. Mara watched the eastern gate until dawn.

Ledger 58 line 134: Neri carried the blue token past marker 0c6d24e318d3. Mara watched the eastern gate until dawn.

Ledger 58 line 135: Neri carried the blue token past marker 61db0d3ea350. Mara watched the eastern gate until dawn.

Ledger 58 line 136: Neri carried the blue token past marker 437251801a78. Mara watched the eastern gate until dawn.

Ledger 58 line 137: Neri carried the blue token past marker ad0978981bfc. Mara watched the eastern gate until dawn.

Ledger 58 line 138: Neri carried the blue token past marker bbd005aaa7fd. Mara watched the eastern gate until dawn.

Ledger 58 line 139: Neri carried the blue token past marker eed05351f4ee. Mara watched the eastern gate until dawn.

Ledger 58 line 140: Neri carried the blue token past marker 75940b519d61. Mara watched the eastern gate until dawn.
