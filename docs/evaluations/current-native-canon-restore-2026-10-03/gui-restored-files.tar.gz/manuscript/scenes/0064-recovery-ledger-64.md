---
id: scene-0064
title: Recovery ledger 64
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.187305+00:00
updated_at: 2026-10-03T12:14:52.187305+00:00
---

Ledger 64 line 001: Neri carried the blue token past marker 7bc7631164fd. Mara watched the eastern gate until dawn.

Ledger 64 line 002: Neri carried the blue token past marker 5f83edf14bec. Mara watched the eastern gate until dawn.

Ledger 64 line 003: Neri carried the blue token past marker 2a4df23275c2. Mara watched the eastern gate until dawn.

Ledger 64 line 004: Neri carried the blue token past marker 3c64e5686f4e. Mara watched the eastern gate until dawn.

Ledger 64 line 005: Neri carried the blue token past marker 91335f672035. Mara watched the eastern gate until dawn.

Ledger 64 line 006: Neri carried the blue token past marker 7cf43991eb4b. Mara watched the eastern gate until dawn.

Ledger 64 line 007: Neri carried the blue token past marker a41a5e3412f2. Mara watched the eastern gate until dawn.

Ledger 64 line 008: Neri carried the blue token past marker dfb5590d907a. Mara watched the eastern gate until dawn.

Ledger 64 line 009: Neri carried the blue token past marker fe4874fe53b7. Mara watched the eastern gate until dawn.

Ledger 64 line 010: Neri carried the blue token past marker 7390b731e2f3. Mara watched the eastern gate until dawn.

Ledger 64 line 011: Neri carried the blue token past marker e9d29ba37503. Mara watched the eastern gate until dawn.

Ledger 64 line 012: Neri carried the blue token past marker c5042bc854bf. Mara watched the eastern gate until dawn.

Ledger 64 line 013: Neri carried the blue token past marker f4a2b3c1ca7d. Mara watched the eastern gate until dawn.

Ledger 64 line 014: Neri carried the blue token past marker dac84d070803. Mara watched the eastern gate until dawn.

Ledger 64 line 015: Neri carried the blue token past marker bd720259e8ba. Mara watched the eastern gate until dawn.

Ledger 64 line 016: Neri carried the blue token past marker fa1e95271751. Mara watched the eastern gate until dawn.

Ledger 64 line 017: Neri carried the blue token past marker b56d45f5b5c3. Mara watched the eastern gate until dawn.

Ledger 64 line 018: Neri carried the blue token past marker 0b0de2fb282c. Mara watched the eastern gate until dawn.

Ledger 64 line 019: Neri carried the blue token past marker ac0f984555fc. Mara watched the eastern gate until dawn.

Ledger 64 line 020: Neri carried the blue token past marker fec1a91d0f40. Mara watched the eastern gate until dawn.

Ledger 64 line 021: Neri carried the blue token past marker 96f77e301279. Mara watched the eastern gate until dawn.

Ledger 64 line 022: Neri carried the blue token past marker 6254405f733e. Mara watched the eastern gate until dawn.

Ledger 64 line 023: Neri carried the blue token past marker 08fb2e4edcad. Mara watched the eastern gate until dawn.

Ledger 64 line 024: Neri carried the blue token past marker d0f64990999f. Mara watched the eastern gate until dawn.

Ledger 64 line 025: Neri carried the blue token past marker 57e5608ca6d5. Mara watched the eastern gate until dawn.

Ledger 64 line 026: Neri carried the blue token past marker a5866d6aad0e. Mara watched the eastern gate until dawn.

Ledger 64 line 027: Neri carried the blue token past marker 57130a9b806a. Mara watched the eastern gate until dawn.

Ledger 64 line 028: Neri carried the blue token past marker 949a27f6a68f. Mara watched the eastern gate until dawn.

Ledger 64 line 029: Neri carried the blue token past marker 6dfcd943f6df. Mara watched the eastern gate until dawn.

Ledger 64 line 030: Neri carried the blue token past marker 166e37c35e94. Mara watched the eastern gate until dawn.

Ledger 64 line 031: Neri carried the blue token past marker fce57a0ac2a5. Mara watched the eastern gate until dawn.

Ledger 64 line 032: Neri carried the blue token past marker 205bffb35e76. Mara watched the eastern gate until dawn.

Ledger 64 line 033: Neri carried the blue token past marker 7d44b22c2b45. Mara watched the eastern gate until dawn.

Ledger 64 line 034: Neri carried the blue token past marker 1356d9faea62. Mara watched the eastern gate until dawn.

Ledger 64 line 035: Neri carried the blue token past marker 6547241a1b20. Mara watched the eastern gate until dawn.

Ledger 64 line 036: Neri carried the blue token past marker 4d09a62eef2c. Mara watched the eastern gate until dawn.

Ledger 64 line 037: Neri carried the blue token past marker 8ea64e587fee. Mara watched the eastern gate until dawn.

Ledger 64 line 038: Neri carried the blue token past marker b61c095dc515. Mara watched the eastern gate until dawn.

Ledger 64 line 039: Neri carried the blue token past marker ac9074e42950. Mara watched the eastern gate until dawn.

Ledger 64 line 040: Neri carried the blue token past marker 116912caea13. Mara watched the eastern gate until dawn.

Ledger 64 line 041: Neri carried the blue token past marker a6c89e231ac1. Mara watched the eastern gate until dawn.

Ledger 64 line 042: Neri carried the blue token past marker 42df96ef25a0. Mara watched the eastern gate until dawn.

Ledger 64 line 043: Neri carried the blue token past marker feb9f1a10421. Mara watched the eastern gate until dawn.

Ledger 64 line 044: Neri carried the blue token past marker 98c1db0f4043. Mara watched the eastern gate until dawn.

Ledger 64 line 045: Neri carried the blue token past marker 73fe8dd7f543. Mara watched the eastern gate until dawn.

Ledger 64 line 046: Neri carried the blue token past marker d787bad6f021. Mara watched the eastern gate until dawn.

Ledger 64 line 047: Neri carried the blue token past marker cc1dd8ebd5fa. Mara watched the eastern gate until dawn.

Ledger 64 line 048: Neri carried the blue token past marker 53db5e002818. Mara watched the eastern gate until dawn.

Ledger 64 line 049: Neri carried the blue token past marker 46b53d5be74a. Mara watched the eastern gate until dawn.

Ledger 64 line 050: Neri carried the blue token past marker fc7ecc92c3c6. Mara watched the eastern gate until dawn.

Ledger 64 line 051: Neri carried the blue token past marker 78938254b44c. Mara watched the eastern gate until dawn.

Ledger 64 line 052: Neri carried the blue token past marker 9f43dafc52ae. Mara watched the eastern gate until dawn.

Ledger 64 line 053: Neri carried the blue token past marker a95beeb94efe. Mara watched the eastern gate until dawn.

Ledger 64 line 054: Neri carried the blue token past marker d17536be73d1. Mara watched the eastern gate until dawn.

Ledger 64 line 055: Neri carried the blue token past marker 9e8659ddaec6. Mara watched the eastern gate until dawn.

Ledger 64 line 056: Neri carried the blue token past marker bea533cbc5ba. Mara watched the eastern gate until dawn.

Ledger 64 line 057: Neri carried the blue token past marker 378a06850023. Mara watched the eastern gate until dawn.

Ledger 64 line 058: Neri carried the blue token past marker fd8aacfb2f06. Mara watched the eastern gate until dawn.

Ledger 64 line 059: Neri carried the blue token past marker 07ec33ed8082. Mara watched the eastern gate until dawn.

Ledger 64 line 060: Neri carried the blue token past marker 0cf70eff34d5. Mara watched the eastern gate until dawn.

Ledger 64 line 061: Neri carried the blue token past marker a5aab40b4bf1. Mara watched the eastern gate until dawn.

Ledger 64 line 062: Neri carried the blue token past marker 9a3f531c859f. Mara watched the eastern gate until dawn.

Ledger 64 line 063: Neri carried the blue token past marker 9dd86d2c0edd. Mara watched the eastern gate until dawn.

Ledger 64 line 064: Neri carried the blue token past marker 17ad074aa136. Mara watched the eastern gate until dawn.

Ledger 64 line 065: Neri carried the blue token past marker 4bdd793af0c6. Mara watched the eastern gate until dawn.

Ledger 64 line 066: Neri carried the blue token past marker 4a185e9adc49. Mara watched the eastern gate until dawn.

Ledger 64 line 067: Neri carried the blue token past marker fe46c52b5f6d. Mara watched the eastern gate until dawn.

Ledger 64 line 068: Neri carried the blue token past marker d6e01e6dd66f. Mara watched the eastern gate until dawn.

Ledger 64 line 069: Neri carried the blue token past marker a0105313afa7. Mara watched the eastern gate until dawn.

Ledger 64 line 070: Neri carried the blue token past marker 723f6b8a4544. Mara watched the eastern gate until dawn.

Ledger 64 line 071: Neri carried the blue token past marker 953e9098dfff. Mara watched the eastern gate until dawn.

Ledger 64 line 072: Neri carried the blue token past marker 1becd7938ab9. Mara watched the eastern gate until dawn.

Ledger 64 line 073: Neri carried the blue token past marker dfe76fe1b3a7. Mara watched the eastern gate until dawn.

Ledger 64 line 074: Neri carried the blue token past marker 4e2246db3ac8. Mara watched the eastern gate until dawn.

Ledger 64 line 075: Neri carried the blue token past marker a770bacfac90. Mara watched the eastern gate until dawn.

Ledger 64 line 076: Neri carried the blue token past marker 19cdc8818fcc. Mara watched the eastern gate until dawn.

Ledger 64 line 077: Neri carried the blue token past marker 030d2c550d12. Mara watched the eastern gate until dawn.

Ledger 64 line 078: Neri carried the blue token past marker ca9171d83b20. Mara watched the eastern gate until dawn.

Ledger 64 line 079: Neri carried the blue token past marker 6f39fcadf45b. Mara watched the eastern gate until dawn.

Ledger 64 line 080: Neri carried the blue token past marker 40285b9d2327. Mara watched the eastern gate until dawn.

Ledger 64 line 081: Neri carried the blue token past marker dd1dfad1b995. Mara watched the eastern gate until dawn.

Ledger 64 line 082: Neri carried the blue token past marker cd10231be565. Mara watched the eastern gate until dawn.

Ledger 64 line 083: Neri carried the blue token past marker 6c75207b0377. Mara watched the eastern gate until dawn.

Ledger 64 line 084: Neri carried the blue token past marker 8be3978ab9aa. Mara watched the eastern gate until dawn.

Ledger 64 line 085: Neri carried the blue token past marker 54f1ac63f9d8. Mara watched the eastern gate until dawn.

Ledger 64 line 086: Neri carried the blue token past marker a378cf8f2c83. Mara watched the eastern gate until dawn.

Ledger 64 line 087: Neri carried the blue token past marker 675f373e1efd. Mara watched the eastern gate until dawn.

Ledger 64 line 088: Neri carried the blue token past marker 48417ccc4d73. Mara watched the eastern gate until dawn.

Ledger 64 line 089: Neri carried the blue token past marker 17a8538e0ba9. Mara watched the eastern gate until dawn.

Ledger 64 line 090: Neri carried the blue token past marker 3f41d2cd77d7. Mara watched the eastern gate until dawn.

Ledger 64 line 091: Neri carried the blue token past marker edbd03efed1c. Mara watched the eastern gate until dawn.

Ledger 64 line 092: Neri carried the blue token past marker 309437031c29. Mara watched the eastern gate until dawn.

Ledger 64 line 093: Neri carried the blue token past marker 92781b1970dc. Mara watched the eastern gate until dawn.

Ledger 64 line 094: Neri carried the blue token past marker 5c835999d6ac. Mara watched the eastern gate until dawn.

Ledger 64 line 095: Neri carried the blue token past marker 0f18e22c296b. Mara watched the eastern gate until dawn.

Ledger 64 line 096: Neri carried the blue token past marker 7744f85414c3. Mara watched the eastern gate until dawn.

Ledger 64 line 097: Neri carried the blue token past marker 1f35d6806cc9. Mara watched the eastern gate until dawn.

Ledger 64 line 098: Neri carried the blue token past marker 9fabf79d56a0. Mara watched the eastern gate until dawn.

Ledger 64 line 099: Neri carried the blue token past marker 0e4a2e722aee. Mara watched the eastern gate until dawn.

Ledger 64 line 100: Neri carried the blue token past marker 70b1a42c9f89. Mara watched the eastern gate until dawn.

Ledger 64 line 101: Neri carried the blue token past marker 0bb20be84597. Mara watched the eastern gate until dawn.

Ledger 64 line 102: Neri carried the blue token past marker 66aedbcd1caa. Mara watched the eastern gate until dawn.

Ledger 64 line 103: Neri carried the blue token past marker dcb4a7414e49. Mara watched the eastern gate until dawn.

Ledger 64 line 104: Neri carried the blue token past marker 28cccaaae0a0. Mara watched the eastern gate until dawn.

Ledger 64 line 105: Neri carried the blue token past marker 64cdbb29db4b. Mara watched the eastern gate until dawn.

Ledger 64 line 106: Neri carried the blue token past marker 1d80aa4aecf8. Mara watched the eastern gate until dawn.

Ledger 64 line 107: Neri carried the blue token past marker 93a6c4f18d8e. Mara watched the eastern gate until dawn.

Ledger 64 line 108: Neri carried the blue token past marker f8458ce87059. Mara watched the eastern gate until dawn.

Ledger 64 line 109: Neri carried the blue token past marker 5192e3510019. Mara watched the eastern gate until dawn.

Ledger 64 line 110: Neri carried the blue token past marker 5858389b3cdb. Mara watched the eastern gate until dawn.

Ledger 64 line 111: Neri carried the blue token past marker a51e9fd2bb0c. Mara watched the eastern gate until dawn.

Ledger 64 line 112: Neri carried the blue token past marker 7db9ba2e2267. Mara watched the eastern gate until dawn.

Ledger 64 line 113: Neri carried the blue token past marker ec80b89ad7c1. Mara watched the eastern gate until dawn.

Ledger 64 line 114: Neri carried the blue token past marker def684daab63. Mara watched the eastern gate until dawn.

Ledger 64 line 115: Neri carried the blue token past marker ef164b0c2f1e. Mara watched the eastern gate until dawn.

Ledger 64 line 116: Neri carried the blue token past marker 9134504bf27b. Mara watched the eastern gate until dawn.

Ledger 64 line 117: Neri carried the blue token past marker d155a0954d62. Mara watched the eastern gate until dawn.

Ledger 64 line 118: Neri carried the blue token past marker 48f7b5a4e0c2. Mara watched the eastern gate until dawn.

Ledger 64 line 119: Neri carried the blue token past marker 1c7178f5a8a5. Mara watched the eastern gate until dawn.

Ledger 64 line 120: Neri carried the blue token past marker d24898ebecbe. Mara watched the eastern gate until dawn.

Ledger 64 line 121: Neri carried the blue token past marker 714a51c0bbcc. Mara watched the eastern gate until dawn.

Ledger 64 line 122: Neri carried the blue token past marker 6100c7b355e8. Mara watched the eastern gate until dawn.

Ledger 64 line 123: Neri carried the blue token past marker 4fa7949c25f8. Mara watched the eastern gate until dawn.

Ledger 64 line 124: Neri carried the blue token past marker 77e840191621. Mara watched the eastern gate until dawn.

Ledger 64 line 125: Neri carried the blue token past marker 652915e0d179. Mara watched the eastern gate until dawn.

Ledger 64 line 126: Neri carried the blue token past marker 6976a01bbc45. Mara watched the eastern gate until dawn.

Ledger 64 line 127: Neri carried the blue token past marker d6ad8036e99a. Mara watched the eastern gate until dawn.

Ledger 64 line 128: Neri carried the blue token past marker da1c218fd516. Mara watched the eastern gate until dawn.

Ledger 64 line 129: Neri carried the blue token past marker 8c3d39114b3a. Mara watched the eastern gate until dawn.

Ledger 64 line 130: Neri carried the blue token past marker f66a5cfb0fd1. Mara watched the eastern gate until dawn.

Ledger 64 line 131: Neri carried the blue token past marker f83ed01793ee. Mara watched the eastern gate until dawn.

Ledger 64 line 132: Neri carried the blue token past marker 64ea083953cf. Mara watched the eastern gate until dawn.

Ledger 64 line 133: Neri carried the blue token past marker a2381fb1687c. Mara watched the eastern gate until dawn.

Ledger 64 line 134: Neri carried the blue token past marker 41d838d71d76. Mara watched the eastern gate until dawn.

Ledger 64 line 135: Neri carried the blue token past marker d40eba41c08d. Mara watched the eastern gate until dawn.

Ledger 64 line 136: Neri carried the blue token past marker b1392ae4f438. Mara watched the eastern gate until dawn.

Ledger 64 line 137: Neri carried the blue token past marker 70160687929b. Mara watched the eastern gate until dawn.

Ledger 64 line 138: Neri carried the blue token past marker 789ae9abceb3. Mara watched the eastern gate until dawn.

Ledger 64 line 139: Neri carried the blue token past marker 946ad2cbd5c7. Mara watched the eastern gate until dawn.

Ledger 64 line 140: Neri carried the blue token past marker 4ba00407948e. Mara watched the eastern gate until dawn.
