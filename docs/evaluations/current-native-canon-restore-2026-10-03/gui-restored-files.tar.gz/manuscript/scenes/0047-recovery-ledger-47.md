---
id: scene-0047
title: Recovery ledger 47
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.177567+00:00
updated_at: 2026-10-03T12:14:52.177567+00:00
---

Ledger 47 line 001: Neri carried the blue token past marker 41e8a1c41b07. Mara watched the eastern gate until dawn.

Ledger 47 line 002: Neri carried the blue token past marker e4a326a4ee63. Mara watched the eastern gate until dawn.

Ledger 47 line 003: Neri carried the blue token past marker 7307560df308. Mara watched the eastern gate until dawn.

Ledger 47 line 004: Neri carried the blue token past marker dc11ddb99b2c. Mara watched the eastern gate until dawn.

Ledger 47 line 005: Neri carried the blue token past marker 7270b04b49a3. Mara watched the eastern gate until dawn.

Ledger 47 line 006: Neri carried the blue token past marker bca3fcb4eaf0. Mara watched the eastern gate until dawn.

Ledger 47 line 007: Neri carried the blue token past marker 3f11eea0742c. Mara watched the eastern gate until dawn.

Ledger 47 line 008: Neri carried the blue token past marker 57614f1701b6. Mara watched the eastern gate until dawn.

Ledger 47 line 009: Neri carried the blue token past marker f8a1442bd234. Mara watched the eastern gate until dawn.

Ledger 47 line 010: Neri carried the blue token past marker 3385eb2fdeb0. Mara watched the eastern gate until dawn.

Ledger 47 line 011: Neri carried the blue token past marker e11447ec303a. Mara watched the eastern gate until dawn.

Ledger 47 line 012: Neri carried the blue token past marker 7b5a016c8588. Mara watched the eastern gate until dawn.

Ledger 47 line 013: Neri carried the blue token past marker ae725c6c94b3. Mara watched the eastern gate until dawn.

Ledger 47 line 014: Neri carried the blue token past marker cbbad59d9213. Mara watched the eastern gate until dawn.

Ledger 47 line 015: Neri carried the blue token past marker 9408e69d5cdb. Mara watched the eastern gate until dawn.

Ledger 47 line 016: Neri carried the blue token past marker 1cda0574bfa9. Mara watched the eastern gate until dawn.

Ledger 47 line 017: Neri carried the blue token past marker f42acf3c9837. Mara watched the eastern gate until dawn.

Ledger 47 line 018: Neri carried the blue token past marker 531a605e14ba. Mara watched the eastern gate until dawn.

Ledger 47 line 019: Neri carried the blue token past marker fee72376f318. Mara watched the eastern gate until dawn.

Ledger 47 line 020: Neri carried the blue token past marker 18a872482560. Mara watched the eastern gate until dawn.

Ledger 47 line 021: Neri carried the blue token past marker 3998e38f6710. Mara watched the eastern gate until dawn.

Ledger 47 line 022: Neri carried the blue token past marker 7c9391121d7c. Mara watched the eastern gate until dawn.

Ledger 47 line 023: Neri carried the blue token past marker 8ec4d0a25211. Mara watched the eastern gate until dawn.

Ledger 47 line 024: Neri carried the blue token past marker 58c390969b2e. Mara watched the eastern gate until dawn.

Ledger 47 line 025: Neri carried the blue token past marker f27356c07045. Mara watched the eastern gate until dawn.

Ledger 47 line 026: Neri carried the blue token past marker 57b37f175c00. Mara watched the eastern gate until dawn.

Ledger 47 line 027: Neri carried the blue token past marker dbcbfa4d7085. Mara watched the eastern gate until dawn.

Ledger 47 line 028: Neri carried the blue token past marker 9e3e959f5381. Mara watched the eastern gate until dawn.

Ledger 47 line 029: Neri carried the blue token past marker 2cdf0c815fc2. Mara watched the eastern gate until dawn.

Ledger 47 line 030: Neri carried the blue token past marker 132c32e066b4. Mara watched the eastern gate until dawn.

Ledger 47 line 031: Neri carried the blue token past marker c17624ad0336. Mara watched the eastern gate until dawn.

Ledger 47 line 032: Neri carried the blue token past marker 27bdef57c62c. Mara watched the eastern gate until dawn.

Ledger 47 line 033: Neri carried the blue token past marker 2fbe57d5cfc4. Mara watched the eastern gate until dawn.

Ledger 47 line 034: Neri carried the blue token past marker 83237689304b. Mara watched the eastern gate until dawn.

Ledger 47 line 035: Neri carried the blue token past marker b7e4bd17fc86. Mara watched the eastern gate until dawn.

Ledger 47 line 036: Neri carried the blue token past marker 3c8c09f70182. Mara watched the eastern gate until dawn.

Ledger 47 line 037: Neri carried the blue token past marker 771fe3700476. Mara watched the eastern gate until dawn.

Ledger 47 line 038: Neri carried the blue token past marker f381486dede8. Mara watched the eastern gate until dawn.

Ledger 47 line 039: Neri carried the blue token past marker 7d5e58e45f68. Mara watched the eastern gate until dawn.

Ledger 47 line 040: Neri carried the blue token past marker cccfbafc9ec4. Mara watched the eastern gate until dawn.

Ledger 47 line 041: Neri carried the blue token past marker 5e1c9f0dbf8b. Mara watched the eastern gate until dawn.

Ledger 47 line 042: Neri carried the blue token past marker 288d987364ca. Mara watched the eastern gate until dawn.

Ledger 47 line 043: Neri carried the blue token past marker a321530e968a. Mara watched the eastern gate until dawn.

Ledger 47 line 044: Neri carried the blue token past marker 249d0b1c98b3. Mara watched the eastern gate until dawn.

Ledger 47 line 045: Neri carried the blue token past marker e787b962ae2e. Mara watched the eastern gate until dawn.

Ledger 47 line 046: Neri carried the blue token past marker 56ce6402b262. Mara watched the eastern gate until dawn.

Ledger 47 line 047: Neri carried the blue token past marker f5b1a187b6f9. Mara watched the eastern gate until dawn.

Ledger 47 line 048: Neri carried the blue token past marker 379baaef50ba. Mara watched the eastern gate until dawn.

Ledger 47 line 049: Neri carried the blue token past marker b3b35ffdd855. Mara watched the eastern gate until dawn.

Ledger 47 line 050: Neri carried the blue token past marker 9fd760dbfd2f. Mara watched the eastern gate until dawn.

Ledger 47 line 051: Neri carried the blue token past marker 736c94e4b315. Mara watched the eastern gate until dawn.

Ledger 47 line 052: Neri carried the blue token past marker 2bddcbef6bb2. Mara watched the eastern gate until dawn.

Ledger 47 line 053: Neri carried the blue token past marker 634a4b11e8c2. Mara watched the eastern gate until dawn.

Ledger 47 line 054: Neri carried the blue token past marker ea1e627a4de2. Mara watched the eastern gate until dawn.

Ledger 47 line 055: Neri carried the blue token past marker eca07d7c6d41. Mara watched the eastern gate until dawn.

Ledger 47 line 056: Neri carried the blue token past marker 8a31a67b4e84. Mara watched the eastern gate until dawn.

Ledger 47 line 057: Neri carried the blue token past marker 4729522a738b. Mara watched the eastern gate until dawn.

Ledger 47 line 058: Neri carried the blue token past marker b1bc1c430978. Mara watched the eastern gate until dawn.

Ledger 47 line 059: Neri carried the blue token past marker d114c7bda0e7. Mara watched the eastern gate until dawn.

Ledger 47 line 060: Neri carried the blue token past marker f5a6b6bfa148. Mara watched the eastern gate until dawn.

Ledger 47 line 061: Neri carried the blue token past marker d39bfbeec5dc. Mara watched the eastern gate until dawn.

Ledger 47 line 062: Neri carried the blue token past marker 65dd582cbcad. Mara watched the eastern gate until dawn.

Ledger 47 line 063: Neri carried the blue token past marker f2030347f058. Mara watched the eastern gate until dawn.

Ledger 47 line 064: Neri carried the blue token past marker 199ef9028524. Mara watched the eastern gate until dawn.

Ledger 47 line 065: Neri carried the blue token past marker a615c91964b8. Mara watched the eastern gate until dawn.

Ledger 47 line 066: Neri carried the blue token past marker 1fc67ffec6ef. Mara watched the eastern gate until dawn.

Ledger 47 line 067: Neri carried the blue token past marker 2d1a7f092e05. Mara watched the eastern gate until dawn.

Ledger 47 line 068: Neri carried the blue token past marker 55fdf2d8acf3. Mara watched the eastern gate until dawn.

Ledger 47 line 069: Neri carried the blue token past marker ba63fd6b63fc. Mara watched the eastern gate until dawn.

Ledger 47 line 070: Neri carried the blue token past marker ea0919fdf909. Mara watched the eastern gate until dawn.

Ledger 47 line 071: Neri carried the blue token past marker 043e06032fcb. Mara watched the eastern gate until dawn.

Ledger 47 line 072: Neri carried the blue token past marker c1e6f4a71bc9. Mara watched the eastern gate until dawn.

Ledger 47 line 073: Neri carried the blue token past marker a22f9ab9e7a0. Mara watched the eastern gate until dawn.

Ledger 47 line 074: Neri carried the blue token past marker 8c74c03629a9. Mara watched the eastern gate until dawn.

Ledger 47 line 075: Neri carried the blue token past marker b7c810ce6918. Mara watched the eastern gate until dawn.

Ledger 47 line 076: Neri carried the blue token past marker 84f690f760d0. Mara watched the eastern gate until dawn.

Ledger 47 line 077: Neri carried the blue token past marker a16d9deff06e. Mara watched the eastern gate until dawn.

Ledger 47 line 078: Neri carried the blue token past marker 0e776703eed5. Mara watched the eastern gate until dawn.

Ledger 47 line 079: Neri carried the blue token past marker 79fa72574773. Mara watched the eastern gate until dawn.

Ledger 47 line 080: Neri carried the blue token past marker 3139823c9da4. Mara watched the eastern gate until dawn.

Ledger 47 line 081: Neri carried the blue token past marker 4ab8047dddaf. Mara watched the eastern gate until dawn.

Ledger 47 line 082: Neri carried the blue token past marker 1a72e54141ae. Mara watched the eastern gate until dawn.

Ledger 47 line 083: Neri carried the blue token past marker 0f0a48a32d3b. Mara watched the eastern gate until dawn.

Ledger 47 line 084: Neri carried the blue token past marker d9d0db92269a. Mara watched the eastern gate until dawn.

Ledger 47 line 085: Neri carried the blue token past marker a40c770cf854. Mara watched the eastern gate until dawn.

Ledger 47 line 086: Neri carried the blue token past marker abcf7cb36997. Mara watched the eastern gate until dawn.

Ledger 47 line 087: Neri carried the blue token past marker af4fc1ac9138. Mara watched the eastern gate until dawn.

Ledger 47 line 088: Neri carried the blue token past marker 06d5a3e0cffe. Mara watched the eastern gate until dawn.

Ledger 47 line 089: Neri carried the blue token past marker ec7617af12a2. Mara watched the eastern gate until dawn.

Ledger 47 line 090: Neri carried the blue token past marker 9ee9524c0c8b. Mara watched the eastern gate until dawn.

Ledger 47 line 091: Neri carried the blue token past marker 9a2914bfdf52. Mara watched the eastern gate until dawn.

Ledger 47 line 092: Neri carried the blue token past marker c84e6b920716. Mara watched the eastern gate until dawn.

Ledger 47 line 093: Neri carried the blue token past marker ac6b2673ea9e. Mara watched the eastern gate until dawn.

Ledger 47 line 094: Neri carried the blue token past marker 5f53bad9eb65. Mara watched the eastern gate until dawn.

Ledger 47 line 095: Neri carried the blue token past marker c9a78e92e1a8. Mara watched the eastern gate until dawn.

Ledger 47 line 096: Neri carried the blue token past marker 6a30c4ccb4d8. Mara watched the eastern gate until dawn.

Ledger 47 line 097: Neri carried the blue token past marker f30cf714668c. Mara watched the eastern gate until dawn.

Ledger 47 line 098: Neri carried the blue token past marker 5e0608d07f18. Mara watched the eastern gate until dawn.

Ledger 47 line 099: Neri carried the blue token past marker 1c71cf6cf0f3. Mara watched the eastern gate until dawn.

Ledger 47 line 100: Neri carried the blue token past marker 2359c62882d6. Mara watched the eastern gate until dawn.

Ledger 47 line 101: Neri carried the blue token past marker 845e36caed4f. Mara watched the eastern gate until dawn.

Ledger 47 line 102: Neri carried the blue token past marker 58b3a2306b9f. Mara watched the eastern gate until dawn.

Ledger 47 line 103: Neri carried the blue token past marker 1abf8a84d3a5. Mara watched the eastern gate until dawn.

Ledger 47 line 104: Neri carried the blue token past marker 6a2f68aa6023. Mara watched the eastern gate until dawn.

Ledger 47 line 105: Neri carried the blue token past marker 55a8975b8dbb. Mara watched the eastern gate until dawn.

Ledger 47 line 106: Neri carried the blue token past marker e607e0f5e91a. Mara watched the eastern gate until dawn.

Ledger 47 line 107: Neri carried the blue token past marker 1c45b365b4ec. Mara watched the eastern gate until dawn.

Ledger 47 line 108: Neri carried the blue token past marker c8d3c82d6a9b. Mara watched the eastern gate until dawn.

Ledger 47 line 109: Neri carried the blue token past marker 72062c59d199. Mara watched the eastern gate until dawn.

Ledger 47 line 110: Neri carried the blue token past marker 65cd7d4b9a52. Mara watched the eastern gate until dawn.

Ledger 47 line 111: Neri carried the blue token past marker 0501b4ac7a91. Mara watched the eastern gate until dawn.

Ledger 47 line 112: Neri carried the blue token past marker 9eb698423a71. Mara watched the eastern gate until dawn.

Ledger 47 line 113: Neri carried the blue token past marker 9678d527fce4. Mara watched the eastern gate until dawn.

Ledger 47 line 114: Neri carried the blue token past marker cf76690319ba. Mara watched the eastern gate until dawn.

Ledger 47 line 115: Neri carried the blue token past marker 69ad3699b038. Mara watched the eastern gate until dawn.

Ledger 47 line 116: Neri carried the blue token past marker 2e201ce193c7. Mara watched the eastern gate until dawn.

Ledger 47 line 117: Neri carried the blue token past marker 9535e88667cd. Mara watched the eastern gate until dawn.

Ledger 47 line 118: Neri carried the blue token past marker dc81cb73c6ff. Mara watched the eastern gate until dawn.

Ledger 47 line 119: Neri carried the blue token past marker dc31b245822a. Mara watched the eastern gate until dawn.

Ledger 47 line 120: Neri carried the blue token past marker 8c2fd005f0e3. Mara watched the eastern gate until dawn.

Ledger 47 line 121: Neri carried the blue token past marker 81466e19cf79. Mara watched the eastern gate until dawn.

Ledger 47 line 122: Neri carried the blue token past marker 615862ddf307. Mara watched the eastern gate until dawn.

Ledger 47 line 123: Neri carried the blue token past marker 86bba51e1faf. Mara watched the eastern gate until dawn.

Ledger 47 line 124: Neri carried the blue token past marker e3d74f210936. Mara watched the eastern gate until dawn.

Ledger 47 line 125: Neri carried the blue token past marker 24f0f4e6117f. Mara watched the eastern gate until dawn.

Ledger 47 line 126: Neri carried the blue token past marker 88d3f92f0b64. Mara watched the eastern gate until dawn.

Ledger 47 line 127: Neri carried the blue token past marker 2f183fda489f. Mara watched the eastern gate until dawn.

Ledger 47 line 128: Neri carried the blue token past marker 8d41f4ef3244. Mara watched the eastern gate until dawn.

Ledger 47 line 129: Neri carried the blue token past marker 3379a6f47317. Mara watched the eastern gate until dawn.

Ledger 47 line 130: Neri carried the blue token past marker 36f7c443eb7f. Mara watched the eastern gate until dawn.

Ledger 47 line 131: Neri carried the blue token past marker abc437ff25c1. Mara watched the eastern gate until dawn.

Ledger 47 line 132: Neri carried the blue token past marker 274b538fcb55. Mara watched the eastern gate until dawn.

Ledger 47 line 133: Neri carried the blue token past marker ec134c367149. Mara watched the eastern gate until dawn.

Ledger 47 line 134: Neri carried the blue token past marker cec538e0a8b6. Mara watched the eastern gate until dawn.

Ledger 47 line 135: Neri carried the blue token past marker 2395142192ab. Mara watched the eastern gate until dawn.

Ledger 47 line 136: Neri carried the blue token past marker 0f96c3c9fdad. Mara watched the eastern gate until dawn.

Ledger 47 line 137: Neri carried the blue token past marker 38602cbb422a. Mara watched the eastern gate until dawn.

Ledger 47 line 138: Neri carried the blue token past marker 1e032b614fc5. Mara watched the eastern gate until dawn.

Ledger 47 line 139: Neri carried the blue token past marker 81a7dd5b5527. Mara watched the eastern gate until dawn.

Ledger 47 line 140: Neri carried the blue token past marker f318102e9576. Mara watched the eastern gate until dawn.
