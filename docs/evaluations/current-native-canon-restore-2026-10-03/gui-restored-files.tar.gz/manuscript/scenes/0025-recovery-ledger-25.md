---
id: scene-0025
title: Recovery ledger 25
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.165969+00:00
updated_at: 2026-10-03T12:14:52.165969+00:00
---

Ledger 25 line 001: Neri carried the blue token past marker cfefdd24b01a. Mara watched the eastern gate until dawn.

Ledger 25 line 002: Neri carried the blue token past marker 55057b27c260. Mara watched the eastern gate until dawn.

Ledger 25 line 003: Neri carried the blue token past marker a285503116eb. Mara watched the eastern gate until dawn.

Ledger 25 line 004: Neri carried the blue token past marker 1e13de1c3d02. Mara watched the eastern gate until dawn.

Ledger 25 line 005: Neri carried the blue token past marker 5a5eade3e79b. Mara watched the eastern gate until dawn.

Ledger 25 line 006: Neri carried the blue token past marker 7340774a3605. Mara watched the eastern gate until dawn.

Ledger 25 line 007: Neri carried the blue token past marker 797d4be15e3d. Mara watched the eastern gate until dawn.

Ledger 25 line 008: Neri carried the blue token past marker 7ecb840b01d1. Mara watched the eastern gate until dawn.

Ledger 25 line 009: Neri carried the blue token past marker 50c9bacdabaa. Mara watched the eastern gate until dawn.

Ledger 25 line 010: Neri carried the blue token past marker 15bee45d7267. Mara watched the eastern gate until dawn.

Ledger 25 line 011: Neri carried the blue token past marker c929da2960e7. Mara watched the eastern gate until dawn.

Ledger 25 line 012: Neri carried the blue token past marker b7341898cd55. Mara watched the eastern gate until dawn.

Ledger 25 line 013: Neri carried the blue token past marker 0d6124f2bdc7. Mara watched the eastern gate until dawn.

Ledger 25 line 014: Neri carried the blue token past marker cd037a46cf84. Mara watched the eastern gate until dawn.

Ledger 25 line 015: Neri carried the blue token past marker 508107b20a13. Mara watched the eastern gate until dawn.

Ledger 25 line 016: Neri carried the blue token past marker af00a26e5dfe. Mara watched the eastern gate until dawn.

Ledger 25 line 017: Neri carried the blue token past marker 9b3bf272ed02. Mara watched the eastern gate until dawn.

Ledger 25 line 018: Neri carried the blue token past marker 385d86b61c88. Mara watched the eastern gate until dawn.

Ledger 25 line 019: Neri carried the blue token past marker e591e502d46a. Mara watched the eastern gate until dawn.

Ledger 25 line 020: Neri carried the blue token past marker 1ec47ab42f01. Mara watched the eastern gate until dawn.

Ledger 25 line 021: Neri carried the blue token past marker d0d3f2c58c11. Mara watched the eastern gate until dawn.

Ledger 25 line 022: Neri carried the blue token past marker ddb5539210f4. Mara watched the eastern gate until dawn.

Ledger 25 line 023: Neri carried the blue token past marker b62f45b9f386. Mara watched the eastern gate until dawn.

Ledger 25 line 024: Neri carried the blue token past marker 75796a167c44. Mara watched the eastern gate until dawn.

Ledger 25 line 025: Neri carried the blue token past marker 0f10e4027fe2. Mara watched the eastern gate until dawn.

Ledger 25 line 026: Neri carried the blue token past marker 0eee7caa6991. Mara watched the eastern gate until dawn.

Ledger 25 line 027: Neri carried the blue token past marker 4b590cc5d99e. Mara watched the eastern gate until dawn.

Ledger 25 line 028: Neri carried the blue token past marker ecc984ff4d44. Mara watched the eastern gate until dawn.

Ledger 25 line 029: Neri carried the blue token past marker 9c8f6f35d180. Mara watched the eastern gate until dawn.

Ledger 25 line 030: Neri carried the blue token past marker d4554b727809. Mara watched the eastern gate until dawn.

Ledger 25 line 031: Neri carried the blue token past marker 26b9ad2cee1e. Mara watched the eastern gate until dawn.

Ledger 25 line 032: Neri carried the blue token past marker 55a721594838. Mara watched the eastern gate until dawn.

Ledger 25 line 033: Neri carried the blue token past marker 428f0bb79194. Mara watched the eastern gate until dawn.

Ledger 25 line 034: Neri carried the blue token past marker a33e79681406. Mara watched the eastern gate until dawn.

Ledger 25 line 035: Neri carried the blue token past marker d14c8bb27f09. Mara watched the eastern gate until dawn.

Ledger 25 line 036: Neri carried the blue token past marker cf7e499ffac3. Mara watched the eastern gate until dawn.

Ledger 25 line 037: Neri carried the blue token past marker d71a2a2baa11. Mara watched the eastern gate until dawn.

Ledger 25 line 038: Neri carried the blue token past marker c1005e1ea656. Mara watched the eastern gate until dawn.

Ledger 25 line 039: Neri carried the blue token past marker 4900c00e6928. Mara watched the eastern gate until dawn.

Ledger 25 line 040: Neri carried the blue token past marker a203b9c5afd5. Mara watched the eastern gate until dawn.

Ledger 25 line 041: Neri carried the blue token past marker e8fd1aef6417. Mara watched the eastern gate until dawn.

Ledger 25 line 042: Neri carried the blue token past marker b5125e55627a. Mara watched the eastern gate until dawn.

Ledger 25 line 043: Neri carried the blue token past marker 1f53d7f309f9. Mara watched the eastern gate until dawn.

Ledger 25 line 044: Neri carried the blue token past marker 149b2b0d440a. Mara watched the eastern gate until dawn.

Ledger 25 line 045: Neri carried the blue token past marker e1bacb075131. Mara watched the eastern gate until dawn.

Ledger 25 line 046: Neri carried the blue token past marker 8a9ec112c3db. Mara watched the eastern gate until dawn.

Ledger 25 line 047: Neri carried the blue token past marker 41b3749ebe71. Mara watched the eastern gate until dawn.

Ledger 25 line 048: Neri carried the blue token past marker 9eef28dc0535. Mara watched the eastern gate until dawn.

Ledger 25 line 049: Neri carried the blue token past marker bd0e7d13b397. Mara watched the eastern gate until dawn.

Ledger 25 line 050: Neri carried the blue token past marker 882945b9cb06. Mara watched the eastern gate until dawn.

Ledger 25 line 051: Neri carried the blue token past marker 2d6aea22f837. Mara watched the eastern gate until dawn.

Ledger 25 line 052: Neri carried the blue token past marker 1569ac176dc4. Mara watched the eastern gate until dawn.

Ledger 25 line 053: Neri carried the blue token past marker 945d6c02cacf. Mara watched the eastern gate until dawn.

Ledger 25 line 054: Neri carried the blue token past marker c51e8a1408aa. Mara watched the eastern gate until dawn.

Ledger 25 line 055: Neri carried the blue token past marker 856c5a038af2. Mara watched the eastern gate until dawn.

Ledger 25 line 056: Neri carried the blue token past marker db97ad992085. Mara watched the eastern gate until dawn.

Ledger 25 line 057: Neri carried the blue token past marker 2eccd39d3942. Mara watched the eastern gate until dawn.

Ledger 25 line 058: Neri carried the blue token past marker 2babe08eddc9. Mara watched the eastern gate until dawn.

Ledger 25 line 059: Neri carried the blue token past marker d673e4b0096b. Mara watched the eastern gate until dawn.

Ledger 25 line 060: Neri carried the blue token past marker ab62bf5baad6. Mara watched the eastern gate until dawn.

Ledger 25 line 061: Neri carried the blue token past marker ca0b8a6e1127. Mara watched the eastern gate until dawn.

Ledger 25 line 062: Neri carried the blue token past marker 50470e274c3a. Mara watched the eastern gate until dawn.

Ledger 25 line 063: Neri carried the blue token past marker 1f45e972db7f. Mara watched the eastern gate until dawn.

Ledger 25 line 064: Neri carried the blue token past marker ae02961cbb68. Mara watched the eastern gate until dawn.

Ledger 25 line 065: Neri carried the blue token past marker 8a5c0b6b6b2f. Mara watched the eastern gate until dawn.

Ledger 25 line 066: Neri carried the blue token past marker be0bdfb30775. Mara watched the eastern gate until dawn.

Ledger 25 line 067: Neri carried the blue token past marker a5a5e793411f. Mara watched the eastern gate until dawn.

Ledger 25 line 068: Neri carried the blue token past marker c7a28b462a98. Mara watched the eastern gate until dawn.

Ledger 25 line 069: Neri carried the blue token past marker 276e141f533f. Mara watched the eastern gate until dawn.

Ledger 25 line 070: Neri carried the blue token past marker 84a5e562dc12. Mara watched the eastern gate until dawn.

Ledger 25 line 071: Neri carried the blue token past marker 0124f4f72a96. Mara watched the eastern gate until dawn.

Ledger 25 line 072: Neri carried the blue token past marker 37032a2246cd. Mara watched the eastern gate until dawn.

Ledger 25 line 073: Neri carried the blue token past marker ed72c07e4b51. Mara watched the eastern gate until dawn.

Ledger 25 line 074: Neri carried the blue token past marker aa83f628f5f4. Mara watched the eastern gate until dawn.

Ledger 25 line 075: Neri carried the blue token past marker dbe8a68dd0b6. Mara watched the eastern gate until dawn.

Ledger 25 line 076: Neri carried the blue token past marker 9948ca3d8637. Mara watched the eastern gate until dawn.

Ledger 25 line 077: Neri carried the blue token past marker dd04d4d3a1c0. Mara watched the eastern gate until dawn.

Ledger 25 line 078: Neri carried the blue token past marker 579711df4ae7. Mara watched the eastern gate until dawn.

Ledger 25 line 079: Neri carried the blue token past marker a85195cfe364. Mara watched the eastern gate until dawn.

Ledger 25 line 080: Neri carried the blue token past marker c441cbffb3a2. Mara watched the eastern gate until dawn.

Ledger 25 line 081: Neri carried the blue token past marker 84db908d1b7f. Mara watched the eastern gate until dawn.

Ledger 25 line 082: Neri carried the blue token past marker 5a6e76b9bb6b. Mara watched the eastern gate until dawn.

Ledger 25 line 083: Neri carried the blue token past marker 8ef38ba0c4f0. Mara watched the eastern gate until dawn.

Ledger 25 line 084: Neri carried the blue token past marker f7bfc9aef216. Mara watched the eastern gate until dawn.

Ledger 25 line 085: Neri carried the blue token past marker 0b1c438cd265. Mara watched the eastern gate until dawn.

Ledger 25 line 086: Neri carried the blue token past marker 2c7b3a25a612. Mara watched the eastern gate until dawn.

Ledger 25 line 087: Neri carried the blue token past marker f569872a7e21. Mara watched the eastern gate until dawn.

Ledger 25 line 088: Neri carried the blue token past marker d9ea3c9bc6ff. Mara watched the eastern gate until dawn.

Ledger 25 line 089: Neri carried the blue token past marker 9130eb288222. Mara watched the eastern gate until dawn.

Ledger 25 line 090: Neri carried the blue token past marker d8bf5d0a54c5. Mara watched the eastern gate until dawn.

Ledger 25 line 091: Neri carried the blue token past marker ac35b3df3e19. Mara watched the eastern gate until dawn.

Ledger 25 line 092: Neri carried the blue token past marker d025f601e667. Mara watched the eastern gate until dawn.

Ledger 25 line 093: Neri carried the blue token past marker e1269b1f9c5c. Mara watched the eastern gate until dawn.

Ledger 25 line 094: Neri carried the blue token past marker e46a8667e897. Mara watched the eastern gate until dawn.

Ledger 25 line 095: Neri carried the blue token past marker 0b14e45e1822. Mara watched the eastern gate until dawn.

Ledger 25 line 096: Neri carried the blue token past marker d16626cdca43. Mara watched the eastern gate until dawn.

Ledger 25 line 097: Neri carried the blue token past marker 776003364a08. Mara watched the eastern gate until dawn.

Ledger 25 line 098: Neri carried the blue token past marker 266434da7e69. Mara watched the eastern gate until dawn.

Ledger 25 line 099: Neri carried the blue token past marker 660fe9c8b3cf. Mara watched the eastern gate until dawn.

Ledger 25 line 100: Neri carried the blue token past marker 47448c7361cc. Mara watched the eastern gate until dawn.

Ledger 25 line 101: Neri carried the blue token past marker ac358d43cbd9. Mara watched the eastern gate until dawn.

Ledger 25 line 102: Neri carried the blue token past marker b083cafa9a99. Mara watched the eastern gate until dawn.

Ledger 25 line 103: Neri carried the blue token past marker 8ba9aa8ba340. Mara watched the eastern gate until dawn.

Ledger 25 line 104: Neri carried the blue token past marker bcdf10c48aba. Mara watched the eastern gate until dawn.

Ledger 25 line 105: Neri carried the blue token past marker 719012047d6f. Mara watched the eastern gate until dawn.

Ledger 25 line 106: Neri carried the blue token past marker f06197bb7a60. Mara watched the eastern gate until dawn.

Ledger 25 line 107: Neri carried the blue token past marker 820e5dd866da. Mara watched the eastern gate until dawn.

Ledger 25 line 108: Neri carried the blue token past marker 90964994ea2e. Mara watched the eastern gate until dawn.

Ledger 25 line 109: Neri carried the blue token past marker 6b37f0ae4074. Mara watched the eastern gate until dawn.

Ledger 25 line 110: Neri carried the blue token past marker 2dce320c0b11. Mara watched the eastern gate until dawn.

Ledger 25 line 111: Neri carried the blue token past marker 08708c8fc60c. Mara watched the eastern gate until dawn.

Ledger 25 line 112: Neri carried the blue token past marker ecfd50557105. Mara watched the eastern gate until dawn.

Ledger 25 line 113: Neri carried the blue token past marker 094de38d12d6. Mara watched the eastern gate until dawn.

Ledger 25 line 114: Neri carried the blue token past marker c2f41672a46e. Mara watched the eastern gate until dawn.

Ledger 25 line 115: Neri carried the blue token past marker a22804c20919. Mara watched the eastern gate until dawn.

Ledger 25 line 116: Neri carried the blue token past marker 624ac391fca6. Mara watched the eastern gate until dawn.

Ledger 25 line 117: Neri carried the blue token past marker 2818cd772f6d. Mara watched the eastern gate until dawn.

Ledger 25 line 118: Neri carried the blue token past marker 54033a710bb7. Mara watched the eastern gate until dawn.

Ledger 25 line 119: Neri carried the blue token past marker 9c03f8c97a9c. Mara watched the eastern gate until dawn.

Ledger 25 line 120: Neri carried the blue token past marker 2f27172a16b0. Mara watched the eastern gate until dawn.

Ledger 25 line 121: Neri carried the blue token past marker b5186d47617e. Mara watched the eastern gate until dawn.

Ledger 25 line 122: Neri carried the blue token past marker a73bde379f3a. Mara watched the eastern gate until dawn.

Ledger 25 line 123: Neri carried the blue token past marker 4d7fddc9598a. Mara watched the eastern gate until dawn.

Ledger 25 line 124: Neri carried the blue token past marker 9924b37480c1. Mara watched the eastern gate until dawn.

Ledger 25 line 125: Neri carried the blue token past marker a59954d0581b. Mara watched the eastern gate until dawn.

Ledger 25 line 126: Neri carried the blue token past marker ed5971026f73. Mara watched the eastern gate until dawn.

Ledger 25 line 127: Neri carried the blue token past marker 19dce20a75bb. Mara watched the eastern gate until dawn.

Ledger 25 line 128: Neri carried the blue token past marker 7cb22cc63c87. Mara watched the eastern gate until dawn.

Ledger 25 line 129: Neri carried the blue token past marker ed4b7fe71833. Mara watched the eastern gate until dawn.

Ledger 25 line 130: Neri carried the blue token past marker 206d1d31f881. Mara watched the eastern gate until dawn.

Ledger 25 line 131: Neri carried the blue token past marker b856fc655b67. Mara watched the eastern gate until dawn.

Ledger 25 line 132: Neri carried the blue token past marker 637a8af9b80a. Mara watched the eastern gate until dawn.

Ledger 25 line 133: Neri carried the blue token past marker 766792197e79. Mara watched the eastern gate until dawn.

Ledger 25 line 134: Neri carried the blue token past marker 6031c96308a8. Mara watched the eastern gate until dawn.

Ledger 25 line 135: Neri carried the blue token past marker fb99f8b331d1. Mara watched the eastern gate until dawn.

Ledger 25 line 136: Neri carried the blue token past marker 18b8188b571f. Mara watched the eastern gate until dawn.

Ledger 25 line 137: Neri carried the blue token past marker a442b6f3dc59. Mara watched the eastern gate until dawn.

Ledger 25 line 138: Neri carried the blue token past marker 186d18528b3f. Mara watched the eastern gate until dawn.

Ledger 25 line 139: Neri carried the blue token past marker 06aa6525cd00. Mara watched the eastern gate until dawn.

Ledger 25 line 140: Neri carried the blue token past marker 661187438803. Mara watched the eastern gate until dawn.
