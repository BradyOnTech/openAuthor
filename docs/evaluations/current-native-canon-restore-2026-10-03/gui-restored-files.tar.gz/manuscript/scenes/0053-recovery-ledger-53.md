---
id: scene-0053
title: Recovery ledger 53
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.180716+00:00
updated_at: 2026-10-03T12:14:52.180716+00:00
---

Ledger 53 line 001: Neri carried the blue token past marker 22e4184a041a. Mara watched the eastern gate until dawn.

Ledger 53 line 002: Neri carried the blue token past marker 716b3b15536f. Mara watched the eastern gate until dawn.

Ledger 53 line 003: Neri carried the blue token past marker 5cb1fc0aa5c0. Mara watched the eastern gate until dawn.

Ledger 53 line 004: Neri carried the blue token past marker a4d14d578454. Mara watched the eastern gate until dawn.

Ledger 53 line 005: Neri carried the blue token past marker 7c6addd19a64. Mara watched the eastern gate until dawn.

Ledger 53 line 006: Neri carried the blue token past marker eb24aa017b47. Mara watched the eastern gate until dawn.

Ledger 53 line 007: Neri carried the blue token past marker 79700041b909. Mara watched the eastern gate until dawn.

Ledger 53 line 008: Neri carried the blue token past marker b903ddce0156. Mara watched the eastern gate until dawn.

Ledger 53 line 009: Neri carried the blue token past marker 6f77463bd09c. Mara watched the eastern gate until dawn.

Ledger 53 line 010: Neri carried the blue token past marker f658e8592fcc. Mara watched the eastern gate until dawn.

Ledger 53 line 011: Neri carried the blue token past marker f6600d5f847f. Mara watched the eastern gate until dawn.

Ledger 53 line 012: Neri carried the blue token past marker 397db8b19760. Mara watched the eastern gate until dawn.

Ledger 53 line 013: Neri carried the blue token past marker c64896b162c0. Mara watched the eastern gate until dawn.

Ledger 53 line 014: Neri carried the blue token past marker be80ea6431fa. Mara watched the eastern gate until dawn.

Ledger 53 line 015: Neri carried the blue token past marker 8345ebcaf3c9. Mara watched the eastern gate until dawn.

Ledger 53 line 016: Neri carried the blue token past marker 850c822f4b56. Mara watched the eastern gate until dawn.

Ledger 53 line 017: Neri carried the blue token past marker a1b96d561820. Mara watched the eastern gate until dawn.

Ledger 53 line 018: Neri carried the blue token past marker ae889dbd12e3. Mara watched the eastern gate until dawn.

Ledger 53 line 019: Neri carried the blue token past marker 955aeb27468f. Mara watched the eastern gate until dawn.

Ledger 53 line 020: Neri carried the blue token past marker eda8cddbfa85. Mara watched the eastern gate until dawn.

Ledger 53 line 021: Neri carried the blue token past marker 996b9196ed4a. Mara watched the eastern gate until dawn.

Ledger 53 line 022: Neri carried the blue token past marker f21e92ff414c. Mara watched the eastern gate until dawn.

Ledger 53 line 023: Neri carried the blue token past marker 0fcf9424274f. Mara watched the eastern gate until dawn.

Ledger 53 line 024: Neri carried the blue token past marker 5087f9ff3768. Mara watched the eastern gate until dawn.

Ledger 53 line 025: Neri carried the blue token past marker bf1c686e7ff6. Mara watched the eastern gate until dawn.

Ledger 53 line 026: Neri carried the blue token past marker 636fb28de53d. Mara watched the eastern gate until dawn.

Ledger 53 line 027: Neri carried the blue token past marker b3b666ea7b6b. Mara watched the eastern gate until dawn.

Ledger 53 line 028: Neri carried the blue token past marker 76b5f9c5821f. Mara watched the eastern gate until dawn.

Ledger 53 line 029: Neri carried the blue token past marker 5a4ca1afdf52. Mara watched the eastern gate until dawn.

Ledger 53 line 030: Neri carried the blue token past marker 27ea245be6e1. Mara watched the eastern gate until dawn.

Ledger 53 line 031: Neri carried the blue token past marker aaecab76f72a. Mara watched the eastern gate until dawn.

Ledger 53 line 032: Neri carried the blue token past marker 314e52f0b49a. Mara watched the eastern gate until dawn.

Ledger 53 line 033: Neri carried the blue token past marker b5e9950bfa7a. Mara watched the eastern gate until dawn.

Ledger 53 line 034: Neri carried the blue token past marker 6f57ed9b634b. Mara watched the eastern gate until dawn.

Ledger 53 line 035: Neri carried the blue token past marker f23c40148ec7. Mara watched the eastern gate until dawn.

Ledger 53 line 036: Neri carried the blue token past marker 4e7f734d586f. Mara watched the eastern gate until dawn.

Ledger 53 line 037: Neri carried the blue token past marker 546d8225c9e0. Mara watched the eastern gate until dawn.

Ledger 53 line 038: Neri carried the blue token past marker cc91f0ebc6ba. Mara watched the eastern gate until dawn.

Ledger 53 line 039: Neri carried the blue token past marker c1230de10bbf. Mara watched the eastern gate until dawn.

Ledger 53 line 040: Neri carried the blue token past marker 96884099db6a. Mara watched the eastern gate until dawn.

Ledger 53 line 041: Neri carried the blue token past marker fa1788a16d89. Mara watched the eastern gate until dawn.

Ledger 53 line 042: Neri carried the blue token past marker 455ac330bc5d. Mara watched the eastern gate until dawn.

Ledger 53 line 043: Neri carried the blue token past marker 7f36ab40dd21. Mara watched the eastern gate until dawn.

Ledger 53 line 044: Neri carried the blue token past marker 007b44496b67. Mara watched the eastern gate until dawn.

Ledger 53 line 045: Neri carried the blue token past marker 0b2e8fae31a2. Mara watched the eastern gate until dawn.

Ledger 53 line 046: Neri carried the blue token past marker 61fea2fd797e. Mara watched the eastern gate until dawn.

Ledger 53 line 047: Neri carried the blue token past marker de67c0c388d6. Mara watched the eastern gate until dawn.

Ledger 53 line 048: Neri carried the blue token past marker c9bcd5ecc50f. Mara watched the eastern gate until dawn.

Ledger 53 line 049: Neri carried the blue token past marker 8dc72ccd1d56. Mara watched the eastern gate until dawn.

Ledger 53 line 050: Neri carried the blue token past marker 850e71f0ff2b. Mara watched the eastern gate until dawn.

Ledger 53 line 051: Neri carried the blue token past marker 84ab492bee4e. Mara watched the eastern gate until dawn.

Ledger 53 line 052: Neri carried the blue token past marker 832f2a4b5b79. Mara watched the eastern gate until dawn.

Ledger 53 line 053: Neri carried the blue token past marker 23ca1dea9858. Mara watched the eastern gate until dawn.

Ledger 53 line 054: Neri carried the blue token past marker 1fe61623e5ea. Mara watched the eastern gate until dawn.

Ledger 53 line 055: Neri carried the blue token past marker bd73bc634d30. Mara watched the eastern gate until dawn.

Ledger 53 line 056: Neri carried the blue token past marker 407d21194a6d. Mara watched the eastern gate until dawn.

Ledger 53 line 057: Neri carried the blue token past marker d3140bc787a5. Mara watched the eastern gate until dawn.

Ledger 53 line 058: Neri carried the blue token past marker e3179b612e96. Mara watched the eastern gate until dawn.

Ledger 53 line 059: Neri carried the blue token past marker 5d383f20e8ba. Mara watched the eastern gate until dawn.

Ledger 53 line 060: Neri carried the blue token past marker 42ba833b06c1. Mara watched the eastern gate until dawn.

Ledger 53 line 061: Neri carried the blue token past marker da92a03c9bc3. Mara watched the eastern gate until dawn.

Ledger 53 line 062: Neri carried the blue token past marker 9a4f4d44abff. Mara watched the eastern gate until dawn.

Ledger 53 line 063: Neri carried the blue token past marker 3ea6271a21d8. Mara watched the eastern gate until dawn.

Ledger 53 line 064: Neri carried the blue token past marker d9864e59b682. Mara watched the eastern gate until dawn.

Ledger 53 line 065: Neri carried the blue token past marker 1bd966dbc841. Mara watched the eastern gate until dawn.

Ledger 53 line 066: Neri carried the blue token past marker 729947a03149. Mara watched the eastern gate until dawn.

Ledger 53 line 067: Neri carried the blue token past marker 409789d4ee82. Mara watched the eastern gate until dawn.

Ledger 53 line 068: Neri carried the blue token past marker c41aab1e6f17. Mara watched the eastern gate until dawn.

Ledger 53 line 069: Neri carried the blue token past marker 77751b2e7e06. Mara watched the eastern gate until dawn.

Ledger 53 line 070: Neri carried the blue token past marker f925fb1421c2. Mara watched the eastern gate until dawn.

Ledger 53 line 071: Neri carried the blue token past marker e573e17c4a63. Mara watched the eastern gate until dawn.

Ledger 53 line 072: Neri carried the blue token past marker 08c0018a0749. Mara watched the eastern gate until dawn.

Ledger 53 line 073: Neri carried the blue token past marker 6b7144d8ccab. Mara watched the eastern gate until dawn.

Ledger 53 line 074: Neri carried the blue token past marker 25f646c73187. Mara watched the eastern gate until dawn.

Ledger 53 line 075: Neri carried the blue token past marker 4c1a3452a293. Mara watched the eastern gate until dawn.

Ledger 53 line 076: Neri carried the blue token past marker bab3635e7f05. Mara watched the eastern gate until dawn.

Ledger 53 line 077: Neri carried the blue token past marker b744b50f7748. Mara watched the eastern gate until dawn.

Ledger 53 line 078: Neri carried the blue token past marker 1848f83e3fe7. Mara watched the eastern gate until dawn.

Ledger 53 line 079: Neri carried the blue token past marker 271546f19b61. Mara watched the eastern gate until dawn.

Ledger 53 line 080: Neri carried the blue token past marker 88dad12f9d73. Mara watched the eastern gate until dawn.

Ledger 53 line 081: Neri carried the blue token past marker 863cf567d51e. Mara watched the eastern gate until dawn.

Ledger 53 line 082: Neri carried the blue token past marker 52913147457b. Mara watched the eastern gate until dawn.

Ledger 53 line 083: Neri carried the blue token past marker 44761c60db71. Mara watched the eastern gate until dawn.

Ledger 53 line 084: Neri carried the blue token past marker d668613f67a4. Mara watched the eastern gate until dawn.

Ledger 53 line 085: Neri carried the blue token past marker 30166902e40c. Mara watched the eastern gate until dawn.

Ledger 53 line 086: Neri carried the blue token past marker 41c93ce8d7fe. Mara watched the eastern gate until dawn.

Ledger 53 line 087: Neri carried the blue token past marker 0deee1e8a4bd. Mara watched the eastern gate until dawn.

Ledger 53 line 088: Neri carried the blue token past marker 259203281e54. Mara watched the eastern gate until dawn.

Ledger 53 line 089: Neri carried the blue token past marker 9469d864f306. Mara watched the eastern gate until dawn.

Ledger 53 line 090: Neri carried the blue token past marker 3c0aa2484fd6. Mara watched the eastern gate until dawn.

Ledger 53 line 091: Neri carried the blue token past marker 12332e424df5. Mara watched the eastern gate until dawn.

Ledger 53 line 092: Neri carried the blue token past marker b5ad331ace43. Mara watched the eastern gate until dawn.

Ledger 53 line 093: Neri carried the blue token past marker 52eb3872c661. Mara watched the eastern gate until dawn.

Ledger 53 line 094: Neri carried the blue token past marker d722f45e0995. Mara watched the eastern gate until dawn.

Ledger 53 line 095: Neri carried the blue token past marker fab8cc55ebdf. Mara watched the eastern gate until dawn.

Ledger 53 line 096: Neri carried the blue token past marker bc4d07a98e19. Mara watched the eastern gate until dawn.

Ledger 53 line 097: Neri carried the blue token past marker ab4e8152749f. Mara watched the eastern gate until dawn.

Ledger 53 line 098: Neri carried the blue token past marker cb19a9e80a57. Mara watched the eastern gate until dawn.

Ledger 53 line 099: Neri carried the blue token past marker aefa0999d23e. Mara watched the eastern gate until dawn.

Ledger 53 line 100: Neri carried the blue token past marker e1c31e30de62. Mara watched the eastern gate until dawn.

Ledger 53 line 101: Neri carried the blue token past marker 7ba7e9756da6. Mara watched the eastern gate until dawn.

Ledger 53 line 102: Neri carried the blue token past marker 9be836e559ac. Mara watched the eastern gate until dawn.

Ledger 53 line 103: Neri carried the blue token past marker e63804ed9ace. Mara watched the eastern gate until dawn.

Ledger 53 line 104: Neri carried the blue token past marker 58ee69ac34ed. Mara watched the eastern gate until dawn.

Ledger 53 line 105: Neri carried the blue token past marker 78712bd78ab6. Mara watched the eastern gate until dawn.

Ledger 53 line 106: Neri carried the blue token past marker 9cc43058a2d6. Mara watched the eastern gate until dawn.

Ledger 53 line 107: Neri carried the blue token past marker ce15cc9da994. Mara watched the eastern gate until dawn.

Ledger 53 line 108: Neri carried the blue token past marker 1355467fd43e. Mara watched the eastern gate until dawn.

Ledger 53 line 109: Neri carried the blue token past marker be480a952ed3. Mara watched the eastern gate until dawn.

Ledger 53 line 110: Neri carried the blue token past marker 7bad20963cc3. Mara watched the eastern gate until dawn.

Ledger 53 line 111: Neri carried the blue token past marker 85c9c71069cf. Mara watched the eastern gate until dawn.

Ledger 53 line 112: Neri carried the blue token past marker 48c6e535c79f. Mara watched the eastern gate until dawn.

Ledger 53 line 113: Neri carried the blue token past marker 0295fc73330f. Mara watched the eastern gate until dawn.

Ledger 53 line 114: Neri carried the blue token past marker 99ab96afffc8. Mara watched the eastern gate until dawn.

Ledger 53 line 115: Neri carried the blue token past marker 56ab49482020. Mara watched the eastern gate until dawn.

Ledger 53 line 116: Neri carried the blue token past marker 45b90a181ca7. Mara watched the eastern gate until dawn.

Ledger 53 line 117: Neri carried the blue token past marker 114b371d7025. Mara watched the eastern gate until dawn.

Ledger 53 line 118: Neri carried the blue token past marker f21838bd8e92. Mara watched the eastern gate until dawn.

Ledger 53 line 119: Neri carried the blue token past marker 7f5b090fa61f. Mara watched the eastern gate until dawn.

Ledger 53 line 120: Neri carried the blue token past marker 4ce1a8080c86. Mara watched the eastern gate until dawn.

Ledger 53 line 121: Neri carried the blue token past marker 5732e0ae9db7. Mara watched the eastern gate until dawn.

Ledger 53 line 122: Neri carried the blue token past marker e53ff850529b. Mara watched the eastern gate until dawn.

Ledger 53 line 123: Neri carried the blue token past marker 8ae8fd9a28b3. Mara watched the eastern gate until dawn.

Ledger 53 line 124: Neri carried the blue token past marker 5b606a5e3524. Mara watched the eastern gate until dawn.

Ledger 53 line 125: Neri carried the blue token past marker 443ceae9177e. Mara watched the eastern gate until dawn.

Ledger 53 line 126: Neri carried the blue token past marker 4484bd733e55. Mara watched the eastern gate until dawn.

Ledger 53 line 127: Neri carried the blue token past marker 6594b15e1327. Mara watched the eastern gate until dawn.

Ledger 53 line 128: Neri carried the blue token past marker c8e68b56f0a2. Mara watched the eastern gate until dawn.

Ledger 53 line 129: Neri carried the blue token past marker d9df4dbfb6b3. Mara watched the eastern gate until dawn.

Ledger 53 line 130: Neri carried the blue token past marker 97682b682f33. Mara watched the eastern gate until dawn.

Ledger 53 line 131: Neri carried the blue token past marker be8b51eacf2e. Mara watched the eastern gate until dawn.

Ledger 53 line 132: Neri carried the blue token past marker f4dd759e0a4b. Mara watched the eastern gate until dawn.

Ledger 53 line 133: Neri carried the blue token past marker 3e6e02008d11. Mara watched the eastern gate until dawn.

Ledger 53 line 134: Neri carried the blue token past marker 5033e5ff2f4d. Mara watched the eastern gate until dawn.

Ledger 53 line 135: Neri carried the blue token past marker 15e3b015e474. Mara watched the eastern gate until dawn.

Ledger 53 line 136: Neri carried the blue token past marker 6aaa73ccb7cf. Mara watched the eastern gate until dawn.

Ledger 53 line 137: Neri carried the blue token past marker 53279945c1c4. Mara watched the eastern gate until dawn.

Ledger 53 line 138: Neri carried the blue token past marker beb07e1197e5. Mara watched the eastern gate until dawn.

Ledger 53 line 139: Neri carried the blue token past marker c7b8228f81f2. Mara watched the eastern gate until dawn.

Ledger 53 line 140: Neri carried the blue token past marker 165fdfa6b178. Mara watched the eastern gate until dawn.
