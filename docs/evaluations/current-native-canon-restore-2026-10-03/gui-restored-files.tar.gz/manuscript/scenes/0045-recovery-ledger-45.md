---
id: scene-0045
title: Recovery ledger 45
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.176564+00:00
updated_at: 2026-10-03T12:14:52.176564+00:00
---

Ledger 45 line 001: Neri carried the blue token past marker 35d856b8b240. Mara watched the eastern gate until dawn.

Ledger 45 line 002: Neri carried the blue token past marker 12198f20f1d8. Mara watched the eastern gate until dawn.

Ledger 45 line 003: Neri carried the blue token past marker 9aa8a719992d. Mara watched the eastern gate until dawn.

Ledger 45 line 004: Neri carried the blue token past marker 61f33af4005b. Mara watched the eastern gate until dawn.

Ledger 45 line 005: Neri carried the blue token past marker 4eb10bea8c0e. Mara watched the eastern gate until dawn.

Ledger 45 line 006: Neri carried the blue token past marker 35e08b84bfc9. Mara watched the eastern gate until dawn.

Ledger 45 line 007: Neri carried the blue token past marker 5be69663cb3b. Mara watched the eastern gate until dawn.

Ledger 45 line 008: Neri carried the blue token past marker c47de210fada. Mara watched the eastern gate until dawn.

Ledger 45 line 009: Neri carried the blue token past marker ba604bff8fa5. Mara watched the eastern gate until dawn.

Ledger 45 line 010: Neri carried the blue token past marker 2dc1586e59f5. Mara watched the eastern gate until dawn.

Ledger 45 line 011: Neri carried the blue token past marker 7085da65289e. Mara watched the eastern gate until dawn.

Ledger 45 line 012: Neri carried the blue token past marker 028602587b62. Mara watched the eastern gate until dawn.

Ledger 45 line 013: Neri carried the blue token past marker 77f8ba813a39. Mara watched the eastern gate until dawn.

Ledger 45 line 014: Neri carried the blue token past marker 74fb3a0de690. Mara watched the eastern gate until dawn.

Ledger 45 line 015: Neri carried the blue token past marker dc2a54396931. Mara watched the eastern gate until dawn.

Ledger 45 line 016: Neri carried the blue token past marker 336a86f154e8. Mara watched the eastern gate until dawn.

Ledger 45 line 017: Neri carried the blue token past marker 2b1e566fa0c2. Mara watched the eastern gate until dawn.

Ledger 45 line 018: Neri carried the blue token past marker b944b443aaea. Mara watched the eastern gate until dawn.

Ledger 45 line 019: Neri carried the blue token past marker 6c2cf0997b6d. Mara watched the eastern gate until dawn.

Ledger 45 line 020: Neri carried the blue token past marker 248ae9eab7dc. Mara watched the eastern gate until dawn.

Ledger 45 line 021: Neri carried the blue token past marker 235cd7bce7d4. Mara watched the eastern gate until dawn.

Ledger 45 line 022: Neri carried the blue token past marker 7a2f88e816a0. Mara watched the eastern gate until dawn.

Ledger 45 line 023: Neri carried the blue token past marker 1977aba02613. Mara watched the eastern gate until dawn.

Ledger 45 line 024: Neri carried the blue token past marker 2d1e636cd383. Mara watched the eastern gate until dawn.

Ledger 45 line 025: Neri carried the blue token past marker 731ae6bdc944. Mara watched the eastern gate until dawn.

Ledger 45 line 026: Neri carried the blue token past marker 44add042939a. Mara watched the eastern gate until dawn.

Ledger 45 line 027: Neri carried the blue token past marker d8a456eeff7f. Mara watched the eastern gate until dawn.

Ledger 45 line 028: Neri carried the blue token past marker 6f4cdcb47e0d. Mara watched the eastern gate until dawn.

Ledger 45 line 029: Neri carried the blue token past marker 9a6f56c8228f. Mara watched the eastern gate until dawn.

Ledger 45 line 030: Neri carried the blue token past marker c8da3cb2d5f8. Mara watched the eastern gate until dawn.

Ledger 45 line 031: Neri carried the blue token past marker 24db6b6b5555. Mara watched the eastern gate until dawn.

Ledger 45 line 032: Neri carried the blue token past marker 63d54b78198f. Mara watched the eastern gate until dawn.

Ledger 45 line 033: Neri carried the blue token past marker 2d8c575f18f6. Mara watched the eastern gate until dawn.

Ledger 45 line 034: Neri carried the blue token past marker b2f00cf3ee15. Mara watched the eastern gate until dawn.

Ledger 45 line 035: Neri carried the blue token past marker 28134975bd44. Mara watched the eastern gate until dawn.

Ledger 45 line 036: Neri carried the blue token past marker da8e19937318. Mara watched the eastern gate until dawn.

Ledger 45 line 037: Neri carried the blue token past marker 86f10b77b3d7. Mara watched the eastern gate until dawn.

Ledger 45 line 038: Neri carried the blue token past marker 529ac177eb9f. Mara watched the eastern gate until dawn.

Ledger 45 line 039: Neri carried the blue token past marker 7b7e25cd8364. Mara watched the eastern gate until dawn.

Ledger 45 line 040: Neri carried the blue token past marker a17abb89990f. Mara watched the eastern gate until dawn.

Ledger 45 line 041: Neri carried the blue token past marker 0690c26b3d1e. Mara watched the eastern gate until dawn.

Ledger 45 line 042: Neri carried the blue token past marker d76ded1f8b6f. Mara watched the eastern gate until dawn.

Ledger 45 line 043: Neri carried the blue token past marker 35865a7969d5. Mara watched the eastern gate until dawn.

Ledger 45 line 044: Neri carried the blue token past marker cea2b2d11e47. Mara watched the eastern gate until dawn.

Ledger 45 line 045: Neri carried the blue token past marker a2ca653b7693. Mara watched the eastern gate until dawn.

Ledger 45 line 046: Neri carried the blue token past marker 25e568e2a8b3. Mara watched the eastern gate until dawn.

Ledger 45 line 047: Neri carried the blue token past marker e341471520da. Mara watched the eastern gate until dawn.

Ledger 45 line 048: Neri carried the blue token past marker d5c5f2581f63. Mara watched the eastern gate until dawn.

Ledger 45 line 049: Neri carried the blue token past marker 2ac5caaf6c1d. Mara watched the eastern gate until dawn.

Ledger 45 line 050: Neri carried the blue token past marker b6b1cf0b45ce. Mara watched the eastern gate until dawn.

Ledger 45 line 051: Neri carried the blue token past marker ce57332e68e1. Mara watched the eastern gate until dawn.

Ledger 45 line 052: Neri carried the blue token past marker 35c6d1405056. Mara watched the eastern gate until dawn.

Ledger 45 line 053: Neri carried the blue token past marker 0e03985e4f02. Mara watched the eastern gate until dawn.

Ledger 45 line 054: Neri carried the blue token past marker ff255312bc5f. Mara watched the eastern gate until dawn.

Ledger 45 line 055: Neri carried the blue token past marker 1f716f78ee1f. Mara watched the eastern gate until dawn.

Ledger 45 line 056: Neri carried the blue token past marker 522da71f1d04. Mara watched the eastern gate until dawn.

Ledger 45 line 057: Neri carried the blue token past marker 5011801f437d. Mara watched the eastern gate until dawn.

Ledger 45 line 058: Neri carried the blue token past marker c0870731afb0. Mara watched the eastern gate until dawn.

Ledger 45 line 059: Neri carried the blue token past marker 45f0159b97a1. Mara watched the eastern gate until dawn.

Ledger 45 line 060: Neri carried the blue token past marker ef7b8031e333. Mara watched the eastern gate until dawn.

Ledger 45 line 061: Neri carried the blue token past marker bcd1bc14b0df. Mara watched the eastern gate until dawn.

Ledger 45 line 062: Neri carried the blue token past marker 92ad7cde4d82. Mara watched the eastern gate until dawn.

Ledger 45 line 063: Neri carried the blue token past marker b3f2c5bce840. Mara watched the eastern gate until dawn.

Ledger 45 line 064: Neri carried the blue token past marker 01fd71452787. Mara watched the eastern gate until dawn.

Ledger 45 line 065: Neri carried the blue token past marker 25a0d5b048f6. Mara watched the eastern gate until dawn.

Ledger 45 line 066: Neri carried the blue token past marker 91895c46db69. Mara watched the eastern gate until dawn.

Ledger 45 line 067: Neri carried the blue token past marker c47328251209. Mara watched the eastern gate until dawn.

Ledger 45 line 068: Neri carried the blue token past marker 6e604f94a6ed. Mara watched the eastern gate until dawn.

Ledger 45 line 069: Neri carried the blue token past marker 2280efc31e7c. Mara watched the eastern gate until dawn.

Ledger 45 line 070: Neri carried the blue token past marker 04ae0e6c5ab0. Mara watched the eastern gate until dawn.

Ledger 45 line 071: Neri carried the blue token past marker 39bcf3bff4ca. Mara watched the eastern gate until dawn.

Ledger 45 line 072: Neri carried the blue token past marker 46cf8196d950. Mara watched the eastern gate until dawn.

Ledger 45 line 073: Neri carried the blue token past marker 606bcc8103c5. Mara watched the eastern gate until dawn.

Ledger 45 line 074: Neri carried the blue token past marker 5582ddc952a6. Mara watched the eastern gate until dawn.

Ledger 45 line 075: Neri carried the blue token past marker 26bb4d347e34. Mara watched the eastern gate until dawn.

Ledger 45 line 076: Neri carried the blue token past marker 2068d59e3bd8. Mara watched the eastern gate until dawn.

Ledger 45 line 077: Neri carried the blue token past marker 1c411c363a59. Mara watched the eastern gate until dawn.

Ledger 45 line 078: Neri carried the blue token past marker a2b3fff68634. Mara watched the eastern gate until dawn.

Ledger 45 line 079: Neri carried the blue token past marker bf556d28f78c. Mara watched the eastern gate until dawn.

Ledger 45 line 080: Neri carried the blue token past marker 7055ff345f7f. Mara watched the eastern gate until dawn.

Ledger 45 line 081: Neri carried the blue token past marker 9ae5a39b57f2. Mara watched the eastern gate until dawn.

Ledger 45 line 082: Neri carried the blue token past marker d6c4bbbb800f. Mara watched the eastern gate until dawn.

Ledger 45 line 083: Neri carried the blue token past marker 76dca0abf8c4. Mara watched the eastern gate until dawn.

Ledger 45 line 084: Neri carried the blue token past marker 71bcf0cdc1fb. Mara watched the eastern gate until dawn.

Ledger 45 line 085: Neri carried the blue token past marker 4c7ae87cdc73. Mara watched the eastern gate until dawn.

Ledger 45 line 086: Neri carried the blue token past marker 9b14e80a27b5. Mara watched the eastern gate until dawn.

Ledger 45 line 087: Neri carried the blue token past marker 7151be11bde7. Mara watched the eastern gate until dawn.

Ledger 45 line 088: Neri carried the blue token past marker 6e7847ed990d. Mara watched the eastern gate until dawn.

Ledger 45 line 089: Neri carried the blue token past marker 0a60814ea90d. Mara watched the eastern gate until dawn.

Ledger 45 line 090: Neri carried the blue token past marker 03ca16a60db2. Mara watched the eastern gate until dawn.

Ledger 45 line 091: Neri carried the blue token past marker 28a986001f5b. Mara watched the eastern gate until dawn.

Ledger 45 line 092: Neri carried the blue token past marker f0415db95dfb. Mara watched the eastern gate until dawn.

Ledger 45 line 093: Neri carried the blue token past marker e976fa047db1. Mara watched the eastern gate until dawn.

Ledger 45 line 094: Neri carried the blue token past marker b428dc09f81b. Mara watched the eastern gate until dawn.

Ledger 45 line 095: Neri carried the blue token past marker 349b0efe6dd3. Mara watched the eastern gate until dawn.

Ledger 45 line 096: Neri carried the blue token past marker 88fe5c638347. Mara watched the eastern gate until dawn.

Ledger 45 line 097: Neri carried the blue token past marker cc0f3b25c751. Mara watched the eastern gate until dawn.

Ledger 45 line 098: Neri carried the blue token past marker cf7707a058f1. Mara watched the eastern gate until dawn.

Ledger 45 line 099: Neri carried the blue token past marker 3fe23ad4794d. Mara watched the eastern gate until dawn.

Ledger 45 line 100: Neri carried the blue token past marker 8e6a5aaffce7. Mara watched the eastern gate until dawn.

Ledger 45 line 101: Neri carried the blue token past marker c774809ed32d. Mara watched the eastern gate until dawn.

Ledger 45 line 102: Neri carried the blue token past marker 681be123e20b. Mara watched the eastern gate until dawn.

Ledger 45 line 103: Neri carried the blue token past marker f56f1d4cc0fe. Mara watched the eastern gate until dawn.

Ledger 45 line 104: Neri carried the blue token past marker 8f9c344ad6a5. Mara watched the eastern gate until dawn.

Ledger 45 line 105: Neri carried the blue token past marker fbad1027de24. Mara watched the eastern gate until dawn.

Ledger 45 line 106: Neri carried the blue token past marker 24abddc93a97. Mara watched the eastern gate until dawn.

Ledger 45 line 107: Neri carried the blue token past marker c599efb38dbd. Mara watched the eastern gate until dawn.

Ledger 45 line 108: Neri carried the blue token past marker 0b1daf8e7db9. Mara watched the eastern gate until dawn.

Ledger 45 line 109: Neri carried the blue token past marker adccd6440040. Mara watched the eastern gate until dawn.

Ledger 45 line 110: Neri carried the blue token past marker 044c37c22bf4. Mara watched the eastern gate until dawn.

Ledger 45 line 111: Neri carried the blue token past marker 698bd3872962. Mara watched the eastern gate until dawn.

Ledger 45 line 112: Neri carried the blue token past marker 6ed22aca3705. Mara watched the eastern gate until dawn.

Ledger 45 line 113: Neri carried the blue token past marker 756e4a36d321. Mara watched the eastern gate until dawn.

Ledger 45 line 114: Neri carried the blue token past marker 7171c83841b3. Mara watched the eastern gate until dawn.

Ledger 45 line 115: Neri carried the blue token past marker fadee3004a85. Mara watched the eastern gate until dawn.

Ledger 45 line 116: Neri carried the blue token past marker a6e73f99e338. Mara watched the eastern gate until dawn.

Ledger 45 line 117: Neri carried the blue token past marker ac76428566fe. Mara watched the eastern gate until dawn.

Ledger 45 line 118: Neri carried the blue token past marker 40ea75cc692a. Mara watched the eastern gate until dawn.

Ledger 45 line 119: Neri carried the blue token past marker 71eced45ae5e. Mara watched the eastern gate until dawn.

Ledger 45 line 120: Neri carried the blue token past marker b4e27d6d0a7d. Mara watched the eastern gate until dawn.

Ledger 45 line 121: Neri carried the blue token past marker c7489b37f42f. Mara watched the eastern gate until dawn.

Ledger 45 line 122: Neri carried the blue token past marker ddb5dd5c45fb. Mara watched the eastern gate until dawn.

Ledger 45 line 123: Neri carried the blue token past marker 4030181efc96. Mara watched the eastern gate until dawn.

Ledger 45 line 124: Neri carried the blue token past marker 4e3c780ea44d. Mara watched the eastern gate until dawn.

Ledger 45 line 125: Neri carried the blue token past marker 62abaa13fe96. Mara watched the eastern gate until dawn.

Ledger 45 line 126: Neri carried the blue token past marker bc587f28eaea. Mara watched the eastern gate until dawn.

Ledger 45 line 127: Neri carried the blue token past marker 1bb8c467790d. Mara watched the eastern gate until dawn.

Ledger 45 line 128: Neri carried the blue token past marker bc05a58c948c. Mara watched the eastern gate until dawn.

Ledger 45 line 129: Neri carried the blue token past marker c27f39335cd5. Mara watched the eastern gate until dawn.

Ledger 45 line 130: Neri carried the blue token past marker b4c1c1d50a11. Mara watched the eastern gate until dawn.

Ledger 45 line 131: Neri carried the blue token past marker b823458fea66. Mara watched the eastern gate until dawn.

Ledger 45 line 132: Neri carried the blue token past marker b42d3e754d5d. Mara watched the eastern gate until dawn.

Ledger 45 line 133: Neri carried the blue token past marker 11c5eca693d7. Mara watched the eastern gate until dawn.

Ledger 45 line 134: Neri carried the blue token past marker 920b9c93a56d. Mara watched the eastern gate until dawn.

Ledger 45 line 135: Neri carried the blue token past marker 10d04b3d0155. Mara watched the eastern gate until dawn.

Ledger 45 line 136: Neri carried the blue token past marker b7172c1131ce. Mara watched the eastern gate until dawn.

Ledger 45 line 137: Neri carried the blue token past marker d5170aa8b7b6. Mara watched the eastern gate until dawn.

Ledger 45 line 138: Neri carried the blue token past marker c472c509d49b. Mara watched the eastern gate until dawn.

Ledger 45 line 139: Neri carried the blue token past marker dc47dadab93a. Mara watched the eastern gate until dawn.

Ledger 45 line 140: Neri carried the blue token past marker 23066b476789. Mara watched the eastern gate until dawn.
