---
id: scene-0050
title: Recovery ledger 50
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.179061+00:00
updated_at: 2026-10-03T12:14:52.179061+00:00
---

Ledger 50 line 001: Neri carried the blue token past marker 9e8de226ca2b. Mara watched the eastern gate until dawn.

Ledger 50 line 002: Neri carried the blue token past marker 753c6b0bd502. Mara watched the eastern gate until dawn.

Ledger 50 line 003: Neri carried the blue token past marker e73ba6c01924. Mara watched the eastern gate until dawn.

Ledger 50 line 004: Neri carried the blue token past marker b3302340d2f9. Mara watched the eastern gate until dawn.

Ledger 50 line 005: Neri carried the blue token past marker cfd2dbc489a6. Mara watched the eastern gate until dawn.

Ledger 50 line 006: Neri carried the blue token past marker a6f6f1034030. Mara watched the eastern gate until dawn.

Ledger 50 line 007: Neri carried the blue token past marker 753649aef1d0. Mara watched the eastern gate until dawn.

Ledger 50 line 008: Neri carried the blue token past marker 93a12ac63c3e. Mara watched the eastern gate until dawn.

Ledger 50 line 009: Neri carried the blue token past marker 48c82443c5ce. Mara watched the eastern gate until dawn.

Ledger 50 line 010: Neri carried the blue token past marker 33ce16b051dc. Mara watched the eastern gate until dawn.

Ledger 50 line 011: Neri carried the blue token past marker 0495e6b93253. Mara watched the eastern gate until dawn.

Ledger 50 line 012: Neri carried the blue token past marker a2707e3b1f90. Mara watched the eastern gate until dawn.

Ledger 50 line 013: Neri carried the blue token past marker 2459abb6e45d. Mara watched the eastern gate until dawn.

Ledger 50 line 014: Neri carried the blue token past marker c666ac5dec31. Mara watched the eastern gate until dawn.

Ledger 50 line 015: Neri carried the blue token past marker d76d87845a95. Mara watched the eastern gate until dawn.

Ledger 50 line 016: Neri carried the blue token past marker 15dc986e832b. Mara watched the eastern gate until dawn.

Ledger 50 line 017: Neri carried the blue token past marker c90795808b64. Mara watched the eastern gate until dawn.

Ledger 50 line 018: Neri carried the blue token past marker 411ea992ee16. Mara watched the eastern gate until dawn.

Ledger 50 line 019: Neri carried the blue token past marker ed85e4caa5dc. Mara watched the eastern gate until dawn.

Ledger 50 line 020: Neri carried the blue token past marker 463d64b62b4e. Mara watched the eastern gate until dawn.

Ledger 50 line 021: Neri carried the blue token past marker da029464e622. Mara watched the eastern gate until dawn.

Ledger 50 line 022: Neri carried the blue token past marker f2d5c87ec144. Mara watched the eastern gate until dawn.

Ledger 50 line 023: Neri carried the blue token past marker 3bcd04f2274f. Mara watched the eastern gate until dawn.

Ledger 50 line 024: Neri carried the blue token past marker 0a3234cd7530. Mara watched the eastern gate until dawn.

Ledger 50 line 025: Neri carried the blue token past marker 833665d883d4. Mara watched the eastern gate until dawn.

Ledger 50 line 026: Neri carried the blue token past marker 24bae6a066d4. Mara watched the eastern gate until dawn.

Ledger 50 line 027: Neri carried the blue token past marker cd6879983438. Mara watched the eastern gate until dawn.

Ledger 50 line 028: Neri carried the blue token past marker ae8b9e1cac2f. Mara watched the eastern gate until dawn.

Ledger 50 line 029: Neri carried the blue token past marker 33e84a538034. Mara watched the eastern gate until dawn.

Ledger 50 line 030: Neri carried the blue token past marker f7c12e931ae1. Mara watched the eastern gate until dawn.

Ledger 50 line 031: Neri carried the blue token past marker 457ec60c8f61. Mara watched the eastern gate until dawn.

Ledger 50 line 032: Neri carried the blue token past marker e3d77e316181. Mara watched the eastern gate until dawn.

Ledger 50 line 033: Neri carried the blue token past marker 1dc0ae3409e6. Mara watched the eastern gate until dawn.

Ledger 50 line 034: Neri carried the blue token past marker ac1943ffdee3. Mara watched the eastern gate until dawn.

Ledger 50 line 035: Neri carried the blue token past marker 743aa428cdf0. Mara watched the eastern gate until dawn.

Ledger 50 line 036: Neri carried the blue token past marker cc2af0a3b13a. Mara watched the eastern gate until dawn.

Ledger 50 line 037: Neri carried the blue token past marker 081915578ca7. Mara watched the eastern gate until dawn.

Ledger 50 line 038: Neri carried the blue token past marker 6e15cb144dce. Mara watched the eastern gate until dawn.

Ledger 50 line 039: Neri carried the blue token past marker f2ed7976109f. Mara watched the eastern gate until dawn.

Ledger 50 line 040: Neri carried the blue token past marker 7e9a26039ff6. Mara watched the eastern gate until dawn.

Ledger 50 line 041: Neri carried the blue token past marker 581328e51224. Mara watched the eastern gate until dawn.

Ledger 50 line 042: Neri carried the blue token past marker c7e9fcd0b1bd. Mara watched the eastern gate until dawn.

Ledger 50 line 043: Neri carried the blue token past marker 5c0b723b259f. Mara watched the eastern gate until dawn.

Ledger 50 line 044: Neri carried the blue token past marker 8a39635bbcf6. Mara watched the eastern gate until dawn.

Ledger 50 line 045: Neri carried the blue token past marker 42bc7b466610. Mara watched the eastern gate until dawn.

Ledger 50 line 046: Neri carried the blue token past marker e06cbcc3ff9f. Mara watched the eastern gate until dawn.

Ledger 50 line 047: Neri carried the blue token past marker 40d920bb58c5. Mara watched the eastern gate until dawn.

Ledger 50 line 048: Neri carried the blue token past marker ab7f02ab57e8. Mara watched the eastern gate until dawn.

Ledger 50 line 049: Neri carried the blue token past marker 5a184e1fa420. Mara watched the eastern gate until dawn.

Ledger 50 line 050: Neri carried the blue token past marker 8aa7a51135eb. Mara watched the eastern gate until dawn.

Ledger 50 line 051: Neri carried the blue token past marker a61c136e2c17. Mara watched the eastern gate until dawn.

Ledger 50 line 052: Neri carried the blue token past marker 45ed0156800c. Mara watched the eastern gate until dawn.

Ledger 50 line 053: Neri carried the blue token past marker 1982078bdeae. Mara watched the eastern gate until dawn.

Ledger 50 line 054: Neri carried the blue token past marker 43053e5eb7a4. Mara watched the eastern gate until dawn.

Ledger 50 line 055: Neri carried the blue token past marker 1b98c4a8a47b. Mara watched the eastern gate until dawn.

Ledger 50 line 056: Neri carried the blue token past marker d681565b5784. Mara watched the eastern gate until dawn.

Ledger 50 line 057: Neri carried the blue token past marker eee5515715ad. Mara watched the eastern gate until dawn.

Ledger 50 line 058: Neri carried the blue token past marker 76635657e2eb. Mara watched the eastern gate until dawn.

Ledger 50 line 059: Neri carried the blue token past marker bcdf1c64d496. Mara watched the eastern gate until dawn.

Ledger 50 line 060: Neri carried the blue token past marker b74f95c9a33f. Mara watched the eastern gate until dawn.

Ledger 50 line 061: Neri carried the blue token past marker e914965f0f45. Mara watched the eastern gate until dawn.

Ledger 50 line 062: Neri carried the blue token past marker 3e5fccf76c25. Mara watched the eastern gate until dawn.

Ledger 50 line 063: Neri carried the blue token past marker 3a1abfea92d2. Mara watched the eastern gate until dawn.

Ledger 50 line 064: Neri carried the blue token past marker de73a3b1adbc. Mara watched the eastern gate until dawn.

Ledger 50 line 065: Neri carried the blue token past marker a08649b452da. Mara watched the eastern gate until dawn.

Ledger 50 line 066: Neri carried the blue token past marker 91453ddc805b. Mara watched the eastern gate until dawn.

Ledger 50 line 067: Neri carried the blue token past marker 813c3fc377e1. Mara watched the eastern gate until dawn.

Ledger 50 line 068: Neri carried the blue token past marker e2794baacf3f. Mara watched the eastern gate until dawn.

Ledger 50 line 069: Neri carried the blue token past marker cdb5ba5ff9d5. Mara watched the eastern gate until dawn.

Ledger 50 line 070: Neri carried the blue token past marker 09af4abbf6fb. Mara watched the eastern gate until dawn.

Ledger 50 line 071: Neri carried the blue token past marker b03b74dd6d1f. Mara watched the eastern gate until dawn.

Ledger 50 line 072: Neri carried the blue token past marker a38300ae178a. Mara watched the eastern gate until dawn.

Ledger 50 line 073: Neri carried the blue token past marker 28f75d1cea2a. Mara watched the eastern gate until dawn.

Ledger 50 line 074: Neri carried the blue token past marker 83836371fda0. Mara watched the eastern gate until dawn.

Ledger 50 line 075: Neri carried the blue token past marker 48a558b308eb. Mara watched the eastern gate until dawn.

Ledger 50 line 076: Neri carried the blue token past marker 1ced2a8aab8d. Mara watched the eastern gate until dawn.

Ledger 50 line 077: Neri carried the blue token past marker f61ce27b9ad6. Mara watched the eastern gate until dawn.

Ledger 50 line 078: Neri carried the blue token past marker 11c3bb0d8ef4. Mara watched the eastern gate until dawn.

Ledger 50 line 079: Neri carried the blue token past marker 010f320bb404. Mara watched the eastern gate until dawn.

Ledger 50 line 080: Neri carried the blue token past marker 0a20fbf651c6. Mara watched the eastern gate until dawn.

Ledger 50 line 081: Neri carried the blue token past marker 40983f970277. Mara watched the eastern gate until dawn.

Ledger 50 line 082: Neri carried the blue token past marker 6fe1a20db9ec. Mara watched the eastern gate until dawn.

Ledger 50 line 083: Neri carried the blue token past marker a3a3ddc0cba0. Mara watched the eastern gate until dawn.

Ledger 50 line 084: Neri carried the blue token past marker 8855dfbfb7a4. Mara watched the eastern gate until dawn.

Ledger 50 line 085: Neri carried the blue token past marker 909913381d65. Mara watched the eastern gate until dawn.

Ledger 50 line 086: Neri carried the blue token past marker 3e7c85804e66. Mara watched the eastern gate until dawn.

Ledger 50 line 087: Neri carried the blue token past marker 0fec6003c2f0. Mara watched the eastern gate until dawn.

Ledger 50 line 088: Neri carried the blue token past marker e691a7074b5c. Mara watched the eastern gate until dawn.

Ledger 50 line 089: Neri carried the blue token past marker df6bc26cb030. Mara watched the eastern gate until dawn.

Ledger 50 line 090: Neri carried the blue token past marker 8965632a5a9c. Mara watched the eastern gate until dawn.

Ledger 50 line 091: Neri carried the blue token past marker fd8fc5258c3e. Mara watched the eastern gate until dawn.

Ledger 50 line 092: Neri carried the blue token past marker e52f725485b9. Mara watched the eastern gate until dawn.

Ledger 50 line 093: Neri carried the blue token past marker 61de776b6fa3. Mara watched the eastern gate until dawn.

Ledger 50 line 094: Neri carried the blue token past marker c0a263f7b62f. Mara watched the eastern gate until dawn.

Ledger 50 line 095: Neri carried the blue token past marker b21036f22dd5. Mara watched the eastern gate until dawn.

Ledger 50 line 096: Neri carried the blue token past marker 6e953cdb2eb1. Mara watched the eastern gate until dawn.

Ledger 50 line 097: Neri carried the blue token past marker 260ae6dca3d8. Mara watched the eastern gate until dawn.

Ledger 50 line 098: Neri carried the blue token past marker 35a85163ec31. Mara watched the eastern gate until dawn.

Ledger 50 line 099: Neri carried the blue token past marker 05c1e6ed78e1. Mara watched the eastern gate until dawn.

Ledger 50 line 100: Neri carried the blue token past marker 0edc44375cff. Mara watched the eastern gate until dawn.

Ledger 50 line 101: Neri carried the blue token past marker 0978c6e1b069. Mara watched the eastern gate until dawn.

Ledger 50 line 102: Neri carried the blue token past marker b75a21519bb4. Mara watched the eastern gate until dawn.

Ledger 50 line 103: Neri carried the blue token past marker 03521ddfc8dd. Mara watched the eastern gate until dawn.

Ledger 50 line 104: Neri carried the blue token past marker 41c662c59008. Mara watched the eastern gate until dawn.

Ledger 50 line 105: Neri carried the blue token past marker eecdece00516. Mara watched the eastern gate until dawn.

Ledger 50 line 106: Neri carried the blue token past marker c88f62ea1dfb. Mara watched the eastern gate until dawn.

Ledger 50 line 107: Neri carried the blue token past marker aad0530c9d1d. Mara watched the eastern gate until dawn.

Ledger 50 line 108: Neri carried the blue token past marker 1e92144a4972. Mara watched the eastern gate until dawn.

Ledger 50 line 109: Neri carried the blue token past marker e31d7b46357d. Mara watched the eastern gate until dawn.

Ledger 50 line 110: Neri carried the blue token past marker 54c731d8bd02. Mara watched the eastern gate until dawn.

Ledger 50 line 111: Neri carried the blue token past marker 0893039a7233. Mara watched the eastern gate until dawn.

Ledger 50 line 112: Neri carried the blue token past marker b2284511ce51. Mara watched the eastern gate until dawn.

Ledger 50 line 113: Neri carried the blue token past marker 06c2fd8dc3e3. Mara watched the eastern gate until dawn.

Ledger 50 line 114: Neri carried the blue token past marker d33608f44c6e. Mara watched the eastern gate until dawn.

Ledger 50 line 115: Neri carried the blue token past marker cd14457835dc. Mara watched the eastern gate until dawn.

Ledger 50 line 116: Neri carried the blue token past marker a3c1221e7cca. Mara watched the eastern gate until dawn.

Ledger 50 line 117: Neri carried the blue token past marker c7db215246bf. Mara watched the eastern gate until dawn.

Ledger 50 line 118: Neri carried the blue token past marker 949cffdb0dff. Mara watched the eastern gate until dawn.

Ledger 50 line 119: Neri carried the blue token past marker 1aec0af748df. Mara watched the eastern gate until dawn.

Ledger 50 line 120: Neri carried the blue token past marker 69bfb1ce6aca. Mara watched the eastern gate until dawn.

Ledger 50 line 121: Neri carried the blue token past marker 6f8a903a4666. Mara watched the eastern gate until dawn.

Ledger 50 line 122: Neri carried the blue token past marker d0c137da6017. Mara watched the eastern gate until dawn.

Ledger 50 line 123: Neri carried the blue token past marker 3ae751d438d5. Mara watched the eastern gate until dawn.

Ledger 50 line 124: Neri carried the blue token past marker 588f5838ccae. Mara watched the eastern gate until dawn.

Ledger 50 line 125: Neri carried the blue token past marker d82a1e43bcc6. Mara watched the eastern gate until dawn.

Ledger 50 line 126: Neri carried the blue token past marker b5b140881452. Mara watched the eastern gate until dawn.

Ledger 50 line 127: Neri carried the blue token past marker 26a4cd5addd8. Mara watched the eastern gate until dawn.

Ledger 50 line 128: Neri carried the blue token past marker 4f21a007c0cd. Mara watched the eastern gate until dawn.

Ledger 50 line 129: Neri carried the blue token past marker 7798ae5361f5. Mara watched the eastern gate until dawn.

Ledger 50 line 130: Neri carried the blue token past marker b620fafd3fc6. Mara watched the eastern gate until dawn.

Ledger 50 line 131: Neri carried the blue token past marker 363e8b07a76b. Mara watched the eastern gate until dawn.

Ledger 50 line 132: Neri carried the blue token past marker 1620b0e80a82. Mara watched the eastern gate until dawn.

Ledger 50 line 133: Neri carried the blue token past marker fa75d325f527. Mara watched the eastern gate until dawn.

Ledger 50 line 134: Neri carried the blue token past marker 51213faad11c. Mara watched the eastern gate until dawn.

Ledger 50 line 135: Neri carried the blue token past marker ace9ee65250c. Mara watched the eastern gate until dawn.

Ledger 50 line 136: Neri carried the blue token past marker f9e0b83b6ea2. Mara watched the eastern gate until dawn.

Ledger 50 line 137: Neri carried the blue token past marker 39347a317df5. Mara watched the eastern gate until dawn.

Ledger 50 line 138: Neri carried the blue token past marker 21fce96287b2. Mara watched the eastern gate until dawn.

Ledger 50 line 139: Neri carried the blue token past marker 73a5d9883875. Mara watched the eastern gate until dawn.

Ledger 50 line 140: Neri carried the blue token past marker 8c969e746eb8. Mara watched the eastern gate until dawn.
