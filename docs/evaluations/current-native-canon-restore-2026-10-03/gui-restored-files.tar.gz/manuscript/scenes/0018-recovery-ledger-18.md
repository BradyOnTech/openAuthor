---
id: scene-0018
title: Recovery ledger 18
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.162021+00:00
updated_at: 2026-10-03T12:14:52.162021+00:00
---

Ledger 18 line 001: Neri carried the blue token past marker 62779b3e7857. Mara watched the eastern gate until dawn.

Ledger 18 line 002: Neri carried the blue token past marker 2cdc309750c0. Mara watched the eastern gate until dawn.

Ledger 18 line 003: Neri carried the blue token past marker 38abca692ce3. Mara watched the eastern gate until dawn.

Ledger 18 line 004: Neri carried the blue token past marker e0cb6cccdefb. Mara watched the eastern gate until dawn.

Ledger 18 line 005: Neri carried the blue token past marker 3f99d8531692. Mara watched the eastern gate until dawn.

Ledger 18 line 006: Neri carried the blue token past marker 5f1e120c557f. Mara watched the eastern gate until dawn.

Ledger 18 line 007: Neri carried the blue token past marker 28e16a4fdb9e. Mara watched the eastern gate until dawn.

Ledger 18 line 008: Neri carried the blue token past marker 6dc416c5dcfc. Mara watched the eastern gate until dawn.

Ledger 18 line 009: Neri carried the blue token past marker 6055f96f8b7f. Mara watched the eastern gate until dawn.

Ledger 18 line 010: Neri carried the blue token past marker 0a70329c68d8. Mara watched the eastern gate until dawn.

Ledger 18 line 011: Neri carried the blue token past marker 5dcf209d6158. Mara watched the eastern gate until dawn.

Ledger 18 line 012: Neri carried the blue token past marker 5e5f28097b67. Mara watched the eastern gate until dawn.

Ledger 18 line 013: Neri carried the blue token past marker 43ed65d479e2. Mara watched the eastern gate until dawn.

Ledger 18 line 014: Neri carried the blue token past marker 963252432c3e. Mara watched the eastern gate until dawn.

Ledger 18 line 015: Neri carried the blue token past marker 526ad5aa2f95. Mara watched the eastern gate until dawn.

Ledger 18 line 016: Neri carried the blue token past marker be24d43edcbd. Mara watched the eastern gate until dawn.

Ledger 18 line 017: Neri carried the blue token past marker 9ac0afb3a875. Mara watched the eastern gate until dawn.

Ledger 18 line 018: Neri carried the blue token past marker f1a153d78767. Mara watched the eastern gate until dawn.

Ledger 18 line 019: Neri carried the blue token past marker 374b00f61c66. Mara watched the eastern gate until dawn.

Ledger 18 line 020: Neri carried the blue token past marker 792385d27127. Mara watched the eastern gate until dawn.

Ledger 18 line 021: Neri carried the blue token past marker 08998d90f8e9. Mara watched the eastern gate until dawn.

Ledger 18 line 022: Neri carried the blue token past marker ce87a0cfb605. Mara watched the eastern gate until dawn.

Ledger 18 line 023: Neri carried the blue token past marker 26f58ca5c966. Mara watched the eastern gate until dawn.

Ledger 18 line 024: Neri carried the blue token past marker df7c45064bf9. Mara watched the eastern gate until dawn.

Ledger 18 line 025: Neri carried the blue token past marker 2063d63ddf4d. Mara watched the eastern gate until dawn.

Ledger 18 line 026: Neri carried the blue token past marker c850b290fee1. Mara watched the eastern gate until dawn.

Ledger 18 line 027: Neri carried the blue token past marker d2fb2393eb52. Mara watched the eastern gate until dawn.

Ledger 18 line 028: Neri carried the blue token past marker d62ac2b58b0a. Mara watched the eastern gate until dawn.

Ledger 18 line 029: Neri carried the blue token past marker 26257df2fb13. Mara watched the eastern gate until dawn.

Ledger 18 line 030: Neri carried the blue token past marker c08cec7026de. Mara watched the eastern gate until dawn.

Ledger 18 line 031: Neri carried the blue token past marker 62f1975c1174. Mara watched the eastern gate until dawn.

Ledger 18 line 032: Neri carried the blue token past marker c79081292de4. Mara watched the eastern gate until dawn.

Ledger 18 line 033: Neri carried the blue token past marker ba51689e9110. Mara watched the eastern gate until dawn.

Ledger 18 line 034: Neri carried the blue token past marker 4b87133d4706. Mara watched the eastern gate until dawn.

Ledger 18 line 035: Neri carried the blue token past marker 7fcbf7557e95. Mara watched the eastern gate until dawn.

Ledger 18 line 036: Neri carried the blue token past marker d68f489251f6. Mara watched the eastern gate until dawn.

Ledger 18 line 037: Neri carried the blue token past marker ea3178378829. Mara watched the eastern gate until dawn.

Ledger 18 line 038: Neri carried the blue token past marker 9f9ff6bc9a5b. Mara watched the eastern gate until dawn.

Ledger 18 line 039: Neri carried the blue token past marker d7790c98c521. Mara watched the eastern gate until dawn.

Ledger 18 line 040: Neri carried the blue token past marker ed5bc7c71331. Mara watched the eastern gate until dawn.

Ledger 18 line 041: Neri carried the blue token past marker cf2fe40023c8. Mara watched the eastern gate until dawn.

Ledger 18 line 042: Neri carried the blue token past marker 5c33bdb2e048. Mara watched the eastern gate until dawn.

Ledger 18 line 043: Neri carried the blue token past marker 8b65a7af8558. Mara watched the eastern gate until dawn.

Ledger 18 line 044: Neri carried the blue token past marker 565c6133c452. Mara watched the eastern gate until dawn.

Ledger 18 line 045: Neri carried the blue token past marker a9cf004d3e96. Mara watched the eastern gate until dawn.

Ledger 18 line 046: Neri carried the blue token past marker 2f182be9a001. Mara watched the eastern gate until dawn.

Ledger 18 line 047: Neri carried the blue token past marker 20b1d1c1484e. Mara watched the eastern gate until dawn.

Ledger 18 line 048: Neri carried the blue token past marker 984c179d35a0. Mara watched the eastern gate until dawn.

Ledger 18 line 049: Neri carried the blue token past marker ac7c67f3718d. Mara watched the eastern gate until dawn.

Ledger 18 line 050: Neri carried the blue token past marker 34dd208ea883. Mara watched the eastern gate until dawn.

Ledger 18 line 051: Neri carried the blue token past marker 4123ca7ce456. Mara watched the eastern gate until dawn.

Ledger 18 line 052: Neri carried the blue token past marker e9d6c304aada. Mara watched the eastern gate until dawn.

Ledger 18 line 053: Neri carried the blue token past marker 5a85237a9356. Mara watched the eastern gate until dawn.

Ledger 18 line 054: Neri carried the blue token past marker 1b3413032026. Mara watched the eastern gate until dawn.

Ledger 18 line 055: Neri carried the blue token past marker 0207f51f5522. Mara watched the eastern gate until dawn.

Ledger 18 line 056: Neri carried the blue token past marker 01ed5bce76c1. Mara watched the eastern gate until dawn.

Ledger 18 line 057: Neri carried the blue token past marker 5d4941a7ce00. Mara watched the eastern gate until dawn.

Ledger 18 line 058: Neri carried the blue token past marker 1b38616d4c0c. Mara watched the eastern gate until dawn.

Ledger 18 line 059: Neri carried the blue token past marker c309ccac9cb6. Mara watched the eastern gate until dawn.

Ledger 18 line 060: Neri carried the blue token past marker 5d2ed7c2608b. Mara watched the eastern gate until dawn.

Ledger 18 line 061: Neri carried the blue token past marker ae7f69dd27b2. Mara watched the eastern gate until dawn.

Ledger 18 line 062: Neri carried the blue token past marker 38a43051329b. Mara watched the eastern gate until dawn.

Ledger 18 line 063: Neri carried the blue token past marker 5cb40f388c4a. Mara watched the eastern gate until dawn.

Ledger 18 line 064: Neri carried the blue token past marker e31534bb1ea7. Mara watched the eastern gate until dawn.

Ledger 18 line 065: Neri carried the blue token past marker 777bc5c66e8d. Mara watched the eastern gate until dawn.

Ledger 18 line 066: Neri carried the blue token past marker 8553874e6cdb. Mara watched the eastern gate until dawn.

Ledger 18 line 067: Neri carried the blue token past marker b80344b93512. Mara watched the eastern gate until dawn.

Ledger 18 line 068: Neri carried the blue token past marker 65c79c837a9b. Mara watched the eastern gate until dawn.

Ledger 18 line 069: Neri carried the blue token past marker 9dec91839b58. Mara watched the eastern gate until dawn.

Ledger 18 line 070: Neri carried the blue token past marker b40c8de7f593. Mara watched the eastern gate until dawn.

Ledger 18 line 071: Neri carried the blue token past marker 1191cb95e7c6. Mara watched the eastern gate until dawn.

Ledger 18 line 072: Neri carried the blue token past marker f9c1a260b299. Mara watched the eastern gate until dawn.

Ledger 18 line 073: Neri carried the blue token past marker 43926db156b5. Mara watched the eastern gate until dawn.

Ledger 18 line 074: Neri carried the blue token past marker 132543d0653d. Mara watched the eastern gate until dawn.

Ledger 18 line 075: Neri carried the blue token past marker 84f4ec86ec8b. Mara watched the eastern gate until dawn.

Ledger 18 line 076: Neri carried the blue token past marker dd85987de2db. Mara watched the eastern gate until dawn.

Ledger 18 line 077: Neri carried the blue token past marker 431d5c6c0a3a. Mara watched the eastern gate until dawn.

Ledger 18 line 078: Neri carried the blue token past marker 48953d49ab9b. Mara watched the eastern gate until dawn.

Ledger 18 line 079: Neri carried the blue token past marker fdfdbbb0dafb. Mara watched the eastern gate until dawn.

Ledger 18 line 080: Neri carried the blue token past marker 6180ea49f52e. Mara watched the eastern gate until dawn.

Ledger 18 line 081: Neri carried the blue token past marker a3f735e6dd3b. Mara watched the eastern gate until dawn.

Ledger 18 line 082: Neri carried the blue token past marker 42e4844632de. Mara watched the eastern gate until dawn.

Ledger 18 line 083: Neri carried the blue token past marker 57a3208f838e. Mara watched the eastern gate until dawn.

Ledger 18 line 084: Neri carried the blue token past marker 247834892c4d. Mara watched the eastern gate until dawn.

Ledger 18 line 085: Neri carried the blue token past marker c8edf4c23f2d. Mara watched the eastern gate until dawn.

Ledger 18 line 086: Neri carried the blue token past marker 7536e5129a3b. Mara watched the eastern gate until dawn.

Ledger 18 line 087: Neri carried the blue token past marker 8e3a6397a76f. Mara watched the eastern gate until dawn.

Ledger 18 line 088: Neri carried the blue token past marker 7388b80a049c. Mara watched the eastern gate until dawn.

Ledger 18 line 089: Neri carried the blue token past marker dbec06127aff. Mara watched the eastern gate until dawn.

Ledger 18 line 090: Neri carried the blue token past marker e3be01d65bbc. Mara watched the eastern gate until dawn.

Ledger 18 line 091: Neri carried the blue token past marker 3cce5409c22a. Mara watched the eastern gate until dawn.

Ledger 18 line 092: Neri carried the blue token past marker 553ba56cb756. Mara watched the eastern gate until dawn.

Ledger 18 line 093: Neri carried the blue token past marker 7c34a2b730bf. Mara watched the eastern gate until dawn.

Ledger 18 line 094: Neri carried the blue token past marker 02af9db77c75. Mara watched the eastern gate until dawn.

Ledger 18 line 095: Neri carried the blue token past marker ee782db8aecc. Mara watched the eastern gate until dawn.

Ledger 18 line 096: Neri carried the blue token past marker d7d4c6108928. Mara watched the eastern gate until dawn.

Ledger 18 line 097: Neri carried the blue token past marker e63d215220c8. Mara watched the eastern gate until dawn.

Ledger 18 line 098: Neri carried the blue token past marker 4e5223c82fdf. Mara watched the eastern gate until dawn.

Ledger 18 line 099: Neri carried the blue token past marker 0c4f43b7996d. Mara watched the eastern gate until dawn.

Ledger 18 line 100: Neri carried the blue token past marker d958f064a1d9. Mara watched the eastern gate until dawn.

Ledger 18 line 101: Neri carried the blue token past marker d68f170d5fd5. Mara watched the eastern gate until dawn.

Ledger 18 line 102: Neri carried the blue token past marker afd2bf81b0d7. Mara watched the eastern gate until dawn.

Ledger 18 line 103: Neri carried the blue token past marker f4c8fab49c86. Mara watched the eastern gate until dawn.

Ledger 18 line 104: Neri carried the blue token past marker a8a2a723446e. Mara watched the eastern gate until dawn.

Ledger 18 line 105: Neri carried the blue token past marker 2216212f446b. Mara watched the eastern gate until dawn.

Ledger 18 line 106: Neri carried the blue token past marker ace49314e127. Mara watched the eastern gate until dawn.

Ledger 18 line 107: Neri carried the blue token past marker ff566e446268. Mara watched the eastern gate until dawn.

Ledger 18 line 108: Neri carried the blue token past marker 57f4721e2186. Mara watched the eastern gate until dawn.

Ledger 18 line 109: Neri carried the blue token past marker f00b05513c91. Mara watched the eastern gate until dawn.

Ledger 18 line 110: Neri carried the blue token past marker 8a9e0418ee6a. Mara watched the eastern gate until dawn.

Ledger 18 line 111: Neri carried the blue token past marker ec4a9b395d3e. Mara watched the eastern gate until dawn.

Ledger 18 line 112: Neri carried the blue token past marker 33f2593a0f20. Mara watched the eastern gate until dawn.

Ledger 18 line 113: Neri carried the blue token past marker 1b73c4549788. Mara watched the eastern gate until dawn.

Ledger 18 line 114: Neri carried the blue token past marker 5fc5c1abea2e. Mara watched the eastern gate until dawn.

Ledger 18 line 115: Neri carried the blue token past marker 84444b4349fb. Mara watched the eastern gate until dawn.

Ledger 18 line 116: Neri carried the blue token past marker 464842a1e0f5. Mara watched the eastern gate until dawn.

Ledger 18 line 117: Neri carried the blue token past marker 09b8f8529316. Mara watched the eastern gate until dawn.

Ledger 18 line 118: Neri carried the blue token past marker d5c3d8f70fb5. Mara watched the eastern gate until dawn.

Ledger 18 line 119: Neri carried the blue token past marker ecde5fe137d6. Mara watched the eastern gate until dawn.

Ledger 18 line 120: Neri carried the blue token past marker a7815c36b006. Mara watched the eastern gate until dawn.

Ledger 18 line 121: Neri carried the blue token past marker 9d2f17f929fa. Mara watched the eastern gate until dawn.

Ledger 18 line 122: Neri carried the blue token past marker 0abbd3b20d02. Mara watched the eastern gate until dawn.

Ledger 18 line 123: Neri carried the blue token past marker 453f04379fb6. Mara watched the eastern gate until dawn.

Ledger 18 line 124: Neri carried the blue token past marker 0668744e237b. Mara watched the eastern gate until dawn.

Ledger 18 line 125: Neri carried the blue token past marker 2f69acf2d538. Mara watched the eastern gate until dawn.

Ledger 18 line 126: Neri carried the blue token past marker acb901d5919d. Mara watched the eastern gate until dawn.

Ledger 18 line 127: Neri carried the blue token past marker e04360e3c0d0. Mara watched the eastern gate until dawn.

Ledger 18 line 128: Neri carried the blue token past marker b13ee2a93b82. Mara watched the eastern gate until dawn.

Ledger 18 line 129: Neri carried the blue token past marker 707a8319beb4. Mara watched the eastern gate until dawn.

Ledger 18 line 130: Neri carried the blue token past marker 5b86be22621a. Mara watched the eastern gate until dawn.

Ledger 18 line 131: Neri carried the blue token past marker 19e1b38422a7. Mara watched the eastern gate until dawn.

Ledger 18 line 132: Neri carried the blue token past marker 9ab838ee0de2. Mara watched the eastern gate until dawn.

Ledger 18 line 133: Neri carried the blue token past marker 25aa6b2c7445. Mara watched the eastern gate until dawn.

Ledger 18 line 134: Neri carried the blue token past marker 935211f93417. Mara watched the eastern gate until dawn.

Ledger 18 line 135: Neri carried the blue token past marker 9226ce952f6a. Mara watched the eastern gate until dawn.

Ledger 18 line 136: Neri carried the blue token past marker cd262a508070. Mara watched the eastern gate until dawn.

Ledger 18 line 137: Neri carried the blue token past marker bdc3735d78d5. Mara watched the eastern gate until dawn.

Ledger 18 line 138: Neri carried the blue token past marker 5c6f8b83923c. Mara watched the eastern gate until dawn.

Ledger 18 line 139: Neri carried the blue token past marker cf7cb904798e. Mara watched the eastern gate until dawn.

Ledger 18 line 140: Neri carried the blue token past marker 9d0de03cd206. Mara watched the eastern gate until dawn.
