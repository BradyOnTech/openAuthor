---
id: scene-0023
title: Recovery ledger 23
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.164639+00:00
updated_at: 2026-10-03T12:14:52.164639+00:00
---

Ledger 23 line 001: Neri carried the blue token past marker 22fdf038024e. Mara watched the eastern gate until dawn.

Ledger 23 line 002: Neri carried the blue token past marker d065080a758b. Mara watched the eastern gate until dawn.

Ledger 23 line 003: Neri carried the blue token past marker 90550879ed0f. Mara watched the eastern gate until dawn.

Ledger 23 line 004: Neri carried the blue token past marker 26d4c61dd3e3. Mara watched the eastern gate until dawn.

Ledger 23 line 005: Neri carried the blue token past marker 4e07b43d3ad2. Mara watched the eastern gate until dawn.

Ledger 23 line 006: Neri carried the blue token past marker 95f3d9c1cf4f. Mara watched the eastern gate until dawn.

Ledger 23 line 007: Neri carried the blue token past marker 1bfc4e6e7a47. Mara watched the eastern gate until dawn.

Ledger 23 line 008: Neri carried the blue token past marker 98cef89c977b. Mara watched the eastern gate until dawn.

Ledger 23 line 009: Neri carried the blue token past marker eb6defb748ea. Mara watched the eastern gate until dawn.

Ledger 23 line 010: Neri carried the blue token past marker c59097fa4f6d. Mara watched the eastern gate until dawn.

Ledger 23 line 011: Neri carried the blue token past marker 3dcb2bc8d41f. Mara watched the eastern gate until dawn.

Ledger 23 line 012: Neri carried the blue token past marker ea3da98ded6f. Mara watched the eastern gate until dawn.

Ledger 23 line 013: Neri carried the blue token past marker e6e8c3cb7119. Mara watched the eastern gate until dawn.

Ledger 23 line 014: Neri carried the blue token past marker 7ef54c35ba7a. Mara watched the eastern gate until dawn.

Ledger 23 line 015: Neri carried the blue token past marker 26448ad0f0c9. Mara watched the eastern gate until dawn.

Ledger 23 line 016: Neri carried the blue token past marker 0c688f0163c3. Mara watched the eastern gate until dawn.

Ledger 23 line 017: Neri carried the blue token past marker c1a60308a930. Mara watched the eastern gate until dawn.

Ledger 23 line 018: Neri carried the blue token past marker 1f2dcfac2941. Mara watched the eastern gate until dawn.

Ledger 23 line 019: Neri carried the blue token past marker ad9ba1757f39. Mara watched the eastern gate until dawn.

Ledger 23 line 020: Neri carried the blue token past marker a66a0f01c34d. Mara watched the eastern gate until dawn.

Ledger 23 line 021: Neri carried the blue token past marker f77ce7073689. Mara watched the eastern gate until dawn.

Ledger 23 line 022: Neri carried the blue token past marker c5795082f706. Mara watched the eastern gate until dawn.

Ledger 23 line 023: Neri carried the blue token past marker 9aa2166139d4. Mara watched the eastern gate until dawn.

Ledger 23 line 024: Neri carried the blue token past marker f7e4eb361cfb. Mara watched the eastern gate until dawn.

Ledger 23 line 025: Neri carried the blue token past marker 9e8445608a8d. Mara watched the eastern gate until dawn.

Ledger 23 line 026: Neri carried the blue token past marker 04568d496690. Mara watched the eastern gate until dawn.

Ledger 23 line 027: Neri carried the blue token past marker 7ffb28e408c7. Mara watched the eastern gate until dawn.

Ledger 23 line 028: Neri carried the blue token past marker 7db48229bd4f. Mara watched the eastern gate until dawn.

Ledger 23 line 029: Neri carried the blue token past marker 938fb2a7ff8c. Mara watched the eastern gate until dawn.

Ledger 23 line 030: Neri carried the blue token past marker 45b6f07cbb74. Mara watched the eastern gate until dawn.

Ledger 23 line 031: Neri carried the blue token past marker 785031270584. Mara watched the eastern gate until dawn.

Ledger 23 line 032: Neri carried the blue token past marker 47382d8beea6. Mara watched the eastern gate until dawn.

Ledger 23 line 033: Neri carried the blue token past marker e6a574eb88d7. Mara watched the eastern gate until dawn.

Ledger 23 line 034: Neri carried the blue token past marker f3702be16ad2. Mara watched the eastern gate until dawn.

Ledger 23 line 035: Neri carried the blue token past marker 80a731994a18. Mara watched the eastern gate until dawn.

Ledger 23 line 036: Neri carried the blue token past marker ac638ddba1fd. Mara watched the eastern gate until dawn.

Ledger 23 line 037: Neri carried the blue token past marker ca00aaa1b176. Mara watched the eastern gate until dawn.

Ledger 23 line 038: Neri carried the blue token past marker 5ac6ab0f6811. Mara watched the eastern gate until dawn.

Ledger 23 line 039: Neri carried the blue token past marker 8423093b53f0. Mara watched the eastern gate until dawn.

Ledger 23 line 040: Neri carried the blue token past marker d3d4d725f46d. Mara watched the eastern gate until dawn.

Ledger 23 line 041: Neri carried the blue token past marker 781449984cb3. Mara watched the eastern gate until dawn.

Ledger 23 line 042: Neri carried the blue token past marker 1e4074f4d357. Mara watched the eastern gate until dawn.

Ledger 23 line 043: Neri carried the blue token past marker 334670bda748. Mara watched the eastern gate until dawn.

Ledger 23 line 044: Neri carried the blue token past marker 4ec11eb25bf3. Mara watched the eastern gate until dawn.

Ledger 23 line 045: Neri carried the blue token past marker 93a90af42138. Mara watched the eastern gate until dawn.

Ledger 23 line 046: Neri carried the blue token past marker 42e42ad8894c. Mara watched the eastern gate until dawn.

Ledger 23 line 047: Neri carried the blue token past marker e655363ca237. Mara watched the eastern gate until dawn.

Ledger 23 line 048: Neri carried the blue token past marker 11bf6873b01c. Mara watched the eastern gate until dawn.

Ledger 23 line 049: Neri carried the blue token past marker 3740109f0c86. Mara watched the eastern gate until dawn.

Ledger 23 line 050: Neri carried the blue token past marker 403388bfd823. Mara watched the eastern gate until dawn.

Ledger 23 line 051: Neri carried the blue token past marker d7587b2a8aa0. Mara watched the eastern gate until dawn.

Ledger 23 line 052: Neri carried the blue token past marker c8b3d9f191e5. Mara watched the eastern gate until dawn.

Ledger 23 line 053: Neri carried the blue token past marker 63b573b56c33. Mara watched the eastern gate until dawn.

Ledger 23 line 054: Neri carried the blue token past marker e9a6b4075e6d. Mara watched the eastern gate until dawn.

Ledger 23 line 055: Neri carried the blue token past marker 505d52e2a9e7. Mara watched the eastern gate until dawn.

Ledger 23 line 056: Neri carried the blue token past marker c4644ddd04c0. Mara watched the eastern gate until dawn.

Ledger 23 line 057: Neri carried the blue token past marker 9f85d096354c. Mara watched the eastern gate until dawn.

Ledger 23 line 058: Neri carried the blue token past marker 3fd33a1e605d. Mara watched the eastern gate until dawn.

Ledger 23 line 059: Neri carried the blue token past marker d3113d824efe. Mara watched the eastern gate until dawn.

Ledger 23 line 060: Neri carried the blue token past marker 1277455232bf. Mara watched the eastern gate until dawn.

Ledger 23 line 061: Neri carried the blue token past marker a33a5bacf439. Mara watched the eastern gate until dawn.

Ledger 23 line 062: Neri carried the blue token past marker 9b7673af82c5. Mara watched the eastern gate until dawn.

Ledger 23 line 063: Neri carried the blue token past marker bd3d491a1dfd. Mara watched the eastern gate until dawn.

Ledger 23 line 064: Neri carried the blue token past marker 2fb1f2363abc. Mara watched the eastern gate until dawn.

Ledger 23 line 065: Neri carried the blue token past marker 2bf717f99497. Mara watched the eastern gate until dawn.

Ledger 23 line 066: Neri carried the blue token past marker 10e028a3405f. Mara watched the eastern gate until dawn.

Ledger 23 line 067: Neri carried the blue token past marker 65506f5c5fcc. Mara watched the eastern gate until dawn.

Ledger 23 line 068: Neri carried the blue token past marker 88ef84eab5f7. Mara watched the eastern gate until dawn.

Ledger 23 line 069: Neri carried the blue token past marker dacdf188207d. Mara watched the eastern gate until dawn.

Ledger 23 line 070: Neri carried the blue token past marker ec0e23532493. Mara watched the eastern gate until dawn.

Ledger 23 line 071: Neri carried the blue token past marker bcc959eb18a6. Mara watched the eastern gate until dawn.

Ledger 23 line 072: Neri carried the blue token past marker 10a3d8daf611. Mara watched the eastern gate until dawn.

Ledger 23 line 073: Neri carried the blue token past marker acd0462a9d67. Mara watched the eastern gate until dawn.

Ledger 23 line 074: Neri carried the blue token past marker 504035705344. Mara watched the eastern gate until dawn.

Ledger 23 line 075: Neri carried the blue token past marker 4989490c9027. Mara watched the eastern gate until dawn.

Ledger 23 line 076: Neri carried the blue token past marker 0deda2fd84e9. Mara watched the eastern gate until dawn.

Ledger 23 line 077: Neri carried the blue token past marker 69d4d6b78d06. Mara watched the eastern gate until dawn.

Ledger 23 line 078: Neri carried the blue token past marker adf2728a9c1a. Mara watched the eastern gate until dawn.

Ledger 23 line 079: Neri carried the blue token past marker e7298706a243. Mara watched the eastern gate until dawn.

Ledger 23 line 080: Neri carried the blue token past marker a4a99cfa5c17. Mara watched the eastern gate until dawn.

Ledger 23 line 081: Neri carried the blue token past marker d790c613d35c. Mara watched the eastern gate until dawn.

Ledger 23 line 082: Neri carried the blue token past marker 7c09ae41c224. Mara watched the eastern gate until dawn.

Ledger 23 line 083: Neri carried the blue token past marker 6cb5ef7bcd74. Mara watched the eastern gate until dawn.

Ledger 23 line 084: Neri carried the blue token past marker 9d9aed051255. Mara watched the eastern gate until dawn.

Ledger 23 line 085: Neri carried the blue token past marker 4c70f493aa02. Mara watched the eastern gate until dawn.

Ledger 23 line 086: Neri carried the blue token past marker 47e30d0a4362. Mara watched the eastern gate until dawn.

Ledger 23 line 087: Neri carried the blue token past marker de9e78774d1d. Mara watched the eastern gate until dawn.

Ledger 23 line 088: Neri carried the blue token past marker 247e4ef4a19c. Mara watched the eastern gate until dawn.

Ledger 23 line 089: Neri carried the blue token past marker e526cbbeb288. Mara watched the eastern gate until dawn.

Ledger 23 line 090: Neri carried the blue token past marker da5a45cac869. Mara watched the eastern gate until dawn.

Ledger 23 line 091: Neri carried the blue token past marker 8aaaeb8cb05b. Mara watched the eastern gate until dawn.

Ledger 23 line 092: Neri carried the blue token past marker 77d699071891. Mara watched the eastern gate until dawn.

Ledger 23 line 093: Neri carried the blue token past marker 1f443b60d629. Mara watched the eastern gate until dawn.

Ledger 23 line 094: Neri carried the blue token past marker b59395d74a1c. Mara watched the eastern gate until dawn.

Ledger 23 line 095: Neri carried the blue token past marker 3971ebf37009. Mara watched the eastern gate until dawn.

Ledger 23 line 096: Neri carried the blue token past marker bebf0f62afaa. Mara watched the eastern gate until dawn.

Ledger 23 line 097: Neri carried the blue token past marker e847c439b182. Mara watched the eastern gate until dawn.

Ledger 23 line 098: Neri carried the blue token past marker 64a3430e59f4. Mara watched the eastern gate until dawn.

Ledger 23 line 099: Neri carried the blue token past marker ae9949dc6d7b. Mara watched the eastern gate until dawn.

Ledger 23 line 100: Neri carried the blue token past marker 7ce4b519f7c8. Mara watched the eastern gate until dawn.

Ledger 23 line 101: Neri carried the blue token past marker d7c4784b4ce8. Mara watched the eastern gate until dawn.

Ledger 23 line 102: Neri carried the blue token past marker 069b3e398f70. Mara watched the eastern gate until dawn.

Ledger 23 line 103: Neri carried the blue token past marker aea5626dd034. Mara watched the eastern gate until dawn.

Ledger 23 line 104: Neri carried the blue token past marker 0aa2af34ab45. Mara watched the eastern gate until dawn.

Ledger 23 line 105: Neri carried the blue token past marker 3421e23fd9b9. Mara watched the eastern gate until dawn.

Ledger 23 line 106: Neri carried the blue token past marker 3c46baf5b341. Mara watched the eastern gate until dawn.

Ledger 23 line 107: Neri carried the blue token past marker 8a822bfbe97e. Mara watched the eastern gate until dawn.

Ledger 23 line 108: Neri carried the blue token past marker 1b0f92364a90. Mara watched the eastern gate until dawn.

Ledger 23 line 109: Neri carried the blue token past marker ee3736932913. Mara watched the eastern gate until dawn.

Ledger 23 line 110: Neri carried the blue token past marker ed0042f51fd2. Mara watched the eastern gate until dawn.

Ledger 23 line 111: Neri carried the blue token past marker 435ede5de328. Mara watched the eastern gate until dawn.

Ledger 23 line 112: Neri carried the blue token past marker d28e2d4890af. Mara watched the eastern gate until dawn.

Ledger 23 line 113: Neri carried the blue token past marker 59349929b721. Mara watched the eastern gate until dawn.

Ledger 23 line 114: Neri carried the blue token past marker cebfc87b0723. Mara watched the eastern gate until dawn.

Ledger 23 line 115: Neri carried the blue token past marker d94485b69cac. Mara watched the eastern gate until dawn.

Ledger 23 line 116: Neri carried the blue token past marker 09d15ae23390. Mara watched the eastern gate until dawn.

Ledger 23 line 117: Neri carried the blue token past marker f71fb986c89d. Mara watched the eastern gate until dawn.

Ledger 23 line 118: Neri carried the blue token past marker 321cf3cb547e. Mara watched the eastern gate until dawn.

Ledger 23 line 119: Neri carried the blue token past marker ba1ba71bd4af. Mara watched the eastern gate until dawn.

Ledger 23 line 120: Neri carried the blue token past marker 8a1f0099c76c. Mara watched the eastern gate until dawn.

Ledger 23 line 121: Neri carried the blue token past marker ac7ffb0bc0c1. Mara watched the eastern gate until dawn.

Ledger 23 line 122: Neri carried the blue token past marker 3e4ac9ec2d12. Mara watched the eastern gate until dawn.

Ledger 23 line 123: Neri carried the blue token past marker 4ef3e279b73b. Mara watched the eastern gate until dawn.

Ledger 23 line 124: Neri carried the blue token past marker 500a14ff3e22. Mara watched the eastern gate until dawn.

Ledger 23 line 125: Neri carried the blue token past marker 1edb08373ef8. Mara watched the eastern gate until dawn.

Ledger 23 line 126: Neri carried the blue token past marker 830ab22da0a0. Mara watched the eastern gate until dawn.

Ledger 23 line 127: Neri carried the blue token past marker 1f5c750b1db3. Mara watched the eastern gate until dawn.

Ledger 23 line 128: Neri carried the blue token past marker 497d3e6f6f67. Mara watched the eastern gate until dawn.

Ledger 23 line 129: Neri carried the blue token past marker f047fec5807a. Mara watched the eastern gate until dawn.

Ledger 23 line 130: Neri carried the blue token past marker 9d2498d39c61. Mara watched the eastern gate until dawn.

Ledger 23 line 131: Neri carried the blue token past marker cfd2ba3514a8. Mara watched the eastern gate until dawn.

Ledger 23 line 132: Neri carried the blue token past marker fcb04de00e72. Mara watched the eastern gate until dawn.

Ledger 23 line 133: Neri carried the blue token past marker cdd853e52c7e. Mara watched the eastern gate until dawn.

Ledger 23 line 134: Neri carried the blue token past marker 0061dbcdcbf2. Mara watched the eastern gate until dawn.

Ledger 23 line 135: Neri carried the blue token past marker 5f23a8110d94. Mara watched the eastern gate until dawn.

Ledger 23 line 136: Neri carried the blue token past marker c8a063614475. Mara watched the eastern gate until dawn.

Ledger 23 line 137: Neri carried the blue token past marker c6d60794eba2. Mara watched the eastern gate until dawn.

Ledger 23 line 138: Neri carried the blue token past marker 2cc214c7cb4f. Mara watched the eastern gate until dawn.

Ledger 23 line 139: Neri carried the blue token past marker 5c5b4cd99783. Mara watched the eastern gate until dawn.

Ledger 23 line 140: Neri carried the blue token past marker 639780c0448f. Mara watched the eastern gate until dawn.
