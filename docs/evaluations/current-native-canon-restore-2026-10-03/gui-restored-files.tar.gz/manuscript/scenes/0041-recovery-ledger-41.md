---
id: scene-0041
title: Recovery ledger 41
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.174598+00:00
updated_at: 2026-10-03T12:14:52.174598+00:00
---

Ledger 41 line 001: Neri carried the blue token past marker 2eaca12b003d. Mara watched the eastern gate until dawn.

Ledger 41 line 002: Neri carried the blue token past marker b0d414457b22. Mara watched the eastern gate until dawn.

Ledger 41 line 003: Neri carried the blue token past marker fb618dac4bca. Mara watched the eastern gate until dawn.

Ledger 41 line 004: Neri carried the blue token past marker 7fb3810b9652. Mara watched the eastern gate until dawn.

Ledger 41 line 005: Neri carried the blue token past marker 9bf5afb18a39. Mara watched the eastern gate until dawn.

Ledger 41 line 006: Neri carried the blue token past marker 22f474afc107. Mara watched the eastern gate until dawn.

Ledger 41 line 007: Neri carried the blue token past marker b2f424a884d6. Mara watched the eastern gate until dawn.

Ledger 41 line 008: Neri carried the blue token past marker b96ef97bc7ac. Mara watched the eastern gate until dawn.

Ledger 41 line 009: Neri carried the blue token past marker 4fd19479a487. Mara watched the eastern gate until dawn.

Ledger 41 line 010: Neri carried the blue token past marker 7c945436f2bb. Mara watched the eastern gate until dawn.

Ledger 41 line 011: Neri carried the blue token past marker 879da1099a39. Mara watched the eastern gate until dawn.

Ledger 41 line 012: Neri carried the blue token past marker e14fdde44cda. Mara watched the eastern gate until dawn.

Ledger 41 line 013: Neri carried the blue token past marker 4a0472ccb2bb. Mara watched the eastern gate until dawn.

Ledger 41 line 014: Neri carried the blue token past marker e469404286a2. Mara watched the eastern gate until dawn.

Ledger 41 line 015: Neri carried the blue token past marker ca4e34e152f4. Mara watched the eastern gate until dawn.

Ledger 41 line 016: Neri carried the blue token past marker 549dbd21cbc1. Mara watched the eastern gate until dawn.

Ledger 41 line 017: Neri carried the blue token past marker a30c7827a395. Mara watched the eastern gate until dawn.

Ledger 41 line 018: Neri carried the blue token past marker febe1c0d11e5. Mara watched the eastern gate until dawn.

Ledger 41 line 019: Neri carried the blue token past marker 36433070426a. Mara watched the eastern gate until dawn.

Ledger 41 line 020: Neri carried the blue token past marker 1bc843ba0881. Mara watched the eastern gate until dawn.

Ledger 41 line 021: Neri carried the blue token past marker 1bdc7e34479d. Mara watched the eastern gate until dawn.

Ledger 41 line 022: Neri carried the blue token past marker 6d5aaafad7cb. Mara watched the eastern gate until dawn.

Ledger 41 line 023: Neri carried the blue token past marker 32ce2e4667e5. Mara watched the eastern gate until dawn.

Ledger 41 line 024: Neri carried the blue token past marker ff041e064b78. Mara watched the eastern gate until dawn.

Ledger 41 line 025: Neri carried the blue token past marker c2949ba491a2. Mara watched the eastern gate until dawn.

Ledger 41 line 026: Neri carried the blue token past marker e1fca864e29b. Mara watched the eastern gate until dawn.

Ledger 41 line 027: Neri carried the blue token past marker bbbdeb14bea3. Mara watched the eastern gate until dawn.

Ledger 41 line 028: Neri carried the blue token past marker 49da58865f67. Mara watched the eastern gate until dawn.

Ledger 41 line 029: Neri carried the blue token past marker 78e8c9383bac. Mara watched the eastern gate until dawn.

Ledger 41 line 030: Neri carried the blue token past marker b9aa4e9a0589. Mara watched the eastern gate until dawn.

Ledger 41 line 031: Neri carried the blue token past marker 266dc8e82f3c. Mara watched the eastern gate until dawn.

Ledger 41 line 032: Neri carried the blue token past marker dc04a9a7e3fc. Mara watched the eastern gate until dawn.

Ledger 41 line 033: Neri carried the blue token past marker 4485441d3da5. Mara watched the eastern gate until dawn.

Ledger 41 line 034: Neri carried the blue token past marker 0ede8ddaa9e9. Mara watched the eastern gate until dawn.

Ledger 41 line 035: Neri carried the blue token past marker 9bbf3a90b1fa. Mara watched the eastern gate until dawn.

Ledger 41 line 036: Neri carried the blue token past marker f82f85e9f31f. Mara watched the eastern gate until dawn.

Ledger 41 line 037: Neri carried the blue token past marker 231d53c4df94. Mara watched the eastern gate until dawn.

Ledger 41 line 038: Neri carried the blue token past marker a3fc76d3ceec. Mara watched the eastern gate until dawn.

Ledger 41 line 039: Neri carried the blue token past marker cf7c09a8c110. Mara watched the eastern gate until dawn.

Ledger 41 line 040: Neri carried the blue token past marker 1907a2b14ed2. Mara watched the eastern gate until dawn.

Ledger 41 line 041: Neri carried the blue token past marker da275f589362. Mara watched the eastern gate until dawn.

Ledger 41 line 042: Neri carried the blue token past marker 39c09b4e330e. Mara watched the eastern gate until dawn.

Ledger 41 line 043: Neri carried the blue token past marker 6c7288e7b483. Mara watched the eastern gate until dawn.

Ledger 41 line 044: Neri carried the blue token past marker 44b33d0e8bb4. Mara watched the eastern gate until dawn.

Ledger 41 line 045: Neri carried the blue token past marker 2e37adf86e7d. Mara watched the eastern gate until dawn.

Ledger 41 line 046: Neri carried the blue token past marker 5cb7555a3378. Mara watched the eastern gate until dawn.

Ledger 41 line 047: Neri carried the blue token past marker f3eb32b3c174. Mara watched the eastern gate until dawn.

Ledger 41 line 048: Neri carried the blue token past marker d37c5e1d6bbc. Mara watched the eastern gate until dawn.

Ledger 41 line 049: Neri carried the blue token past marker 838a47666272. Mara watched the eastern gate until dawn.

Ledger 41 line 050: Neri carried the blue token past marker d6310ada6348. Mara watched the eastern gate until dawn.

Ledger 41 line 051: Neri carried the blue token past marker 4a24e38205da. Mara watched the eastern gate until dawn.

Ledger 41 line 052: Neri carried the blue token past marker c23df0658fb6. Mara watched the eastern gate until dawn.

Ledger 41 line 053: Neri carried the blue token past marker 880932acb006. Mara watched the eastern gate until dawn.

Ledger 41 line 054: Neri carried the blue token past marker 527b1a20cee3. Mara watched the eastern gate until dawn.

Ledger 41 line 055: Neri carried the blue token past marker 695e048539fd. Mara watched the eastern gate until dawn.

Ledger 41 line 056: Neri carried the blue token past marker 82dd10f861af. Mara watched the eastern gate until dawn.

Ledger 41 line 057: Neri carried the blue token past marker 95f072278302. Mara watched the eastern gate until dawn.

Ledger 41 line 058: Neri carried the blue token past marker 433f5047f627. Mara watched the eastern gate until dawn.

Ledger 41 line 059: Neri carried the blue token past marker 25de1e4b5e1e. Mara watched the eastern gate until dawn.

Ledger 41 line 060: Neri carried the blue token past marker 86ddb4248328. Mara watched the eastern gate until dawn.

Ledger 41 line 061: Neri carried the blue token past marker abd333c6debb. Mara watched the eastern gate until dawn.

Ledger 41 line 062: Neri carried the blue token past marker 46fd646a5c29. Mara watched the eastern gate until dawn.

Ledger 41 line 063: Neri carried the blue token past marker 7faeba6a7fef. Mara watched the eastern gate until dawn.

Ledger 41 line 064: Neri carried the blue token past marker d272f93624e1. Mara watched the eastern gate until dawn.

Ledger 41 line 065: Neri carried the blue token past marker 61375e93db7d. Mara watched the eastern gate until dawn.

Ledger 41 line 066: Neri carried the blue token past marker 7c7a4e94cc21. Mara watched the eastern gate until dawn.

Ledger 41 line 067: Neri carried the blue token past marker 8f4d3e1e84ef. Mara watched the eastern gate until dawn.

Ledger 41 line 068: Neri carried the blue token past marker 0735a002186a. Mara watched the eastern gate until dawn.

Ledger 41 line 069: Neri carried the blue token past marker 4480bd337368. Mara watched the eastern gate until dawn.

Ledger 41 line 070: Neri carried the blue token past marker a333e28f106d. Mara watched the eastern gate until dawn.

Ledger 41 line 071: Neri carried the blue token past marker d023276e34ee. Mara watched the eastern gate until dawn.

Ledger 41 line 072: Neri carried the blue token past marker 31796f9f2c98. Mara watched the eastern gate until dawn.

Ledger 41 line 073: Neri carried the blue token past marker fe408e6d3377. Mara watched the eastern gate until dawn.

Ledger 41 line 074: Neri carried the blue token past marker 212d11e25d44. Mara watched the eastern gate until dawn.

Ledger 41 line 075: Neri carried the blue token past marker a3e74c3a4251. Mara watched the eastern gate until dawn.

Ledger 41 line 076: Neri carried the blue token past marker 70e43fed07bb. Mara watched the eastern gate until dawn.

Ledger 41 line 077: Neri carried the blue token past marker 42ac8dbc8110. Mara watched the eastern gate until dawn.

Ledger 41 line 078: Neri carried the blue token past marker 604abcd3afe2. Mara watched the eastern gate until dawn.

Ledger 41 line 079: Neri carried the blue token past marker 44dcd8206bb7. Mara watched the eastern gate until dawn.

Ledger 41 line 080: Neri carried the blue token past marker f472cc762149. Mara watched the eastern gate until dawn.

Ledger 41 line 081: Neri carried the blue token past marker 549e7ba72fd6. Mara watched the eastern gate until dawn.

Ledger 41 line 082: Neri carried the blue token past marker 89d82de33891. Mara watched the eastern gate until dawn.

Ledger 41 line 083: Neri carried the blue token past marker 44d51e6e2a1a. Mara watched the eastern gate until dawn.

Ledger 41 line 084: Neri carried the blue token past marker 018e366c5760. Mara watched the eastern gate until dawn.

Ledger 41 line 085: Neri carried the blue token past marker 391829c80754. Mara watched the eastern gate until dawn.

Ledger 41 line 086: Neri carried the blue token past marker 932222af6c4a. Mara watched the eastern gate until dawn.

Ledger 41 line 087: Neri carried the blue token past marker 81c7fc944f8d. Mara watched the eastern gate until dawn.

Ledger 41 line 088: Neri carried the blue token past marker 691c1c4f4bf6. Mara watched the eastern gate until dawn.

Ledger 41 line 089: Neri carried the blue token past marker e8926f6477ab. Mara watched the eastern gate until dawn.

Ledger 41 line 090: Neri carried the blue token past marker 2ecd13be6784. Mara watched the eastern gate until dawn.

Ledger 41 line 091: Neri carried the blue token past marker 1cfc0885c92a. Mara watched the eastern gate until dawn.

Ledger 41 line 092: Neri carried the blue token past marker 9c7deedcd131. Mara watched the eastern gate until dawn.

Ledger 41 line 093: Neri carried the blue token past marker b79460e8ce8d. Mara watched the eastern gate until dawn.

Ledger 41 line 094: Neri carried the blue token past marker a3587ec7ff48. Mara watched the eastern gate until dawn.

Ledger 41 line 095: Neri carried the blue token past marker 832feb2b8d5a. Mara watched the eastern gate until dawn.

Ledger 41 line 096: Neri carried the blue token past marker 82d9bcb1741a. Mara watched the eastern gate until dawn.

Ledger 41 line 097: Neri carried the blue token past marker 32d55f06484a. Mara watched the eastern gate until dawn.

Ledger 41 line 098: Neri carried the blue token past marker b8f16a35c937. Mara watched the eastern gate until dawn.

Ledger 41 line 099: Neri carried the blue token past marker 36323e3a1505. Mara watched the eastern gate until dawn.

Ledger 41 line 100: Neri carried the blue token past marker ea5dddd248db. Mara watched the eastern gate until dawn.

Ledger 41 line 101: Neri carried the blue token past marker 853dd26a85a2. Mara watched the eastern gate until dawn.

Ledger 41 line 102: Neri carried the blue token past marker a01a880f484b. Mara watched the eastern gate until dawn.

Ledger 41 line 103: Neri carried the blue token past marker 5837773e9037. Mara watched the eastern gate until dawn.

Ledger 41 line 104: Neri carried the blue token past marker 29d82c0dc4d7. Mara watched the eastern gate until dawn.

Ledger 41 line 105: Neri carried the blue token past marker e9e593a46b15. Mara watched the eastern gate until dawn.

Ledger 41 line 106: Neri carried the blue token past marker 93a4357beeb4. Mara watched the eastern gate until dawn.

Ledger 41 line 107: Neri carried the blue token past marker 9a44e02f7ca9. Mara watched the eastern gate until dawn.

Ledger 41 line 108: Neri carried the blue token past marker 8dd7f4b1e71f. Mara watched the eastern gate until dawn.

Ledger 41 line 109: Neri carried the blue token past marker b57e19b9995d. Mara watched the eastern gate until dawn.

Ledger 41 line 110: Neri carried the blue token past marker e58f609d82cd. Mara watched the eastern gate until dawn.

Ledger 41 line 111: Neri carried the blue token past marker 24744d084a5e. Mara watched the eastern gate until dawn.

Ledger 41 line 112: Neri carried the blue token past marker c73aeb3eb2fb. Mara watched the eastern gate until dawn.

Ledger 41 line 113: Neri carried the blue token past marker fc1f1f2dc729. Mara watched the eastern gate until dawn.

Ledger 41 line 114: Neri carried the blue token past marker 8ac692f104b0. Mara watched the eastern gate until dawn.

Ledger 41 line 115: Neri carried the blue token past marker 483e09f6facb. Mara watched the eastern gate until dawn.

Ledger 41 line 116: Neri carried the blue token past marker 8dae2cb43466. Mara watched the eastern gate until dawn.

Ledger 41 line 117: Neri carried the blue token past marker 3be2c274c3a3. Mara watched the eastern gate until dawn.

Ledger 41 line 118: Neri carried the blue token past marker d25d7ddd22ce. Mara watched the eastern gate until dawn.

Ledger 41 line 119: Neri carried the blue token past marker 03c79eddaae0. Mara watched the eastern gate until dawn.

Ledger 41 line 120: Neri carried the blue token past marker 3bbf647ee1b4. Mara watched the eastern gate until dawn.

Ledger 41 line 121: Neri carried the blue token past marker bbc63042271e. Mara watched the eastern gate until dawn.

Ledger 41 line 122: Neri carried the blue token past marker 1e0a27dda2be. Mara watched the eastern gate until dawn.

Ledger 41 line 123: Neri carried the blue token past marker c592cb39470c. Mara watched the eastern gate until dawn.

Ledger 41 line 124: Neri carried the blue token past marker da0e0cf817e7. Mara watched the eastern gate until dawn.

Ledger 41 line 125: Neri carried the blue token past marker a08bf34405e9. Mara watched the eastern gate until dawn.

Ledger 41 line 126: Neri carried the blue token past marker c8a6747bd307. Mara watched the eastern gate until dawn.

Ledger 41 line 127: Neri carried the blue token past marker 8ec44cb0eb1a. Mara watched the eastern gate until dawn.

Ledger 41 line 128: Neri carried the blue token past marker 849316e44657. Mara watched the eastern gate until dawn.

Ledger 41 line 129: Neri carried the blue token past marker 9ee4140989a8. Mara watched the eastern gate until dawn.

Ledger 41 line 130: Neri carried the blue token past marker 1c8a9e685cec. Mara watched the eastern gate until dawn.

Ledger 41 line 131: Neri carried the blue token past marker bfe8310c1c79. Mara watched the eastern gate until dawn.

Ledger 41 line 132: Neri carried the blue token past marker 8006573a87c4. Mara watched the eastern gate until dawn.

Ledger 41 line 133: Neri carried the blue token past marker c87b83a80b1a. Mara watched the eastern gate until dawn.

Ledger 41 line 134: Neri carried the blue token past marker f6639d3735d0. Mara watched the eastern gate until dawn.

Ledger 41 line 135: Neri carried the blue token past marker 2109b8939a1c. Mara watched the eastern gate until dawn.

Ledger 41 line 136: Neri carried the blue token past marker a7d5394e32b4. Mara watched the eastern gate until dawn.

Ledger 41 line 137: Neri carried the blue token past marker 9a75399c5992. Mara watched the eastern gate until dawn.

Ledger 41 line 138: Neri carried the blue token past marker dcb62251b5f8. Mara watched the eastern gate until dawn.

Ledger 41 line 139: Neri carried the blue token past marker 37971f20d885. Mara watched the eastern gate until dawn.

Ledger 41 line 140: Neri carried the blue token past marker 3b777a36492a. Mara watched the eastern gate until dawn.
