---
id: scene-0044
title: Recovery ledger 44
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.176076+00:00
updated_at: 2026-10-03T12:14:52.176076+00:00
---

Ledger 44 line 001: Neri carried the blue token past marker ff1ee2c52fb7. Mara watched the eastern gate until dawn.

Ledger 44 line 002: Neri carried the blue token past marker d439e8989742. Mara watched the eastern gate until dawn.

Ledger 44 line 003: Neri carried the blue token past marker e2f3ff5d1cfc. Mara watched the eastern gate until dawn.

Ledger 44 line 004: Neri carried the blue token past marker 81b8c8eda252. Mara watched the eastern gate until dawn.

Ledger 44 line 005: Neri carried the blue token past marker b7209f5a5813. Mara watched the eastern gate until dawn.

Ledger 44 line 006: Neri carried the blue token past marker aa39a4c62f1f. Mara watched the eastern gate until dawn.

Ledger 44 line 007: Neri carried the blue token past marker dc5a59955358. Mara watched the eastern gate until dawn.

Ledger 44 line 008: Neri carried the blue token past marker 986860848e94. Mara watched the eastern gate until dawn.

Ledger 44 line 009: Neri carried the blue token past marker 1b1492a762f7. Mara watched the eastern gate until dawn.

Ledger 44 line 010: Neri carried the blue token past marker 3b67eb9f870e. Mara watched the eastern gate until dawn.

Ledger 44 line 011: Neri carried the blue token past marker 55eeb0541274. Mara watched the eastern gate until dawn.

Ledger 44 line 012: Neri carried the blue token past marker 22928f5bca62. Mara watched the eastern gate until dawn.

Ledger 44 line 013: Neri carried the blue token past marker ee6f536d563f. Mara watched the eastern gate until dawn.

Ledger 44 line 014: Neri carried the blue token past marker 243091e2734b. Mara watched the eastern gate until dawn.

Ledger 44 line 015: Neri carried the blue token past marker 0709462dcdf0. Mara watched the eastern gate until dawn.

Ledger 44 line 016: Neri carried the blue token past marker 66caf5968aab. Mara watched the eastern gate until dawn.

Ledger 44 line 017: Neri carried the blue token past marker 4bb44b4ec435. Mara watched the eastern gate until dawn.

Ledger 44 line 018: Neri carried the blue token past marker 66f48759292a. Mara watched the eastern gate until dawn.

Ledger 44 line 019: Neri carried the blue token past marker 4289b63d864f. Mara watched the eastern gate until dawn.

Ledger 44 line 020: Neri carried the blue token past marker b5f6159c624e. Mara watched the eastern gate until dawn.

Ledger 44 line 021: Neri carried the blue token past marker 3d12c6b0c1c8. Mara watched the eastern gate until dawn.

Ledger 44 line 022: Neri carried the blue token past marker 1e4d47985fb5. Mara watched the eastern gate until dawn.

Ledger 44 line 023: Neri carried the blue token past marker 10044c3d078c. Mara watched the eastern gate until dawn.

Ledger 44 line 024: Neri carried the blue token past marker 9eba8b4791a6. Mara watched the eastern gate until dawn.

Ledger 44 line 025: Neri carried the blue token past marker bea4d5b02c26. Mara watched the eastern gate until dawn.

Ledger 44 line 026: Neri carried the blue token past marker 0985bc12b2be. Mara watched the eastern gate until dawn.

Ledger 44 line 027: Neri carried the blue token past marker 52fdfb638863. Mara watched the eastern gate until dawn.

Ledger 44 line 028: Neri carried the blue token past marker 05d4355b65ee. Mara watched the eastern gate until dawn.

Ledger 44 line 029: Neri carried the blue token past marker efee6d2100f2. Mara watched the eastern gate until dawn.

Ledger 44 line 030: Neri carried the blue token past marker ea4f3dd510c5. Mara watched the eastern gate until dawn.

Ledger 44 line 031: Neri carried the blue token past marker 48a10328b0da. Mara watched the eastern gate until dawn.

Ledger 44 line 032: Neri carried the blue token past marker fea634c73dea. Mara watched the eastern gate until dawn.

Ledger 44 line 033: Neri carried the blue token past marker 285457ade313. Mara watched the eastern gate until dawn.

Ledger 44 line 034: Neri carried the blue token past marker e7c9a2c45b60. Mara watched the eastern gate until dawn.

Ledger 44 line 035: Neri carried the blue token past marker 880c9c7f80a8. Mara watched the eastern gate until dawn.

Ledger 44 line 036: Neri carried the blue token past marker 2cbfc46056cf. Mara watched the eastern gate until dawn.

Ledger 44 line 037: Neri carried the blue token past marker d6b6656bf3af. Mara watched the eastern gate until dawn.

Ledger 44 line 038: Neri carried the blue token past marker ac3db07feb60. Mara watched the eastern gate until dawn.

Ledger 44 line 039: Neri carried the blue token past marker 702123999549. Mara watched the eastern gate until dawn.

Ledger 44 line 040: Neri carried the blue token past marker 86cf7660367b. Mara watched the eastern gate until dawn.

Ledger 44 line 041: Neri carried the blue token past marker 616139032701. Mara watched the eastern gate until dawn.

Ledger 44 line 042: Neri carried the blue token past marker 96217a5251c9. Mara watched the eastern gate until dawn.

Ledger 44 line 043: Neri carried the blue token past marker 7eec3dec2528. Mara watched the eastern gate until dawn.

Ledger 44 line 044: Neri carried the blue token past marker 90a5a8467525. Mara watched the eastern gate until dawn.

Ledger 44 line 045: Neri carried the blue token past marker db94eed20fc9. Mara watched the eastern gate until dawn.

Ledger 44 line 046: Neri carried the blue token past marker 92e13194d9b6. Mara watched the eastern gate until dawn.

Ledger 44 line 047: Neri carried the blue token past marker cb44042b930e. Mara watched the eastern gate until dawn.

Ledger 44 line 048: Neri carried the blue token past marker 7bf1ef932279. Mara watched the eastern gate until dawn.

Ledger 44 line 049: Neri carried the blue token past marker 7fcbf4849930. Mara watched the eastern gate until dawn.

Ledger 44 line 050: Neri carried the blue token past marker 4ca22b45703f. Mara watched the eastern gate until dawn.

Ledger 44 line 051: Neri carried the blue token past marker c7e445b72a4e. Mara watched the eastern gate until dawn.

Ledger 44 line 052: Neri carried the blue token past marker 0d20fa3ce86b. Mara watched the eastern gate until dawn.

Ledger 44 line 053: Neri carried the blue token past marker d39e2d44a11f. Mara watched the eastern gate until dawn.

Ledger 44 line 054: Neri carried the blue token past marker 0f6793e39727. Mara watched the eastern gate until dawn.

Ledger 44 line 055: Neri carried the blue token past marker 486391e5a719. Mara watched the eastern gate until dawn.

Ledger 44 line 056: Neri carried the blue token past marker ae445ae52d44. Mara watched the eastern gate until dawn.

Ledger 44 line 057: Neri carried the blue token past marker b9ed3470b778. Mara watched the eastern gate until dawn.

Ledger 44 line 058: Neri carried the blue token past marker aeb41f5976f6. Mara watched the eastern gate until dawn.

Ledger 44 line 059: Neri carried the blue token past marker 3514aae8cff2. Mara watched the eastern gate until dawn.

Ledger 44 line 060: Neri carried the blue token past marker 7de3e1b25de3. Mara watched the eastern gate until dawn.

Ledger 44 line 061: Neri carried the blue token past marker f13871ae404a. Mara watched the eastern gate until dawn.

Ledger 44 line 062: Neri carried the blue token past marker 0fae51707948. Mara watched the eastern gate until dawn.

Ledger 44 line 063: Neri carried the blue token past marker 4082272d7d67. Mara watched the eastern gate until dawn.

Ledger 44 line 064: Neri carried the blue token past marker b4f3a34fb16a. Mara watched the eastern gate until dawn.

Ledger 44 line 065: Neri carried the blue token past marker 9b3b5d2d35ca. Mara watched the eastern gate until dawn.

Ledger 44 line 066: Neri carried the blue token past marker 4b82751831ae. Mara watched the eastern gate until dawn.

Ledger 44 line 067: Neri carried the blue token past marker 3af3a80a0e40. Mara watched the eastern gate until dawn.

Ledger 44 line 068: Neri carried the blue token past marker de646d826c4c. Mara watched the eastern gate until dawn.

Ledger 44 line 069: Neri carried the blue token past marker bd2d3486d9e2. Mara watched the eastern gate until dawn.

Ledger 44 line 070: Neri carried the blue token past marker d967c09bb7e2. Mara watched the eastern gate until dawn.

Ledger 44 line 071: Neri carried the blue token past marker c024b673daf8. Mara watched the eastern gate until dawn.

Ledger 44 line 072: Neri carried the blue token past marker ab35301acd02. Mara watched the eastern gate until dawn.

Ledger 44 line 073: Neri carried the blue token past marker 95e1e8906f38. Mara watched the eastern gate until dawn.

Ledger 44 line 074: Neri carried the blue token past marker 066d77584e04. Mara watched the eastern gate until dawn.

Ledger 44 line 075: Neri carried the blue token past marker ce2fa90277b8. Mara watched the eastern gate until dawn.

Ledger 44 line 076: Neri carried the blue token past marker 2a4bdda73a37. Mara watched the eastern gate until dawn.

Ledger 44 line 077: Neri carried the blue token past marker 22ff99a08d5c. Mara watched the eastern gate until dawn.

Ledger 44 line 078: Neri carried the blue token past marker 6f1fb69c00e2. Mara watched the eastern gate until dawn.

Ledger 44 line 079: Neri carried the blue token past marker 251dd24c80e3. Mara watched the eastern gate until dawn.

Ledger 44 line 080: Neri carried the blue token past marker ff34fd9f70c5. Mara watched the eastern gate until dawn.

Ledger 44 line 081: Neri carried the blue token past marker 6798223f3694. Mara watched the eastern gate until dawn.

Ledger 44 line 082: Neri carried the blue token past marker e96b4d9ce334. Mara watched the eastern gate until dawn.

Ledger 44 line 083: Neri carried the blue token past marker 0af87894312d. Mara watched the eastern gate until dawn.

Ledger 44 line 084: Neri carried the blue token past marker 9bde376f39f1. Mara watched the eastern gate until dawn.

Ledger 44 line 085: Neri carried the blue token past marker 6e54cf9ede06. Mara watched the eastern gate until dawn.

Ledger 44 line 086: Neri carried the blue token past marker 2b5844600b25. Mara watched the eastern gate until dawn.

Ledger 44 line 087: Neri carried the blue token past marker c3f05df1a553. Mara watched the eastern gate until dawn.

Ledger 44 line 088: Neri carried the blue token past marker 7ec4bfe423fe. Mara watched the eastern gate until dawn.

Ledger 44 line 089: Neri carried the blue token past marker 869d19255f23. Mara watched the eastern gate until dawn.

Ledger 44 line 090: Neri carried the blue token past marker 95ea08a5a048. Mara watched the eastern gate until dawn.

Ledger 44 line 091: Neri carried the blue token past marker 363cb3140db6. Mara watched the eastern gate until dawn.

Ledger 44 line 092: Neri carried the blue token past marker 7debfdfc9f49. Mara watched the eastern gate until dawn.

Ledger 44 line 093: Neri carried the blue token past marker 9a93c9754025. Mara watched the eastern gate until dawn.

Ledger 44 line 094: Neri carried the blue token past marker cf4984c74ff0. Mara watched the eastern gate until dawn.

Ledger 44 line 095: Neri carried the blue token past marker afd31a486684. Mara watched the eastern gate until dawn.

Ledger 44 line 096: Neri carried the blue token past marker defe03a41218. Mara watched the eastern gate until dawn.

Ledger 44 line 097: Neri carried the blue token past marker ac1b4aee471d. Mara watched the eastern gate until dawn.

Ledger 44 line 098: Neri carried the blue token past marker 50eff6277d9a. Mara watched the eastern gate until dawn.

Ledger 44 line 099: Neri carried the blue token past marker eb560cdaf38c. Mara watched the eastern gate until dawn.

Ledger 44 line 100: Neri carried the blue token past marker 724d869d5890. Mara watched the eastern gate until dawn.

Ledger 44 line 101: Neri carried the blue token past marker 20ec75ad21a3. Mara watched the eastern gate until dawn.

Ledger 44 line 102: Neri carried the blue token past marker 5eaf6d3af73b. Mara watched the eastern gate until dawn.

Ledger 44 line 103: Neri carried the blue token past marker 74bc132259f5. Mara watched the eastern gate until dawn.

Ledger 44 line 104: Neri carried the blue token past marker b8c6fa44d5b1. Mara watched the eastern gate until dawn.

Ledger 44 line 105: Neri carried the blue token past marker 47af9c9b7654. Mara watched the eastern gate until dawn.

Ledger 44 line 106: Neri carried the blue token past marker 2f2ae0e3d0df. Mara watched the eastern gate until dawn.

Ledger 44 line 107: Neri carried the blue token past marker d4e8d32397aa. Mara watched the eastern gate until dawn.

Ledger 44 line 108: Neri carried the blue token past marker 8422fa540d15. Mara watched the eastern gate until dawn.

Ledger 44 line 109: Neri carried the blue token past marker d40649bc36f7. Mara watched the eastern gate until dawn.

Ledger 44 line 110: Neri carried the blue token past marker 17853be5db9f. Mara watched the eastern gate until dawn.

Ledger 44 line 111: Neri carried the blue token past marker 132ea0f85a27. Mara watched the eastern gate until dawn.

Ledger 44 line 112: Neri carried the blue token past marker 511430cbab8a. Mara watched the eastern gate until dawn.

Ledger 44 line 113: Neri carried the blue token past marker 0d97c29fe3c9. Mara watched the eastern gate until dawn.

Ledger 44 line 114: Neri carried the blue token past marker 0112375258c6. Mara watched the eastern gate until dawn.

Ledger 44 line 115: Neri carried the blue token past marker 10e8176081ff. Mara watched the eastern gate until dawn.

Ledger 44 line 116: Neri carried the blue token past marker 43a0692b75a1. Mara watched the eastern gate until dawn.

Ledger 44 line 117: Neri carried the blue token past marker 711f76c282a7. Mara watched the eastern gate until dawn.

Ledger 44 line 118: Neri carried the blue token past marker f5dabd70365e. Mara watched the eastern gate until dawn.

Ledger 44 line 119: Neri carried the blue token past marker f5948e0d65c3. Mara watched the eastern gate until dawn.

Ledger 44 line 120: Neri carried the blue token past marker d2c816ebc788. Mara watched the eastern gate until dawn.

Ledger 44 line 121: Neri carried the blue token past marker eb8f40df89e6. Mara watched the eastern gate until dawn.

Ledger 44 line 122: Neri carried the blue token past marker 95d04c138a81. Mara watched the eastern gate until dawn.

Ledger 44 line 123: Neri carried the blue token past marker 8ac527784dbc. Mara watched the eastern gate until dawn.

Ledger 44 line 124: Neri carried the blue token past marker 41553d60da90. Mara watched the eastern gate until dawn.

Ledger 44 line 125: Neri carried the blue token past marker 4b0f1fea1ad7. Mara watched the eastern gate until dawn.

Ledger 44 line 126: Neri carried the blue token past marker 94d8be25492e. Mara watched the eastern gate until dawn.

Ledger 44 line 127: Neri carried the blue token past marker c7eb1feed8a7. Mara watched the eastern gate until dawn.

Ledger 44 line 128: Neri carried the blue token past marker 5f7eccaee583. Mara watched the eastern gate until dawn.

Ledger 44 line 129: Neri carried the blue token past marker f941d4fbb3c6. Mara watched the eastern gate until dawn.

Ledger 44 line 130: Neri carried the blue token past marker 9fee245b2c26. Mara watched the eastern gate until dawn.

Ledger 44 line 131: Neri carried the blue token past marker 2f668a67ed34. Mara watched the eastern gate until dawn.

Ledger 44 line 132: Neri carried the blue token past marker cc483083d8b3. Mara watched the eastern gate until dawn.

Ledger 44 line 133: Neri carried the blue token past marker f6fdbc60e0d2. Mara watched the eastern gate until dawn.

Ledger 44 line 134: Neri carried the blue token past marker 6441d4b1822e. Mara watched the eastern gate until dawn.

Ledger 44 line 135: Neri carried the blue token past marker 235bc9aa7087. Mara watched the eastern gate until dawn.

Ledger 44 line 136: Neri carried the blue token past marker c45843eec663. Mara watched the eastern gate until dawn.

Ledger 44 line 137: Neri carried the blue token past marker d8b9002c8bd9. Mara watched the eastern gate until dawn.

Ledger 44 line 138: Neri carried the blue token past marker 23263527a4fe. Mara watched the eastern gate until dawn.

Ledger 44 line 139: Neri carried the blue token past marker ae13aaa5bdf2. Mara watched the eastern gate until dawn.

Ledger 44 line 140: Neri carried the blue token past marker d6c348fa04f2. Mara watched the eastern gate until dawn.
