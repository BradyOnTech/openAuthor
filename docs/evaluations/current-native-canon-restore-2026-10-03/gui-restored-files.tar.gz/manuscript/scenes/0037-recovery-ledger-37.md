---
id: scene-0037
title: Recovery ledger 37
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.172471+00:00
updated_at: 2026-10-03T12:14:52.172471+00:00
---

Ledger 37 line 001: Neri carried the blue token past marker dba773c43247. Mara watched the eastern gate until dawn.

Ledger 37 line 002: Neri carried the blue token past marker 68d0aae1c4c6. Mara watched the eastern gate until dawn.

Ledger 37 line 003: Neri carried the blue token past marker 69acb6484113. Mara watched the eastern gate until dawn.

Ledger 37 line 004: Neri carried the blue token past marker 933f30b56c4a. Mara watched the eastern gate until dawn.

Ledger 37 line 005: Neri carried the blue token past marker 75575b6492a5. Mara watched the eastern gate until dawn.

Ledger 37 line 006: Neri carried the blue token past marker e01c6a5a4649. Mara watched the eastern gate until dawn.

Ledger 37 line 007: Neri carried the blue token past marker 1ed2096f6285. Mara watched the eastern gate until dawn.

Ledger 37 line 008: Neri carried the blue token past marker 85ddd46bbf50. Mara watched the eastern gate until dawn.

Ledger 37 line 009: Neri carried the blue token past marker 7abca5a62732. Mara watched the eastern gate until dawn.

Ledger 37 line 010: Neri carried the blue token past marker 8cb4a3cb9663. Mara watched the eastern gate until dawn.

Ledger 37 line 011: Neri carried the blue token past marker 0af016ce5c6a. Mara watched the eastern gate until dawn.

Ledger 37 line 012: Neri carried the blue token past marker 3a5a5d6633d4. Mara watched the eastern gate until dawn.

Ledger 37 line 013: Neri carried the blue token past marker 6320fb8324eb. Mara watched the eastern gate until dawn.

Ledger 37 line 014: Neri carried the blue token past marker 5dbd224ff6a7. Mara watched the eastern gate until dawn.

Ledger 37 line 015: Neri carried the blue token past marker c96259f91c12. Mara watched the eastern gate until dawn.

Ledger 37 line 016: Neri carried the blue token past marker 1d0e8c73b65a. Mara watched the eastern gate until dawn.

Ledger 37 line 017: Neri carried the blue token past marker f7293c8e8818. Mara watched the eastern gate until dawn.

Ledger 37 line 018: Neri carried the blue token past marker adc5b1fcc11c. Mara watched the eastern gate until dawn.

Ledger 37 line 019: Neri carried the blue token past marker 3e383b66c443. Mara watched the eastern gate until dawn.

Ledger 37 line 020: Neri carried the blue token past marker ea3a7d7f0229. Mara watched the eastern gate until dawn.

Ledger 37 line 021: Neri carried the blue token past marker 449d963b85f5. Mara watched the eastern gate until dawn.

Ledger 37 line 022: Neri carried the blue token past marker 395def1554b0. Mara watched the eastern gate until dawn.

Ledger 37 line 023: Neri carried the blue token past marker 78cadeba7074. Mara watched the eastern gate until dawn.

Ledger 37 line 024: Neri carried the blue token past marker 31dc8cef4b9b. Mara watched the eastern gate until dawn.

Ledger 37 line 025: Neri carried the blue token past marker aab3e4af28cd. Mara watched the eastern gate until dawn.

Ledger 37 line 026: Neri carried the blue token past marker 9b60d3135c6e. Mara watched the eastern gate until dawn.

Ledger 37 line 027: Neri carried the blue token past marker 00dacb6d8d7f. Mara watched the eastern gate until dawn.

Ledger 37 line 028: Neri carried the blue token past marker b548ec3eb648. Mara watched the eastern gate until dawn.

Ledger 37 line 029: Neri carried the blue token past marker 7cb743410c45. Mara watched the eastern gate until dawn.

Ledger 37 line 030: Neri carried the blue token past marker ab25c2a5b233. Mara watched the eastern gate until dawn.

Ledger 37 line 031: Neri carried the blue token past marker 5905dc3dfbed. Mara watched the eastern gate until dawn.

Ledger 37 line 032: Neri carried the blue token past marker f9069d6c932c. Mara watched the eastern gate until dawn.

Ledger 37 line 033: Neri carried the blue token past marker dd89f527f418. Mara watched the eastern gate until dawn.

Ledger 37 line 034: Neri carried the blue token past marker 61f0cb6a28e2. Mara watched the eastern gate until dawn.

Ledger 37 line 035: Neri carried the blue token past marker 1ec2062eb957. Mara watched the eastern gate until dawn.

Ledger 37 line 036: Neri carried the blue token past marker bc67ac12374e. Mara watched the eastern gate until dawn.

Ledger 37 line 037: Neri carried the blue token past marker e30bc4c3962f. Mara watched the eastern gate until dawn.

Ledger 37 line 038: Neri carried the blue token past marker 416c7d918e67. Mara watched the eastern gate until dawn.

Ledger 37 line 039: Neri carried the blue token past marker 88031822b15e. Mara watched the eastern gate until dawn.

Ledger 37 line 040: Neri carried the blue token past marker 46735d195d15. Mara watched the eastern gate until dawn.

Ledger 37 line 041: Neri carried the blue token past marker 86359677aba6. Mara watched the eastern gate until dawn.

Ledger 37 line 042: Neri carried the blue token past marker 079a0803a630. Mara watched the eastern gate until dawn.

Ledger 37 line 043: Neri carried the blue token past marker 4202f0d973be. Mara watched the eastern gate until dawn.

Ledger 37 line 044: Neri carried the blue token past marker 5133b657db59. Mara watched the eastern gate until dawn.

Ledger 37 line 045: Neri carried the blue token past marker 9aec2ddc0c5c. Mara watched the eastern gate until dawn.

Ledger 37 line 046: Neri carried the blue token past marker 3ebc276b3b10. Mara watched the eastern gate until dawn.

Ledger 37 line 047: Neri carried the blue token past marker ce0d2883fecd. Mara watched the eastern gate until dawn.

Ledger 37 line 048: Neri carried the blue token past marker de8c2afbb845. Mara watched the eastern gate until dawn.

Ledger 37 line 049: Neri carried the blue token past marker cbda3f9756f1. Mara watched the eastern gate until dawn.

Ledger 37 line 050: Neri carried the blue token past marker 161439f53768. Mara watched the eastern gate until dawn.

Ledger 37 line 051: Neri carried the blue token past marker d05d0854c21b. Mara watched the eastern gate until dawn.

Ledger 37 line 052: Neri carried the blue token past marker 80863cce8378. Mara watched the eastern gate until dawn.

Ledger 37 line 053: Neri carried the blue token past marker d1cfab9ab279. Mara watched the eastern gate until dawn.

Ledger 37 line 054: Neri carried the blue token past marker 8afbea3458e2. Mara watched the eastern gate until dawn.

Ledger 37 line 055: Neri carried the blue token past marker e3c4b93dd31d. Mara watched the eastern gate until dawn.

Ledger 37 line 056: Neri carried the blue token past marker 1f290f0e28a3. Mara watched the eastern gate until dawn.

Ledger 37 line 057: Neri carried the blue token past marker 80188a8f3b1c. Mara watched the eastern gate until dawn.

Ledger 37 line 058: Neri carried the blue token past marker 875396038fc8. Mara watched the eastern gate until dawn.

Ledger 37 line 059: Neri carried the blue token past marker fe7ac2d69cd7. Mara watched the eastern gate until dawn.

Ledger 37 line 060: Neri carried the blue token past marker 12f212ae1a57. Mara watched the eastern gate until dawn.

Ledger 37 line 061: Neri carried the blue token past marker ab7dac984d18. Mara watched the eastern gate until dawn.

Ledger 37 line 062: Neri carried the blue token past marker a3fe9bf4a10c. Mara watched the eastern gate until dawn.

Ledger 37 line 063: Neri carried the blue token past marker d8ad25f9cbd2. Mara watched the eastern gate until dawn.

Ledger 37 line 064: Neri carried the blue token past marker 97dbd9301b6a. Mara watched the eastern gate until dawn.

Ledger 37 line 065: Neri carried the blue token past marker 0144b957a0ef. Mara watched the eastern gate until dawn.

Ledger 37 line 066: Neri carried the blue token past marker 46529a448299. Mara watched the eastern gate until dawn.

Ledger 37 line 067: Neri carried the blue token past marker 784f8980b7dc. Mara watched the eastern gate until dawn.

Ledger 37 line 068: Neri carried the blue token past marker cedb2bcbf7b2. Mara watched the eastern gate until dawn.

Ledger 37 line 069: Neri carried the blue token past marker dcbcefd9216b. Mara watched the eastern gate until dawn.

Ledger 37 line 070: Neri carried the blue token past marker c08afcd75f8f. Mara watched the eastern gate until dawn.

Ledger 37 line 071: Neri carried the blue token past marker eedf5137535b. Mara watched the eastern gate until dawn.

Ledger 37 line 072: Neri carried the blue token past marker 1b30b21542c4. Mara watched the eastern gate until dawn.

Ledger 37 line 073: Neri carried the blue token past marker 48736a8adc46. Mara watched the eastern gate until dawn.

Ledger 37 line 074: Neri carried the blue token past marker 731b6268b4e7. Mara watched the eastern gate until dawn.

Ledger 37 line 075: Neri carried the blue token past marker bd1b9f3bf207. Mara watched the eastern gate until dawn.

Ledger 37 line 076: Neri carried the blue token past marker 9046ff0b19a3. Mara watched the eastern gate until dawn.

Ledger 37 line 077: Neri carried the blue token past marker 987893902f6e. Mara watched the eastern gate until dawn.

Ledger 37 line 078: Neri carried the blue token past marker 5784eec298d2. Mara watched the eastern gate until dawn.

Ledger 37 line 079: Neri carried the blue token past marker 52e7bbb2c3c9. Mara watched the eastern gate until dawn.

Ledger 37 line 080: Neri carried the blue token past marker 59455a145380. Mara watched the eastern gate until dawn.

Ledger 37 line 081: Neri carried the blue token past marker 6c9d478a9376. Mara watched the eastern gate until dawn.

Ledger 37 line 082: Neri carried the blue token past marker 82bcc2460feb. Mara watched the eastern gate until dawn.

Ledger 37 line 083: Neri carried the blue token past marker 0ffb12271791. Mara watched the eastern gate until dawn.

Ledger 37 line 084: Neri carried the blue token past marker ded5091f34fb. Mara watched the eastern gate until dawn.

Ledger 37 line 085: Neri carried the blue token past marker 4867d7168861. Mara watched the eastern gate until dawn.

Ledger 37 line 086: Neri carried the blue token past marker 58439ef4d587. Mara watched the eastern gate until dawn.

Ledger 37 line 087: Neri carried the blue token past marker d80d1b5e7708. Mara watched the eastern gate until dawn.

Ledger 37 line 088: Neri carried the blue token past marker 3068d28cb5c4. Mara watched the eastern gate until dawn.

Ledger 37 line 089: Neri carried the blue token past marker 37c3e7533636. Mara watched the eastern gate until dawn.

Ledger 37 line 090: Neri carried the blue token past marker c4f8eefca8d3. Mara watched the eastern gate until dawn.

Ledger 37 line 091: Neri carried the blue token past marker 22556d9bf328. Mara watched the eastern gate until dawn.

Ledger 37 line 092: Neri carried the blue token past marker 7afd33ce2634. Mara watched the eastern gate until dawn.

Ledger 37 line 093: Neri carried the blue token past marker 3cacb4e45ec8. Mara watched the eastern gate until dawn.

Ledger 37 line 094: Neri carried the blue token past marker a60a48d1ef92. Mara watched the eastern gate until dawn.

Ledger 37 line 095: Neri carried the blue token past marker b4b8ae80c57e. Mara watched the eastern gate until dawn.

Ledger 37 line 096: Neri carried the blue token past marker 28f252740932. Mara watched the eastern gate until dawn.

Ledger 37 line 097: Neri carried the blue token past marker 722f35ee7d2d. Mara watched the eastern gate until dawn.

Ledger 37 line 098: Neri carried the blue token past marker 2c9cbcc6a8c8. Mara watched the eastern gate until dawn.

Ledger 37 line 099: Neri carried the blue token past marker 8a0daba6afd7. Mara watched the eastern gate until dawn.

Ledger 37 line 100: Neri carried the blue token past marker 237880e7a41b. Mara watched the eastern gate until dawn.

Ledger 37 line 101: Neri carried the blue token past marker 91f047ec5d9a. Mara watched the eastern gate until dawn.

Ledger 37 line 102: Neri carried the blue token past marker dfd654663983. Mara watched the eastern gate until dawn.

Ledger 37 line 103: Neri carried the blue token past marker 25b40589a864. Mara watched the eastern gate until dawn.

Ledger 37 line 104: Neri carried the blue token past marker 2af81f8fee02. Mara watched the eastern gate until dawn.

Ledger 37 line 105: Neri carried the blue token past marker 9fe020e9a91e. Mara watched the eastern gate until dawn.

Ledger 37 line 106: Neri carried the blue token past marker 40c3528af522. Mara watched the eastern gate until dawn.

Ledger 37 line 107: Neri carried the blue token past marker cd678df0fc51. Mara watched the eastern gate until dawn.

Ledger 37 line 108: Neri carried the blue token past marker 11aa67e2511c. Mara watched the eastern gate until dawn.

Ledger 37 line 109: Neri carried the blue token past marker 2feb0b29d427. Mara watched the eastern gate until dawn.

Ledger 37 line 110: Neri carried the blue token past marker 3d35dd4d9b69. Mara watched the eastern gate until dawn.

Ledger 37 line 111: Neri carried the blue token past marker 838b0ce1a064. Mara watched the eastern gate until dawn.

Ledger 37 line 112: Neri carried the blue token past marker bf8cc2ee1542. Mara watched the eastern gate until dawn.

Ledger 37 line 113: Neri carried the blue token past marker 223ef625d1ee. Mara watched the eastern gate until dawn.

Ledger 37 line 114: Neri carried the blue token past marker 575fb257a477. Mara watched the eastern gate until dawn.

Ledger 37 line 115: Neri carried the blue token past marker 09168ae08004. Mara watched the eastern gate until dawn.

Ledger 37 line 116: Neri carried the blue token past marker 4be0ac639d05. Mara watched the eastern gate until dawn.

Ledger 37 line 117: Neri carried the blue token past marker 5ea35c803150. Mara watched the eastern gate until dawn.

Ledger 37 line 118: Neri carried the blue token past marker 050414b4d59d. Mara watched the eastern gate until dawn.

Ledger 37 line 119: Neri carried the blue token past marker 27f1dff03438. Mara watched the eastern gate until dawn.

Ledger 37 line 120: Neri carried the blue token past marker 86e39d9c7712. Mara watched the eastern gate until dawn.

Ledger 37 line 121: Neri carried the blue token past marker 529b34ae5c8b. Mara watched the eastern gate until dawn.

Ledger 37 line 122: Neri carried the blue token past marker 3750aec66dac. Mara watched the eastern gate until dawn.

Ledger 37 line 123: Neri carried the blue token past marker 078ebddfd471. Mara watched the eastern gate until dawn.

Ledger 37 line 124: Neri carried the blue token past marker 276a5ea91135. Mara watched the eastern gate until dawn.

Ledger 37 line 125: Neri carried the blue token past marker bcbfa5ef6245. Mara watched the eastern gate until dawn.

Ledger 37 line 126: Neri carried the blue token past marker 327161aa2c89. Mara watched the eastern gate until dawn.

Ledger 37 line 127: Neri carried the blue token past marker bef071cf7ab8. Mara watched the eastern gate until dawn.

Ledger 37 line 128: Neri carried the blue token past marker f80997bee999. Mara watched the eastern gate until dawn.

Ledger 37 line 129: Neri carried the blue token past marker 9e1dedf2a487. Mara watched the eastern gate until dawn.

Ledger 37 line 130: Neri carried the blue token past marker 820504b00133. Mara watched the eastern gate until dawn.

Ledger 37 line 131: Neri carried the blue token past marker 640d8d00148b. Mara watched the eastern gate until dawn.

Ledger 37 line 132: Neri carried the blue token past marker acb3c9f15717. Mara watched the eastern gate until dawn.

Ledger 37 line 133: Neri carried the blue token past marker c4aad1e2112b. Mara watched the eastern gate until dawn.

Ledger 37 line 134: Neri carried the blue token past marker c5fe94981ff1. Mara watched the eastern gate until dawn.

Ledger 37 line 135: Neri carried the blue token past marker 8d00017c0346. Mara watched the eastern gate until dawn.

Ledger 37 line 136: Neri carried the blue token past marker 5eb35842cd97. Mara watched the eastern gate until dawn.

Ledger 37 line 137: Neri carried the blue token past marker db56ddc64c9e. Mara watched the eastern gate until dawn.

Ledger 37 line 138: Neri carried the blue token past marker 00302a8e5bae. Mara watched the eastern gate until dawn.

Ledger 37 line 139: Neri carried the blue token past marker 3bd842b9a245. Mara watched the eastern gate until dawn.

Ledger 37 line 140: Neri carried the blue token past marker 27fcc3e2070c. Mara watched the eastern gate until dawn.
