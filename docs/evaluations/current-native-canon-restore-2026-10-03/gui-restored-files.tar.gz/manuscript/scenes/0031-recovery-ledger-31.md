---
id: scene-0031
title: Recovery ledger 31
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.169205+00:00
updated_at: 2026-10-03T12:14:52.169205+00:00
---

Ledger 31 line 001: Neri carried the blue token past marker 527eb46fefab. Mara watched the eastern gate until dawn.

Ledger 31 line 002: Neri carried the blue token past marker d2c823470ab5. Mara watched the eastern gate until dawn.

Ledger 31 line 003: Neri carried the blue token past marker c44e0a8027d9. Mara watched the eastern gate until dawn.

Ledger 31 line 004: Neri carried the blue token past marker b463aa22ad44. Mara watched the eastern gate until dawn.

Ledger 31 line 005: Neri carried the blue token past marker d96e99008f9f. Mara watched the eastern gate until dawn.

Ledger 31 line 006: Neri carried the blue token past marker 859f14a643cd. Mara watched the eastern gate until dawn.

Ledger 31 line 007: Neri carried the blue token past marker 81d6ff96f83b. Mara watched the eastern gate until dawn.

Ledger 31 line 008: Neri carried the blue token past marker aff8f6fc8b3c. Mara watched the eastern gate until dawn.

Ledger 31 line 009: Neri carried the blue token past marker 86ac2c27d654. Mara watched the eastern gate until dawn.

Ledger 31 line 010: Neri carried the blue token past marker ace932440e34. Mara watched the eastern gate until dawn.

Ledger 31 line 011: Neri carried the blue token past marker fb8e86d857cd. Mara watched the eastern gate until dawn.

Ledger 31 line 012: Neri carried the blue token past marker a539c51fe246. Mara watched the eastern gate until dawn.

Ledger 31 line 013: Neri carried the blue token past marker 2ad737ebcb04. Mara watched the eastern gate until dawn.

Ledger 31 line 014: Neri carried the blue token past marker d2ce711e8f3a. Mara watched the eastern gate until dawn.

Ledger 31 line 015: Neri carried the blue token past marker 34101e6bf73c. Mara watched the eastern gate until dawn.

Ledger 31 line 016: Neri carried the blue token past marker 4b5728561e60. Mara watched the eastern gate until dawn.

Ledger 31 line 017: Neri carried the blue token past marker 1c67d1b5fcff. Mara watched the eastern gate until dawn.

Ledger 31 line 018: Neri carried the blue token past marker 46d0ba616a8e. Mara watched the eastern gate until dawn.

Ledger 31 line 019: Neri carried the blue token past marker fc7150053a84. Mara watched the eastern gate until dawn.

Ledger 31 line 020: Neri carried the blue token past marker ab38d3fad9f7. Mara watched the eastern gate until dawn.

Ledger 31 line 021: Neri carried the blue token past marker 8942c2c22e94. Mara watched the eastern gate until dawn.

Ledger 31 line 022: Neri carried the blue token past marker e188a3912fa2. Mara watched the eastern gate until dawn.

Ledger 31 line 023: Neri carried the blue token past marker d6b7b4e2601f. Mara watched the eastern gate until dawn.

Ledger 31 line 024: Neri carried the blue token past marker c478e460e0be. Mara watched the eastern gate until dawn.

Ledger 31 line 025: Neri carried the blue token past marker e5e507650dba. Mara watched the eastern gate until dawn.

Ledger 31 line 026: Neri carried the blue token past marker 10c34f6891f3. Mara watched the eastern gate until dawn.

Ledger 31 line 027: Neri carried the blue token past marker baadf24a0e8f. Mara watched the eastern gate until dawn.

Ledger 31 line 028: Neri carried the blue token past marker 3212b2af5aab. Mara watched the eastern gate until dawn.

Ledger 31 line 029: Neri carried the blue token past marker 07845486261d. Mara watched the eastern gate until dawn.

Ledger 31 line 030: Neri carried the blue token past marker 09754ee297e4. Mara watched the eastern gate until dawn.

Ledger 31 line 031: Neri carried the blue token past marker 19584a9e83af. Mara watched the eastern gate until dawn.

Ledger 31 line 032: Neri carried the blue token past marker 7b819e0b6fd2. Mara watched the eastern gate until dawn.

Ledger 31 line 033: Neri carried the blue token past marker ad1d0ccd3c4d. Mara watched the eastern gate until dawn.

Ledger 31 line 034: Neri carried the blue token past marker 4f436592d468. Mara watched the eastern gate until dawn.

Ledger 31 line 035: Neri carried the blue token past marker d828aeab16b7. Mara watched the eastern gate until dawn.

Ledger 31 line 036: Neri carried the blue token past marker 71a6aa039df3. Mara watched the eastern gate until dawn.

Ledger 31 line 037: Neri carried the blue token past marker ed5f3950cff1. Mara watched the eastern gate until dawn.

Ledger 31 line 038: Neri carried the blue token past marker 076c04daf107. Mara watched the eastern gate until dawn.

Ledger 31 line 039: Neri carried the blue token past marker 763f75c81884. Mara watched the eastern gate until dawn.

Ledger 31 line 040: Neri carried the blue token past marker 99672a9ef409. Mara watched the eastern gate until dawn.

Ledger 31 line 041: Neri carried the blue token past marker 95e04155380b. Mara watched the eastern gate until dawn.

Ledger 31 line 042: Neri carried the blue token past marker 38687644ab2f. Mara watched the eastern gate until dawn.

Ledger 31 line 043: Neri carried the blue token past marker af6b0384a7b7. Mara watched the eastern gate until dawn.

Ledger 31 line 044: Neri carried the blue token past marker dcb01b4f1fa4. Mara watched the eastern gate until dawn.

Ledger 31 line 045: Neri carried the blue token past marker 7d68241859be. Mara watched the eastern gate until dawn.

Ledger 31 line 046: Neri carried the blue token past marker 3e66edf21833. Mara watched the eastern gate until dawn.

Ledger 31 line 047: Neri carried the blue token past marker d8d50fbf5073. Mara watched the eastern gate until dawn.

Ledger 31 line 048: Neri carried the blue token past marker 77e0b0b86906. Mara watched the eastern gate until dawn.

Ledger 31 line 049: Neri carried the blue token past marker 0aa8d898a406. Mara watched the eastern gate until dawn.

Ledger 31 line 050: Neri carried the blue token past marker e52ce17673ba. Mara watched the eastern gate until dawn.

Ledger 31 line 051: Neri carried the blue token past marker 7eda28d30793. Mara watched the eastern gate until dawn.

Ledger 31 line 052: Neri carried the blue token past marker 129c11eeb9d5. Mara watched the eastern gate until dawn.

Ledger 31 line 053: Neri carried the blue token past marker 748770ce50f4. Mara watched the eastern gate until dawn.

Ledger 31 line 054: Neri carried the blue token past marker 742e6383a72d. Mara watched the eastern gate until dawn.

Ledger 31 line 055: Neri carried the blue token past marker 10f38c1a26f6. Mara watched the eastern gate until dawn.

Ledger 31 line 056: Neri carried the blue token past marker 00d37a73c48b. Mara watched the eastern gate until dawn.

Ledger 31 line 057: Neri carried the blue token past marker 04875f746d63. Mara watched the eastern gate until dawn.

Ledger 31 line 058: Neri carried the blue token past marker 8ff3db420159. Mara watched the eastern gate until dawn.

Ledger 31 line 059: Neri carried the blue token past marker 65211e992cb7. Mara watched the eastern gate until dawn.

Ledger 31 line 060: Neri carried the blue token past marker 1e102b9f5812. Mara watched the eastern gate until dawn.

Ledger 31 line 061: Neri carried the blue token past marker 1a8064621023. Mara watched the eastern gate until dawn.

Ledger 31 line 062: Neri carried the blue token past marker 780c85e1abc1. Mara watched the eastern gate until dawn.

Ledger 31 line 063: Neri carried the blue token past marker 6092da7b0d72. Mara watched the eastern gate until dawn.

Ledger 31 line 064: Neri carried the blue token past marker 8a5ae90a2c52. Mara watched the eastern gate until dawn.

Ledger 31 line 065: Neri carried the blue token past marker a7fbe5c2dfc9. Mara watched the eastern gate until dawn.

Ledger 31 line 066: Neri carried the blue token past marker c6c178eccda2. Mara watched the eastern gate until dawn.

Ledger 31 line 067: Neri carried the blue token past marker 9381eb01867a. Mara watched the eastern gate until dawn.

Ledger 31 line 068: Neri carried the blue token past marker 359a2bcd7001. Mara watched the eastern gate until dawn.

Ledger 31 line 069: Neri carried the blue token past marker 4e80e573b730. Mara watched the eastern gate until dawn.

Ledger 31 line 070: Neri carried the blue token past marker a87dc0c502f4. Mara watched the eastern gate until dawn.

Ledger 31 line 071: Neri carried the blue token past marker 22aa1e68c1f1. Mara watched the eastern gate until dawn.

Ledger 31 line 072: Neri carried the blue token past marker 6cfbc7708070. Mara watched the eastern gate until dawn.

Ledger 31 line 073: Neri carried the blue token past marker 227ec3fee4aa. Mara watched the eastern gate until dawn.

Ledger 31 line 074: Neri carried the blue token past marker 2e0be722d310. Mara watched the eastern gate until dawn.

Ledger 31 line 075: Neri carried the blue token past marker b0b3dbb60625. Mara watched the eastern gate until dawn.

Ledger 31 line 076: Neri carried the blue token past marker a3800b82c5e2. Mara watched the eastern gate until dawn.

Ledger 31 line 077: Neri carried the blue token past marker 01eaa0e38897. Mara watched the eastern gate until dawn.

Ledger 31 line 078: Neri carried the blue token past marker adc45b05860e. Mara watched the eastern gate until dawn.

Ledger 31 line 079: Neri carried the blue token past marker 8995f55077b7. Mara watched the eastern gate until dawn.

Ledger 31 line 080: Neri carried the blue token past marker 67e4a901a9e0. Mara watched the eastern gate until dawn.

Ledger 31 line 081: Neri carried the blue token past marker 5ab68a7a4f0d. Mara watched the eastern gate until dawn.

Ledger 31 line 082: Neri carried the blue token past marker dd4636c60c99. Mara watched the eastern gate until dawn.

Ledger 31 line 083: Neri carried the blue token past marker 9ac4a4132149. Mara watched the eastern gate until dawn.

Ledger 31 line 084: Neri carried the blue token past marker 023884e0b06b. Mara watched the eastern gate until dawn.

Ledger 31 line 085: Neri carried the blue token past marker 089845136417. Mara watched the eastern gate until dawn.

Ledger 31 line 086: Neri carried the blue token past marker 5cc9d8f012d2. Mara watched the eastern gate until dawn.

Ledger 31 line 087: Neri carried the blue token past marker 95312fc2a88f. Mara watched the eastern gate until dawn.

Ledger 31 line 088: Neri carried the blue token past marker ab9ede2c3c04. Mara watched the eastern gate until dawn.

Ledger 31 line 089: Neri carried the blue token past marker e54f4df50e04. Mara watched the eastern gate until dawn.

Ledger 31 line 090: Neri carried the blue token past marker 08ebb316d8c5. Mara watched the eastern gate until dawn.

Ledger 31 line 091: Neri carried the blue token past marker 4af5cc5bd7e9. Mara watched the eastern gate until dawn.

Ledger 31 line 092: Neri carried the blue token past marker 7723f7964bd5. Mara watched the eastern gate until dawn.

Ledger 31 line 093: Neri carried the blue token past marker 753af51c7758. Mara watched the eastern gate until dawn.

Ledger 31 line 094: Neri carried the blue token past marker 1ff5f67d1a3a. Mara watched the eastern gate until dawn.

Ledger 31 line 095: Neri carried the blue token past marker f48f27f43557. Mara watched the eastern gate until dawn.

Ledger 31 line 096: Neri carried the blue token past marker 8bbf765b28e7. Mara watched the eastern gate until dawn.

Ledger 31 line 097: Neri carried the blue token past marker 6448f27c0dc1. Mara watched the eastern gate until dawn.

Ledger 31 line 098: Neri carried the blue token past marker ae43e4d8d66b. Mara watched the eastern gate until dawn.

Ledger 31 line 099: Neri carried the blue token past marker d66a653df4ca. Mara watched the eastern gate until dawn.

Ledger 31 line 100: Neri carried the blue token past marker 18b4d1063c33. Mara watched the eastern gate until dawn.

Ledger 31 line 101: Neri carried the blue token past marker 46e542625e6f. Mara watched the eastern gate until dawn.

Ledger 31 line 102: Neri carried the blue token past marker fef7edee60a5. Mara watched the eastern gate until dawn.

Ledger 31 line 103: Neri carried the blue token past marker 8692ed07b0bd. Mara watched the eastern gate until dawn.

Ledger 31 line 104: Neri carried the blue token past marker 0e00db64379d. Mara watched the eastern gate until dawn.

Ledger 31 line 105: Neri carried the blue token past marker 07478bbe8ab0. Mara watched the eastern gate until dawn.

Ledger 31 line 106: Neri carried the blue token past marker 5d01297c8d23. Mara watched the eastern gate until dawn.

Ledger 31 line 107: Neri carried the blue token past marker 23d132ca064c. Mara watched the eastern gate until dawn.

Ledger 31 line 108: Neri carried the blue token past marker 8cb8b0b1b2de. Mara watched the eastern gate until dawn.

Ledger 31 line 109: Neri carried the blue token past marker ac290382ade8. Mara watched the eastern gate until dawn.

Ledger 31 line 110: Neri carried the blue token past marker 9cfcf1d79a30. Mara watched the eastern gate until dawn.

Ledger 31 line 111: Neri carried the blue token past marker 8344fc29ef54. Mara watched the eastern gate until dawn.

Ledger 31 line 112: Neri carried the blue token past marker 0386f3e987c3. Mara watched the eastern gate until dawn.

Ledger 31 line 113: Neri carried the blue token past marker f624c333b686. Mara watched the eastern gate until dawn.

Ledger 31 line 114: Neri carried the blue token past marker 80ec413a245c. Mara watched the eastern gate until dawn.

Ledger 31 line 115: Neri carried the blue token past marker e2e2f035f24d. Mara watched the eastern gate until dawn.

Ledger 31 line 116: Neri carried the blue token past marker 280bc16da282. Mara watched the eastern gate until dawn.

Ledger 31 line 117: Neri carried the blue token past marker 7ac48807de94. Mara watched the eastern gate until dawn.

Ledger 31 line 118: Neri carried the blue token past marker 2ed30335fe70. Mara watched the eastern gate until dawn.

Ledger 31 line 119: Neri carried the blue token past marker 48ed8f679826. Mara watched the eastern gate until dawn.

Ledger 31 line 120: Neri carried the blue token past marker 6fb1e678d90a. Mara watched the eastern gate until dawn.

Ledger 31 line 121: Neri carried the blue token past marker ba7106dc003f. Mara watched the eastern gate until dawn.

Ledger 31 line 122: Neri carried the blue token past marker b6662dfb607c. Mara watched the eastern gate until dawn.

Ledger 31 line 123: Neri carried the blue token past marker fc537100d676. Mara watched the eastern gate until dawn.

Ledger 31 line 124: Neri carried the blue token past marker e74c60df94e3. Mara watched the eastern gate until dawn.

Ledger 31 line 125: Neri carried the blue token past marker 9b298bf5f177. Mara watched the eastern gate until dawn.

Ledger 31 line 126: Neri carried the blue token past marker 1403bf5e53bb. Mara watched the eastern gate until dawn.

Ledger 31 line 127: Neri carried the blue token past marker f7df3bcacbbc. Mara watched the eastern gate until dawn.

Ledger 31 line 128: Neri carried the blue token past marker af82c2824819. Mara watched the eastern gate until dawn.

Ledger 31 line 129: Neri carried the blue token past marker 76f80b710425. Mara watched the eastern gate until dawn.

Ledger 31 line 130: Neri carried the blue token past marker b49c6068ca21. Mara watched the eastern gate until dawn.

Ledger 31 line 131: Neri carried the blue token past marker 73bb1c2d2d4d. Mara watched the eastern gate until dawn.

Ledger 31 line 132: Neri carried the blue token past marker 402ffaabe4b0. Mara watched the eastern gate until dawn.

Ledger 31 line 133: Neri carried the blue token past marker 0824d05ec397. Mara watched the eastern gate until dawn.

Ledger 31 line 134: Neri carried the blue token past marker 0b47e117d310. Mara watched the eastern gate until dawn.

Ledger 31 line 135: Neri carried the blue token past marker 5be67a02042b. Mara watched the eastern gate until dawn.

Ledger 31 line 136: Neri carried the blue token past marker e2d9ffd38677. Mara watched the eastern gate until dawn.

Ledger 31 line 137: Neri carried the blue token past marker a9a60f940543. Mara watched the eastern gate until dawn.

Ledger 31 line 138: Neri carried the blue token past marker ce281e6eff9e. Mara watched the eastern gate until dawn.

Ledger 31 line 139: Neri carried the blue token past marker d573ee451786. Mara watched the eastern gate until dawn.

Ledger 31 line 140: Neri carried the blue token past marker 83a3958d3f48. Mara watched the eastern gate until dawn.
