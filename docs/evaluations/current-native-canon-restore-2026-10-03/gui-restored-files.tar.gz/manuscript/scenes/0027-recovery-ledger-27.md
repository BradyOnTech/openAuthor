---
id: scene-0027
title: Recovery ledger 27
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.166958+00:00
updated_at: 2026-10-03T12:14:52.166958+00:00
---

Ledger 27 line 001: Neri carried the blue token past marker 0d8ca7836ad7. Mara watched the eastern gate until dawn.

Ledger 27 line 002: Neri carried the blue token past marker 232a49b82891. Mara watched the eastern gate until dawn.

Ledger 27 line 003: Neri carried the blue token past marker 87493f1ddb38. Mara watched the eastern gate until dawn.

Ledger 27 line 004: Neri carried the blue token past marker 6667ce351fd1. Mara watched the eastern gate until dawn.

Ledger 27 line 005: Neri carried the blue token past marker ddbcc84cd3be. Mara watched the eastern gate until dawn.

Ledger 27 line 006: Neri carried the blue token past marker 175250c03ec9. Mara watched the eastern gate until dawn.

Ledger 27 line 007: Neri carried the blue token past marker a8b2a85f41ca. Mara watched the eastern gate until dawn.

Ledger 27 line 008: Neri carried the blue token past marker 8f0ebbd9bdb4. Mara watched the eastern gate until dawn.

Ledger 27 line 009: Neri carried the blue token past marker 21fbd4d3b5c9. Mara watched the eastern gate until dawn.

Ledger 27 line 010: Neri carried the blue token past marker 6398be4e4cf3. Mara watched the eastern gate until dawn.

Ledger 27 line 011: Neri carried the blue token past marker 17e2c48e26dc. Mara watched the eastern gate until dawn.

Ledger 27 line 012: Neri carried the blue token past marker db964e076aca. Mara watched the eastern gate until dawn.

Ledger 27 line 013: Neri carried the blue token past marker 9eb9dfb954f0. Mara watched the eastern gate until dawn.

Ledger 27 line 014: Neri carried the blue token past marker 427b38d5fae4. Mara watched the eastern gate until dawn.

Ledger 27 line 015: Neri carried the blue token past marker 94dab9537cd3. Mara watched the eastern gate until dawn.

Ledger 27 line 016: Neri carried the blue token past marker f823fe6eee2d. Mara watched the eastern gate until dawn.

Ledger 27 line 017: Neri carried the blue token past marker b67950e455a3. Mara watched the eastern gate until dawn.

Ledger 27 line 018: Neri carried the blue token past marker e4549e1b92ed. Mara watched the eastern gate until dawn.

Ledger 27 line 019: Neri carried the blue token past marker f5fec19ac824. Mara watched the eastern gate until dawn.

Ledger 27 line 020: Neri carried the blue token past marker ee06ce140056. Mara watched the eastern gate until dawn.

Ledger 27 line 021: Neri carried the blue token past marker 4ffb993c6728. Mara watched the eastern gate until dawn.

Ledger 27 line 022: Neri carried the blue token past marker 8187acf73ad2. Mara watched the eastern gate until dawn.

Ledger 27 line 023: Neri carried the blue token past marker b5a6f1ef45df. Mara watched the eastern gate until dawn.

Ledger 27 line 024: Neri carried the blue token past marker 29ae52e82122. Mara watched the eastern gate until dawn.

Ledger 27 line 025: Neri carried the blue token past marker b96abbe5d67b. Mara watched the eastern gate until dawn.

Ledger 27 line 026: Neri carried the blue token past marker 6f252d80481b. Mara watched the eastern gate until dawn.

Ledger 27 line 027: Neri carried the blue token past marker 7ed34e79d1d0. Mara watched the eastern gate until dawn.

Ledger 27 line 028: Neri carried the blue token past marker aa1b4f270520. Mara watched the eastern gate until dawn.

Ledger 27 line 029: Neri carried the blue token past marker 0db2c87a42f3. Mara watched the eastern gate until dawn.

Ledger 27 line 030: Neri carried the blue token past marker 7df963c4a23d. Mara watched the eastern gate until dawn.

Ledger 27 line 031: Neri carried the blue token past marker a0396ba02d7c. Mara watched the eastern gate until dawn.

Ledger 27 line 032: Neri carried the blue token past marker 4211f6012dbf. Mara watched the eastern gate until dawn.

Ledger 27 line 033: Neri carried the blue token past marker 61b8da067216. Mara watched the eastern gate until dawn.

Ledger 27 line 034: Neri carried the blue token past marker b8ac8550a049. Mara watched the eastern gate until dawn.

Ledger 27 line 035: Neri carried the blue token past marker ac6936c8730d. Mara watched the eastern gate until dawn.

Ledger 27 line 036: Neri carried the blue token past marker 82ffcc22c27c. Mara watched the eastern gate until dawn.

Ledger 27 line 037: Neri carried the blue token past marker 04672168cd38. Mara watched the eastern gate until dawn.

Ledger 27 line 038: Neri carried the blue token past marker 47083d294f54. Mara watched the eastern gate until dawn.

Ledger 27 line 039: Neri carried the blue token past marker 84028ad8ce34. Mara watched the eastern gate until dawn.

Ledger 27 line 040: Neri carried the blue token past marker 4fed9ca69ef7. Mara watched the eastern gate until dawn.

Ledger 27 line 041: Neri carried the blue token past marker 8ef32eb27bd6. Mara watched the eastern gate until dawn.

Ledger 27 line 042: Neri carried the blue token past marker a77ceeed611c. Mara watched the eastern gate until dawn.

Ledger 27 line 043: Neri carried the blue token past marker 7f4b1caab460. Mara watched the eastern gate until dawn.

Ledger 27 line 044: Neri carried the blue token past marker 00392dc33334. Mara watched the eastern gate until dawn.

Ledger 27 line 045: Neri carried the blue token past marker fc3fcc519eca. Mara watched the eastern gate until dawn.

Ledger 27 line 046: Neri carried the blue token past marker 54058d9398de. Mara watched the eastern gate until dawn.

Ledger 27 line 047: Neri carried the blue token past marker 26838bf65968. Mara watched the eastern gate until dawn.

Ledger 27 line 048: Neri carried the blue token past marker 466ef9a79884. Mara watched the eastern gate until dawn.

Ledger 27 line 049: Neri carried the blue token past marker 3c0678a31722. Mara watched the eastern gate until dawn.

Ledger 27 line 050: Neri carried the blue token past marker e7a3d5c760e5. Mara watched the eastern gate until dawn.

Ledger 27 line 051: Neri carried the blue token past marker 2c8d51bdcdf3. Mara watched the eastern gate until dawn.

Ledger 27 line 052: Neri carried the blue token past marker df43bb6f7a1b. Mara watched the eastern gate until dawn.

Ledger 27 line 053: Neri carried the blue token past marker 50fc93ddcfdc. Mara watched the eastern gate until dawn.

Ledger 27 line 054: Neri carried the blue token past marker dbf84084d16b. Mara watched the eastern gate until dawn.

Ledger 27 line 055: Neri carried the blue token past marker cb7b7d586ef8. Mara watched the eastern gate until dawn.

Ledger 27 line 056: Neri carried the blue token past marker 23f14d883707. Mara watched the eastern gate until dawn.

Ledger 27 line 057: Neri carried the blue token past marker f6a8e31f4c24. Mara watched the eastern gate until dawn.

Ledger 27 line 058: Neri carried the blue token past marker 00e51c93fcb2. Mara watched the eastern gate until dawn.

Ledger 27 line 059: Neri carried the blue token past marker a76f77b8d662. Mara watched the eastern gate until dawn.

Ledger 27 line 060: Neri carried the blue token past marker d598e80b432b. Mara watched the eastern gate until dawn.

Ledger 27 line 061: Neri carried the blue token past marker 08cff4841d81. Mara watched the eastern gate until dawn.

Ledger 27 line 062: Neri carried the blue token past marker 2588aeb7273f. Mara watched the eastern gate until dawn.

Ledger 27 line 063: Neri carried the blue token past marker 897137a48a33. Mara watched the eastern gate until dawn.

Ledger 27 line 064: Neri carried the blue token past marker b3f306efe42b. Mara watched the eastern gate until dawn.

Ledger 27 line 065: Neri carried the blue token past marker 07a0d5e7221e. Mara watched the eastern gate until dawn.

Ledger 27 line 066: Neri carried the blue token past marker 5c2d22fd6599. Mara watched the eastern gate until dawn.

Ledger 27 line 067: Neri carried the blue token past marker cb0cfb5960e6. Mara watched the eastern gate until dawn.

Ledger 27 line 068: Neri carried the blue token past marker 7abe609f0276. Mara watched the eastern gate until dawn.

Ledger 27 line 069: Neri carried the blue token past marker ca2a46cce95a. Mara watched the eastern gate until dawn.

Ledger 27 line 070: Neri carried the blue token past marker 755180bb3662. Mara watched the eastern gate until dawn.

Ledger 27 line 071: Neri carried the blue token past marker ebee7e8aa4fe. Mara watched the eastern gate until dawn.

Ledger 27 line 072: Neri carried the blue token past marker d225767bde6a. Mara watched the eastern gate until dawn.

Ledger 27 line 073: Neri carried the blue token past marker 10e2e2ed148c. Mara watched the eastern gate until dawn.

Ledger 27 line 074: Neri carried the blue token past marker d84057129a1f. Mara watched the eastern gate until dawn.

Ledger 27 line 075: Neri carried the blue token past marker b4484e6dde29. Mara watched the eastern gate until dawn.

Ledger 27 line 076: Neri carried the blue token past marker 5c35d29fb254. Mara watched the eastern gate until dawn.

Ledger 27 line 077: Neri carried the blue token past marker ee3ee283cabc. Mara watched the eastern gate until dawn.

Ledger 27 line 078: Neri carried the blue token past marker c658678faa8f. Mara watched the eastern gate until dawn.

Ledger 27 line 079: Neri carried the blue token past marker 55b6f273007f. Mara watched the eastern gate until dawn.

Ledger 27 line 080: Neri carried the blue token past marker 2c2642cdd13f. Mara watched the eastern gate until dawn.

Ledger 27 line 081: Neri carried the blue token past marker e8da049e5866. Mara watched the eastern gate until dawn.

Ledger 27 line 082: Neri carried the blue token past marker bcc0baf3fcd5. Mara watched the eastern gate until dawn.

Ledger 27 line 083: Neri carried the blue token past marker 2cafc8c389fd. Mara watched the eastern gate until dawn.

Ledger 27 line 084: Neri carried the blue token past marker 22c564d0695a. Mara watched the eastern gate until dawn.

Ledger 27 line 085: Neri carried the blue token past marker 6c198a838bb2. Mara watched the eastern gate until dawn.

Ledger 27 line 086: Neri carried the blue token past marker 7d8b1f7ae37b. Mara watched the eastern gate until dawn.

Ledger 27 line 087: Neri carried the blue token past marker 1dc1c9c28b67. Mara watched the eastern gate until dawn.

Ledger 27 line 088: Neri carried the blue token past marker efba50f1083a. Mara watched the eastern gate until dawn.

Ledger 27 line 089: Neri carried the blue token past marker 35da05d4aa35. Mara watched the eastern gate until dawn.

Ledger 27 line 090: Neri carried the blue token past marker 5242e16503f8. Mara watched the eastern gate until dawn.

Ledger 27 line 091: Neri carried the blue token past marker 83056396e39c. Mara watched the eastern gate until dawn.

Ledger 27 line 092: Neri carried the blue token past marker dd5830d3433d. Mara watched the eastern gate until dawn.

Ledger 27 line 093: Neri carried the blue token past marker 7d100d8412ce. Mara watched the eastern gate until dawn.

Ledger 27 line 094: Neri carried the blue token past marker 131a0f170c71. Mara watched the eastern gate until dawn.

Ledger 27 line 095: Neri carried the blue token past marker 38e4f22010b0. Mara watched the eastern gate until dawn.

Ledger 27 line 096: Neri carried the blue token past marker 06e7cc1cb5bc. Mara watched the eastern gate until dawn.

Ledger 27 line 097: Neri carried the blue token past marker b71eec2ec478. Mara watched the eastern gate until dawn.

Ledger 27 line 098: Neri carried the blue token past marker 6e66fafa6762. Mara watched the eastern gate until dawn.

Ledger 27 line 099: Neri carried the blue token past marker 7ef51e6bf92f. Mara watched the eastern gate until dawn.

Ledger 27 line 100: Neri carried the blue token past marker 1e049a7a3e3c. Mara watched the eastern gate until dawn.

Ledger 27 line 101: Neri carried the blue token past marker a9b4530ca453. Mara watched the eastern gate until dawn.

Ledger 27 line 102: Neri carried the blue token past marker d8710dddffcc. Mara watched the eastern gate until dawn.

Ledger 27 line 103: Neri carried the blue token past marker f53a5dba3760. Mara watched the eastern gate until dawn.

Ledger 27 line 104: Neri carried the blue token past marker 0b719d8346b1. Mara watched the eastern gate until dawn.

Ledger 27 line 105: Neri carried the blue token past marker c623b4c48f37. Mara watched the eastern gate until dawn.

Ledger 27 line 106: Neri carried the blue token past marker 38248ebafbfa. Mara watched the eastern gate until dawn.

Ledger 27 line 107: Neri carried the blue token past marker a62334cec717. Mara watched the eastern gate until dawn.

Ledger 27 line 108: Neri carried the blue token past marker fd557e088a9c. Mara watched the eastern gate until dawn.

Ledger 27 line 109: Neri carried the blue token past marker f1019598bf0e. Mara watched the eastern gate until dawn.

Ledger 27 line 110: Neri carried the blue token past marker ca8395675e61. Mara watched the eastern gate until dawn.

Ledger 27 line 111: Neri carried the blue token past marker 4d20386c60a4. Mara watched the eastern gate until dawn.

Ledger 27 line 112: Neri carried the blue token past marker 30029d8d6952. Mara watched the eastern gate until dawn.

Ledger 27 line 113: Neri carried the blue token past marker 94d64f2290ca. Mara watched the eastern gate until dawn.

Ledger 27 line 114: Neri carried the blue token past marker 07e5b0e0873b. Mara watched the eastern gate until dawn.

Ledger 27 line 115: Neri carried the blue token past marker 3e86279ab49b. Mara watched the eastern gate until dawn.

Ledger 27 line 116: Neri carried the blue token past marker 8edbe27427ca. Mara watched the eastern gate until dawn.

Ledger 27 line 117: Neri carried the blue token past marker 6fb6c490b045. Mara watched the eastern gate until dawn.

Ledger 27 line 118: Neri carried the blue token past marker 32f7edd5cbcf. Mara watched the eastern gate until dawn.

Ledger 27 line 119: Neri carried the blue token past marker 79afe90d2853. Mara watched the eastern gate until dawn.

Ledger 27 line 120: Neri carried the blue token past marker a8b45281cce3. Mara watched the eastern gate until dawn.

Ledger 27 line 121: Neri carried the blue token past marker 32ff61e4148b. Mara watched the eastern gate until dawn.

Ledger 27 line 122: Neri carried the blue token past marker db2001e2cb52. Mara watched the eastern gate until dawn.

Ledger 27 line 123: Neri carried the blue token past marker 3c0ddc2fabee. Mara watched the eastern gate until dawn.

Ledger 27 line 124: Neri carried the blue token past marker 23da8efc462e. Mara watched the eastern gate until dawn.

Ledger 27 line 125: Neri carried the blue token past marker f86c643be115. Mara watched the eastern gate until dawn.

Ledger 27 line 126: Neri carried the blue token past marker cd796817084f. Mara watched the eastern gate until dawn.

Ledger 27 line 127: Neri carried the blue token past marker 1ca636ff4734. Mara watched the eastern gate until dawn.

Ledger 27 line 128: Neri carried the blue token past marker c0512d5f14ba. Mara watched the eastern gate until dawn.

Ledger 27 line 129: Neri carried the blue token past marker 9cf8d19a699e. Mara watched the eastern gate until dawn.

Ledger 27 line 130: Neri carried the blue token past marker 5c5b9bf74e67. Mara watched the eastern gate until dawn.

Ledger 27 line 131: Neri carried the blue token past marker 534a7f71d65b. Mara watched the eastern gate until dawn.

Ledger 27 line 132: Neri carried the blue token past marker 7f0b0862a96d. Mara watched the eastern gate until dawn.

Ledger 27 line 133: Neri carried the blue token past marker 40d6c9b08805. Mara watched the eastern gate until dawn.

Ledger 27 line 134: Neri carried the blue token past marker 1d3869664e46. Mara watched the eastern gate until dawn.

Ledger 27 line 135: Neri carried the blue token past marker dbab231ce052. Mara watched the eastern gate until dawn.

Ledger 27 line 136: Neri carried the blue token past marker b708e5a12d65. Mara watched the eastern gate until dawn.

Ledger 27 line 137: Neri carried the blue token past marker 965148f31ebb. Mara watched the eastern gate until dawn.

Ledger 27 line 138: Neri carried the blue token past marker 0bba083c9aac. Mara watched the eastern gate until dawn.

Ledger 27 line 139: Neri carried the blue token past marker 5970a0927a3d. Mara watched the eastern gate until dawn.

Ledger 27 line 140: Neri carried the blue token past marker 36bfdf11990a. Mara watched the eastern gate until dawn.
