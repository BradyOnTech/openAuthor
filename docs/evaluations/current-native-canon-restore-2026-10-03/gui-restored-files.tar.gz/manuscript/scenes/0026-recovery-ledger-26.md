---
id: scene-0026
title: Recovery ledger 26
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.166468+00:00
updated_at: 2026-10-03T12:14:52.166468+00:00
---

Ledger 26 line 001: Neri carried the blue token past marker 5e2f1bafa654. Mara watched the eastern gate until dawn.

Ledger 26 line 002: Neri carried the blue token past marker 22b2e5451506. Mara watched the eastern gate until dawn.

Ledger 26 line 003: Neri carried the blue token past marker 6f3a05213f73. Mara watched the eastern gate until dawn.

Ledger 26 line 004: Neri carried the blue token past marker fccc27a4184a. Mara watched the eastern gate until dawn.

Ledger 26 line 005: Neri carried the blue token past marker beccf85f8d94. Mara watched the eastern gate until dawn.

Ledger 26 line 006: Neri carried the blue token past marker 3dae4ff75c02. Mara watched the eastern gate until dawn.

Ledger 26 line 007: Neri carried the blue token past marker 20b4b7ea38fd. Mara watched the eastern gate until dawn.

Ledger 26 line 008: Neri carried the blue token past marker e678644f8e71. Mara watched the eastern gate until dawn.

Ledger 26 line 009: Neri carried the blue token past marker 5867311378bc. Mara watched the eastern gate until dawn.

Ledger 26 line 010: Neri carried the blue token past marker 0680da9f0255. Mara watched the eastern gate until dawn.

Ledger 26 line 011: Neri carried the blue token past marker cb6e6d089e7b. Mara watched the eastern gate until dawn.

Ledger 26 line 012: Neri carried the blue token past marker 338f3a2ea706. Mara watched the eastern gate until dawn.

Ledger 26 line 013: Neri carried the blue token past marker 6d1ab810f012. Mara watched the eastern gate until dawn.

Ledger 26 line 014: Neri carried the blue token past marker a50146650717. Mara watched the eastern gate until dawn.

Ledger 26 line 015: Neri carried the blue token past marker af6337a987d6. Mara watched the eastern gate until dawn.

Ledger 26 line 016: Neri carried the blue token past marker a24da98a9131. Mara watched the eastern gate until dawn.

Ledger 26 line 017: Neri carried the blue token past marker 067a57b0a324. Mara watched the eastern gate until dawn.

Ledger 26 line 018: Neri carried the blue token past marker 52a9a4c65b68. Mara watched the eastern gate until dawn.

Ledger 26 line 019: Neri carried the blue token past marker 0dc0feaae222. Mara watched the eastern gate until dawn.

Ledger 26 line 020: Neri carried the blue token past marker 08d7c7344cec. Mara watched the eastern gate until dawn.

Ledger 26 line 021: Neri carried the blue token past marker ca09e333bf1a. Mara watched the eastern gate until dawn.

Ledger 26 line 022: Neri carried the blue token past marker 895cb0cedc68. Mara watched the eastern gate until dawn.

Ledger 26 line 023: Neri carried the blue token past marker 177d64081806. Mara watched the eastern gate until dawn.

Ledger 26 line 024: Neri carried the blue token past marker f18237ab1562. Mara watched the eastern gate until dawn.

Ledger 26 line 025: Neri carried the blue token past marker 52828a716f80. Mara watched the eastern gate until dawn.

Ledger 26 line 026: Neri carried the blue token past marker a71608017a11. Mara watched the eastern gate until dawn.

Ledger 26 line 027: Neri carried the blue token past marker 33e81bc6c2be. Mara watched the eastern gate until dawn.

Ledger 26 line 028: Neri carried the blue token past marker 282c116b1ae6. Mara watched the eastern gate until dawn.

Ledger 26 line 029: Neri carried the blue token past marker 0a508d291b2e. Mara watched the eastern gate until dawn.

Ledger 26 line 030: Neri carried the blue token past marker 9bfafdcd897e. Mara watched the eastern gate until dawn.

Ledger 26 line 031: Neri carried the blue token past marker 1e8cedb77d6a. Mara watched the eastern gate until dawn.

Ledger 26 line 032: Neri carried the blue token past marker 3a4d9ccd48ad. Mara watched the eastern gate until dawn.

Ledger 26 line 033: Neri carried the blue token past marker e47c8a35b8cf. Mara watched the eastern gate until dawn.

Ledger 26 line 034: Neri carried the blue token past marker ff0e405e5624. Mara watched the eastern gate until dawn.

Ledger 26 line 035: Neri carried the blue token past marker 8b777760d504. Mara watched the eastern gate until dawn.

Ledger 26 line 036: Neri carried the blue token past marker 387edfb55872. Mara watched the eastern gate until dawn.

Ledger 26 line 037: Neri carried the blue token past marker de603bf9ad3b. Mara watched the eastern gate until dawn.

Ledger 26 line 038: Neri carried the blue token past marker dc064bec0986. Mara watched the eastern gate until dawn.

Ledger 26 line 039: Neri carried the blue token past marker 337f70bd0460. Mara watched the eastern gate until dawn.

Ledger 26 line 040: Neri carried the blue token past marker de06b0713db1. Mara watched the eastern gate until dawn.

Ledger 26 line 041: Neri carried the blue token past marker bba24af23264. Mara watched the eastern gate until dawn.

Ledger 26 line 042: Neri carried the blue token past marker 6b29927270a1. Mara watched the eastern gate until dawn.

Ledger 26 line 043: Neri carried the blue token past marker 4dd18bb301d7. Mara watched the eastern gate until dawn.

Ledger 26 line 044: Neri carried the blue token past marker d8f1fc46abd2. Mara watched the eastern gate until dawn.

Ledger 26 line 045: Neri carried the blue token past marker ea4ef7311fcb. Mara watched the eastern gate until dawn.

Ledger 26 line 046: Neri carried the blue token past marker baa84344435f. Mara watched the eastern gate until dawn.

Ledger 26 line 047: Neri carried the blue token past marker 48047a13619a. Mara watched the eastern gate until dawn.

Ledger 26 line 048: Neri carried the blue token past marker 3ee396193305. Mara watched the eastern gate until dawn.

Ledger 26 line 049: Neri carried the blue token past marker 8dc1df5a6945. Mara watched the eastern gate until dawn.

Ledger 26 line 050: Neri carried the blue token past marker ea84bec9bc1d. Mara watched the eastern gate until dawn.

Ledger 26 line 051: Neri carried the blue token past marker b15159d9e915. Mara watched the eastern gate until dawn.

Ledger 26 line 052: Neri carried the blue token past marker 592de6c38fc9. Mara watched the eastern gate until dawn.

Ledger 26 line 053: Neri carried the blue token past marker 6636307e8be2. Mara watched the eastern gate until dawn.

Ledger 26 line 054: Neri carried the blue token past marker fa494de89cbe. Mara watched the eastern gate until dawn.

Ledger 26 line 055: Neri carried the blue token past marker 6cef75259cb9. Mara watched the eastern gate until dawn.

Ledger 26 line 056: Neri carried the blue token past marker 8c6b63666455. Mara watched the eastern gate until dawn.

Ledger 26 line 057: Neri carried the blue token past marker 5fa748a272d0. Mara watched the eastern gate until dawn.

Ledger 26 line 058: Neri carried the blue token past marker 95b02c79419d. Mara watched the eastern gate until dawn.

Ledger 26 line 059: Neri carried the blue token past marker bf481665c288. Mara watched the eastern gate until dawn.

Ledger 26 line 060: Neri carried the blue token past marker 5fc9fd02a03a. Mara watched the eastern gate until dawn.

Ledger 26 line 061: Neri carried the blue token past marker 14fe931c2b41. Mara watched the eastern gate until dawn.

Ledger 26 line 062: Neri carried the blue token past marker bec107a0ca0c. Mara watched the eastern gate until dawn.

Ledger 26 line 063: Neri carried the blue token past marker 52256ff99724. Mara watched the eastern gate until dawn.

Ledger 26 line 064: Neri carried the blue token past marker ff8d4ab7b8dc. Mara watched the eastern gate until dawn.

Ledger 26 line 065: Neri carried the blue token past marker 7687307411e8. Mara watched the eastern gate until dawn.

Ledger 26 line 066: Neri carried the blue token past marker 7f7ffe2c9373. Mara watched the eastern gate until dawn.

Ledger 26 line 067: Neri carried the blue token past marker cf738948e494. Mara watched the eastern gate until dawn.

Ledger 26 line 068: Neri carried the blue token past marker 5662548c8d48. Mara watched the eastern gate until dawn.

Ledger 26 line 069: Neri carried the blue token past marker 14678e00636c. Mara watched the eastern gate until dawn.

Ledger 26 line 070: Neri carried the blue token past marker 82255fc86a0e. Mara watched the eastern gate until dawn.

Ledger 26 line 071: Neri carried the blue token past marker 65a2c93a4dc3. Mara watched the eastern gate until dawn.

Ledger 26 line 072: Neri carried the blue token past marker 71958a4c4867. Mara watched the eastern gate until dawn.

Ledger 26 line 073: Neri carried the blue token past marker 33cc8bab9ce8. Mara watched the eastern gate until dawn.

Ledger 26 line 074: Neri carried the blue token past marker dd8b03d09615. Mara watched the eastern gate until dawn.

Ledger 26 line 075: Neri carried the blue token past marker cf0818ac2101. Mara watched the eastern gate until dawn.

Ledger 26 line 076: Neri carried the blue token past marker 6dc9c09c384c. Mara watched the eastern gate until dawn.

Ledger 26 line 077: Neri carried the blue token past marker 84d2463b7b8c. Mara watched the eastern gate until dawn.

Ledger 26 line 078: Neri carried the blue token past marker d2693a7063cd. Mara watched the eastern gate until dawn.

Ledger 26 line 079: Neri carried the blue token past marker abc503b2fd5f. Mara watched the eastern gate until dawn.

Ledger 26 line 080: Neri carried the blue token past marker ba76f0e74eb7. Mara watched the eastern gate until dawn.

Ledger 26 line 081: Neri carried the blue token past marker f1d8ce337649. Mara watched the eastern gate until dawn.

Ledger 26 line 082: Neri carried the blue token past marker fe7b650c2cd6. Mara watched the eastern gate until dawn.

Ledger 26 line 083: Neri carried the blue token past marker fe8d15246b4c. Mara watched the eastern gate until dawn.

Ledger 26 line 084: Neri carried the blue token past marker 52cd931476eb. Mara watched the eastern gate until dawn.

Ledger 26 line 085: Neri carried the blue token past marker c5d62e760e7f. Mara watched the eastern gate until dawn.

Ledger 26 line 086: Neri carried the blue token past marker 45008e417dfc. Mara watched the eastern gate until dawn.

Ledger 26 line 087: Neri carried the blue token past marker 9d8983589e25. Mara watched the eastern gate until dawn.

Ledger 26 line 088: Neri carried the blue token past marker 96c062c07119. Mara watched the eastern gate until dawn.

Ledger 26 line 089: Neri carried the blue token past marker b3c194350a5c. Mara watched the eastern gate until dawn.

Ledger 26 line 090: Neri carried the blue token past marker 056c39a5d523. Mara watched the eastern gate until dawn.

Ledger 26 line 091: Neri carried the blue token past marker 1c31c4f34804. Mara watched the eastern gate until dawn.

Ledger 26 line 092: Neri carried the blue token past marker 5ccc36802771. Mara watched the eastern gate until dawn.

Ledger 26 line 093: Neri carried the blue token past marker a586fe018adf. Mara watched the eastern gate until dawn.

Ledger 26 line 094: Neri carried the blue token past marker 2ed7b001bc41. Mara watched the eastern gate until dawn.

Ledger 26 line 095: Neri carried the blue token past marker 836ac30bfb5f. Mara watched the eastern gate until dawn.

Ledger 26 line 096: Neri carried the blue token past marker 3b2993b01d64. Mara watched the eastern gate until dawn.

Ledger 26 line 097: Neri carried the blue token past marker ff7ce9ddbaf6. Mara watched the eastern gate until dawn.

Ledger 26 line 098: Neri carried the blue token past marker aa20fbf3e40f. Mara watched the eastern gate until dawn.

Ledger 26 line 099: Neri carried the blue token past marker 38fdb234a973. Mara watched the eastern gate until dawn.

Ledger 26 line 100: Neri carried the blue token past marker a87c8140eba8. Mara watched the eastern gate until dawn.

Ledger 26 line 101: Neri carried the blue token past marker ac0e0919e2f1. Mara watched the eastern gate until dawn.

Ledger 26 line 102: Neri carried the blue token past marker c159677ea72f. Mara watched the eastern gate until dawn.

Ledger 26 line 103: Neri carried the blue token past marker 87ee1787deb1. Mara watched the eastern gate until dawn.

Ledger 26 line 104: Neri carried the blue token past marker f0036ea4a54f. Mara watched the eastern gate until dawn.

Ledger 26 line 105: Neri carried the blue token past marker c479b36c21c7. Mara watched the eastern gate until dawn.

Ledger 26 line 106: Neri carried the blue token past marker 4efd5de49df7. Mara watched the eastern gate until dawn.

Ledger 26 line 107: Neri carried the blue token past marker c20b1b8530c5. Mara watched the eastern gate until dawn.

Ledger 26 line 108: Neri carried the blue token past marker 98e1605af075. Mara watched the eastern gate until dawn.

Ledger 26 line 109: Neri carried the blue token past marker 884b202b1449. Mara watched the eastern gate until dawn.

Ledger 26 line 110: Neri carried the blue token past marker e7b0d33f7f00. Mara watched the eastern gate until dawn.

Ledger 26 line 111: Neri carried the blue token past marker 0efbcb1a48c1. Mara watched the eastern gate until dawn.

Ledger 26 line 112: Neri carried the blue token past marker 492572baf5be. Mara watched the eastern gate until dawn.

Ledger 26 line 113: Neri carried the blue token past marker bbbd3858d0cc. Mara watched the eastern gate until dawn.

Ledger 26 line 114: Neri carried the blue token past marker 820623f6e53c. Mara watched the eastern gate until dawn.

Ledger 26 line 115: Neri carried the blue token past marker aec88746de4a. Mara watched the eastern gate until dawn.

Ledger 26 line 116: Neri carried the blue token past marker eab70801c88e. Mara watched the eastern gate until dawn.

Ledger 26 line 117: Neri carried the blue token past marker 201c8af7c9b4. Mara watched the eastern gate until dawn.

Ledger 26 line 118: Neri carried the blue token past marker f54f32ba38c9. Mara watched the eastern gate until dawn.

Ledger 26 line 119: Neri carried the blue token past marker 8be5eeda4619. Mara watched the eastern gate until dawn.

Ledger 26 line 120: Neri carried the blue token past marker 3f16ebe438ee. Mara watched the eastern gate until dawn.

Ledger 26 line 121: Neri carried the blue token past marker 8f178b22e444. Mara watched the eastern gate until dawn.

Ledger 26 line 122: Neri carried the blue token past marker 0d744e6f47b4. Mara watched the eastern gate until dawn.

Ledger 26 line 123: Neri carried the blue token past marker ed27b944f3c3. Mara watched the eastern gate until dawn.

Ledger 26 line 124: Neri carried the blue token past marker b25969eb27d2. Mara watched the eastern gate until dawn.

Ledger 26 line 125: Neri carried the blue token past marker 06431bcec095. Mara watched the eastern gate until dawn.

Ledger 26 line 126: Neri carried the blue token past marker 9219826ae7be. Mara watched the eastern gate until dawn.

Ledger 26 line 127: Neri carried the blue token past marker d828f02ecaaf. Mara watched the eastern gate until dawn.

Ledger 26 line 128: Neri carried the blue token past marker ab50e6255a8e. Mara watched the eastern gate until dawn.

Ledger 26 line 129: Neri carried the blue token past marker 8b03437a4f78. Mara watched the eastern gate until dawn.

Ledger 26 line 130: Neri carried the blue token past marker c35aaf4b3f47. Mara watched the eastern gate until dawn.

Ledger 26 line 131: Neri carried the blue token past marker 0b2b797d4d60. Mara watched the eastern gate until dawn.

Ledger 26 line 132: Neri carried the blue token past marker c0ca669659a1. Mara watched the eastern gate until dawn.

Ledger 26 line 133: Neri carried the blue token past marker e8fc88fa5ac3. Mara watched the eastern gate until dawn.

Ledger 26 line 134: Neri carried the blue token past marker cc7fb3bb6d99. Mara watched the eastern gate until dawn.

Ledger 26 line 135: Neri carried the blue token past marker 60d6db76de43. Mara watched the eastern gate until dawn.

Ledger 26 line 136: Neri carried the blue token past marker 458bb458b7bd. Mara watched the eastern gate until dawn.

Ledger 26 line 137: Neri carried the blue token past marker 18a3b60c0b98. Mara watched the eastern gate until dawn.

Ledger 26 line 138: Neri carried the blue token past marker 200b0a26a752. Mara watched the eastern gate until dawn.

Ledger 26 line 139: Neri carried the blue token past marker 9445c65f8342. Mara watched the eastern gate until dawn.

Ledger 26 line 140: Neri carried the blue token past marker eceda4d53cfe. Mara watched the eastern gate until dawn.
