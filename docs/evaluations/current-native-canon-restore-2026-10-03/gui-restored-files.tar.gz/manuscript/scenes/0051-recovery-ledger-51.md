---
id: scene-0051
title: Recovery ledger 51
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.179565+00:00
updated_at: 2026-10-03T12:14:52.179565+00:00
---

Ledger 51 line 001: Neri carried the blue token past marker 8f0cff07116a. Mara watched the eastern gate until dawn.

Ledger 51 line 002: Neri carried the blue token past marker c34a304b8e1a. Mara watched the eastern gate until dawn.

Ledger 51 line 003: Neri carried the blue token past marker 982b2c720c07. Mara watched the eastern gate until dawn.

Ledger 51 line 004: Neri carried the blue token past marker 6da4d2de9e61. Mara watched the eastern gate until dawn.

Ledger 51 line 005: Neri carried the blue token past marker 17afc3c812dd. Mara watched the eastern gate until dawn.

Ledger 51 line 006: Neri carried the blue token past marker 88aa2c3b09f7. Mara watched the eastern gate until dawn.

Ledger 51 line 007: Neri carried the blue token past marker 574db8c21a03. Mara watched the eastern gate until dawn.

Ledger 51 line 008: Neri carried the blue token past marker fa19a23563dc. Mara watched the eastern gate until dawn.

Ledger 51 line 009: Neri carried the blue token past marker a9fe19f5b475. Mara watched the eastern gate until dawn.

Ledger 51 line 010: Neri carried the blue token past marker af031122c0c4. Mara watched the eastern gate until dawn.

Ledger 51 line 011: Neri carried the blue token past marker dc4eb01f0835. Mara watched the eastern gate until dawn.

Ledger 51 line 012: Neri carried the blue token past marker 3cbdf30caee2. Mara watched the eastern gate until dawn.

Ledger 51 line 013: Neri carried the blue token past marker c0ec6008e067. Mara watched the eastern gate until dawn.

Ledger 51 line 014: Neri carried the blue token past marker c9a6fd62e6cc. Mara watched the eastern gate until dawn.

Ledger 51 line 015: Neri carried the blue token past marker bb684a9285c9. Mara watched the eastern gate until dawn.

Ledger 51 line 016: Neri carried the blue token past marker f7a024afb3a6. Mara watched the eastern gate until dawn.

Ledger 51 line 017: Neri carried the blue token past marker e0ac484aab51. Mara watched the eastern gate until dawn.

Ledger 51 line 018: Neri carried the blue token past marker 719a2682a136. Mara watched the eastern gate until dawn.

Ledger 51 line 019: Neri carried the blue token past marker 0514531ee4e6. Mara watched the eastern gate until dawn.

Ledger 51 line 020: Neri carried the blue token past marker da187172333c. Mara watched the eastern gate until dawn.

Ledger 51 line 021: Neri carried the blue token past marker 7f2088108cb1. Mara watched the eastern gate until dawn.

Ledger 51 line 022: Neri carried the blue token past marker 16f2f96afa50. Mara watched the eastern gate until dawn.

Ledger 51 line 023: Neri carried the blue token past marker b25772cb1c55. Mara watched the eastern gate until dawn.

Ledger 51 line 024: Neri carried the blue token past marker 3857ef741d3c. Mara watched the eastern gate until dawn.

Ledger 51 line 025: Neri carried the blue token past marker f210b4afa84a. Mara watched the eastern gate until dawn.

Ledger 51 line 026: Neri carried the blue token past marker 0c80efb22170. Mara watched the eastern gate until dawn.

Ledger 51 line 027: Neri carried the blue token past marker c7e7ded657e5. Mara watched the eastern gate until dawn.

Ledger 51 line 028: Neri carried the blue token past marker b94b085e0ed5. Mara watched the eastern gate until dawn.

Ledger 51 line 029: Neri carried the blue token past marker 9d6b4f82671b. Mara watched the eastern gate until dawn.

Ledger 51 line 030: Neri carried the blue token past marker c0ad2d4eeb8c. Mara watched the eastern gate until dawn.

Ledger 51 line 031: Neri carried the blue token past marker 66cf96c2ae70. Mara watched the eastern gate until dawn.

Ledger 51 line 032: Neri carried the blue token past marker 6115f1292e88. Mara watched the eastern gate until dawn.

Ledger 51 line 033: Neri carried the blue token past marker c7acf88fbde3. Mara watched the eastern gate until dawn.

Ledger 51 line 034: Neri carried the blue token past marker 737d9d6aea56. Mara watched the eastern gate until dawn.

Ledger 51 line 035: Neri carried the blue token past marker c7f99d336855. Mara watched the eastern gate until dawn.

Ledger 51 line 036: Neri carried the blue token past marker 705e8b23e7ea. Mara watched the eastern gate until dawn.

Ledger 51 line 037: Neri carried the blue token past marker e6ad1587aa3d. Mara watched the eastern gate until dawn.

Ledger 51 line 038: Neri carried the blue token past marker ddae20c42abc. Mara watched the eastern gate until dawn.

Ledger 51 line 039: Neri carried the blue token past marker df2eb6694cfb. Mara watched the eastern gate until dawn.

Ledger 51 line 040: Neri carried the blue token past marker 452dd271f025. Mara watched the eastern gate until dawn.

Ledger 51 line 041: Neri carried the blue token past marker 94d15f1f18e2. Mara watched the eastern gate until dawn.

Ledger 51 line 042: Neri carried the blue token past marker 33edb7451499. Mara watched the eastern gate until dawn.

Ledger 51 line 043: Neri carried the blue token past marker 5f6143247834. Mara watched the eastern gate until dawn.

Ledger 51 line 044: Neri carried the blue token past marker 3c565f293d63. Mara watched the eastern gate until dawn.

Ledger 51 line 045: Neri carried the blue token past marker 4658f161df38. Mara watched the eastern gate until dawn.

Ledger 51 line 046: Neri carried the blue token past marker e243976eb124. Mara watched the eastern gate until dawn.

Ledger 51 line 047: Neri carried the blue token past marker 2298d7b988f4. Mara watched the eastern gate until dawn.

Ledger 51 line 048: Neri carried the blue token past marker 6045ad61f7da. Mara watched the eastern gate until dawn.

Ledger 51 line 049: Neri carried the blue token past marker e7cd0df2601a. Mara watched the eastern gate until dawn.

Ledger 51 line 050: Neri carried the blue token past marker 35dc5b842c20. Mara watched the eastern gate until dawn.

Ledger 51 line 051: Neri carried the blue token past marker 54eea5a1302c. Mara watched the eastern gate until dawn.

Ledger 51 line 052: Neri carried the blue token past marker aee494d992c9. Mara watched the eastern gate until dawn.

Ledger 51 line 053: Neri carried the blue token past marker 47fe037a4a12. Mara watched the eastern gate until dawn.

Ledger 51 line 054: Neri carried the blue token past marker 9cf4a627e35f. Mara watched the eastern gate until dawn.

Ledger 51 line 055: Neri carried the blue token past marker 070d88cf8704. Mara watched the eastern gate until dawn.

Ledger 51 line 056: Neri carried the blue token past marker 97046d0f5328. Mara watched the eastern gate until dawn.

Ledger 51 line 057: Neri carried the blue token past marker 557fcfcc4b88. Mara watched the eastern gate until dawn.

Ledger 51 line 058: Neri carried the blue token past marker 3d9db2fe3e6c. Mara watched the eastern gate until dawn.

Ledger 51 line 059: Neri carried the blue token past marker e955f53582ad. Mara watched the eastern gate until dawn.

Ledger 51 line 060: Neri carried the blue token past marker 12da491c0bdb. Mara watched the eastern gate until dawn.

Ledger 51 line 061: Neri carried the blue token past marker 0fb52bbafb5f. Mara watched the eastern gate until dawn.

Ledger 51 line 062: Neri carried the blue token past marker 39dcc66c0ca1. Mara watched the eastern gate until dawn.

Ledger 51 line 063: Neri carried the blue token past marker b048580fb51a. Mara watched the eastern gate until dawn.

Ledger 51 line 064: Neri carried the blue token past marker ed66d9e4e662. Mara watched the eastern gate until dawn.

Ledger 51 line 065: Neri carried the blue token past marker 0e082ce70307. Mara watched the eastern gate until dawn.

Ledger 51 line 066: Neri carried the blue token past marker 30e1ebe80d14. Mara watched the eastern gate until dawn.

Ledger 51 line 067: Neri carried the blue token past marker 9f39bb25929a. Mara watched the eastern gate until dawn.

Ledger 51 line 068: Neri carried the blue token past marker c0c7899a9049. Mara watched the eastern gate until dawn.

Ledger 51 line 069: Neri carried the blue token past marker e6551d4e4ca4. Mara watched the eastern gate until dawn.

Ledger 51 line 070: Neri carried the blue token past marker f0a82aa5cc42. Mara watched the eastern gate until dawn.

Ledger 51 line 071: Neri carried the blue token past marker a6be3fcfd647. Mara watched the eastern gate until dawn.

Ledger 51 line 072: Neri carried the blue token past marker d524346868e2. Mara watched the eastern gate until dawn.

Ledger 51 line 073: Neri carried the blue token past marker 88d726370fe9. Mara watched the eastern gate until dawn.

Ledger 51 line 074: Neri carried the blue token past marker 31f4825e735f. Mara watched the eastern gate until dawn.

Ledger 51 line 075: Neri carried the blue token past marker 79fcdf9dd98a. Mara watched the eastern gate until dawn.

Ledger 51 line 076: Neri carried the blue token past marker fef1b9c85b29. Mara watched the eastern gate until dawn.

Ledger 51 line 077: Neri carried the blue token past marker 8856f92f6d14. Mara watched the eastern gate until dawn.

Ledger 51 line 078: Neri carried the blue token past marker 75d024b0d018. Mara watched the eastern gate until dawn.

Ledger 51 line 079: Neri carried the blue token past marker 4b0f3c771aba. Mara watched the eastern gate until dawn.

Ledger 51 line 080: Neri carried the blue token past marker 4bd4ac0a0688. Mara watched the eastern gate until dawn.

Ledger 51 line 081: Neri carried the blue token past marker ac9a5891926f. Mara watched the eastern gate until dawn.

Ledger 51 line 082: Neri carried the blue token past marker 3ab10e30e570. Mara watched the eastern gate until dawn.

Ledger 51 line 083: Neri carried the blue token past marker 41083b82904a. Mara watched the eastern gate until dawn.

Ledger 51 line 084: Neri carried the blue token past marker 8519a95a2765. Mara watched the eastern gate until dawn.

Ledger 51 line 085: Neri carried the blue token past marker 85b18c5e06e4. Mara watched the eastern gate until dawn.

Ledger 51 line 086: Neri carried the blue token past marker fbd6adaf1f90. Mara watched the eastern gate until dawn.

Ledger 51 line 087: Neri carried the blue token past marker 007a67da2188. Mara watched the eastern gate until dawn.

Ledger 51 line 088: Neri carried the blue token past marker e75507d5e9be. Mara watched the eastern gate until dawn.

Ledger 51 line 089: Neri carried the blue token past marker 3d06ba8f67b9. Mara watched the eastern gate until dawn.

Ledger 51 line 090: Neri carried the blue token past marker d665368e46f6. Mara watched the eastern gate until dawn.

Ledger 51 line 091: Neri carried the blue token past marker 03ffb6c96b9b. Mara watched the eastern gate until dawn.

Ledger 51 line 092: Neri carried the blue token past marker 25c564ddd22a. Mara watched the eastern gate until dawn.

Ledger 51 line 093: Neri carried the blue token past marker b8027f3d4e4c. Mara watched the eastern gate until dawn.

Ledger 51 line 094: Neri carried the blue token past marker 698ea0a5a115. Mara watched the eastern gate until dawn.

Ledger 51 line 095: Neri carried the blue token past marker 8ca438d5caa9. Mara watched the eastern gate until dawn.

Ledger 51 line 096: Neri carried the blue token past marker fb5c47206212. Mara watched the eastern gate until dawn.

Ledger 51 line 097: Neri carried the blue token past marker cee89bbb109e. Mara watched the eastern gate until dawn.

Ledger 51 line 098: Neri carried the blue token past marker c7b0f9c33cd3. Mara watched the eastern gate until dawn.

Ledger 51 line 099: Neri carried the blue token past marker ee8a1ad97e5a. Mara watched the eastern gate until dawn.

Ledger 51 line 100: Neri carried the blue token past marker e0988d772995. Mara watched the eastern gate until dawn.

Ledger 51 line 101: Neri carried the blue token past marker d3c04799d839. Mara watched the eastern gate until dawn.

Ledger 51 line 102: Neri carried the blue token past marker c57edda0d3ba. Mara watched the eastern gate until dawn.

Ledger 51 line 103: Neri carried the blue token past marker 8e09431a637d. Mara watched the eastern gate until dawn.

Ledger 51 line 104: Neri carried the blue token past marker 0db0e9fbf8ad. Mara watched the eastern gate until dawn.

Ledger 51 line 105: Neri carried the blue token past marker 6dc8b080bebe. Mara watched the eastern gate until dawn.

Ledger 51 line 106: Neri carried the blue token past marker 12446d9a163a. Mara watched the eastern gate until dawn.

Ledger 51 line 107: Neri carried the blue token past marker 23d8c0874a63. Mara watched the eastern gate until dawn.

Ledger 51 line 108: Neri carried the blue token past marker e0fca25a5e7e. Mara watched the eastern gate until dawn.

Ledger 51 line 109: Neri carried the blue token past marker 8fad4c8194ce. Mara watched the eastern gate until dawn.

Ledger 51 line 110: Neri carried the blue token past marker 0b29c16cf200. Mara watched the eastern gate until dawn.

Ledger 51 line 111: Neri carried the blue token past marker a512499edcb7. Mara watched the eastern gate until dawn.

Ledger 51 line 112: Neri carried the blue token past marker a559d834bd3d. Mara watched the eastern gate until dawn.

Ledger 51 line 113: Neri carried the blue token past marker 9e01511668e9. Mara watched the eastern gate until dawn.

Ledger 51 line 114: Neri carried the blue token past marker 62342d31bd9b. Mara watched the eastern gate until dawn.

Ledger 51 line 115: Neri carried the blue token past marker 191c5d1e8c3b. Mara watched the eastern gate until dawn.

Ledger 51 line 116: Neri carried the blue token past marker 226d2a4388cb. Mara watched the eastern gate until dawn.

Ledger 51 line 117: Neri carried the blue token past marker 0a291b6d2b4b. Mara watched the eastern gate until dawn.

Ledger 51 line 118: Neri carried the blue token past marker 99364718dec6. Mara watched the eastern gate until dawn.

Ledger 51 line 119: Neri carried the blue token past marker 625c14b3d909. Mara watched the eastern gate until dawn.

Ledger 51 line 120: Neri carried the blue token past marker 4725e30448ed. Mara watched the eastern gate until dawn.

Ledger 51 line 121: Neri carried the blue token past marker a7361a1b3155. Mara watched the eastern gate until dawn.

Ledger 51 line 122: Neri carried the blue token past marker 3de4ea91bef2. Mara watched the eastern gate until dawn.

Ledger 51 line 123: Neri carried the blue token past marker ab564c1c2064. Mara watched the eastern gate until dawn.

Ledger 51 line 124: Neri carried the blue token past marker 0b715cf5dba5. Mara watched the eastern gate until dawn.

Ledger 51 line 125: Neri carried the blue token past marker 40385c2a695f. Mara watched the eastern gate until dawn.

Ledger 51 line 126: Neri carried the blue token past marker 570372ec0343. Mara watched the eastern gate until dawn.

Ledger 51 line 127: Neri carried the blue token past marker c25b03d2a819. Mara watched the eastern gate until dawn.

Ledger 51 line 128: Neri carried the blue token past marker e23526facc1c. Mara watched the eastern gate until dawn.

Ledger 51 line 129: Neri carried the blue token past marker 941dfebd45a7. Mara watched the eastern gate until dawn.

Ledger 51 line 130: Neri carried the blue token past marker b34e416e16c3. Mara watched the eastern gate until dawn.

Ledger 51 line 131: Neri carried the blue token past marker cc720d793494. Mara watched the eastern gate until dawn.

Ledger 51 line 132: Neri carried the blue token past marker 0e61f33338c0. Mara watched the eastern gate until dawn.

Ledger 51 line 133: Neri carried the blue token past marker 81bc8a62a93b. Mara watched the eastern gate until dawn.

Ledger 51 line 134: Neri carried the blue token past marker 08462611075b. Mara watched the eastern gate until dawn.

Ledger 51 line 135: Neri carried the blue token past marker d7a97d20c964. Mara watched the eastern gate until dawn.

Ledger 51 line 136: Neri carried the blue token past marker a9277e72fa2b. Mara watched the eastern gate until dawn.

Ledger 51 line 137: Neri carried the blue token past marker 14d248aa3ca5. Mara watched the eastern gate until dawn.

Ledger 51 line 138: Neri carried the blue token past marker dad9df569308. Mara watched the eastern gate until dawn.

Ledger 51 line 139: Neri carried the blue token past marker 6448951fa172. Mara watched the eastern gate until dawn.

Ledger 51 line 140: Neri carried the blue token past marker 446fe55dad00. Mara watched the eastern gate until dawn.
