---
id: scene-0012
title: Recovery ledger 12
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.158926+00:00
updated_at: 2026-10-03T12:14:52.158926+00:00
---

Ledger 12 line 001: Neri carried the blue token past marker b7871fccde16. Mara watched the eastern gate until dawn.

Ledger 12 line 002: Neri carried the blue token past marker 8bb918ba8079. Mara watched the eastern gate until dawn.

Ledger 12 line 003: Neri carried the blue token past marker a87aa3a28873. Mara watched the eastern gate until dawn.

Ledger 12 line 004: Neri carried the blue token past marker cb7f23428c49. Mara watched the eastern gate until dawn.

Ledger 12 line 005: Neri carried the blue token past marker ec7aeb85af88. Mara watched the eastern gate until dawn.

Ledger 12 line 006: Neri carried the blue token past marker d2f6298c62fa. Mara watched the eastern gate until dawn.

Ledger 12 line 007: Neri carried the blue token past marker c5bc660c9be5. Mara watched the eastern gate until dawn.

Ledger 12 line 008: Neri carried the blue token past marker 2b4a091ea522. Mara watched the eastern gate until dawn.

Ledger 12 line 009: Neri carried the blue token past marker 15ec9e9b4645. Mara watched the eastern gate until dawn.

Ledger 12 line 010: Neri carried the blue token past marker 606dd5821ad0. Mara watched the eastern gate until dawn.

Ledger 12 line 011: Neri carried the blue token past marker b0c7935490dc. Mara watched the eastern gate until dawn.

Ledger 12 line 012: Neri carried the blue token past marker 37ddcc6b50de. Mara watched the eastern gate until dawn.

Ledger 12 line 013: Neri carried the blue token past marker 74825b5db161. Mara watched the eastern gate until dawn.

Ledger 12 line 014: Neri carried the blue token past marker ed2b618517a4. Mara watched the eastern gate until dawn.

Ledger 12 line 015: Neri carried the blue token past marker 15e14d683073. Mara watched the eastern gate until dawn.

Ledger 12 line 016: Neri carried the blue token past marker bd253d0e4086. Mara watched the eastern gate until dawn.

Ledger 12 line 017: Neri carried the blue token past marker e294778b7cf4. Mara watched the eastern gate until dawn.

Ledger 12 line 018: Neri carried the blue token past marker 0f5c22f4102b. Mara watched the eastern gate until dawn.

Ledger 12 line 019: Neri carried the blue token past marker 95628cb02b06. Mara watched the eastern gate until dawn.

Ledger 12 line 020: Neri carried the blue token past marker b73b7a3269ad. Mara watched the eastern gate until dawn.

Ledger 12 line 021: Neri carried the blue token past marker 14e7bc49925c. Mara watched the eastern gate until dawn.

Ledger 12 line 022: Neri carried the blue token past marker 76a42cb28070. Mara watched the eastern gate until dawn.

Ledger 12 line 023: Neri carried the blue token past marker d73312ce88d5. Mara watched the eastern gate until dawn.

Ledger 12 line 024: Neri carried the blue token past marker 4980dddd2967. Mara watched the eastern gate until dawn.

Ledger 12 line 025: Neri carried the blue token past marker 98acfa0fd852. Mara watched the eastern gate until dawn.

Ledger 12 line 026: Neri carried the blue token past marker de8ac8390d43. Mara watched the eastern gate until dawn.

Ledger 12 line 027: Neri carried the blue token past marker ce68d738b2e7. Mara watched the eastern gate until dawn.

Ledger 12 line 028: Neri carried the blue token past marker 705b3524b800. Mara watched the eastern gate until dawn.

Ledger 12 line 029: Neri carried the blue token past marker e41f331d8557. Mara watched the eastern gate until dawn.

Ledger 12 line 030: Neri carried the blue token past marker 4c658021550d. Mara watched the eastern gate until dawn.

Ledger 12 line 031: Neri carried the blue token past marker ea3e41943fca. Mara watched the eastern gate until dawn.

Ledger 12 line 032: Neri carried the blue token past marker e6866f02f13f. Mara watched the eastern gate until dawn.

Ledger 12 line 033: Neri carried the blue token past marker f6230657fb36. Mara watched the eastern gate until dawn.

Ledger 12 line 034: Neri carried the blue token past marker a7487e589668. Mara watched the eastern gate until dawn.

Ledger 12 line 035: Neri carried the blue token past marker 34a7f1b33cfc. Mara watched the eastern gate until dawn.

Ledger 12 line 036: Neri carried the blue token past marker 9bd3ddf97d2d. Mara watched the eastern gate until dawn.

Ledger 12 line 037: Neri carried the blue token past marker aaae1ae184d4. Mara watched the eastern gate until dawn.

Ledger 12 line 038: Neri carried the blue token past marker 8536afd93ad7. Mara watched the eastern gate until dawn.

Ledger 12 line 039: Neri carried the blue token past marker b5a5db845d2e. Mara watched the eastern gate until dawn.

Ledger 12 line 040: Neri carried the blue token past marker d8ff7de1fd52. Mara watched the eastern gate until dawn.

Ledger 12 line 041: Neri carried the blue token past marker 908375bdcea2. Mara watched the eastern gate until dawn.

Ledger 12 line 042: Neri carried the blue token past marker e5fdacb1dac0. Mara watched the eastern gate until dawn.

Ledger 12 line 043: Neri carried the blue token past marker ff981c6081b6. Mara watched the eastern gate until dawn.

Ledger 12 line 044: Neri carried the blue token past marker b7db9f9cb458. Mara watched the eastern gate until dawn.

Ledger 12 line 045: Neri carried the blue token past marker 96412e01f745. Mara watched the eastern gate until dawn.

Ledger 12 line 046: Neri carried the blue token past marker b843de143f83. Mara watched the eastern gate until dawn.

Ledger 12 line 047: Neri carried the blue token past marker 5e041e34e82e. Mara watched the eastern gate until dawn.

Ledger 12 line 048: Neri carried the blue token past marker f7b56c6e8dcc. Mara watched the eastern gate until dawn.

Ledger 12 line 049: Neri carried the blue token past marker 2ed311fdbe48. Mara watched the eastern gate until dawn.

Ledger 12 line 050: Neri carried the blue token past marker e432a9253ab7. Mara watched the eastern gate until dawn.

Ledger 12 line 051: Neri carried the blue token past marker eb0c425715ed. Mara watched the eastern gate until dawn.

Ledger 12 line 052: Neri carried the blue token past marker 04733262bc67. Mara watched the eastern gate until dawn.

Ledger 12 line 053: Neri carried the blue token past marker 87eff3384b6b. Mara watched the eastern gate until dawn.

Ledger 12 line 054: Neri carried the blue token past marker d744b19d0d7d. Mara watched the eastern gate until dawn.

Ledger 12 line 055: Neri carried the blue token past marker cee19c3a894a. Mara watched the eastern gate until dawn.

Ledger 12 line 056: Neri carried the blue token past marker e8445b6d7fd7. Mara watched the eastern gate until dawn.

Ledger 12 line 057: Neri carried the blue token past marker 6df5d87fa58b. Mara watched the eastern gate until dawn.

Ledger 12 line 058: Neri carried the blue token past marker a57d715c7251. Mara watched the eastern gate until dawn.

Ledger 12 line 059: Neri carried the blue token past marker 7d49c12dd77b. Mara watched the eastern gate until dawn.

Ledger 12 line 060: Neri carried the blue token past marker 0d0ba1408eaa. Mara watched the eastern gate until dawn.

Ledger 12 line 061: Neri carried the blue token past marker f5ebc80d4413. Mara watched the eastern gate until dawn.

Ledger 12 line 062: Neri carried the blue token past marker d414f0e802f4. Mara watched the eastern gate until dawn.

Ledger 12 line 063: Neri carried the blue token past marker b16484cd6af3. Mara watched the eastern gate until dawn.

Ledger 12 line 064: Neri carried the blue token past marker 78e3c57768a1. Mara watched the eastern gate until dawn.

Ledger 12 line 065: Neri carried the blue token past marker f418700e95ca. Mara watched the eastern gate until dawn.

Ledger 12 line 066: Neri carried the blue token past marker dd9275d82bb4. Mara watched the eastern gate until dawn.

Ledger 12 line 067: Neri carried the blue token past marker 61e31d3cabb5. Mara watched the eastern gate until dawn.

Ledger 12 line 068: Neri carried the blue token past marker 8ac974ecdd8d. Mara watched the eastern gate until dawn.

Ledger 12 line 069: Neri carried the blue token past marker 08a33a3bd4d2. Mara watched the eastern gate until dawn.

Ledger 12 line 070: Neri carried the blue token past marker c087e45458f5. Mara watched the eastern gate until dawn.

Ledger 12 line 071: Neri carried the blue token past marker 8684bdf19910. Mara watched the eastern gate until dawn.

Ledger 12 line 072: Neri carried the blue token past marker 848aefa3efc5. Mara watched the eastern gate until dawn.

Ledger 12 line 073: Neri carried the blue token past marker 64c2441a1290. Mara watched the eastern gate until dawn.

Ledger 12 line 074: Neri carried the blue token past marker 1b8c43a5f394. Mara watched the eastern gate until dawn.

Ledger 12 line 075: Neri carried the blue token past marker 2a5261789f11. Mara watched the eastern gate until dawn.

Ledger 12 line 076: Neri carried the blue token past marker 281a43124303. Mara watched the eastern gate until dawn.

Ledger 12 line 077: Neri carried the blue token past marker 069047936205. Mara watched the eastern gate until dawn.

Ledger 12 line 078: Neri carried the blue token past marker 0602222cb26d. Mara watched the eastern gate until dawn.

Ledger 12 line 079: Neri carried the blue token past marker cb6553783a9a. Mara watched the eastern gate until dawn.

Ledger 12 line 080: Neri carried the blue token past marker ea3e801664ac. Mara watched the eastern gate until dawn.

Ledger 12 line 081: Neri carried the blue token past marker 7f670cdf3079. Mara watched the eastern gate until dawn.

Ledger 12 line 082: Neri carried the blue token past marker 6f565c5bf5df. Mara watched the eastern gate until dawn.

Ledger 12 line 083: Neri carried the blue token past marker 435b4c9d8222. Mara watched the eastern gate until dawn.

Ledger 12 line 084: Neri carried the blue token past marker c949c827527f. Mara watched the eastern gate until dawn.

Ledger 12 line 085: Neri carried the blue token past marker a007827f8f00. Mara watched the eastern gate until dawn.

Ledger 12 line 086: Neri carried the blue token past marker 5bc2eba28112. Mara watched the eastern gate until dawn.

Ledger 12 line 087: Neri carried the blue token past marker a4efa2eb9aeb. Mara watched the eastern gate until dawn.

Ledger 12 line 088: Neri carried the blue token past marker 483e06dc5239. Mara watched the eastern gate until dawn.

Ledger 12 line 089: Neri carried the blue token past marker 4a22d0be6f97. Mara watched the eastern gate until dawn.

Ledger 12 line 090: Neri carried the blue token past marker f67e1acf073e. Mara watched the eastern gate until dawn.

Ledger 12 line 091: Neri carried the blue token past marker 7432024b199f. Mara watched the eastern gate until dawn.

Ledger 12 line 092: Neri carried the blue token past marker 1c014e111aa3. Mara watched the eastern gate until dawn.

Ledger 12 line 093: Neri carried the blue token past marker 05c48be7b703. Mara watched the eastern gate until dawn.

Ledger 12 line 094: Neri carried the blue token past marker 33ea6b988b2c. Mara watched the eastern gate until dawn.

Ledger 12 line 095: Neri carried the blue token past marker 0abc5f937bcb. Mara watched the eastern gate until dawn.

Ledger 12 line 096: Neri carried the blue token past marker 78a32348f2b2. Mara watched the eastern gate until dawn.

Ledger 12 line 097: Neri carried the blue token past marker 2e5410960988. Mara watched the eastern gate until dawn.

Ledger 12 line 098: Neri carried the blue token past marker 24a12b5c6093. Mara watched the eastern gate until dawn.

Ledger 12 line 099: Neri carried the blue token past marker 56a3eaefac70. Mara watched the eastern gate until dawn.

Ledger 12 line 100: Neri carried the blue token past marker b387186c6368. Mara watched the eastern gate until dawn.

Ledger 12 line 101: Neri carried the blue token past marker 18f2decd1684. Mara watched the eastern gate until dawn.

Ledger 12 line 102: Neri carried the blue token past marker 1360efc0a5ab. Mara watched the eastern gate until dawn.

Ledger 12 line 103: Neri carried the blue token past marker c2d61dce9a86. Mara watched the eastern gate until dawn.

Ledger 12 line 104: Neri carried the blue token past marker f502a46c7c6f. Mara watched the eastern gate until dawn.

Ledger 12 line 105: Neri carried the blue token past marker 93f82b1d92b1. Mara watched the eastern gate until dawn.

Ledger 12 line 106: Neri carried the blue token past marker 24ace8d7c7b4. Mara watched the eastern gate until dawn.

Ledger 12 line 107: Neri carried the blue token past marker 4b9d7cdef47b. Mara watched the eastern gate until dawn.

Ledger 12 line 108: Neri carried the blue token past marker 65ac60e489bf. Mara watched the eastern gate until dawn.

Ledger 12 line 109: Neri carried the blue token past marker 1cbb52fbec2e. Mara watched the eastern gate until dawn.

Ledger 12 line 110: Neri carried the blue token past marker 71a424de4605. Mara watched the eastern gate until dawn.

Ledger 12 line 111: Neri carried the blue token past marker 8cef264b9897. Mara watched the eastern gate until dawn.

Ledger 12 line 112: Neri carried the blue token past marker 8f5f188b2013. Mara watched the eastern gate until dawn.

Ledger 12 line 113: Neri carried the blue token past marker ff9dc99fa9ad. Mara watched the eastern gate until dawn.

Ledger 12 line 114: Neri carried the blue token past marker dd27dedf8a32. Mara watched the eastern gate until dawn.

Ledger 12 line 115: Neri carried the blue token past marker da641f76fa59. Mara watched the eastern gate until dawn.

Ledger 12 line 116: Neri carried the blue token past marker af89ca15c6d9. Mara watched the eastern gate until dawn.

Ledger 12 line 117: Neri carried the blue token past marker a9f1fd147e3b. Mara watched the eastern gate until dawn.

Ledger 12 line 118: Neri carried the blue token past marker 753d5f12776c. Mara watched the eastern gate until dawn.

Ledger 12 line 119: Neri carried the blue token past marker 064f485f2c5c. Mara watched the eastern gate until dawn.

Ledger 12 line 120: Neri carried the blue token past marker 561b66ec6938. Mara watched the eastern gate until dawn.

Ledger 12 line 121: Neri carried the blue token past marker 574ae15c07ac. Mara watched the eastern gate until dawn.

Ledger 12 line 122: Neri carried the blue token past marker 231cb58f9f03. Mara watched the eastern gate until dawn.

Ledger 12 line 123: Neri carried the blue token past marker d6480e29f956. Mara watched the eastern gate until dawn.

Ledger 12 line 124: Neri carried the blue token past marker 027b41acf66f. Mara watched the eastern gate until dawn.

Ledger 12 line 125: Neri carried the blue token past marker a8ea066ebd26. Mara watched the eastern gate until dawn.

Ledger 12 line 126: Neri carried the blue token past marker 54bd76a33858. Mara watched the eastern gate until dawn.

Ledger 12 line 127: Neri carried the blue token past marker 194947558d59. Mara watched the eastern gate until dawn.

Ledger 12 line 128: Neri carried the blue token past marker c0de2294cfde. Mara watched the eastern gate until dawn.

Ledger 12 line 129: Neri carried the blue token past marker 92e813147ad8. Mara watched the eastern gate until dawn.

Ledger 12 line 130: Neri carried the blue token past marker a61eadb2e1ed. Mara watched the eastern gate until dawn.

Ledger 12 line 131: Neri carried the blue token past marker d742293c1cac. Mara watched the eastern gate until dawn.

Ledger 12 line 132: Neri carried the blue token past marker d8a4c03e340d. Mara watched the eastern gate until dawn.

Ledger 12 line 133: Neri carried the blue token past marker e1eec38acf94. Mara watched the eastern gate until dawn.

Ledger 12 line 134: Neri carried the blue token past marker 009e79207418. Mara watched the eastern gate until dawn.

Ledger 12 line 135: Neri carried the blue token past marker a47664ddac66. Mara watched the eastern gate until dawn.

Ledger 12 line 136: Neri carried the blue token past marker e1c65893b801. Mara watched the eastern gate until dawn.

Ledger 12 line 137: Neri carried the blue token past marker a7ba17e6fada. Mara watched the eastern gate until dawn.

Ledger 12 line 138: Neri carried the blue token past marker dcc396dfde78. Mara watched the eastern gate until dawn.

Ledger 12 line 139: Neri carried the blue token past marker 026dd948a0f0. Mara watched the eastern gate until dawn.

Ledger 12 line 140: Neri carried the blue token past marker f1c5b8336035. Mara watched the eastern gate until dawn.
