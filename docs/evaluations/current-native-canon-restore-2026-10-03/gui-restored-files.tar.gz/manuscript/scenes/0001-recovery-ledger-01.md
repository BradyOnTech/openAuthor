---
id: scene-0001
title: Recovery ledger 01
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.153330+00:00
updated_at: 2026-10-03T12:14:52.990038+00:00
---

Ledger 01 line 001: Neri carried the blue token past marker 253d950f11eb. Mara watched the eastern gate until dawn.

Ledger 01 line 002: Neri carried the blue token past marker d939926f0544. Mara watched the eastern gate until dawn.

Ledger 01 line 003: Neri carried the blue token past marker 0d7f0e336166. Mara watched the eastern gate until dawn.

Ledger 01 line 004: Neri carried the blue token past marker f70b94aeb67d. Mara watched the eastern gate until dawn.

Ledger 01 line 005: Neri carried the blue token past marker bd82a28b1f08. Mara watched the eastern gate until dawn.

Ledger 01 line 006: Neri carried the blue token past marker 8f854692d8bc. Mara watched the eastern gate until dawn.

Ledger 01 line 007: Neri carried the blue token past marker 2da190e578dd. Mara watched the eastern gate until dawn.

Ledger 01 line 008: Neri carried the blue token past marker 52e90ae24326. Mara watched the eastern gate until dawn.

Ledger 01 line 009: Neri carried the blue token past marker 7dbf57a3ed61. Mara watched the eastern gate until dawn.

Ledger 01 line 010: Neri carried the blue token past marker 9d5d5c10c5df. Mara watched the eastern gate until dawn.

Ledger 01 line 011: Neri carried the blue token past marker 00e48c98b384. Mara watched the eastern gate until dawn.

Ledger 01 line 012: Neri carried the blue token past marker 47ba35745eff. Mara watched the eastern gate until dawn.

Ledger 01 line 013: Neri carried the blue token past marker 4b6172b339b6. Mara watched the eastern gate until dawn.

Ledger 01 line 014: Neri carried the blue token past marker 65e3fe75fe8d. Mara watched the eastern gate until dawn.

Ledger 01 line 015: Neri carried the blue token past marker ab5395ff3008. Mara watched the eastern gate until dawn.

Ledger 01 line 016: Neri carried the blue token past marker ece2d97a6903. Mara watched the eastern gate until dawn.

Ledger 01 line 017: Neri carried the blue token past marker 2c624356e34c. Mara watched the eastern gate until dawn.

Ledger 01 line 018: Neri carried the blue token past marker 142bd7f88656. Mara watched the eastern gate until dawn.

Ledger 01 line 019: Neri carried the blue token past marker 5a79080aefc9. Mara watched the eastern gate until dawn.

Ledger 01 line 020: Neri carried the blue token past marker 10f7f6b8715b. Mara watched the eastern gate until dawn.

Ledger 01 line 021: Neri carried the blue token past marker 77c9a9746d80. Mara watched the eastern gate until dawn.

Ledger 01 line 022: Neri carried the blue token past marker 9916798fc65a. Mara watched the eastern gate until dawn.

Ledger 01 line 023: Neri carried the blue token past marker f09fd1c45ad5. Mara watched the eastern gate until dawn.

Ledger 01 line 024: Neri carried the blue token past marker 8f3ccc3707f2. Mara watched the eastern gate until dawn.

Ledger 01 line 025: Neri carried the blue token past marker f4c4a538074d. Mara watched the eastern gate until dawn.

Ledger 01 line 026: Neri carried the blue token past marker 99bf5c0f84d3. Mara watched the eastern gate until dawn.

Ledger 01 line 027: Neri carried the blue token past marker 4dce63c862d6. Mara watched the eastern gate until dawn.

Ledger 01 line 028: Neri carried the blue token past marker f39049fd8ecc. Mara watched the eastern gate until dawn.

Ledger 01 line 029: Neri carried the blue token past marker 9a917a14de39. Mara watched the eastern gate until dawn.

Ledger 01 line 030: Neri carried the blue token past marker da951ee49d26. Mara watched the eastern gate until dawn.

Ledger 01 line 031: Neri carried the blue token past marker e36a25663003. Mara watched the eastern gate until dawn.

Ledger 01 line 032: Neri carried the blue token past marker 3e7359965020. Mara watched the eastern gate until dawn.

Ledger 01 line 033: Neri carried the blue token past marker 998e71d423d3. Mara watched the eastern gate until dawn.

Ledger 01 line 034: Neri carried the blue token past marker b488fa727903. Mara watched the eastern gate until dawn.

Ledger 01 line 035: Neri carried the blue token past marker cf7d4568358b. Mara watched the eastern gate until dawn.

Ledger 01 line 036: Neri carried the blue token past marker d8db71771b70. Mara watched the eastern gate until dawn.

Ledger 01 line 037: Neri carried the blue token past marker 058584c53b4c. Mara watched the eastern gate until dawn.

Ledger 01 line 038: Neri carried the blue token past marker 4c1fe4932d3c. Mara watched the eastern gate until dawn.

Ledger 01 line 039: Neri carried the blue token past marker d2eb82ce8102. Mara watched the eastern gate until dawn.

Ledger 01 line 040: Neri carried the blue token past marker edafd4ca829f. Mara watched the eastern gate until dawn.

Ledger 01 line 041: Neri carried the blue token past marker 45d6e1eb5c04. Mara watched the eastern gate until dawn.

Ledger 01 line 042: Neri carried the blue token past marker 73cfd0ff7ed1. Mara watched the eastern gate until dawn.

Ledger 01 line 043: Neri carried the blue token past marker 7c0f037fdbd7. Mara watched the eastern gate until dawn.

Ledger 01 line 044: Neri carried the blue token past marker 02e074c9574c. Mara watched the eastern gate until dawn.

Ledger 01 line 045: Neri carried the blue token past marker 8ac2868ef1c1. Mara watched the eastern gate until dawn.

Ledger 01 line 046: Neri carried the blue token past marker a82b3599d8fe. Mara watched the eastern gate until dawn.

Ledger 01 line 047: Neri carried the blue token past marker f94473f0f43f. Mara watched the eastern gate until dawn.

Ledger 01 line 048: Neri carried the blue token past marker f63627d56ce2. Mara watched the eastern gate until dawn.

Ledger 01 line 049: Neri carried the blue token past marker 72f35a12eb66. Mara watched the eastern gate until dawn.

Ledger 01 line 050: Neri carried the blue token past marker 60ae2ffd0fee. Mara watched the eastern gate until dawn.

Ledger 01 line 051: Neri carried the blue token past marker 8abfcc44d2f3. Mara watched the eastern gate until dawn.

Ledger 01 line 052: Neri carried the blue token past marker 9c1d6d373ccb. Mara watched the eastern gate until dawn.

Ledger 01 line 053: Neri carried the blue token past marker 3e8edbd8579f. Mara watched the eastern gate until dawn.

Ledger 01 line 054: Neri carried the blue token past marker c997b7580a92. Mara watched the eastern gate until dawn.

Ledger 01 line 055: Neri carried the blue token past marker d6432af5b444. Mara watched the eastern gate until dawn.

Ledger 01 line 056: Neri carried the blue token past marker 2fd4b940faeb. Mara watched the eastern gate until dawn.

Ledger 01 line 057: Neri carried the blue token past marker e8fcf29d2d81. Mara watched the eastern gate until dawn.

Ledger 01 line 058: Neri carried the blue token past marker c44dca91e204. Mara watched the eastern gate until dawn.

Ledger 01 line 059: Neri carried the blue token past marker 7864cb96faa8. Mara watched the eastern gate until dawn.

Ledger 01 line 060: Neri carried the blue token past marker 854a836ab796. Mara watched the eastern gate until dawn.

Ledger 01 line 061: Neri carried the blue token past marker a97b54dafb1c. Mara watched the eastern gate until dawn.

Ledger 01 line 062: Neri carried the blue token past marker 3bd4035601b8. Mara watched the eastern gate until dawn.

Ledger 01 line 063: Neri carried the blue token past marker fd7064e92698. Mara watched the eastern gate until dawn.

Ledger 01 line 064: Neri carried the blue token past marker 67724395556a. Mara watched the eastern gate until dawn.

Ledger 01 line 065: Neri carried the blue token past marker 63c4351c79e1. Mara watched the eastern gate until dawn.

Ledger 01 line 066: Neri carried the blue token past marker c82339b503f1. Mara watched the eastern gate until dawn.

Ledger 01 line 067: Neri carried the blue token past marker bbcef615e1ba. Mara watched the eastern gate until dawn.

Ledger 01 line 068: Neri carried the blue token past marker 6165d8a9ab47. Mara watched the eastern gate until dawn.

Ledger 01 line 069: Neri carried the blue token past marker b134ea5aac45. Mara watched the eastern gate until dawn.

Ledger 01 line 070: Neri carried the blue token past marker be1f2223c2f7. Mara watched the eastern gate until dawn.

Ledger 01 line 071: Neri carried the blue token past marker 853edc7f5999. Mara watched the eastern gate until dawn.

Ledger 01 line 072: Neri carried the blue token past marker 63b2d5c3de09. Mara watched the eastern gate until dawn.

Ledger 01 line 073: Neri carried the blue token past marker e80b62be7340. Mara watched the eastern gate until dawn.

Ledger 01 line 074: Neri carried the blue token past marker 702b67ce57ab. Mara watched the eastern gate until dawn.

Ledger 01 line 075: Neri carried the blue token past marker 7e3f1f765358. Mara watched the eastern gate until dawn.

Ledger 01 line 076: Neri carried the blue token past marker 75016d60f698. Mara watched the eastern gate until dawn.

Ledger 01 line 077: Neri carried the blue token past marker 3757ac8d444a. Mara watched the eastern gate until dawn.

Ledger 01 line 078: Neri carried the blue token past marker d31648da5e70. Mara watched the eastern gate until dawn.

Ledger 01 line 079: Neri carried the blue token past marker 49d2b76bf8b6. Mara watched the eastern gate until dawn.

Ledger 01 line 080: Neri carried the blue token past marker 792df107ffbb. Mara watched the eastern gate until dawn.

Ledger 01 line 081: Neri carried the blue token past marker aab8a507528e. Mara watched the eastern gate until dawn.

Ledger 01 line 082: Neri carried the blue token past marker d691d7017c0d. Mara watched the eastern gate until dawn.

Ledger 01 line 083: Neri carried the blue token past marker 11e90f49631e. Mara watched the eastern gate until dawn.

Ledger 01 line 084: Neri carried the blue token past marker a5fd64d4fb8c. Mara watched the eastern gate until dawn.

Ledger 01 line 085: Neri carried the blue token past marker 1317b17e1a5a. Mara watched the eastern gate until dawn.

Ledger 01 line 086: Neri carried the blue token past marker a096d2d06e1c. Mara watched the eastern gate until dawn.

Ledger 01 line 087: Neri carried the blue token past marker 1b722d433c8e. Mara watched the eastern gate until dawn.

Ledger 01 line 088: Neri carried the blue token past marker 5c52f7f02d36. Mara watched the eastern gate until dawn.

Ledger 01 line 089: Neri carried the blue token past marker cfa0e67dd1c5. Mara watched the eastern gate until dawn.

Ledger 01 line 090: Neri carried the blue token past marker 66f8cd9eb74e. Mara watched the eastern gate until dawn.

Ledger 01 line 091: Neri carried the blue token past marker 054b5e50a871. Mara watched the eastern gate until dawn.

Ledger 01 line 092: Neri carried the blue token past marker f3cdd54c36eb. Mara watched the eastern gate until dawn.

Ledger 01 line 093: Neri carried the blue token past marker 80166d27d91d. Mara watched the eastern gate until dawn.

Ledger 01 line 094: Neri carried the blue token past marker ce6c638f311f. Mara watched the eastern gate until dawn.

Ledger 01 line 095: Neri carried the blue token past marker 633156e37536. Mara watched the eastern gate until dawn.

Ledger 01 line 096: Neri carried the blue token past marker 380defbd201d. Mara watched the eastern gate until dawn.

Ledger 01 line 097: Neri carried the blue token past marker 69c92fdf02c2. Mara watched the eastern gate until dawn.

Ledger 01 line 098: Neri carried the blue token past marker f3771fa2a218. Mara watched the eastern gate until dawn.

Ledger 01 line 099: Neri carried the blue token past marker 8a23c7cea0a7. Mara watched the eastern gate until dawn.

Ledger 01 line 100: Neri carried the blue token past marker d3fbc8272593. Mara watched the eastern gate until dawn.

Ledger 01 line 101: Neri carried the blue token past marker e13f1ffd7222. Mara watched the eastern gate until dawn.

Ledger 01 line 102: Neri carried the blue token past marker c3f70a38b875. Mara watched the eastern gate until dawn.

Ledger 01 line 103: Neri carried the blue token past marker 058195817995. Mara watched the eastern gate until dawn.

Ledger 01 line 104: Neri carried the blue token past marker 3a577e79dcb5. Mara watched the eastern gate until dawn.

Ledger 01 line 105: Neri carried the blue token past marker 1fb77d88e7ea. Mara watched the eastern gate until dawn.

Ledger 01 line 106: Neri carried the blue token past marker 7b251c5575a6. Mara watched the eastern gate until dawn.

Ledger 01 line 107: Neri carried the blue token past marker 27431d24bee5. Mara watched the eastern gate until dawn.

Ledger 01 line 108: Neri carried the blue token past marker 34f6ca3ac713. Mara watched the eastern gate until dawn.

Ledger 01 line 109: Neri carried the blue token past marker e9ab4e2f4a61. Mara watched the eastern gate until dawn.

Ledger 01 line 110: Neri carried the blue token past marker 047b100e1948. Mara watched the eastern gate until dawn.

Ledger 01 line 111: Neri carried the blue token past marker c2933328cfa8. Mara watched the eastern gate until dawn.

Ledger 01 line 112: Neri carried the blue token past marker cc102e3ad3b2. Mara watched the eastern gate until dawn.

Ledger 01 line 113: Neri carried the blue token past marker d7ee712b02f0. Mara watched the eastern gate until dawn.

Ledger 01 line 114: Neri carried the blue token past marker 74293f68d721. Mara watched the eastern gate until dawn.

Ledger 01 line 115: Neri carried the blue token past marker b230d987b483. Mara watched the eastern gate until dawn.

Ledger 01 line 116: Neri carried the blue token past marker 6cecd257aa2b. Mara watched the eastern gate until dawn.

Ledger 01 line 117: Neri carried the blue token past marker 61342b6fc150. Mara watched the eastern gate until dawn.

Ledger 01 line 118: Neri carried the blue token past marker 9bf326e2f310. Mara watched the eastern gate until dawn.

Ledger 01 line 119: Neri carried the blue token past marker 1330c0218218. Mara watched the eastern gate until dawn.

Ledger 01 line 120: Neri carried the blue token past marker ac68274d0683. Mara watched the eastern gate until dawn.

Ledger 01 line 121: Neri carried the blue token past marker 6322bbc2ec28. Mara watched the eastern gate until dawn.

Ledger 01 line 122: Neri carried the blue token past marker b03b10a898e3. Mara watched the eastern gate until dawn.

Ledger 01 line 123: Neri carried the blue token past marker de3d9313d6de. Mara watched the eastern gate until dawn.

Ledger 01 line 124: Neri carried the blue token past marker 58b18583075b. Mara watched the eastern gate until dawn.

Ledger 01 line 125: Neri carried the blue token past marker cb57a137cee6. Mara watched the eastern gate until dawn.

Ledger 01 line 126: Neri carried the blue token past marker b8e77dabc2cd. Mara watched the eastern gate until dawn.

Ledger 01 line 127: Neri carried the blue token past marker c33455e92392. Mara watched the eastern gate until dawn.

Ledger 01 line 128: Neri carried the blue token past marker 7fe36c614267. Mara watched the eastern gate until dawn.

Ledger 01 line 129: Neri carried the blue token past marker 7fbeac8c9373. Mara watched the eastern gate until dawn.

Ledger 01 line 130: Neri carried the blue token past marker 315b701806cd. Mara watched the eastern gate until dawn.

Ledger 01 line 131: Neri carried the blue token past marker ba80a6dbd7b3. Mara watched the eastern gate until dawn.

Ledger 01 line 132: Neri carried the blue token past marker 0a1006ba35f3. Mara watched the eastern gate until dawn.

Ledger 01 line 133: Neri carried the blue token past marker f325f14bed5a. Mara watched the eastern gate until dawn.

Ledger 01 line 134: Neri carried the blue token past marker 6207b83107b4. Mara watched the eastern gate until dawn.

Ledger 01 line 135: Neri carried the blue token past marker 962ee76a419b. Mara watched the eastern gate until dawn.

Ledger 01 line 136: Neri carried the blue token past marker 97d3f3210ee3. Mara watched the eastern gate until dawn.

Ledger 01 line 137: Neri carried the blue token past marker c151d1bc6b72. Mara watched the eastern gate until dawn.

Ledger 01 line 138: Neri carried the blue token past marker 9ba84333d200. Mara watched the eastern gate until dawn.

Ledger 01 line 139: Neri carried the blue token past marker 91d659eaed61. Mara watched the eastern gate until dawn.

Ledger 01 line 140: Neri carried the blue token past marker d0d5d9279bb4. Mara watched the eastern gate until dawn.


Acceptance revision 128: Ivo checked marker 2747b7c718564ba5.
