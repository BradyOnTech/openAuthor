---
id: scene-0043
title: Recovery ledger 43
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.175589+00:00
updated_at: 2026-10-03T12:14:52.175589+00:00
---

Ledger 43 line 001: Neri carried the blue token past marker 7de12c79f422. Mara watched the eastern gate until dawn.

Ledger 43 line 002: Neri carried the blue token past marker f7113afe91b3. Mara watched the eastern gate until dawn.

Ledger 43 line 003: Neri carried the blue token past marker d176b2623860. Mara watched the eastern gate until dawn.

Ledger 43 line 004: Neri carried the blue token past marker 22b7e37b9a7d. Mara watched the eastern gate until dawn.

Ledger 43 line 005: Neri carried the blue token past marker 4ef3c07e0916. Mara watched the eastern gate until dawn.

Ledger 43 line 006: Neri carried the blue token past marker 84619df081c0. Mara watched the eastern gate until dawn.

Ledger 43 line 007: Neri carried the blue token past marker 0f34a0870496. Mara watched the eastern gate until dawn.

Ledger 43 line 008: Neri carried the blue token past marker 3560e8b7865f. Mara watched the eastern gate until dawn.

Ledger 43 line 009: Neri carried the blue token past marker 24cdadd7edc7. Mara watched the eastern gate until dawn.

Ledger 43 line 010: Neri carried the blue token past marker 73774d77c329. Mara watched the eastern gate until dawn.

Ledger 43 line 011: Neri carried the blue token past marker 3721bfbb54ed. Mara watched the eastern gate until dawn.

Ledger 43 line 012: Neri carried the blue token past marker de38c3f0796a. Mara watched the eastern gate until dawn.

Ledger 43 line 013: Neri carried the blue token past marker c759c545045d. Mara watched the eastern gate until dawn.

Ledger 43 line 014: Neri carried the blue token past marker eb0b6716c446. Mara watched the eastern gate until dawn.

Ledger 43 line 015: Neri carried the blue token past marker 5f3ca5a56c3e. Mara watched the eastern gate until dawn.

Ledger 43 line 016: Neri carried the blue token past marker 8088384f4023. Mara watched the eastern gate until dawn.

Ledger 43 line 017: Neri carried the blue token past marker ef87c1956589. Mara watched the eastern gate until dawn.

Ledger 43 line 018: Neri carried the blue token past marker 6034279a1142. Mara watched the eastern gate until dawn.

Ledger 43 line 019: Neri carried the blue token past marker 101553ab163f. Mara watched the eastern gate until dawn.

Ledger 43 line 020: Neri carried the blue token past marker b430558c49c7. Mara watched the eastern gate until dawn.

Ledger 43 line 021: Neri carried the blue token past marker 7fa8bf3afbac. Mara watched the eastern gate until dawn.

Ledger 43 line 022: Neri carried the blue token past marker 3446584472d0. Mara watched the eastern gate until dawn.

Ledger 43 line 023: Neri carried the blue token past marker 53d944561ad8. Mara watched the eastern gate until dawn.

Ledger 43 line 024: Neri carried the blue token past marker cca8bc063963. Mara watched the eastern gate until dawn.

Ledger 43 line 025: Neri carried the blue token past marker f3ec74761848. Mara watched the eastern gate until dawn.

Ledger 43 line 026: Neri carried the blue token past marker badf14b4cf6a. Mara watched the eastern gate until dawn.

Ledger 43 line 027: Neri carried the blue token past marker 51cc98265f99. Mara watched the eastern gate until dawn.

Ledger 43 line 028: Neri carried the blue token past marker 5b307274d4cc. Mara watched the eastern gate until dawn.

Ledger 43 line 029: Neri carried the blue token past marker 67bafb217788. Mara watched the eastern gate until dawn.

Ledger 43 line 030: Neri carried the blue token past marker bad69d395ef0. Mara watched the eastern gate until dawn.

Ledger 43 line 031: Neri carried the blue token past marker fc75c8250535. Mara watched the eastern gate until dawn.

Ledger 43 line 032: Neri carried the blue token past marker d70a99c709c7. Mara watched the eastern gate until dawn.

Ledger 43 line 033: Neri carried the blue token past marker 7d3d57609baa. Mara watched the eastern gate until dawn.

Ledger 43 line 034: Neri carried the blue token past marker d8d4a2d326e5. Mara watched the eastern gate until dawn.

Ledger 43 line 035: Neri carried the blue token past marker 3e3789cea14b. Mara watched the eastern gate until dawn.

Ledger 43 line 036: Neri carried the blue token past marker fcc562d2472f. Mara watched the eastern gate until dawn.

Ledger 43 line 037: Neri carried the blue token past marker e4daf1b016de. Mara watched the eastern gate until dawn.

Ledger 43 line 038: Neri carried the blue token past marker 2389a30e3d24. Mara watched the eastern gate until dawn.

Ledger 43 line 039: Neri carried the blue token past marker 25aa8b383242. Mara watched the eastern gate until dawn.

Ledger 43 line 040: Neri carried the blue token past marker 28cd6e01c5ad. Mara watched the eastern gate until dawn.

Ledger 43 line 041: Neri carried the blue token past marker 15092ef9e157. Mara watched the eastern gate until dawn.

Ledger 43 line 042: Neri carried the blue token past marker 7dd3e96e002a. Mara watched the eastern gate until dawn.

Ledger 43 line 043: Neri carried the blue token past marker 1d32f06f8953. Mara watched the eastern gate until dawn.

Ledger 43 line 044: Neri carried the blue token past marker d972641f9d89. Mara watched the eastern gate until dawn.

Ledger 43 line 045: Neri carried the blue token past marker c4fb2d93018c. Mara watched the eastern gate until dawn.

Ledger 43 line 046: Neri carried the blue token past marker d53896851989. Mara watched the eastern gate until dawn.

Ledger 43 line 047: Neri carried the blue token past marker 22b7847c3cdd. Mara watched the eastern gate until dawn.

Ledger 43 line 048: Neri carried the blue token past marker 56a678e479da. Mara watched the eastern gate until dawn.

Ledger 43 line 049: Neri carried the blue token past marker 765f6e690761. Mara watched the eastern gate until dawn.

Ledger 43 line 050: Neri carried the blue token past marker 90da7675d08f. Mara watched the eastern gate until dawn.

Ledger 43 line 051: Neri carried the blue token past marker 0f8405076783. Mara watched the eastern gate until dawn.

Ledger 43 line 052: Neri carried the blue token past marker 35adfd90d76e. Mara watched the eastern gate until dawn.

Ledger 43 line 053: Neri carried the blue token past marker fed4dfce30b0. Mara watched the eastern gate until dawn.

Ledger 43 line 054: Neri carried the blue token past marker 36b00c54f9aa. Mara watched the eastern gate until dawn.

Ledger 43 line 055: Neri carried the blue token past marker c0d7830628ee. Mara watched the eastern gate until dawn.

Ledger 43 line 056: Neri carried the blue token past marker af4a1e5f4825. Mara watched the eastern gate until dawn.

Ledger 43 line 057: Neri carried the blue token past marker 5ca27fe1db3f. Mara watched the eastern gate until dawn.

Ledger 43 line 058: Neri carried the blue token past marker ee05cbfcb326. Mara watched the eastern gate until dawn.

Ledger 43 line 059: Neri carried the blue token past marker 66720bdfb1ae. Mara watched the eastern gate until dawn.

Ledger 43 line 060: Neri carried the blue token past marker 97d1275b3eaa. Mara watched the eastern gate until dawn.

Ledger 43 line 061: Neri carried the blue token past marker 465e10480627. Mara watched the eastern gate until dawn.

Ledger 43 line 062: Neri carried the blue token past marker 5ae3db44521f. Mara watched the eastern gate until dawn.

Ledger 43 line 063: Neri carried the blue token past marker 9ed5d80be741. Mara watched the eastern gate until dawn.

Ledger 43 line 064: Neri carried the blue token past marker 000d1b3c9a1d. Mara watched the eastern gate until dawn.

Ledger 43 line 065: Neri carried the blue token past marker 9b4325790696. Mara watched the eastern gate until dawn.

Ledger 43 line 066: Neri carried the blue token past marker ae63c0f80fa9. Mara watched the eastern gate until dawn.

Ledger 43 line 067: Neri carried the blue token past marker fbdb10728aa9. Mara watched the eastern gate until dawn.

Ledger 43 line 068: Neri carried the blue token past marker 4dfe12bff331. Mara watched the eastern gate until dawn.

Ledger 43 line 069: Neri carried the blue token past marker 4b400a06b49c. Mara watched the eastern gate until dawn.

Ledger 43 line 070: Neri carried the blue token past marker e639f087c6bc. Mara watched the eastern gate until dawn.

Ledger 43 line 071: Neri carried the blue token past marker 15b2a4268aba. Mara watched the eastern gate until dawn.

Ledger 43 line 072: Neri carried the blue token past marker 310de9b676e6. Mara watched the eastern gate until dawn.

Ledger 43 line 073: Neri carried the blue token past marker aad1be59687b. Mara watched the eastern gate until dawn.

Ledger 43 line 074: Neri carried the blue token past marker 58f9b8ff621d. Mara watched the eastern gate until dawn.

Ledger 43 line 075: Neri carried the blue token past marker 675a876e260a. Mara watched the eastern gate until dawn.

Ledger 43 line 076: Neri carried the blue token past marker 720a128f1a07. Mara watched the eastern gate until dawn.

Ledger 43 line 077: Neri carried the blue token past marker 236cc19cd80a. Mara watched the eastern gate until dawn.

Ledger 43 line 078: Neri carried the blue token past marker 127f03d46eb8. Mara watched the eastern gate until dawn.

Ledger 43 line 079: Neri carried the blue token past marker 16339c87371f. Mara watched the eastern gate until dawn.

Ledger 43 line 080: Neri carried the blue token past marker 26946c68f91f. Mara watched the eastern gate until dawn.

Ledger 43 line 081: Neri carried the blue token past marker 39897a70f199. Mara watched the eastern gate until dawn.

Ledger 43 line 082: Neri carried the blue token past marker 8a48c82a5b93. Mara watched the eastern gate until dawn.

Ledger 43 line 083: Neri carried the blue token past marker 3a116407cbf7. Mara watched the eastern gate until dawn.

Ledger 43 line 084: Neri carried the blue token past marker dce9d0908773. Mara watched the eastern gate until dawn.

Ledger 43 line 085: Neri carried the blue token past marker 86b3190a09e2. Mara watched the eastern gate until dawn.

Ledger 43 line 086: Neri carried the blue token past marker 4497f9889d98. Mara watched the eastern gate until dawn.

Ledger 43 line 087: Neri carried the blue token past marker 9176c508de8e. Mara watched the eastern gate until dawn.

Ledger 43 line 088: Neri carried the blue token past marker deafb0c46cd2. Mara watched the eastern gate until dawn.

Ledger 43 line 089: Neri carried the blue token past marker c423c19f9850. Mara watched the eastern gate until dawn.

Ledger 43 line 090: Neri carried the blue token past marker 5ac3120de251. Mara watched the eastern gate until dawn.

Ledger 43 line 091: Neri carried the blue token past marker 063b15b24033. Mara watched the eastern gate until dawn.

Ledger 43 line 092: Neri carried the blue token past marker d58df4a95bfc. Mara watched the eastern gate until dawn.

Ledger 43 line 093: Neri carried the blue token past marker cb262210e262. Mara watched the eastern gate until dawn.

Ledger 43 line 094: Neri carried the blue token past marker 5946b9b2321e. Mara watched the eastern gate until dawn.

Ledger 43 line 095: Neri carried the blue token past marker 3d43a0f0c6b4. Mara watched the eastern gate until dawn.

Ledger 43 line 096: Neri carried the blue token past marker dcc2515a5357. Mara watched the eastern gate until dawn.

Ledger 43 line 097: Neri carried the blue token past marker 86309a8088ed. Mara watched the eastern gate until dawn.

Ledger 43 line 098: Neri carried the blue token past marker 137e05452007. Mara watched the eastern gate until dawn.

Ledger 43 line 099: Neri carried the blue token past marker f38d48be15c3. Mara watched the eastern gate until dawn.

Ledger 43 line 100: Neri carried the blue token past marker a1615dbba2d9. Mara watched the eastern gate until dawn.

Ledger 43 line 101: Neri carried the blue token past marker 96fa806e1f61. Mara watched the eastern gate until dawn.

Ledger 43 line 102: Neri carried the blue token past marker 30e4d67dcbbe. Mara watched the eastern gate until dawn.

Ledger 43 line 103: Neri carried the blue token past marker bf7f2f3a536e. Mara watched the eastern gate until dawn.

Ledger 43 line 104: Neri carried the blue token past marker 0c4ae1d60145. Mara watched the eastern gate until dawn.

Ledger 43 line 105: Neri carried the blue token past marker b69cf0c0b3c7. Mara watched the eastern gate until dawn.

Ledger 43 line 106: Neri carried the blue token past marker 079ce810337e. Mara watched the eastern gate until dawn.

Ledger 43 line 107: Neri carried the blue token past marker de1a6d11e674. Mara watched the eastern gate until dawn.

Ledger 43 line 108: Neri carried the blue token past marker f7fdc461a243. Mara watched the eastern gate until dawn.

Ledger 43 line 109: Neri carried the blue token past marker 6a96bafa5e05. Mara watched the eastern gate until dawn.

Ledger 43 line 110: Neri carried the blue token past marker 44220240f90c. Mara watched the eastern gate until dawn.

Ledger 43 line 111: Neri carried the blue token past marker ca49a28e69c0. Mara watched the eastern gate until dawn.

Ledger 43 line 112: Neri carried the blue token past marker 07f875ded001. Mara watched the eastern gate until dawn.

Ledger 43 line 113: Neri carried the blue token past marker bc7a1422e52e. Mara watched the eastern gate until dawn.

Ledger 43 line 114: Neri carried the blue token past marker b87d0beee7f0. Mara watched the eastern gate until dawn.

Ledger 43 line 115: Neri carried the blue token past marker 2b4515d9aa8d. Mara watched the eastern gate until dawn.

Ledger 43 line 116: Neri carried the blue token past marker aa978003e99d. Mara watched the eastern gate until dawn.

Ledger 43 line 117: Neri carried the blue token past marker 45168f90f605. Mara watched the eastern gate until dawn.

Ledger 43 line 118: Neri carried the blue token past marker a53187e0dcc9. Mara watched the eastern gate until dawn.

Ledger 43 line 119: Neri carried the blue token past marker 84759156f54c. Mara watched the eastern gate until dawn.

Ledger 43 line 120: Neri carried the blue token past marker aaef20ba85ab. Mara watched the eastern gate until dawn.

Ledger 43 line 121: Neri carried the blue token past marker e39738a79083. Mara watched the eastern gate until dawn.

Ledger 43 line 122: Neri carried the blue token past marker a0047ea4860b. Mara watched the eastern gate until dawn.

Ledger 43 line 123: Neri carried the blue token past marker 91ccc01e59af. Mara watched the eastern gate until dawn.

Ledger 43 line 124: Neri carried the blue token past marker 3e7faf496f58. Mara watched the eastern gate until dawn.

Ledger 43 line 125: Neri carried the blue token past marker 3210817ac592. Mara watched the eastern gate until dawn.

Ledger 43 line 126: Neri carried the blue token past marker 9d2b2e41eb1c. Mara watched the eastern gate until dawn.

Ledger 43 line 127: Neri carried the blue token past marker f06587bd26a8. Mara watched the eastern gate until dawn.

Ledger 43 line 128: Neri carried the blue token past marker 0612eb1c6106. Mara watched the eastern gate until dawn.

Ledger 43 line 129: Neri carried the blue token past marker 767f4da72cbf. Mara watched the eastern gate until dawn.

Ledger 43 line 130: Neri carried the blue token past marker 5b099367e4f5. Mara watched the eastern gate until dawn.

Ledger 43 line 131: Neri carried the blue token past marker 03604517f30c. Mara watched the eastern gate until dawn.

Ledger 43 line 132: Neri carried the blue token past marker d96058a41091. Mara watched the eastern gate until dawn.

Ledger 43 line 133: Neri carried the blue token past marker dc85790453c0. Mara watched the eastern gate until dawn.

Ledger 43 line 134: Neri carried the blue token past marker 18d3871de7e9. Mara watched the eastern gate until dawn.

Ledger 43 line 135: Neri carried the blue token past marker 2aa31b92c04d. Mara watched the eastern gate until dawn.

Ledger 43 line 136: Neri carried the blue token past marker 9b22f3c7b350. Mara watched the eastern gate until dawn.

Ledger 43 line 137: Neri carried the blue token past marker dd0b9951e4a4. Mara watched the eastern gate until dawn.

Ledger 43 line 138: Neri carried the blue token past marker 5ab3403bf9ee. Mara watched the eastern gate until dawn.

Ledger 43 line 139: Neri carried the blue token past marker 0f44b6c1bfbe. Mara watched the eastern gate until dawn.

Ledger 43 line 140: Neri carried the blue token past marker a78f08b30d7d. Mara watched the eastern gate until dawn.
