---
id: scene-0022
title: Recovery ledger 22
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.163928+00:00
updated_at: 2026-10-03T12:14:52.163928+00:00
---

Ledger 22 line 001: Neri carried the blue token past marker ef9242a1a3f7. Mara watched the eastern gate until dawn.

Ledger 22 line 002: Neri carried the blue token past marker 88140f00afa2. Mara watched the eastern gate until dawn.

Ledger 22 line 003: Neri carried the blue token past marker ec8c431ddade. Mara watched the eastern gate until dawn.

Ledger 22 line 004: Neri carried the blue token past marker 7aa94583ddae. Mara watched the eastern gate until dawn.

Ledger 22 line 005: Neri carried the blue token past marker ef8bd460c481. Mara watched the eastern gate until dawn.

Ledger 22 line 006: Neri carried the blue token past marker b153474d9da6. Mara watched the eastern gate until dawn.

Ledger 22 line 007: Neri carried the blue token past marker d02ddfcf8223. Mara watched the eastern gate until dawn.

Ledger 22 line 008: Neri carried the blue token past marker 6a3cce8cb147. Mara watched the eastern gate until dawn.

Ledger 22 line 009: Neri carried the blue token past marker 7b4dd9636d39. Mara watched the eastern gate until dawn.

Ledger 22 line 010: Neri carried the blue token past marker 4f307efb9919. Mara watched the eastern gate until dawn.

Ledger 22 line 011: Neri carried the blue token past marker 1f9ac73d79ce. Mara watched the eastern gate until dawn.

Ledger 22 line 012: Neri carried the blue token past marker 03a731d7d7c8. Mara watched the eastern gate until dawn.

Ledger 22 line 013: Neri carried the blue token past marker 2dcf2f108262. Mara watched the eastern gate until dawn.

Ledger 22 line 014: Neri carried the blue token past marker 8500af6c5714. Mara watched the eastern gate until dawn.

Ledger 22 line 015: Neri carried the blue token past marker 1bc5aecfdba0. Mara watched the eastern gate until dawn.

Ledger 22 line 016: Neri carried the blue token past marker 792fdc3f15c6. Mara watched the eastern gate until dawn.

Ledger 22 line 017: Neri carried the blue token past marker 0f0539103985. Mara watched the eastern gate until dawn.

Ledger 22 line 018: Neri carried the blue token past marker 33ae283bec3c. Mara watched the eastern gate until dawn.

Ledger 22 line 019: Neri carried the blue token past marker 461947f27e61. Mara watched the eastern gate until dawn.

Ledger 22 line 020: Neri carried the blue token past marker 252b47fc413d. Mara watched the eastern gate until dawn.

Ledger 22 line 021: Neri carried the blue token past marker e88ee31dd110. Mara watched the eastern gate until dawn.

Ledger 22 line 022: Neri carried the blue token past marker 1aad7ce9f53d. Mara watched the eastern gate until dawn.

Ledger 22 line 023: Neri carried the blue token past marker eb30ec6a37d5. Mara watched the eastern gate until dawn.

Ledger 22 line 024: Neri carried the blue token past marker fd9a210962b7. Mara watched the eastern gate until dawn.

Ledger 22 line 025: Neri carried the blue token past marker 3958679e8506. Mara watched the eastern gate until dawn.

Ledger 22 line 026: Neri carried the blue token past marker a8b5b88da118. Mara watched the eastern gate until dawn.

Ledger 22 line 027: Neri carried the blue token past marker 759d2d97f482. Mara watched the eastern gate until dawn.

Ledger 22 line 028: Neri carried the blue token past marker c4409a0250a0. Mara watched the eastern gate until dawn.

Ledger 22 line 029: Neri carried the blue token past marker 0740e1bb9e60. Mara watched the eastern gate until dawn.

Ledger 22 line 030: Neri carried the blue token past marker 9c9e947dc9bc. Mara watched the eastern gate until dawn.

Ledger 22 line 031: Neri carried the blue token past marker 57939c937f6c. Mara watched the eastern gate until dawn.

Ledger 22 line 032: Neri carried the blue token past marker 5a847a8df059. Mara watched the eastern gate until dawn.

Ledger 22 line 033: Neri carried the blue token past marker 7603d77d4dc0. Mara watched the eastern gate until dawn.

Ledger 22 line 034: Neri carried the blue token past marker b2fb394b7009. Mara watched the eastern gate until dawn.

Ledger 22 line 035: Neri carried the blue token past marker d0313769d06b. Mara watched the eastern gate until dawn.

Ledger 22 line 036: Neri carried the blue token past marker ced7bee7cc50. Mara watched the eastern gate until dawn.

Ledger 22 line 037: Neri carried the blue token past marker 5e20c761119c. Mara watched the eastern gate until dawn.

Ledger 22 line 038: Neri carried the blue token past marker 835a5983235e. Mara watched the eastern gate until dawn.

Ledger 22 line 039: Neri carried the blue token past marker 676a17da288f. Mara watched the eastern gate until dawn.

Ledger 22 line 040: Neri carried the blue token past marker 654a7bfcfc53. Mara watched the eastern gate until dawn.

Ledger 22 line 041: Neri carried the blue token past marker 43c3ad4611de. Mara watched the eastern gate until dawn.

Ledger 22 line 042: Neri carried the blue token past marker 3e06f29d87a3. Mara watched the eastern gate until dawn.

Ledger 22 line 043: Neri carried the blue token past marker a1fc88c97c55. Mara watched the eastern gate until dawn.

Ledger 22 line 044: Neri carried the blue token past marker 1442794bb2dc. Mara watched the eastern gate until dawn.

Ledger 22 line 045: Neri carried the blue token past marker 212f46ffbffb. Mara watched the eastern gate until dawn.

Ledger 22 line 046: Neri carried the blue token past marker c246595da11c. Mara watched the eastern gate until dawn.

Ledger 22 line 047: Neri carried the blue token past marker 82220096bb00. Mara watched the eastern gate until dawn.

Ledger 22 line 048: Neri carried the blue token past marker 6895601e3190. Mara watched the eastern gate until dawn.

Ledger 22 line 049: Neri carried the blue token past marker 1137595b7cb1. Mara watched the eastern gate until dawn.

Ledger 22 line 050: Neri carried the blue token past marker 4b06aa0cd38d. Mara watched the eastern gate until dawn.

Ledger 22 line 051: Neri carried the blue token past marker c3b2c6a979d3. Mara watched the eastern gate until dawn.

Ledger 22 line 052: Neri carried the blue token past marker 4fb1fd863728. Mara watched the eastern gate until dawn.

Ledger 22 line 053: Neri carried the blue token past marker fada17c3ed24. Mara watched the eastern gate until dawn.

Ledger 22 line 054: Neri carried the blue token past marker edd58f18f848. Mara watched the eastern gate until dawn.

Ledger 22 line 055: Neri carried the blue token past marker feda3da9f2a0. Mara watched the eastern gate until dawn.

Ledger 22 line 056: Neri carried the blue token past marker 9ccb183038ff. Mara watched the eastern gate until dawn.

Ledger 22 line 057: Neri carried the blue token past marker 974036742b82. Mara watched the eastern gate until dawn.

Ledger 22 line 058: Neri carried the blue token past marker aed28d11990e. Mara watched the eastern gate until dawn.

Ledger 22 line 059: Neri carried the blue token past marker 9a219f898774. Mara watched the eastern gate until dawn.

Ledger 22 line 060: Neri carried the blue token past marker 947850b3de96. Mara watched the eastern gate until dawn.

Ledger 22 line 061: Neri carried the blue token past marker 880ef868278d. Mara watched the eastern gate until dawn.

Ledger 22 line 062: Neri carried the blue token past marker 1fa8acd3ea2b. Mara watched the eastern gate until dawn.

Ledger 22 line 063: Neri carried the blue token past marker 3af80f1e7c5d. Mara watched the eastern gate until dawn.

Ledger 22 line 064: Neri carried the blue token past marker e00b69794c9b. Mara watched the eastern gate until dawn.

Ledger 22 line 065: Neri carried the blue token past marker 2e725165f059. Mara watched the eastern gate until dawn.

Ledger 22 line 066: Neri carried the blue token past marker 2f7af434900a. Mara watched the eastern gate until dawn.

Ledger 22 line 067: Neri carried the blue token past marker aa00dea7564e. Mara watched the eastern gate until dawn.

Ledger 22 line 068: Neri carried the blue token past marker 6d32664c6e22. Mara watched the eastern gate until dawn.

Ledger 22 line 069: Neri carried the blue token past marker 14a2c0825823. Mara watched the eastern gate until dawn.

Ledger 22 line 070: Neri carried the blue token past marker 19356aa3becf. Mara watched the eastern gate until dawn.

Ledger 22 line 071: Neri carried the blue token past marker abcc0007805d. Mara watched the eastern gate until dawn.

Ledger 22 line 072: Neri carried the blue token past marker 2389064c4f39. Mara watched the eastern gate until dawn.

Ledger 22 line 073: Neri carried the blue token past marker 6b944347bdd4. Mara watched the eastern gate until dawn.

Ledger 22 line 074: Neri carried the blue token past marker c73331bb36f2. Mara watched the eastern gate until dawn.

Ledger 22 line 075: Neri carried the blue token past marker afbbb63fd093. Mara watched the eastern gate until dawn.

Ledger 22 line 076: Neri carried the blue token past marker 94c85140135c. Mara watched the eastern gate until dawn.

Ledger 22 line 077: Neri carried the blue token past marker b8e1fa575249. Mara watched the eastern gate until dawn.

Ledger 22 line 078: Neri carried the blue token past marker 604bf243df59. Mara watched the eastern gate until dawn.

Ledger 22 line 079: Neri carried the blue token past marker a0ff4f798afc. Mara watched the eastern gate until dawn.

Ledger 22 line 080: Neri carried the blue token past marker a0c5ead25594. Mara watched the eastern gate until dawn.

Ledger 22 line 081: Neri carried the blue token past marker 05bfb40742d5. Mara watched the eastern gate until dawn.

Ledger 22 line 082: Neri carried the blue token past marker d8c08a48411d. Mara watched the eastern gate until dawn.

Ledger 22 line 083: Neri carried the blue token past marker e65ed9f923a8. Mara watched the eastern gate until dawn.

Ledger 22 line 084: Neri carried the blue token past marker 9a8fee6baed5. Mara watched the eastern gate until dawn.

Ledger 22 line 085: Neri carried the blue token past marker 71fc0aeb5aff. Mara watched the eastern gate until dawn.

Ledger 22 line 086: Neri carried the blue token past marker 1224c5c785cc. Mara watched the eastern gate until dawn.

Ledger 22 line 087: Neri carried the blue token past marker 865af4a7f33f. Mara watched the eastern gate until dawn.

Ledger 22 line 088: Neri carried the blue token past marker 47405b778a49. Mara watched the eastern gate until dawn.

Ledger 22 line 089: Neri carried the blue token past marker d747bddfa607. Mara watched the eastern gate until dawn.

Ledger 22 line 090: Neri carried the blue token past marker dc7b3eb3dc70. Mara watched the eastern gate until dawn.

Ledger 22 line 091: Neri carried the blue token past marker 1ac81278961e. Mara watched the eastern gate until dawn.

Ledger 22 line 092: Neri carried the blue token past marker c0f1ab813db1. Mara watched the eastern gate until dawn.

Ledger 22 line 093: Neri carried the blue token past marker d92b44857f00. Mara watched the eastern gate until dawn.

Ledger 22 line 094: Neri carried the blue token past marker 4e23e2fb9072. Mara watched the eastern gate until dawn.

Ledger 22 line 095: Neri carried the blue token past marker a910484e80cf. Mara watched the eastern gate until dawn.

Ledger 22 line 096: Neri carried the blue token past marker 417968783b0c. Mara watched the eastern gate until dawn.

Ledger 22 line 097: Neri carried the blue token past marker bef9e7abc586. Mara watched the eastern gate until dawn.

Ledger 22 line 098: Neri carried the blue token past marker c28f3aa85347. Mara watched the eastern gate until dawn.

Ledger 22 line 099: Neri carried the blue token past marker d04dbcff742e. Mara watched the eastern gate until dawn.

Ledger 22 line 100: Neri carried the blue token past marker 38233dd291c7. Mara watched the eastern gate until dawn.

Ledger 22 line 101: Neri carried the blue token past marker 6e392d30c52e. Mara watched the eastern gate until dawn.

Ledger 22 line 102: Neri carried the blue token past marker 92e1ee75b044. Mara watched the eastern gate until dawn.

Ledger 22 line 103: Neri carried the blue token past marker ab2a29aa5a43. Mara watched the eastern gate until dawn.

Ledger 22 line 104: Neri carried the blue token past marker 12e6ee047929. Mara watched the eastern gate until dawn.

Ledger 22 line 105: Neri carried the blue token past marker 23b9fa2ba10d. Mara watched the eastern gate until dawn.

Ledger 22 line 106: Neri carried the blue token past marker 7db2e3bf9852. Mara watched the eastern gate until dawn.

Ledger 22 line 107: Neri carried the blue token past marker f63dd59bf8b7. Mara watched the eastern gate until dawn.

Ledger 22 line 108: Neri carried the blue token past marker 1d500e73eb2d. Mara watched the eastern gate until dawn.

Ledger 22 line 109: Neri carried the blue token past marker 61c4167ee9e9. Mara watched the eastern gate until dawn.

Ledger 22 line 110: Neri carried the blue token past marker a953d0c36d85. Mara watched the eastern gate until dawn.

Ledger 22 line 111: Neri carried the blue token past marker afc688b827b2. Mara watched the eastern gate until dawn.

Ledger 22 line 112: Neri carried the blue token past marker 66c9a8357c0d. Mara watched the eastern gate until dawn.

Ledger 22 line 113: Neri carried the blue token past marker d96cb26d47c5. Mara watched the eastern gate until dawn.

Ledger 22 line 114: Neri carried the blue token past marker 103b32a36ef7. Mara watched the eastern gate until dawn.

Ledger 22 line 115: Neri carried the blue token past marker d32f2df6fa07. Mara watched the eastern gate until dawn.

Ledger 22 line 116: Neri carried the blue token past marker eadfa823ba04. Mara watched the eastern gate until dawn.

Ledger 22 line 117: Neri carried the blue token past marker 30a8e7f8aba2. Mara watched the eastern gate until dawn.

Ledger 22 line 118: Neri carried the blue token past marker ed942b110007. Mara watched the eastern gate until dawn.

Ledger 22 line 119: Neri carried the blue token past marker 475e0b2956f4. Mara watched the eastern gate until dawn.

Ledger 22 line 120: Neri carried the blue token past marker af44527897dd. Mara watched the eastern gate until dawn.

Ledger 22 line 121: Neri carried the blue token past marker baf8c5df94d3. Mara watched the eastern gate until dawn.

Ledger 22 line 122: Neri carried the blue token past marker 2dbb30164a3e. Mara watched the eastern gate until dawn.

Ledger 22 line 123: Neri carried the blue token past marker b239146ee454. Mara watched the eastern gate until dawn.

Ledger 22 line 124: Neri carried the blue token past marker 0356775e7a09. Mara watched the eastern gate until dawn.

Ledger 22 line 125: Neri carried the blue token past marker 291c105f9f6a. Mara watched the eastern gate until dawn.

Ledger 22 line 126: Neri carried the blue token past marker aafc620e64c3. Mara watched the eastern gate until dawn.

Ledger 22 line 127: Neri carried the blue token past marker 0310bf0e14f0. Mara watched the eastern gate until dawn.

Ledger 22 line 128: Neri carried the blue token past marker 6781b49ea668. Mara watched the eastern gate until dawn.

Ledger 22 line 129: Neri carried the blue token past marker 950c14558028. Mara watched the eastern gate until dawn.

Ledger 22 line 130: Neri carried the blue token past marker 9c7b40c5ad58. Mara watched the eastern gate until dawn.

Ledger 22 line 131: Neri carried the blue token past marker 4f31bc574f9f. Mara watched the eastern gate until dawn.

Ledger 22 line 132: Neri carried the blue token past marker 5bb49a5f0afb. Mara watched the eastern gate until dawn.

Ledger 22 line 133: Neri carried the blue token past marker 4fb4967a859c. Mara watched the eastern gate until dawn.

Ledger 22 line 134: Neri carried the blue token past marker 445b269ae158. Mara watched the eastern gate until dawn.

Ledger 22 line 135: Neri carried the blue token past marker b7c268b04839. Mara watched the eastern gate until dawn.

Ledger 22 line 136: Neri carried the blue token past marker c8f0a3aa3357. Mara watched the eastern gate until dawn.

Ledger 22 line 137: Neri carried the blue token past marker 29b44701d736. Mara watched the eastern gate until dawn.

Ledger 22 line 138: Neri carried the blue token past marker 578833cbf59f. Mara watched the eastern gate until dawn.

Ledger 22 line 139: Neri carried the blue token past marker 724d8dcfe72e. Mara watched the eastern gate until dawn.

Ledger 22 line 140: Neri carried the blue token past marker 9b1eb3735722. Mara watched the eastern gate until dawn.
