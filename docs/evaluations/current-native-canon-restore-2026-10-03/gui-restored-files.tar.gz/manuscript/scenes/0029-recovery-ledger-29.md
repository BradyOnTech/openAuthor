---
id: scene-0029
title: Recovery ledger 29
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.167917+00:00
updated_at: 2026-10-03T12:14:52.167917+00:00
---

Ledger 29 line 001: Neri carried the blue token past marker 0552146b89cb. Mara watched the eastern gate until dawn.

Ledger 29 line 002: Neri carried the blue token past marker 6fdcca93a426. Mara watched the eastern gate until dawn.

Ledger 29 line 003: Neri carried the blue token past marker e9e2e5a2b0bd. Mara watched the eastern gate until dawn.

Ledger 29 line 004: Neri carried the blue token past marker 0cbfb263269c. Mara watched the eastern gate until dawn.

Ledger 29 line 005: Neri carried the blue token past marker a5c16bf53288. Mara watched the eastern gate until dawn.

Ledger 29 line 006: Neri carried the blue token past marker d4b90f9d3c35. Mara watched the eastern gate until dawn.

Ledger 29 line 007: Neri carried the blue token past marker 8f45e56eaa88. Mara watched the eastern gate until dawn.

Ledger 29 line 008: Neri carried the blue token past marker 5800c39b7a5e. Mara watched the eastern gate until dawn.

Ledger 29 line 009: Neri carried the blue token past marker f0a6b23687d5. Mara watched the eastern gate until dawn.

Ledger 29 line 010: Neri carried the blue token past marker adf12f892234. Mara watched the eastern gate until dawn.

Ledger 29 line 011: Neri carried the blue token past marker 7c8c26de067f. Mara watched the eastern gate until dawn.

Ledger 29 line 012: Neri carried the blue token past marker 7a8b7a4c3f5d. Mara watched the eastern gate until dawn.

Ledger 29 line 013: Neri carried the blue token past marker 5adf9b32621f. Mara watched the eastern gate until dawn.

Ledger 29 line 014: Neri carried the blue token past marker de9f10361a6d. Mara watched the eastern gate until dawn.

Ledger 29 line 015: Neri carried the blue token past marker 2a7e18891410. Mara watched the eastern gate until dawn.

Ledger 29 line 016: Neri carried the blue token past marker 377eed843140. Mara watched the eastern gate until dawn.

Ledger 29 line 017: Neri carried the blue token past marker f2be240af668. Mara watched the eastern gate until dawn.

Ledger 29 line 018: Neri carried the blue token past marker 4972bd9e19d8. Mara watched the eastern gate until dawn.

Ledger 29 line 019: Neri carried the blue token past marker 237887918460. Mara watched the eastern gate until dawn.

Ledger 29 line 020: Neri carried the blue token past marker ddb495064459. Mara watched the eastern gate until dawn.

Ledger 29 line 021: Neri carried the blue token past marker 14cc12d5b156. Mara watched the eastern gate until dawn.

Ledger 29 line 022: Neri carried the blue token past marker 065198b15965. Mara watched the eastern gate until dawn.

Ledger 29 line 023: Neri carried the blue token past marker dab138679ccf. Mara watched the eastern gate until dawn.

Ledger 29 line 024: Neri carried the blue token past marker b8c2623653a7. Mara watched the eastern gate until dawn.

Ledger 29 line 025: Neri carried the blue token past marker 4295f73c65bd. Mara watched the eastern gate until dawn.

Ledger 29 line 026: Neri carried the blue token past marker 45869ad3b404. Mara watched the eastern gate until dawn.

Ledger 29 line 027: Neri carried the blue token past marker 7303c4f5e247. Mara watched the eastern gate until dawn.

Ledger 29 line 028: Neri carried the blue token past marker 5726b9993097. Mara watched the eastern gate until dawn.

Ledger 29 line 029: Neri carried the blue token past marker be4896fbc610. Mara watched the eastern gate until dawn.

Ledger 29 line 030: Neri carried the blue token past marker 90e3ecb4f135. Mara watched the eastern gate until dawn.

Ledger 29 line 031: Neri carried the blue token past marker 1be0b07098fd. Mara watched the eastern gate until dawn.

Ledger 29 line 032: Neri carried the blue token past marker 974e13395133. Mara watched the eastern gate until dawn.

Ledger 29 line 033: Neri carried the blue token past marker 9a7908b41425. Mara watched the eastern gate until dawn.

Ledger 29 line 034: Neri carried the blue token past marker 32eaaad082f2. Mara watched the eastern gate until dawn.

Ledger 29 line 035: Neri carried the blue token past marker cae1652a7217. Mara watched the eastern gate until dawn.

Ledger 29 line 036: Neri carried the blue token past marker dd154feee71e. Mara watched the eastern gate until dawn.

Ledger 29 line 037: Neri carried the blue token past marker 4b7a0e0458c5. Mara watched the eastern gate until dawn.

Ledger 29 line 038: Neri carried the blue token past marker 9adc7378f560. Mara watched the eastern gate until dawn.

Ledger 29 line 039: Neri carried the blue token past marker 06a62ed0bcc0. Mara watched the eastern gate until dawn.

Ledger 29 line 040: Neri carried the blue token past marker 42f2ad7628b9. Mara watched the eastern gate until dawn.

Ledger 29 line 041: Neri carried the blue token past marker 000616ee1b75. Mara watched the eastern gate until dawn.

Ledger 29 line 042: Neri carried the blue token past marker 5ff792a1c892. Mara watched the eastern gate until dawn.

Ledger 29 line 043: Neri carried the blue token past marker 269e9d86ea5f. Mara watched the eastern gate until dawn.

Ledger 29 line 044: Neri carried the blue token past marker b8741022b936. Mara watched the eastern gate until dawn.

Ledger 29 line 045: Neri carried the blue token past marker 2d7f83cb38be. Mara watched the eastern gate until dawn.

Ledger 29 line 046: Neri carried the blue token past marker 5f7cca7023cf. Mara watched the eastern gate until dawn.

Ledger 29 line 047: Neri carried the blue token past marker 5d372dc688a7. Mara watched the eastern gate until dawn.

Ledger 29 line 048: Neri carried the blue token past marker 00d250b87738. Mara watched the eastern gate until dawn.

Ledger 29 line 049: Neri carried the blue token past marker 67cf164e8ff5. Mara watched the eastern gate until dawn.

Ledger 29 line 050: Neri carried the blue token past marker 780c503cd2e9. Mara watched the eastern gate until dawn.

Ledger 29 line 051: Neri carried the blue token past marker 74b78b821d9b. Mara watched the eastern gate until dawn.

Ledger 29 line 052: Neri carried the blue token past marker 9a4efc79ae6d. Mara watched the eastern gate until dawn.

Ledger 29 line 053: Neri carried the blue token past marker 62bc2aca0e0d. Mara watched the eastern gate until dawn.

Ledger 29 line 054: Neri carried the blue token past marker 58c9979466ae. Mara watched the eastern gate until dawn.

Ledger 29 line 055: Neri carried the blue token past marker e4b0e3798920. Mara watched the eastern gate until dawn.

Ledger 29 line 056: Neri carried the blue token past marker 46e1e9df7d33. Mara watched the eastern gate until dawn.

Ledger 29 line 057: Neri carried the blue token past marker 57e2cda12a5d. Mara watched the eastern gate until dawn.

Ledger 29 line 058: Neri carried the blue token past marker 02fd8120dae2. Mara watched the eastern gate until dawn.

Ledger 29 line 059: Neri carried the blue token past marker 36dc09ad2d2a. Mara watched the eastern gate until dawn.

Ledger 29 line 060: Neri carried the blue token past marker 08ec75b4363a. Mara watched the eastern gate until dawn.

Ledger 29 line 061: Neri carried the blue token past marker e11c34de024f. Mara watched the eastern gate until dawn.

Ledger 29 line 062: Neri carried the blue token past marker 6f2627679501. Mara watched the eastern gate until dawn.

Ledger 29 line 063: Neri carried the blue token past marker be0ba9c83c52. Mara watched the eastern gate until dawn.

Ledger 29 line 064: Neri carried the blue token past marker 7fbdeabc208f. Mara watched the eastern gate until dawn.

Ledger 29 line 065: Neri carried the blue token past marker 6655937f29c0. Mara watched the eastern gate until dawn.

Ledger 29 line 066: Neri carried the blue token past marker b1620732e098. Mara watched the eastern gate until dawn.

Ledger 29 line 067: Neri carried the blue token past marker d2fe016bdff5. Mara watched the eastern gate until dawn.

Ledger 29 line 068: Neri carried the blue token past marker ff1d639ab23f. Mara watched the eastern gate until dawn.

Ledger 29 line 069: Neri carried the blue token past marker bbd7be0edd7a. Mara watched the eastern gate until dawn.

Ledger 29 line 070: Neri carried the blue token past marker 6d775b357c18. Mara watched the eastern gate until dawn.

Ledger 29 line 071: Neri carried the blue token past marker 60892b30f2ca. Mara watched the eastern gate until dawn.

Ledger 29 line 072: Neri carried the blue token past marker abe1431d4342. Mara watched the eastern gate until dawn.

Ledger 29 line 073: Neri carried the blue token past marker 470e3481f5e3. Mara watched the eastern gate until dawn.

Ledger 29 line 074: Neri carried the blue token past marker c81899c6e442. Mara watched the eastern gate until dawn.

Ledger 29 line 075: Neri carried the blue token past marker 6e1ebe034f75. Mara watched the eastern gate until dawn.

Ledger 29 line 076: Neri carried the blue token past marker fa9f6fc64223. Mara watched the eastern gate until dawn.

Ledger 29 line 077: Neri carried the blue token past marker 7b275e6a2b74. Mara watched the eastern gate until dawn.

Ledger 29 line 078: Neri carried the blue token past marker 2e87d252a761. Mara watched the eastern gate until dawn.

Ledger 29 line 079: Neri carried the blue token past marker 722711802d11. Mara watched the eastern gate until dawn.

Ledger 29 line 080: Neri carried the blue token past marker 53d8954985fa. Mara watched the eastern gate until dawn.

Ledger 29 line 081: Neri carried the blue token past marker 836341f96b5b. Mara watched the eastern gate until dawn.

Ledger 29 line 082: Neri carried the blue token past marker 04fa4c2ad2fb. Mara watched the eastern gate until dawn.

Ledger 29 line 083: Neri carried the blue token past marker 6f93fa322c34. Mara watched the eastern gate until dawn.

Ledger 29 line 084: Neri carried the blue token past marker d11c2f7a927c. Mara watched the eastern gate until dawn.

Ledger 29 line 085: Neri carried the blue token past marker 67fc8933532d. Mara watched the eastern gate until dawn.

Ledger 29 line 086: Neri carried the blue token past marker ba0485735d58. Mara watched the eastern gate until dawn.

Ledger 29 line 087: Neri carried the blue token past marker f7bf85ed66c1. Mara watched the eastern gate until dawn.

Ledger 29 line 088: Neri carried the blue token past marker fa2710532605. Mara watched the eastern gate until dawn.

Ledger 29 line 089: Neri carried the blue token past marker 123cdb6e06f3. Mara watched the eastern gate until dawn.

Ledger 29 line 090: Neri carried the blue token past marker 46961eb58e0b. Mara watched the eastern gate until dawn.

Ledger 29 line 091: Neri carried the blue token past marker 2ddf74b2c692. Mara watched the eastern gate until dawn.

Ledger 29 line 092: Neri carried the blue token past marker 84ea2ea79c1f. Mara watched the eastern gate until dawn.

Ledger 29 line 093: Neri carried the blue token past marker d6d4d5d1e82f. Mara watched the eastern gate until dawn.

Ledger 29 line 094: Neri carried the blue token past marker 2cce5498fc3c. Mara watched the eastern gate until dawn.

Ledger 29 line 095: Neri carried the blue token past marker 9313eb835e55. Mara watched the eastern gate until dawn.

Ledger 29 line 096: Neri carried the blue token past marker a305fa587a04. Mara watched the eastern gate until dawn.

Ledger 29 line 097: Neri carried the blue token past marker fdf00f1bd924. Mara watched the eastern gate until dawn.

Ledger 29 line 098: Neri carried the blue token past marker dd29768e8e4f. Mara watched the eastern gate until dawn.

Ledger 29 line 099: Neri carried the blue token past marker 8a1938856a4b. Mara watched the eastern gate until dawn.

Ledger 29 line 100: Neri carried the blue token past marker 6725ec563d5e. Mara watched the eastern gate until dawn.

Ledger 29 line 101: Neri carried the blue token past marker 13e1e8c4d995. Mara watched the eastern gate until dawn.

Ledger 29 line 102: Neri carried the blue token past marker 8a5246f94d3b. Mara watched the eastern gate until dawn.

Ledger 29 line 103: Neri carried the blue token past marker b611af0de060. Mara watched the eastern gate until dawn.

Ledger 29 line 104: Neri carried the blue token past marker 9b6c23998a7c. Mara watched the eastern gate until dawn.

Ledger 29 line 105: Neri carried the blue token past marker 4aab92042cd9. Mara watched the eastern gate until dawn.

Ledger 29 line 106: Neri carried the blue token past marker 171685585e7e. Mara watched the eastern gate until dawn.

Ledger 29 line 107: Neri carried the blue token past marker 2aa701f524e1. Mara watched the eastern gate until dawn.

Ledger 29 line 108: Neri carried the blue token past marker 0fce40db3777. Mara watched the eastern gate until dawn.

Ledger 29 line 109: Neri carried the blue token past marker c12b9a6cf6eb. Mara watched the eastern gate until dawn.

Ledger 29 line 110: Neri carried the blue token past marker 643fe59e0a28. Mara watched the eastern gate until dawn.

Ledger 29 line 111: Neri carried the blue token past marker 7074c50e61bc. Mara watched the eastern gate until dawn.

Ledger 29 line 112: Neri carried the blue token past marker 8d9d8fa3c97b. Mara watched the eastern gate until dawn.

Ledger 29 line 113: Neri carried the blue token past marker fc3cdbb5f63d. Mara watched the eastern gate until dawn.

Ledger 29 line 114: Neri carried the blue token past marker c8068285ce28. Mara watched the eastern gate until dawn.

Ledger 29 line 115: Neri carried the blue token past marker dc7f58a71d94. Mara watched the eastern gate until dawn.

Ledger 29 line 116: Neri carried the blue token past marker 2f6e6775c6cc. Mara watched the eastern gate until dawn.

Ledger 29 line 117: Neri carried the blue token past marker c4961becc085. Mara watched the eastern gate until dawn.

Ledger 29 line 118: Neri carried the blue token past marker 3229b64d2d47. Mara watched the eastern gate until dawn.

Ledger 29 line 119: Neri carried the blue token past marker 0e043b40c185. Mara watched the eastern gate until dawn.

Ledger 29 line 120: Neri carried the blue token past marker 05e4f4dd940b. Mara watched the eastern gate until dawn.

Ledger 29 line 121: Neri carried the blue token past marker 999abade4e7d. Mara watched the eastern gate until dawn.

Ledger 29 line 122: Neri carried the blue token past marker 434191e9249a. Mara watched the eastern gate until dawn.

Ledger 29 line 123: Neri carried the blue token past marker 2e60b61d2d39. Mara watched the eastern gate until dawn.

Ledger 29 line 124: Neri carried the blue token past marker 9dea603ac97f. Mara watched the eastern gate until dawn.

Ledger 29 line 125: Neri carried the blue token past marker 3d0727ea716c. Mara watched the eastern gate until dawn.

Ledger 29 line 126: Neri carried the blue token past marker f67031815196. Mara watched the eastern gate until dawn.

Ledger 29 line 127: Neri carried the blue token past marker 9c4e55eed920. Mara watched the eastern gate until dawn.

Ledger 29 line 128: Neri carried the blue token past marker 882f7243b326. Mara watched the eastern gate until dawn.

Ledger 29 line 129: Neri carried the blue token past marker fcb3a12986b6. Mara watched the eastern gate until dawn.

Ledger 29 line 130: Neri carried the blue token past marker 41f06a66cd1c. Mara watched the eastern gate until dawn.

Ledger 29 line 131: Neri carried the blue token past marker 683ab651f93d. Mara watched the eastern gate until dawn.

Ledger 29 line 132: Neri carried the blue token past marker cf65f686daa0. Mara watched the eastern gate until dawn.

Ledger 29 line 133: Neri carried the blue token past marker 14e0d48e52f6. Mara watched the eastern gate until dawn.

Ledger 29 line 134: Neri carried the blue token past marker d529b7904c63. Mara watched the eastern gate until dawn.

Ledger 29 line 135: Neri carried the blue token past marker 55a7616a1a35. Mara watched the eastern gate until dawn.

Ledger 29 line 136: Neri carried the blue token past marker c98f30dfdec9. Mara watched the eastern gate until dawn.

Ledger 29 line 137: Neri carried the blue token past marker 45310e08611d. Mara watched the eastern gate until dawn.

Ledger 29 line 138: Neri carried the blue token past marker a0aacaa0302c. Mara watched the eastern gate until dawn.

Ledger 29 line 139: Neri carried the blue token past marker 57abbbcb2bba. Mara watched the eastern gate until dawn.

Ledger 29 line 140: Neri carried the blue token past marker 0ef1240c08e9. Mara watched the eastern gate until dawn.
