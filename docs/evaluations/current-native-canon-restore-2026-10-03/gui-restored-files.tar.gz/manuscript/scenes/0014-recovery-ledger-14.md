---
id: scene-0014
title: Recovery ledger 14
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.160019+00:00
updated_at: 2026-10-03T12:14:52.160019+00:00
---

Ledger 14 line 001: Neri carried the blue token past marker 34124ee0e435. Mara watched the eastern gate until dawn.

Ledger 14 line 002: Neri carried the blue token past marker 8f6b2190a7bf. Mara watched the eastern gate until dawn.

Ledger 14 line 003: Neri carried the blue token past marker 7c3ec7450c23. Mara watched the eastern gate until dawn.

Ledger 14 line 004: Neri carried the blue token past marker 128006f5ae14. Mara watched the eastern gate until dawn.

Ledger 14 line 005: Neri carried the blue token past marker 22642ec82122. Mara watched the eastern gate until dawn.

Ledger 14 line 006: Neri carried the blue token past marker c499c9530ac6. Mara watched the eastern gate until dawn.

Ledger 14 line 007: Neri carried the blue token past marker 1efe3a7d0ece. Mara watched the eastern gate until dawn.

Ledger 14 line 008: Neri carried the blue token past marker 1c0225b5df4d. Mara watched the eastern gate until dawn.

Ledger 14 line 009: Neri carried the blue token past marker 09a4717b445a. Mara watched the eastern gate until dawn.

Ledger 14 line 010: Neri carried the blue token past marker 499ec6718125. Mara watched the eastern gate until dawn.

Ledger 14 line 011: Neri carried the blue token past marker 74d6c3d9c493. Mara watched the eastern gate until dawn.

Ledger 14 line 012: Neri carried the blue token past marker 882f3ff1337f. Mara watched the eastern gate until dawn.

Ledger 14 line 013: Neri carried the blue token past marker 72d9d2b8b932. Mara watched the eastern gate until dawn.

Ledger 14 line 014: Neri carried the blue token past marker 73b15e62f49b. Mara watched the eastern gate until dawn.

Ledger 14 line 015: Neri carried the blue token past marker 106dcc254588. Mara watched the eastern gate until dawn.

Ledger 14 line 016: Neri carried the blue token past marker 8c058f41a260. Mara watched the eastern gate until dawn.

Ledger 14 line 017: Neri carried the blue token past marker de50c02b7086. Mara watched the eastern gate until dawn.

Ledger 14 line 018: Neri carried the blue token past marker 6c9b5789129d. Mara watched the eastern gate until dawn.

Ledger 14 line 019: Neri carried the blue token past marker 57a898af5966. Mara watched the eastern gate until dawn.

Ledger 14 line 020: Neri carried the blue token past marker 0e3975b11906. Mara watched the eastern gate until dawn.

Ledger 14 line 021: Neri carried the blue token past marker d5bc67411a7d. Mara watched the eastern gate until dawn.

Ledger 14 line 022: Neri carried the blue token past marker e72c0821fe51. Mara watched the eastern gate until dawn.

Ledger 14 line 023: Neri carried the blue token past marker 7d991452a905. Mara watched the eastern gate until dawn.

Ledger 14 line 024: Neri carried the blue token past marker 7ed7b3a12442. Mara watched the eastern gate until dawn.

Ledger 14 line 025: Neri carried the blue token past marker bdad23af1789. Mara watched the eastern gate until dawn.

Ledger 14 line 026: Neri carried the blue token past marker d62f52c75bab. Mara watched the eastern gate until dawn.

Ledger 14 line 027: Neri carried the blue token past marker f8b68c59350e. Mara watched the eastern gate until dawn.

Ledger 14 line 028: Neri carried the blue token past marker fad8c7d9c25a. Mara watched the eastern gate until dawn.

Ledger 14 line 029: Neri carried the blue token past marker ce62018f7ef0. Mara watched the eastern gate until dawn.

Ledger 14 line 030: Neri carried the blue token past marker 7ff367a502cd. Mara watched the eastern gate until dawn.

Ledger 14 line 031: Neri carried the blue token past marker a7b4954b2c7d. Mara watched the eastern gate until dawn.

Ledger 14 line 032: Neri carried the blue token past marker f99e6751869f. Mara watched the eastern gate until dawn.

Ledger 14 line 033: Neri carried the blue token past marker 3cdb2e8c4eea. Mara watched the eastern gate until dawn.

Ledger 14 line 034: Neri carried the blue token past marker fb2a8702ea5d. Mara watched the eastern gate until dawn.

Ledger 14 line 035: Neri carried the blue token past marker a7d50ec36766. Mara watched the eastern gate until dawn.

Ledger 14 line 036: Neri carried the blue token past marker 5f3aeb0ca02b. Mara watched the eastern gate until dawn.

Ledger 14 line 037: Neri carried the blue token past marker 3cb71639e6e2. Mara watched the eastern gate until dawn.

Ledger 14 line 038: Neri carried the blue token past marker 581e742626ad. Mara watched the eastern gate until dawn.

Ledger 14 line 039: Neri carried the blue token past marker 51365b51f426. Mara watched the eastern gate until dawn.

Ledger 14 line 040: Neri carried the blue token past marker 032628d10ba7. Mara watched the eastern gate until dawn.

Ledger 14 line 041: Neri carried the blue token past marker 40541128b9bc. Mara watched the eastern gate until dawn.

Ledger 14 line 042: Neri carried the blue token past marker ff65a0ab6afe. Mara watched the eastern gate until dawn.

Ledger 14 line 043: Neri carried the blue token past marker 470581b64879. Mara watched the eastern gate until dawn.

Ledger 14 line 044: Neri carried the blue token past marker bbe893f206f2. Mara watched the eastern gate until dawn.

Ledger 14 line 045: Neri carried the blue token past marker 184f9534a28e. Mara watched the eastern gate until dawn.

Ledger 14 line 046: Neri carried the blue token past marker 95213f09d96a. Mara watched the eastern gate until dawn.

Ledger 14 line 047: Neri carried the blue token past marker aa447e9f16b1. Mara watched the eastern gate until dawn.

Ledger 14 line 048: Neri carried the blue token past marker 1aadf23dcd0c. Mara watched the eastern gate until dawn.

Ledger 14 line 049: Neri carried the blue token past marker cff4d9d3e9dc. Mara watched the eastern gate until dawn.

Ledger 14 line 050: Neri carried the blue token past marker cad1ca50782f. Mara watched the eastern gate until dawn.

Ledger 14 line 051: Neri carried the blue token past marker 2674a8d0da64. Mara watched the eastern gate until dawn.

Ledger 14 line 052: Neri carried the blue token past marker b8c0d2cb23c4. Mara watched the eastern gate until dawn.

Ledger 14 line 053: Neri carried the blue token past marker a3b80e160cf0. Mara watched the eastern gate until dawn.

Ledger 14 line 054: Neri carried the blue token past marker 6bd7a40f5ce0. Mara watched the eastern gate until dawn.

Ledger 14 line 055: Neri carried the blue token past marker 9a0f88c366a2. Mara watched the eastern gate until dawn.

Ledger 14 line 056: Neri carried the blue token past marker fde9914c44a4. Mara watched the eastern gate until dawn.

Ledger 14 line 057: Neri carried the blue token past marker 741323f3bd9d. Mara watched the eastern gate until dawn.

Ledger 14 line 058: Neri carried the blue token past marker 94e06b6b8db8. Mara watched the eastern gate until dawn.

Ledger 14 line 059: Neri carried the blue token past marker 3431b3e3322a. Mara watched the eastern gate until dawn.

Ledger 14 line 060: Neri carried the blue token past marker ae928b5085a4. Mara watched the eastern gate until dawn.

Ledger 14 line 061: Neri carried the blue token past marker 8ca58261cf19. Mara watched the eastern gate until dawn.

Ledger 14 line 062: Neri carried the blue token past marker 6143546bf804. Mara watched the eastern gate until dawn.

Ledger 14 line 063: Neri carried the blue token past marker da9841014f21. Mara watched the eastern gate until dawn.

Ledger 14 line 064: Neri carried the blue token past marker 934e289a32ac. Mara watched the eastern gate until dawn.

Ledger 14 line 065: Neri carried the blue token past marker 35c4abc278a5. Mara watched the eastern gate until dawn.

Ledger 14 line 066: Neri carried the blue token past marker e5c24f822f6d. Mara watched the eastern gate until dawn.

Ledger 14 line 067: Neri carried the blue token past marker fd4d85d79b0c. Mara watched the eastern gate until dawn.

Ledger 14 line 068: Neri carried the blue token past marker 66de00dbdc52. Mara watched the eastern gate until dawn.

Ledger 14 line 069: Neri carried the blue token past marker beb61e860061. Mara watched the eastern gate until dawn.

Ledger 14 line 070: Neri carried the blue token past marker 824186840a65. Mara watched the eastern gate until dawn.

Ledger 14 line 071: Neri carried the blue token past marker 279278f7be38. Mara watched the eastern gate until dawn.

Ledger 14 line 072: Neri carried the blue token past marker 65a8ad0e8347. Mara watched the eastern gate until dawn.

Ledger 14 line 073: Neri carried the blue token past marker 8f7083b9aa5b. Mara watched the eastern gate until dawn.

Ledger 14 line 074: Neri carried the blue token past marker 59307a2b8d91. Mara watched the eastern gate until dawn.

Ledger 14 line 075: Neri carried the blue token past marker 99890697905a. Mara watched the eastern gate until dawn.

Ledger 14 line 076: Neri carried the blue token past marker afaf7712316c. Mara watched the eastern gate until dawn.

Ledger 14 line 077: Neri carried the blue token past marker 29e1cad5d963. Mara watched the eastern gate until dawn.

Ledger 14 line 078: Neri carried the blue token past marker 6b03336b04eb. Mara watched the eastern gate until dawn.

Ledger 14 line 079: Neri carried the blue token past marker a84ac3c05be0. Mara watched the eastern gate until dawn.

Ledger 14 line 080: Neri carried the blue token past marker 94b54319c22e. Mara watched the eastern gate until dawn.

Ledger 14 line 081: Neri carried the blue token past marker 1cb6187f11e2. Mara watched the eastern gate until dawn.

Ledger 14 line 082: Neri carried the blue token past marker b4ef0053e3b7. Mara watched the eastern gate until dawn.

Ledger 14 line 083: Neri carried the blue token past marker ae655411bf90. Mara watched the eastern gate until dawn.

Ledger 14 line 084: Neri carried the blue token past marker 7fad2d44cec5. Mara watched the eastern gate until dawn.

Ledger 14 line 085: Neri carried the blue token past marker 574dccd03f93. Mara watched the eastern gate until dawn.

Ledger 14 line 086: Neri carried the blue token past marker 75355054647b. Mara watched the eastern gate until dawn.

Ledger 14 line 087: Neri carried the blue token past marker 055e1a28e799. Mara watched the eastern gate until dawn.

Ledger 14 line 088: Neri carried the blue token past marker 39af81bced06. Mara watched the eastern gate until dawn.

Ledger 14 line 089: Neri carried the blue token past marker c6197456f43d. Mara watched the eastern gate until dawn.

Ledger 14 line 090: Neri carried the blue token past marker 30d863925338. Mara watched the eastern gate until dawn.

Ledger 14 line 091: Neri carried the blue token past marker 1832a66e3be1. Mara watched the eastern gate until dawn.

Ledger 14 line 092: Neri carried the blue token past marker 77090e260fbb. Mara watched the eastern gate until dawn.

Ledger 14 line 093: Neri carried the blue token past marker 95584523687c. Mara watched the eastern gate until dawn.

Ledger 14 line 094: Neri carried the blue token past marker 1f38e629c5e3. Mara watched the eastern gate until dawn.

Ledger 14 line 095: Neri carried the blue token past marker c254fae5d65d. Mara watched the eastern gate until dawn.

Ledger 14 line 096: Neri carried the blue token past marker 908719fa55cf. Mara watched the eastern gate until dawn.

Ledger 14 line 097: Neri carried the blue token past marker ce21d1023041. Mara watched the eastern gate until dawn.

Ledger 14 line 098: Neri carried the blue token past marker bf60a850df36. Mara watched the eastern gate until dawn.

Ledger 14 line 099: Neri carried the blue token past marker 7832c51b6d6b. Mara watched the eastern gate until dawn.

Ledger 14 line 100: Neri carried the blue token past marker 69855d845527. Mara watched the eastern gate until dawn.

Ledger 14 line 101: Neri carried the blue token past marker ff0b01633389. Mara watched the eastern gate until dawn.

Ledger 14 line 102: Neri carried the blue token past marker 75383f829221. Mara watched the eastern gate until dawn.

Ledger 14 line 103: Neri carried the blue token past marker 6385674b6d31. Mara watched the eastern gate until dawn.

Ledger 14 line 104: Neri carried the blue token past marker f60f685d1fe9. Mara watched the eastern gate until dawn.

Ledger 14 line 105: Neri carried the blue token past marker 152b1578729d. Mara watched the eastern gate until dawn.

Ledger 14 line 106: Neri carried the blue token past marker acf9fda10fb1. Mara watched the eastern gate until dawn.

Ledger 14 line 107: Neri carried the blue token past marker e79756436808. Mara watched the eastern gate until dawn.

Ledger 14 line 108: Neri carried the blue token past marker a9e046d783e0. Mara watched the eastern gate until dawn.

Ledger 14 line 109: Neri carried the blue token past marker 2e658d8d49d4. Mara watched the eastern gate until dawn.

Ledger 14 line 110: Neri carried the blue token past marker ea2fe54b16e0. Mara watched the eastern gate until dawn.

Ledger 14 line 111: Neri carried the blue token past marker 8d5dbb6f4a34. Mara watched the eastern gate until dawn.

Ledger 14 line 112: Neri carried the blue token past marker d6e7cba9d5d3. Mara watched the eastern gate until dawn.

Ledger 14 line 113: Neri carried the blue token past marker 773b667c8720. Mara watched the eastern gate until dawn.

Ledger 14 line 114: Neri carried the blue token past marker 63287351eebe. Mara watched the eastern gate until dawn.

Ledger 14 line 115: Neri carried the blue token past marker 302769840b5c. Mara watched the eastern gate until dawn.

Ledger 14 line 116: Neri carried the blue token past marker 5c37c9e47ffe. Mara watched the eastern gate until dawn.

Ledger 14 line 117: Neri carried the blue token past marker 20eba5e53c12. Mara watched the eastern gate until dawn.

Ledger 14 line 118: Neri carried the blue token past marker 4993800005ff. Mara watched the eastern gate until dawn.

Ledger 14 line 119: Neri carried the blue token past marker 643a22757923. Mara watched the eastern gate until dawn.

Ledger 14 line 120: Neri carried the blue token past marker 5bced8f73023. Mara watched the eastern gate until dawn.

Ledger 14 line 121: Neri carried the blue token past marker fe2cb599b451. Mara watched the eastern gate until dawn.

Ledger 14 line 122: Neri carried the blue token past marker 4762fd2814d5. Mara watched the eastern gate until dawn.

Ledger 14 line 123: Neri carried the blue token past marker 92930e446d8a. Mara watched the eastern gate until dawn.

Ledger 14 line 124: Neri carried the blue token past marker 93cc23d6e7e9. Mara watched the eastern gate until dawn.

Ledger 14 line 125: Neri carried the blue token past marker 67bcbd4ea18a. Mara watched the eastern gate until dawn.

Ledger 14 line 126: Neri carried the blue token past marker c68885a9350c. Mara watched the eastern gate until dawn.

Ledger 14 line 127: Neri carried the blue token past marker 87706864ae88. Mara watched the eastern gate until dawn.

Ledger 14 line 128: Neri carried the blue token past marker a84ddf0cc0ca. Mara watched the eastern gate until dawn.

Ledger 14 line 129: Neri carried the blue token past marker 655f6ccf15e2. Mara watched the eastern gate until dawn.

Ledger 14 line 130: Neri carried the blue token past marker 02ba2d17edbe. Mara watched the eastern gate until dawn.

Ledger 14 line 131: Neri carried the blue token past marker 6120a2508c71. Mara watched the eastern gate until dawn.

Ledger 14 line 132: Neri carried the blue token past marker 4cbf2719cb36. Mara watched the eastern gate until dawn.

Ledger 14 line 133: Neri carried the blue token past marker a0e9fbede44d. Mara watched the eastern gate until dawn.

Ledger 14 line 134: Neri carried the blue token past marker 130b6082ec27. Mara watched the eastern gate until dawn.

Ledger 14 line 135: Neri carried the blue token past marker 50d1112db7d8. Mara watched the eastern gate until dawn.

Ledger 14 line 136: Neri carried the blue token past marker aea3da256721. Mara watched the eastern gate until dawn.

Ledger 14 line 137: Neri carried the blue token past marker 4d9b6274f3cf. Mara watched the eastern gate until dawn.

Ledger 14 line 138: Neri carried the blue token past marker b94076557aba. Mara watched the eastern gate until dawn.

Ledger 14 line 139: Neri carried the blue token past marker af1563978a9d. Mara watched the eastern gate until dawn.

Ledger 14 line 140: Neri carried the blue token past marker 76b189916855. Mara watched the eastern gate until dawn.
