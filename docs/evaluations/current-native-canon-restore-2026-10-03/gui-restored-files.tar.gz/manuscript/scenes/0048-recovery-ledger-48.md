---
id: scene-0048
title: Recovery ledger 48
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.178065+00:00
updated_at: 2026-10-03T12:14:52.178065+00:00
---

Ledger 48 line 001: Neri carried the blue token past marker 8df33932fe32. Mara watched the eastern gate until dawn.

Ledger 48 line 002: Neri carried the blue token past marker 23c6d9e0c36e. Mara watched the eastern gate until dawn.

Ledger 48 line 003: Neri carried the blue token past marker 33c49cc569f3. Mara watched the eastern gate until dawn.

Ledger 48 line 004: Neri carried the blue token past marker 7b5fc394d033. Mara watched the eastern gate until dawn.

Ledger 48 line 005: Neri carried the blue token past marker 60b30fddefbf. Mara watched the eastern gate until dawn.

Ledger 48 line 006: Neri carried the blue token past marker 523868bca6e3. Mara watched the eastern gate until dawn.

Ledger 48 line 007: Neri carried the blue token past marker bc72bd1844ca. Mara watched the eastern gate until dawn.

Ledger 48 line 008: Neri carried the blue token past marker d553abefb84d. Mara watched the eastern gate until dawn.

Ledger 48 line 009: Neri carried the blue token past marker 9d9cbbe64b08. Mara watched the eastern gate until dawn.

Ledger 48 line 010: Neri carried the blue token past marker 30b41946ccde. Mara watched the eastern gate until dawn.

Ledger 48 line 011: Neri carried the blue token past marker 15e5282efabc. Mara watched the eastern gate until dawn.

Ledger 48 line 012: Neri carried the blue token past marker 07e0f9aa0c2c. Mara watched the eastern gate until dawn.

Ledger 48 line 013: Neri carried the blue token past marker 3ac2022b906d. Mara watched the eastern gate until dawn.

Ledger 48 line 014: Neri carried the blue token past marker df78a5bb7aa7. Mara watched the eastern gate until dawn.

Ledger 48 line 015: Neri carried the blue token past marker 31c42f0d7980. Mara watched the eastern gate until dawn.

Ledger 48 line 016: Neri carried the blue token past marker 68e30bd4d715. Mara watched the eastern gate until dawn.

Ledger 48 line 017: Neri carried the blue token past marker 5a912339fd93. Mara watched the eastern gate until dawn.

Ledger 48 line 018: Neri carried the blue token past marker e007b231494b. Mara watched the eastern gate until dawn.

Ledger 48 line 019: Neri carried the blue token past marker 5d41f37b6d3a. Mara watched the eastern gate until dawn.

Ledger 48 line 020: Neri carried the blue token past marker 5d6278a756e0. Mara watched the eastern gate until dawn.

Ledger 48 line 021: Neri carried the blue token past marker f9b79bd2bd5b. Mara watched the eastern gate until dawn.

Ledger 48 line 022: Neri carried the blue token past marker 76f7a484061d. Mara watched the eastern gate until dawn.

Ledger 48 line 023: Neri carried the blue token past marker e9e0d54c6f1d. Mara watched the eastern gate until dawn.

Ledger 48 line 024: Neri carried the blue token past marker 07468b181b11. Mara watched the eastern gate until dawn.

Ledger 48 line 025: Neri carried the blue token past marker fb2198246ed3. Mara watched the eastern gate until dawn.

Ledger 48 line 026: Neri carried the blue token past marker e73952cb30e2. Mara watched the eastern gate until dawn.

Ledger 48 line 027: Neri carried the blue token past marker e4a4c0c37a8a. Mara watched the eastern gate until dawn.

Ledger 48 line 028: Neri carried the blue token past marker 59f433a2ba8d. Mara watched the eastern gate until dawn.

Ledger 48 line 029: Neri carried the blue token past marker 25083fbff8ac. Mara watched the eastern gate until dawn.

Ledger 48 line 030: Neri carried the blue token past marker ea24205a4cf8. Mara watched the eastern gate until dawn.

Ledger 48 line 031: Neri carried the blue token past marker f217bccfaf51. Mara watched the eastern gate until dawn.

Ledger 48 line 032: Neri carried the blue token past marker bceaa9cefa41. Mara watched the eastern gate until dawn.

Ledger 48 line 033: Neri carried the blue token past marker 642bb44dde55. Mara watched the eastern gate until dawn.

Ledger 48 line 034: Neri carried the blue token past marker 074bcba5d971. Mara watched the eastern gate until dawn.

Ledger 48 line 035: Neri carried the blue token past marker ced2d2b042cf. Mara watched the eastern gate until dawn.

Ledger 48 line 036: Neri carried the blue token past marker e3ce0ee27bbc. Mara watched the eastern gate until dawn.

Ledger 48 line 037: Neri carried the blue token past marker 6aba438d2787. Mara watched the eastern gate until dawn.

Ledger 48 line 038: Neri carried the blue token past marker 14fe9a895960. Mara watched the eastern gate until dawn.

Ledger 48 line 039: Neri carried the blue token past marker 69ed37c1a5e5. Mara watched the eastern gate until dawn.

Ledger 48 line 040: Neri carried the blue token past marker c8d1e693e4bf. Mara watched the eastern gate until dawn.

Ledger 48 line 041: Neri carried the blue token past marker ea1b8bc2ea6a. Mara watched the eastern gate until dawn.

Ledger 48 line 042: Neri carried the blue token past marker 585f1f79e86d. Mara watched the eastern gate until dawn.

Ledger 48 line 043: Neri carried the blue token past marker bebb18296e93. Mara watched the eastern gate until dawn.

Ledger 48 line 044: Neri carried the blue token past marker fe5c53168a30. Mara watched the eastern gate until dawn.

Ledger 48 line 045: Neri carried the blue token past marker fdabafb82eef. Mara watched the eastern gate until dawn.

Ledger 48 line 046: Neri carried the blue token past marker d3a72ee77c65. Mara watched the eastern gate until dawn.

Ledger 48 line 047: Neri carried the blue token past marker 0c127765b039. Mara watched the eastern gate until dawn.

Ledger 48 line 048: Neri carried the blue token past marker 3df0f0f290bd. Mara watched the eastern gate until dawn.

Ledger 48 line 049: Neri carried the blue token past marker 27d7af0d9e40. Mara watched the eastern gate until dawn.

Ledger 48 line 050: Neri carried the blue token past marker 0dc8ef221b05. Mara watched the eastern gate until dawn.

Ledger 48 line 051: Neri carried the blue token past marker 57d29c952d6d. Mara watched the eastern gate until dawn.

Ledger 48 line 052: Neri carried the blue token past marker 1ca28e706b24. Mara watched the eastern gate until dawn.

Ledger 48 line 053: Neri carried the blue token past marker d1f5babffedd. Mara watched the eastern gate until dawn.

Ledger 48 line 054: Neri carried the blue token past marker 6a6637999032. Mara watched the eastern gate until dawn.

Ledger 48 line 055: Neri carried the blue token past marker 8be7c3dbc262. Mara watched the eastern gate until dawn.

Ledger 48 line 056: Neri carried the blue token past marker 14e52704bb02. Mara watched the eastern gate until dawn.

Ledger 48 line 057: Neri carried the blue token past marker 6cbb578d024d. Mara watched the eastern gate until dawn.

Ledger 48 line 058: Neri carried the blue token past marker f20ef8dd9c68. Mara watched the eastern gate until dawn.

Ledger 48 line 059: Neri carried the blue token past marker a533da933645. Mara watched the eastern gate until dawn.

Ledger 48 line 060: Neri carried the blue token past marker bdcc01a5456f. Mara watched the eastern gate until dawn.

Ledger 48 line 061: Neri carried the blue token past marker acc6d0712498. Mara watched the eastern gate until dawn.

Ledger 48 line 062: Neri carried the blue token past marker facef4feb31c. Mara watched the eastern gate until dawn.

Ledger 48 line 063: Neri carried the blue token past marker 4e8895df3e2f. Mara watched the eastern gate until dawn.

Ledger 48 line 064: Neri carried the blue token past marker 2e67c4fdcf41. Mara watched the eastern gate until dawn.

Ledger 48 line 065: Neri carried the blue token past marker 34200acdc8ff. Mara watched the eastern gate until dawn.

Ledger 48 line 066: Neri carried the blue token past marker f74ee179b4c5. Mara watched the eastern gate until dawn.

Ledger 48 line 067: Neri carried the blue token past marker d8c6c0f0c5fa. Mara watched the eastern gate until dawn.

Ledger 48 line 068: Neri carried the blue token past marker 07fa80c3c6f5. Mara watched the eastern gate until dawn.

Ledger 48 line 069: Neri carried the blue token past marker a9d6f61aab5c. Mara watched the eastern gate until dawn.

Ledger 48 line 070: Neri carried the blue token past marker 838157f2a728. Mara watched the eastern gate until dawn.

Ledger 48 line 071: Neri carried the blue token past marker b892820a76e1. Mara watched the eastern gate until dawn.

Ledger 48 line 072: Neri carried the blue token past marker ae03b23a8c32. Mara watched the eastern gate until dawn.

Ledger 48 line 073: Neri carried the blue token past marker 7be82f3de2fa. Mara watched the eastern gate until dawn.

Ledger 48 line 074: Neri carried the blue token past marker 216b3f0efd7e. Mara watched the eastern gate until dawn.

Ledger 48 line 075: Neri carried the blue token past marker 8d02cadfdc76. Mara watched the eastern gate until dawn.

Ledger 48 line 076: Neri carried the blue token past marker 9d4dd3bf1602. Mara watched the eastern gate until dawn.

Ledger 48 line 077: Neri carried the blue token past marker 211bc967d93d. Mara watched the eastern gate until dawn.

Ledger 48 line 078: Neri carried the blue token past marker 0c3a51453cdc. Mara watched the eastern gate until dawn.

Ledger 48 line 079: Neri carried the blue token past marker b538f30e6ec9. Mara watched the eastern gate until dawn.

Ledger 48 line 080: Neri carried the blue token past marker 8e833c8850c8. Mara watched the eastern gate until dawn.

Ledger 48 line 081: Neri carried the blue token past marker 21f69d75522e. Mara watched the eastern gate until dawn.

Ledger 48 line 082: Neri carried the blue token past marker 2de44ffac9a8. Mara watched the eastern gate until dawn.

Ledger 48 line 083: Neri carried the blue token past marker 841f3337be57. Mara watched the eastern gate until dawn.

Ledger 48 line 084: Neri carried the blue token past marker 9504505946ff. Mara watched the eastern gate until dawn.

Ledger 48 line 085: Neri carried the blue token past marker e92ca1a25e45. Mara watched the eastern gate until dawn.

Ledger 48 line 086: Neri carried the blue token past marker 3258313cc329. Mara watched the eastern gate until dawn.

Ledger 48 line 087: Neri carried the blue token past marker 306d25074b3a. Mara watched the eastern gate until dawn.

Ledger 48 line 088: Neri carried the blue token past marker abdbfda152f5. Mara watched the eastern gate until dawn.

Ledger 48 line 089: Neri carried the blue token past marker 751ab40dedd7. Mara watched the eastern gate until dawn.

Ledger 48 line 090: Neri carried the blue token past marker 089a539019e1. Mara watched the eastern gate until dawn.

Ledger 48 line 091: Neri carried the blue token past marker d80d0a6b4296. Mara watched the eastern gate until dawn.

Ledger 48 line 092: Neri carried the blue token past marker 806304ded173. Mara watched the eastern gate until dawn.

Ledger 48 line 093: Neri carried the blue token past marker 90cf6d358c54. Mara watched the eastern gate until dawn.

Ledger 48 line 094: Neri carried the blue token past marker b9b30865e1c8. Mara watched the eastern gate until dawn.

Ledger 48 line 095: Neri carried the blue token past marker 9acf640495d1. Mara watched the eastern gate until dawn.

Ledger 48 line 096: Neri carried the blue token past marker 1f6924bb2651. Mara watched the eastern gate until dawn.

Ledger 48 line 097: Neri carried the blue token past marker 4a20d66045fd. Mara watched the eastern gate until dawn.

Ledger 48 line 098: Neri carried the blue token past marker 40be2b9ae3ce. Mara watched the eastern gate until dawn.

Ledger 48 line 099: Neri carried the blue token past marker eec3bcbc8ca7. Mara watched the eastern gate until dawn.

Ledger 48 line 100: Neri carried the blue token past marker f07f70a6d630. Mara watched the eastern gate until dawn.

Ledger 48 line 101: Neri carried the blue token past marker ec83282b2d78. Mara watched the eastern gate until dawn.

Ledger 48 line 102: Neri carried the blue token past marker 1af47137d386. Mara watched the eastern gate until dawn.

Ledger 48 line 103: Neri carried the blue token past marker 9ea2956efabd. Mara watched the eastern gate until dawn.

Ledger 48 line 104: Neri carried the blue token past marker 569d16fb0e7f. Mara watched the eastern gate until dawn.

Ledger 48 line 105: Neri carried the blue token past marker a7226cad389c. Mara watched the eastern gate until dawn.

Ledger 48 line 106: Neri carried the blue token past marker dc5098a21b0c. Mara watched the eastern gate until dawn.

Ledger 48 line 107: Neri carried the blue token past marker b374da2ea006. Mara watched the eastern gate until dawn.

Ledger 48 line 108: Neri carried the blue token past marker b9b19ddd3d53. Mara watched the eastern gate until dawn.

Ledger 48 line 109: Neri carried the blue token past marker fee1d185c8a6. Mara watched the eastern gate until dawn.

Ledger 48 line 110: Neri carried the blue token past marker 05f7e5b6510c. Mara watched the eastern gate until dawn.

Ledger 48 line 111: Neri carried the blue token past marker c0cc4e43ae62. Mara watched the eastern gate until dawn.

Ledger 48 line 112: Neri carried the blue token past marker a266131c6838. Mara watched the eastern gate until dawn.

Ledger 48 line 113: Neri carried the blue token past marker 000233b08239. Mara watched the eastern gate until dawn.

Ledger 48 line 114: Neri carried the blue token past marker 368f7f024401. Mara watched the eastern gate until dawn.

Ledger 48 line 115: Neri carried the blue token past marker b87b1c0747c1. Mara watched the eastern gate until dawn.

Ledger 48 line 116: Neri carried the blue token past marker c1181908fc45. Mara watched the eastern gate until dawn.

Ledger 48 line 117: Neri carried the blue token past marker 6e0dc1bcfcc7. Mara watched the eastern gate until dawn.

Ledger 48 line 118: Neri carried the blue token past marker c0ea12066398. Mara watched the eastern gate until dawn.

Ledger 48 line 119: Neri carried the blue token past marker 043443cbb524. Mara watched the eastern gate until dawn.

Ledger 48 line 120: Neri carried the blue token past marker d54f8fcfe7d9. Mara watched the eastern gate until dawn.

Ledger 48 line 121: Neri carried the blue token past marker 788d05bf5c4c. Mara watched the eastern gate until dawn.

Ledger 48 line 122: Neri carried the blue token past marker 5a76ff42e9b1. Mara watched the eastern gate until dawn.

Ledger 48 line 123: Neri carried the blue token past marker 9f7bb64df610. Mara watched the eastern gate until dawn.

Ledger 48 line 124: Neri carried the blue token past marker 18e4f0e80dd6. Mara watched the eastern gate until dawn.

Ledger 48 line 125: Neri carried the blue token past marker 899d12651e0d. Mara watched the eastern gate until dawn.

Ledger 48 line 126: Neri carried the blue token past marker 798c85c33cdc. Mara watched the eastern gate until dawn.

Ledger 48 line 127: Neri carried the blue token past marker ee3c9b9092d2. Mara watched the eastern gate until dawn.

Ledger 48 line 128: Neri carried the blue token past marker 22c3c1fc2018. Mara watched the eastern gate until dawn.

Ledger 48 line 129: Neri carried the blue token past marker 1b1db3e2fe23. Mara watched the eastern gate until dawn.

Ledger 48 line 130: Neri carried the blue token past marker f62f35e9ecdd. Mara watched the eastern gate until dawn.

Ledger 48 line 131: Neri carried the blue token past marker 85eff113a3f5. Mara watched the eastern gate until dawn.

Ledger 48 line 132: Neri carried the blue token past marker d80ca3a70e7f. Mara watched the eastern gate until dawn.

Ledger 48 line 133: Neri carried the blue token past marker 6ced860dca9d. Mara watched the eastern gate until dawn.

Ledger 48 line 134: Neri carried the blue token past marker e29f9628ccb9. Mara watched the eastern gate until dawn.

Ledger 48 line 135: Neri carried the blue token past marker c500c1938260. Mara watched the eastern gate until dawn.

Ledger 48 line 136: Neri carried the blue token past marker 203364c6a634. Mara watched the eastern gate until dawn.

Ledger 48 line 137: Neri carried the blue token past marker 755bfae5aeb4. Mara watched the eastern gate until dawn.

Ledger 48 line 138: Neri carried the blue token past marker e18c3ea66560. Mara watched the eastern gate until dawn.

Ledger 48 line 139: Neri carried the blue token past marker 58e3480f786d. Mara watched the eastern gate until dawn.

Ledger 48 line 140: Neri carried the blue token past marker 8be30f1e34d6. Mara watched the eastern gate until dawn.
