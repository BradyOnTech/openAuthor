---
id: scene-0015
title: Recovery ledger 15
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.160488+00:00
updated_at: 2026-10-03T12:14:52.160488+00:00
---

Ledger 15 line 001: Neri carried the blue token past marker 39f3f23f4901. Mara watched the eastern gate until dawn.

Ledger 15 line 002: Neri carried the blue token past marker 2a873d587af2. Mara watched the eastern gate until dawn.

Ledger 15 line 003: Neri carried the blue token past marker ea7d00b9fd3f. Mara watched the eastern gate until dawn.

Ledger 15 line 004: Neri carried the blue token past marker a97e26cbadb1. Mara watched the eastern gate until dawn.

Ledger 15 line 005: Neri carried the blue token past marker e13d48dae3d0. Mara watched the eastern gate until dawn.

Ledger 15 line 006: Neri carried the blue token past marker 36594111b2d5. Mara watched the eastern gate until dawn.

Ledger 15 line 007: Neri carried the blue token past marker 1f725b2546ca. Mara watched the eastern gate until dawn.

Ledger 15 line 008: Neri carried the blue token past marker 98d4074af8e2. Mara watched the eastern gate until dawn.

Ledger 15 line 009: Neri carried the blue token past marker 92caa7421b04. Mara watched the eastern gate until dawn.

Ledger 15 line 010: Neri carried the blue token past marker 714d49375fbf. Mara watched the eastern gate until dawn.

Ledger 15 line 011: Neri carried the blue token past marker af280ba0db04. Mara watched the eastern gate until dawn.

Ledger 15 line 012: Neri carried the blue token past marker 79fe5ded26d8. Mara watched the eastern gate until dawn.

Ledger 15 line 013: Neri carried the blue token past marker 1a3829f0d6cf. Mara watched the eastern gate until dawn.

Ledger 15 line 014: Neri carried the blue token past marker d90f09cc2c5f. Mara watched the eastern gate until dawn.

Ledger 15 line 015: Neri carried the blue token past marker 6c56e7f9cb2a. Mara watched the eastern gate until dawn.

Ledger 15 line 016: Neri carried the blue token past marker 00a7febb8dd4. Mara watched the eastern gate until dawn.

Ledger 15 line 017: Neri carried the blue token past marker 7ed616997c7d. Mara watched the eastern gate until dawn.

Ledger 15 line 018: Neri carried the blue token past marker 4e6d3a5a48d0. Mara watched the eastern gate until dawn.

Ledger 15 line 019: Neri carried the blue token past marker 4b5d6949b52c. Mara watched the eastern gate until dawn.

Ledger 15 line 020: Neri carried the blue token past marker 9ba5f532f7b8. Mara watched the eastern gate until dawn.

Ledger 15 line 021: Neri carried the blue token past marker 115e76f4310e. Mara watched the eastern gate until dawn.

Ledger 15 line 022: Neri carried the blue token past marker ac3cc6d56b1b. Mara watched the eastern gate until dawn.

Ledger 15 line 023: Neri carried the blue token past marker 109e76b63ceb. Mara watched the eastern gate until dawn.

Ledger 15 line 024: Neri carried the blue token past marker 6dc3a244935d. Mara watched the eastern gate until dawn.

Ledger 15 line 025: Neri carried the blue token past marker 541d71025ab3. Mara watched the eastern gate until dawn.

Ledger 15 line 026: Neri carried the blue token past marker 22cf2495b3ce. Mara watched the eastern gate until dawn.

Ledger 15 line 027: Neri carried the blue token past marker 9b63202f71ec. Mara watched the eastern gate until dawn.

Ledger 15 line 028: Neri carried the blue token past marker e1e77a5c43b7. Mara watched the eastern gate until dawn.

Ledger 15 line 029: Neri carried the blue token past marker cafb0e99b4d7. Mara watched the eastern gate until dawn.

Ledger 15 line 030: Neri carried the blue token past marker 4978057050af. Mara watched the eastern gate until dawn.

Ledger 15 line 031: Neri carried the blue token past marker 963e998232ff. Mara watched the eastern gate until dawn.

Ledger 15 line 032: Neri carried the blue token past marker 4b53eaa9f1be. Mara watched the eastern gate until dawn.

Ledger 15 line 033: Neri carried the blue token past marker 53b8129eb295. Mara watched the eastern gate until dawn.

Ledger 15 line 034: Neri carried the blue token past marker 3e9903d12237. Mara watched the eastern gate until dawn.

Ledger 15 line 035: Neri carried the blue token past marker 98464bee18d5. Mara watched the eastern gate until dawn.

Ledger 15 line 036: Neri carried the blue token past marker 509a1337ad65. Mara watched the eastern gate until dawn.

Ledger 15 line 037: Neri carried the blue token past marker 04f25791c0d8. Mara watched the eastern gate until dawn.

Ledger 15 line 038: Neri carried the blue token past marker b8b2ff6073dc. Mara watched the eastern gate until dawn.

Ledger 15 line 039: Neri carried the blue token past marker 73a89f401aad. Mara watched the eastern gate until dawn.

Ledger 15 line 040: Neri carried the blue token past marker 1d6dd9f6c44d. Mara watched the eastern gate until dawn.

Ledger 15 line 041: Neri carried the blue token past marker 5a5e9d2bd8ef. Mara watched the eastern gate until dawn.

Ledger 15 line 042: Neri carried the blue token past marker d1832e396133. Mara watched the eastern gate until dawn.

Ledger 15 line 043: Neri carried the blue token past marker bea30ed79db0. Mara watched the eastern gate until dawn.

Ledger 15 line 044: Neri carried the blue token past marker eb9287257228. Mara watched the eastern gate until dawn.

Ledger 15 line 045: Neri carried the blue token past marker 2b5b28c53e3e. Mara watched the eastern gate until dawn.

Ledger 15 line 046: Neri carried the blue token past marker 8386ed926eb8. Mara watched the eastern gate until dawn.

Ledger 15 line 047: Neri carried the blue token past marker 299bb4554bee. Mara watched the eastern gate until dawn.

Ledger 15 line 048: Neri carried the blue token past marker d91e016515ed. Mara watched the eastern gate until dawn.

Ledger 15 line 049: Neri carried the blue token past marker d0d5ad61871d. Mara watched the eastern gate until dawn.

Ledger 15 line 050: Neri carried the blue token past marker 2b8862f18909. Mara watched the eastern gate until dawn.

Ledger 15 line 051: Neri carried the blue token past marker 8f4e8152ef71. Mara watched the eastern gate until dawn.

Ledger 15 line 052: Neri carried the blue token past marker 33bb9fdbbd18. Mara watched the eastern gate until dawn.

Ledger 15 line 053: Neri carried the blue token past marker cec5e4b2f5ed. Mara watched the eastern gate until dawn.

Ledger 15 line 054: Neri carried the blue token past marker 58bc025d7238. Mara watched the eastern gate until dawn.

Ledger 15 line 055: Neri carried the blue token past marker 21bc892c96b1. Mara watched the eastern gate until dawn.

Ledger 15 line 056: Neri carried the blue token past marker c3b711f476c1. Mara watched the eastern gate until dawn.

Ledger 15 line 057: Neri carried the blue token past marker 581745a96fb8. Mara watched the eastern gate until dawn.

Ledger 15 line 058: Neri carried the blue token past marker f5e5e2e60ecd. Mara watched the eastern gate until dawn.

Ledger 15 line 059: Neri carried the blue token past marker 4fcdba7a6398. Mara watched the eastern gate until dawn.

Ledger 15 line 060: Neri carried the blue token past marker f61cba9b5039. Mara watched the eastern gate until dawn.

Ledger 15 line 061: Neri carried the blue token past marker 7c6878ddea44. Mara watched the eastern gate until dawn.

Ledger 15 line 062: Neri carried the blue token past marker 03ede34c6ab3. Mara watched the eastern gate until dawn.

Ledger 15 line 063: Neri carried the blue token past marker d5c35d1be900. Mara watched the eastern gate until dawn.

Ledger 15 line 064: Neri carried the blue token past marker 001e59d5744c. Mara watched the eastern gate until dawn.

Ledger 15 line 065: Neri carried the blue token past marker 95932e2dccdc. Mara watched the eastern gate until dawn.

Ledger 15 line 066: Neri carried the blue token past marker dde0a9d0fd38. Mara watched the eastern gate until dawn.

Ledger 15 line 067: Neri carried the blue token past marker 0c6112166d69. Mara watched the eastern gate until dawn.

Ledger 15 line 068: Neri carried the blue token past marker 544aa38f0ee2. Mara watched the eastern gate until dawn.

Ledger 15 line 069: Neri carried the blue token past marker 24b8d513d233. Mara watched the eastern gate until dawn.

Ledger 15 line 070: Neri carried the blue token past marker e0238c4ec38b. Mara watched the eastern gate until dawn.

Ledger 15 line 071: Neri carried the blue token past marker cde13d1b0bd0. Mara watched the eastern gate until dawn.

Ledger 15 line 072: Neri carried the blue token past marker 3199b319b9f4. Mara watched the eastern gate until dawn.

Ledger 15 line 073: Neri carried the blue token past marker 9370b8c4e5d4. Mara watched the eastern gate until dawn.

Ledger 15 line 074: Neri carried the blue token past marker b423b08ce63e. Mara watched the eastern gate until dawn.

Ledger 15 line 075: Neri carried the blue token past marker e7aee11f4b8a. Mara watched the eastern gate until dawn.

Ledger 15 line 076: Neri carried the blue token past marker dcd8a67b84b3. Mara watched the eastern gate until dawn.

Ledger 15 line 077: Neri carried the blue token past marker 2563989527ec. Mara watched the eastern gate until dawn.

Ledger 15 line 078: Neri carried the blue token past marker 763584c07d81. Mara watched the eastern gate until dawn.

Ledger 15 line 079: Neri carried the blue token past marker 3a55d0b86701. Mara watched the eastern gate until dawn.

Ledger 15 line 080: Neri carried the blue token past marker 7bd5457ff922. Mara watched the eastern gate until dawn.

Ledger 15 line 081: Neri carried the blue token past marker f69c31409420. Mara watched the eastern gate until dawn.

Ledger 15 line 082: Neri carried the blue token past marker b6997e9150f2. Mara watched the eastern gate until dawn.

Ledger 15 line 083: Neri carried the blue token past marker 37f4f22cb047. Mara watched the eastern gate until dawn.

Ledger 15 line 084: Neri carried the blue token past marker c513d5cc7a0c. Mara watched the eastern gate until dawn.

Ledger 15 line 085: Neri carried the blue token past marker 9d4b3e25f589. Mara watched the eastern gate until dawn.

Ledger 15 line 086: Neri carried the blue token past marker 93ac5ac991c2. Mara watched the eastern gate until dawn.

Ledger 15 line 087: Neri carried the blue token past marker c54dc14a6539. Mara watched the eastern gate until dawn.

Ledger 15 line 088: Neri carried the blue token past marker c14b8d020b73. Mara watched the eastern gate until dawn.

Ledger 15 line 089: Neri carried the blue token past marker 9519c5dd9223. Mara watched the eastern gate until dawn.

Ledger 15 line 090: Neri carried the blue token past marker 7049cbbe74ee. Mara watched the eastern gate until dawn.

Ledger 15 line 091: Neri carried the blue token past marker 944384c9663f. Mara watched the eastern gate until dawn.

Ledger 15 line 092: Neri carried the blue token past marker 231964adb468. Mara watched the eastern gate until dawn.

Ledger 15 line 093: Neri carried the blue token past marker fa670eb62ada. Mara watched the eastern gate until dawn.

Ledger 15 line 094: Neri carried the blue token past marker 35d613f7b9aa. Mara watched the eastern gate until dawn.

Ledger 15 line 095: Neri carried the blue token past marker 79daedd67b1e. Mara watched the eastern gate until dawn.

Ledger 15 line 096: Neri carried the blue token past marker 19dbb35a889c. Mara watched the eastern gate until dawn.

Ledger 15 line 097: Neri carried the blue token past marker 9724fac04363. Mara watched the eastern gate until dawn.

Ledger 15 line 098: Neri carried the blue token past marker aaf7ce8b41fe. Mara watched the eastern gate until dawn.

Ledger 15 line 099: Neri carried the blue token past marker 7658e744979a. Mara watched the eastern gate until dawn.

Ledger 15 line 100: Neri carried the blue token past marker ae04222d40dc. Mara watched the eastern gate until dawn.

Ledger 15 line 101: Neri carried the blue token past marker 2a34ab2b6a8d. Mara watched the eastern gate until dawn.

Ledger 15 line 102: Neri carried the blue token past marker 5c2bfb435e72. Mara watched the eastern gate until dawn.

Ledger 15 line 103: Neri carried the blue token past marker 8c826f9f4a98. Mara watched the eastern gate until dawn.

Ledger 15 line 104: Neri carried the blue token past marker 686f7948449b. Mara watched the eastern gate until dawn.

Ledger 15 line 105: Neri carried the blue token past marker 009b2b839e6b. Mara watched the eastern gate until dawn.

Ledger 15 line 106: Neri carried the blue token past marker 41e8874d3d56. Mara watched the eastern gate until dawn.

Ledger 15 line 107: Neri carried the blue token past marker 94493d4aeb34. Mara watched the eastern gate until dawn.

Ledger 15 line 108: Neri carried the blue token past marker 6539a9c2bd48. Mara watched the eastern gate until dawn.

Ledger 15 line 109: Neri carried the blue token past marker 8884f207e832. Mara watched the eastern gate until dawn.

Ledger 15 line 110: Neri carried the blue token past marker 92bf1adf6293. Mara watched the eastern gate until dawn.

Ledger 15 line 111: Neri carried the blue token past marker 908d04eefe49. Mara watched the eastern gate until dawn.

Ledger 15 line 112: Neri carried the blue token past marker f3b401369336. Mara watched the eastern gate until dawn.

Ledger 15 line 113: Neri carried the blue token past marker cf8186796ae5. Mara watched the eastern gate until dawn.

Ledger 15 line 114: Neri carried the blue token past marker e2233f90b0ab. Mara watched the eastern gate until dawn.

Ledger 15 line 115: Neri carried the blue token past marker f26b906f6446. Mara watched the eastern gate until dawn.

Ledger 15 line 116: Neri carried the blue token past marker 0f131217f55d. Mara watched the eastern gate until dawn.

Ledger 15 line 117: Neri carried the blue token past marker 4922987e664b. Mara watched the eastern gate until dawn.

Ledger 15 line 118: Neri carried the blue token past marker 5fc469b5ac47. Mara watched the eastern gate until dawn.

Ledger 15 line 119: Neri carried the blue token past marker 9ca28365df2f. Mara watched the eastern gate until dawn.

Ledger 15 line 120: Neri carried the blue token past marker 382721e711c2. Mara watched the eastern gate until dawn.

Ledger 15 line 121: Neri carried the blue token past marker 24c25c145299. Mara watched the eastern gate until dawn.

Ledger 15 line 122: Neri carried the blue token past marker 8ca96dc0fc07. Mara watched the eastern gate until dawn.

Ledger 15 line 123: Neri carried the blue token past marker d5a2e05561f6. Mara watched the eastern gate until dawn.

Ledger 15 line 124: Neri carried the blue token past marker 7248c44fd175. Mara watched the eastern gate until dawn.

Ledger 15 line 125: Neri carried the blue token past marker 8a77237ea148. Mara watched the eastern gate until dawn.

Ledger 15 line 126: Neri carried the blue token past marker 2c7a55757946. Mara watched the eastern gate until dawn.

Ledger 15 line 127: Neri carried the blue token past marker 2f9b9abca764. Mara watched the eastern gate until dawn.

Ledger 15 line 128: Neri carried the blue token past marker 7faada0333b2. Mara watched the eastern gate until dawn.

Ledger 15 line 129: Neri carried the blue token past marker ce9398f6c880. Mara watched the eastern gate until dawn.

Ledger 15 line 130: Neri carried the blue token past marker 2f53b4cdfaad. Mara watched the eastern gate until dawn.

Ledger 15 line 131: Neri carried the blue token past marker 3086ac073edf. Mara watched the eastern gate until dawn.

Ledger 15 line 132: Neri carried the blue token past marker 9b0cb9e624ff. Mara watched the eastern gate until dawn.

Ledger 15 line 133: Neri carried the blue token past marker dc73af52b2a2. Mara watched the eastern gate until dawn.

Ledger 15 line 134: Neri carried the blue token past marker acc509eed07c. Mara watched the eastern gate until dawn.

Ledger 15 line 135: Neri carried the blue token past marker 8a29a9d7c29a. Mara watched the eastern gate until dawn.

Ledger 15 line 136: Neri carried the blue token past marker a79d4e6e5070. Mara watched the eastern gate until dawn.

Ledger 15 line 137: Neri carried the blue token past marker 724afc2b0969. Mara watched the eastern gate until dawn.

Ledger 15 line 138: Neri carried the blue token past marker 0c70b554447a. Mara watched the eastern gate until dawn.

Ledger 15 line 139: Neri carried the blue token past marker f8ca30ed6ed8. Mara watched the eastern gate until dawn.

Ledger 15 line 140: Neri carried the blue token past marker 6c1ac583a16c. Mara watched the eastern gate until dawn.
