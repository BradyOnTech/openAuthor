---
id: scene-0055
title: Recovery ledger 55
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.181904+00:00
updated_at: 2026-10-03T12:14:52.181904+00:00
---

Ledger 55 line 001: Neri carried the blue token past marker c565cba61a89. Mara watched the eastern gate until dawn.

Ledger 55 line 002: Neri carried the blue token past marker 7c83e069c71d. Mara watched the eastern gate until dawn.

Ledger 55 line 003: Neri carried the blue token past marker 39f1e5fa4dff. Mara watched the eastern gate until dawn.

Ledger 55 line 004: Neri carried the blue token past marker 19c4aafa516d. Mara watched the eastern gate until dawn.

Ledger 55 line 005: Neri carried the blue token past marker d8d6ec459f05. Mara watched the eastern gate until dawn.

Ledger 55 line 006: Neri carried the blue token past marker d8a2405ee6ea. Mara watched the eastern gate until dawn.

Ledger 55 line 007: Neri carried the blue token past marker 6685f92ab0c9. Mara watched the eastern gate until dawn.

Ledger 55 line 008: Neri carried the blue token past marker 764ffddca1e8. Mara watched the eastern gate until dawn.

Ledger 55 line 009: Neri carried the blue token past marker d93d43b70bd4. Mara watched the eastern gate until dawn.

Ledger 55 line 010: Neri carried the blue token past marker 0eca5a5a1abf. Mara watched the eastern gate until dawn.

Ledger 55 line 011: Neri carried the blue token past marker 60d8c876c03b. Mara watched the eastern gate until dawn.

Ledger 55 line 012: Neri carried the blue token past marker 6a0f535b4580. Mara watched the eastern gate until dawn.

Ledger 55 line 013: Neri carried the blue token past marker 0db9e8e529fe. Mara watched the eastern gate until dawn.

Ledger 55 line 014: Neri carried the blue token past marker 4db6837cd4c9. Mara watched the eastern gate until dawn.

Ledger 55 line 015: Neri carried the blue token past marker c4a5f221ad56. Mara watched the eastern gate until dawn.

Ledger 55 line 016: Neri carried the blue token past marker ea2a19dfe897. Mara watched the eastern gate until dawn.

Ledger 55 line 017: Neri carried the blue token past marker a8b20af569be. Mara watched the eastern gate until dawn.

Ledger 55 line 018: Neri carried the blue token past marker 30d2682a2578. Mara watched the eastern gate until dawn.

Ledger 55 line 019: Neri carried the blue token past marker 6e6b30a8afca. Mara watched the eastern gate until dawn.

Ledger 55 line 020: Neri carried the blue token past marker 6bad039de958. Mara watched the eastern gate until dawn.

Ledger 55 line 021: Neri carried the blue token past marker 59850d63e443. Mara watched the eastern gate until dawn.

Ledger 55 line 022: Neri carried the blue token past marker 37398d633832. Mara watched the eastern gate until dawn.

Ledger 55 line 023: Neri carried the blue token past marker 84e92e1030a4. Mara watched the eastern gate until dawn.

Ledger 55 line 024: Neri carried the blue token past marker e1cea35c87ec. Mara watched the eastern gate until dawn.

Ledger 55 line 025: Neri carried the blue token past marker bf35f462a8d8. Mara watched the eastern gate until dawn.

Ledger 55 line 026: Neri carried the blue token past marker 760294b72c8f. Mara watched the eastern gate until dawn.

Ledger 55 line 027: Neri carried the blue token past marker 3fcf3db09e0a. Mara watched the eastern gate until dawn.

Ledger 55 line 028: Neri carried the blue token past marker 36aa01a21de5. Mara watched the eastern gate until dawn.

Ledger 55 line 029: Neri carried the blue token past marker c1db8e594885. Mara watched the eastern gate until dawn.

Ledger 55 line 030: Neri carried the blue token past marker 7ffbfe2d2328. Mara watched the eastern gate until dawn.

Ledger 55 line 031: Neri carried the blue token past marker f33b240efdfc. Mara watched the eastern gate until dawn.

Ledger 55 line 032: Neri carried the blue token past marker d16eb1225f21. Mara watched the eastern gate until dawn.

Ledger 55 line 033: Neri carried the blue token past marker fb6e27812dfe. Mara watched the eastern gate until dawn.

Ledger 55 line 034: Neri carried the blue token past marker 9cd2cae88b71. Mara watched the eastern gate until dawn.

Ledger 55 line 035: Neri carried the blue token past marker f56b2f4d9fbe. Mara watched the eastern gate until dawn.

Ledger 55 line 036: Neri carried the blue token past marker 5f319e549d16. Mara watched the eastern gate until dawn.

Ledger 55 line 037: Neri carried the blue token past marker 6d8546eaadb7. Mara watched the eastern gate until dawn.

Ledger 55 line 038: Neri carried the blue token past marker 56f22bbd406a. Mara watched the eastern gate until dawn.

Ledger 55 line 039: Neri carried the blue token past marker 2f7fcf6674bf. Mara watched the eastern gate until dawn.

Ledger 55 line 040: Neri carried the blue token past marker 70883f5a9195. Mara watched the eastern gate until dawn.

Ledger 55 line 041: Neri carried the blue token past marker d3813aeff175. Mara watched the eastern gate until dawn.

Ledger 55 line 042: Neri carried the blue token past marker eb625849858f. Mara watched the eastern gate until dawn.

Ledger 55 line 043: Neri carried the blue token past marker 8e8afd5ece7e. Mara watched the eastern gate until dawn.

Ledger 55 line 044: Neri carried the blue token past marker 4bb50cbf93cd. Mara watched the eastern gate until dawn.

Ledger 55 line 045: Neri carried the blue token past marker 1e2042bf0537. Mara watched the eastern gate until dawn.

Ledger 55 line 046: Neri carried the blue token past marker 38ac5e11a020. Mara watched the eastern gate until dawn.

Ledger 55 line 047: Neri carried the blue token past marker 4f3491fc4975. Mara watched the eastern gate until dawn.

Ledger 55 line 048: Neri carried the blue token past marker 9e428b4f7468. Mara watched the eastern gate until dawn.

Ledger 55 line 049: Neri carried the blue token past marker 38d9afb2c91b. Mara watched the eastern gate until dawn.

Ledger 55 line 050: Neri carried the blue token past marker f8ec21657847. Mara watched the eastern gate until dawn.

Ledger 55 line 051: Neri carried the blue token past marker a129529c537f. Mara watched the eastern gate until dawn.

Ledger 55 line 052: Neri carried the blue token past marker 5812191fe822. Mara watched the eastern gate until dawn.

Ledger 55 line 053: Neri carried the blue token past marker c9c230adef4c. Mara watched the eastern gate until dawn.

Ledger 55 line 054: Neri carried the blue token past marker c14a44199df2. Mara watched the eastern gate until dawn.

Ledger 55 line 055: Neri carried the blue token past marker 308de9ba9bf6. Mara watched the eastern gate until dawn.

Ledger 55 line 056: Neri carried the blue token past marker 119a0fbd4ad4. Mara watched the eastern gate until dawn.

Ledger 55 line 057: Neri carried the blue token past marker f3aa78423957. Mara watched the eastern gate until dawn.

Ledger 55 line 058: Neri carried the blue token past marker b06dd9e7d582. Mara watched the eastern gate until dawn.

Ledger 55 line 059: Neri carried the blue token past marker 705e3ebeb4ac. Mara watched the eastern gate until dawn.

Ledger 55 line 060: Neri carried the blue token past marker 403694d143d6. Mara watched the eastern gate until dawn.

Ledger 55 line 061: Neri carried the blue token past marker 479a7d307344. Mara watched the eastern gate until dawn.

Ledger 55 line 062: Neri carried the blue token past marker 85bfbd40eb18. Mara watched the eastern gate until dawn.

Ledger 55 line 063: Neri carried the blue token past marker 20609585ac65. Mara watched the eastern gate until dawn.

Ledger 55 line 064: Neri carried the blue token past marker a6a37f723b62. Mara watched the eastern gate until dawn.

Ledger 55 line 065: Neri carried the blue token past marker 47bfddeb6497. Mara watched the eastern gate until dawn.

Ledger 55 line 066: Neri carried the blue token past marker 12fca31fc58d. Mara watched the eastern gate until dawn.

Ledger 55 line 067: Neri carried the blue token past marker f38d3f9b2cb0. Mara watched the eastern gate until dawn.

Ledger 55 line 068: Neri carried the blue token past marker 59903439be7d. Mara watched the eastern gate until dawn.

Ledger 55 line 069: Neri carried the blue token past marker 7275e26de637. Mara watched the eastern gate until dawn.

Ledger 55 line 070: Neri carried the blue token past marker aa39991a9504. Mara watched the eastern gate until dawn.

Ledger 55 line 071: Neri carried the blue token past marker 45685ed4dae6. Mara watched the eastern gate until dawn.

Ledger 55 line 072: Neri carried the blue token past marker b688fdba6d14. Mara watched the eastern gate until dawn.

Ledger 55 line 073: Neri carried the blue token past marker 4fa86c491b08. Mara watched the eastern gate until dawn.

Ledger 55 line 074: Neri carried the blue token past marker f19fd663e807. Mara watched the eastern gate until dawn.

Ledger 55 line 075: Neri carried the blue token past marker 92cebfa1d522. Mara watched the eastern gate until dawn.

Ledger 55 line 076: Neri carried the blue token past marker 15aaf036eecb. Mara watched the eastern gate until dawn.

Ledger 55 line 077: Neri carried the blue token past marker b2b36f963dbe. Mara watched the eastern gate until dawn.

Ledger 55 line 078: Neri carried the blue token past marker 4f51692f71b6. Mara watched the eastern gate until dawn.

Ledger 55 line 079: Neri carried the blue token past marker 97252dcaa97b. Mara watched the eastern gate until dawn.

Ledger 55 line 080: Neri carried the blue token past marker 18deab1f0b2b. Mara watched the eastern gate until dawn.

Ledger 55 line 081: Neri carried the blue token past marker d3ec0eaf73b9. Mara watched the eastern gate until dawn.

Ledger 55 line 082: Neri carried the blue token past marker 531dca17516f. Mara watched the eastern gate until dawn.

Ledger 55 line 083: Neri carried the blue token past marker f4c6698ffce9. Mara watched the eastern gate until dawn.

Ledger 55 line 084: Neri carried the blue token past marker 91a84df80bb3. Mara watched the eastern gate until dawn.

Ledger 55 line 085: Neri carried the blue token past marker 6d88e730867b. Mara watched the eastern gate until dawn.

Ledger 55 line 086: Neri carried the blue token past marker 7266342bab98. Mara watched the eastern gate until dawn.

Ledger 55 line 087: Neri carried the blue token past marker ed936287c128. Mara watched the eastern gate until dawn.

Ledger 55 line 088: Neri carried the blue token past marker 76fd797ef362. Mara watched the eastern gate until dawn.

Ledger 55 line 089: Neri carried the blue token past marker edb3f222e6c7. Mara watched the eastern gate until dawn.

Ledger 55 line 090: Neri carried the blue token past marker fec00cdcfec1. Mara watched the eastern gate until dawn.

Ledger 55 line 091: Neri carried the blue token past marker 4652ec496d4a. Mara watched the eastern gate until dawn.

Ledger 55 line 092: Neri carried the blue token past marker 19929bf88826. Mara watched the eastern gate until dawn.

Ledger 55 line 093: Neri carried the blue token past marker d7a76a569421. Mara watched the eastern gate until dawn.

Ledger 55 line 094: Neri carried the blue token past marker 2465c58c31dd. Mara watched the eastern gate until dawn.

Ledger 55 line 095: Neri carried the blue token past marker 2c6c7d4e01fa. Mara watched the eastern gate until dawn.

Ledger 55 line 096: Neri carried the blue token past marker 5b7813a3854b. Mara watched the eastern gate until dawn.

Ledger 55 line 097: Neri carried the blue token past marker 77156190e693. Mara watched the eastern gate until dawn.

Ledger 55 line 098: Neri carried the blue token past marker 5022b9773fbe. Mara watched the eastern gate until dawn.

Ledger 55 line 099: Neri carried the blue token past marker fbfeafe7f03d. Mara watched the eastern gate until dawn.

Ledger 55 line 100: Neri carried the blue token past marker c613abae5406. Mara watched the eastern gate until dawn.

Ledger 55 line 101: Neri carried the blue token past marker c6b074ab6ca3. Mara watched the eastern gate until dawn.

Ledger 55 line 102: Neri carried the blue token past marker 02cfbb34d664. Mara watched the eastern gate until dawn.

Ledger 55 line 103: Neri carried the blue token past marker a1a5d63d23c8. Mara watched the eastern gate until dawn.

Ledger 55 line 104: Neri carried the blue token past marker 2bf47134a95d. Mara watched the eastern gate until dawn.

Ledger 55 line 105: Neri carried the blue token past marker 8c2f00e0aa77. Mara watched the eastern gate until dawn.

Ledger 55 line 106: Neri carried the blue token past marker 5d4f01826f94. Mara watched the eastern gate until dawn.

Ledger 55 line 107: Neri carried the blue token past marker 7a5d66b622ce. Mara watched the eastern gate until dawn.

Ledger 55 line 108: Neri carried the blue token past marker 9d71d0d55032. Mara watched the eastern gate until dawn.

Ledger 55 line 109: Neri carried the blue token past marker 2a9494f8a339. Mara watched the eastern gate until dawn.

Ledger 55 line 110: Neri carried the blue token past marker 9c0e48d864d4. Mara watched the eastern gate until dawn.

Ledger 55 line 111: Neri carried the blue token past marker 58242a3ec79b. Mara watched the eastern gate until dawn.

Ledger 55 line 112: Neri carried the blue token past marker 907e3530fda6. Mara watched the eastern gate until dawn.

Ledger 55 line 113: Neri carried the blue token past marker a69656c763c0. Mara watched the eastern gate until dawn.

Ledger 55 line 114: Neri carried the blue token past marker 1fcd83580ca0. Mara watched the eastern gate until dawn.

Ledger 55 line 115: Neri carried the blue token past marker 62b9d81b9958. Mara watched the eastern gate until dawn.

Ledger 55 line 116: Neri carried the blue token past marker f8186d7ff91b. Mara watched the eastern gate until dawn.

Ledger 55 line 117: Neri carried the blue token past marker 3a0e3143dbc0. Mara watched the eastern gate until dawn.

Ledger 55 line 118: Neri carried the blue token past marker 10707ac2c91e. Mara watched the eastern gate until dawn.

Ledger 55 line 119: Neri carried the blue token past marker b8602e90b566. Mara watched the eastern gate until dawn.

Ledger 55 line 120: Neri carried the blue token past marker 35efa7e30961. Mara watched the eastern gate until dawn.

Ledger 55 line 121: Neri carried the blue token past marker 8080ef2fbbcc. Mara watched the eastern gate until dawn.

Ledger 55 line 122: Neri carried the blue token past marker e39acac0948d. Mara watched the eastern gate until dawn.

Ledger 55 line 123: Neri carried the blue token past marker 33f19d391e01. Mara watched the eastern gate until dawn.

Ledger 55 line 124: Neri carried the blue token past marker abc6ed7b3d24. Mara watched the eastern gate until dawn.

Ledger 55 line 125: Neri carried the blue token past marker f60c6b57fd18. Mara watched the eastern gate until dawn.

Ledger 55 line 126: Neri carried the blue token past marker 313c70d98a69. Mara watched the eastern gate until dawn.

Ledger 55 line 127: Neri carried the blue token past marker d98ea2fc2f38. Mara watched the eastern gate until dawn.

Ledger 55 line 128: Neri carried the blue token past marker 6204c8967172. Mara watched the eastern gate until dawn.

Ledger 55 line 129: Neri carried the blue token past marker d0149ec36b08. Mara watched the eastern gate until dawn.

Ledger 55 line 130: Neri carried the blue token past marker 4655d79f0459. Mara watched the eastern gate until dawn.

Ledger 55 line 131: Neri carried the blue token past marker 83c785c37d6c. Mara watched the eastern gate until dawn.

Ledger 55 line 132: Neri carried the blue token past marker aab6aa2cb5df. Mara watched the eastern gate until dawn.

Ledger 55 line 133: Neri carried the blue token past marker c883ac602117. Mara watched the eastern gate until dawn.

Ledger 55 line 134: Neri carried the blue token past marker 76e8d8dd61a6. Mara watched the eastern gate until dawn.

Ledger 55 line 135: Neri carried the blue token past marker c2d672b33d1c. Mara watched the eastern gate until dawn.

Ledger 55 line 136: Neri carried the blue token past marker bb4fbd5a9f64. Mara watched the eastern gate until dawn.

Ledger 55 line 137: Neri carried the blue token past marker 68a1b3263029. Mara watched the eastern gate until dawn.

Ledger 55 line 138: Neri carried the blue token past marker 683491564c25. Mara watched the eastern gate until dawn.

Ledger 55 line 139: Neri carried the blue token past marker e864ef67316a. Mara watched the eastern gate until dawn.

Ledger 55 line 140: Neri carried the blue token past marker 23cb7b8873d5. Mara watched the eastern gate until dawn.
