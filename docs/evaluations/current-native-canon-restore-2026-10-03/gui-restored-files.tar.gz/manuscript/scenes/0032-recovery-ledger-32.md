---
id: scene-0032
title: Recovery ledger 32
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.169704+00:00
updated_at: 2026-10-03T12:14:52.169704+00:00
---

Ledger 32 line 001: Neri carried the blue token past marker cdd9fb5bf993. Mara watched the eastern gate until dawn.

Ledger 32 line 002: Neri carried the blue token past marker c3b379619e6e. Mara watched the eastern gate until dawn.

Ledger 32 line 003: Neri carried the blue token past marker 27a27566ed80. Mara watched the eastern gate until dawn.

Ledger 32 line 004: Neri carried the blue token past marker 284c85d3ae28. Mara watched the eastern gate until dawn.

Ledger 32 line 005: Neri carried the blue token past marker 0db3c82b1cd9. Mara watched the eastern gate until dawn.

Ledger 32 line 006: Neri carried the blue token past marker 9c37cd4bf738. Mara watched the eastern gate until dawn.

Ledger 32 line 007: Neri carried the blue token past marker 0edb14c632c9. Mara watched the eastern gate until dawn.

Ledger 32 line 008: Neri carried the blue token past marker 423b3696d5ae. Mara watched the eastern gate until dawn.

Ledger 32 line 009: Neri carried the blue token past marker 5e01b1370fd9. Mara watched the eastern gate until dawn.

Ledger 32 line 010: Neri carried the blue token past marker 8997d1452a58. Mara watched the eastern gate until dawn.

Ledger 32 line 011: Neri carried the blue token past marker c84b786b2c6a. Mara watched the eastern gate until dawn.

Ledger 32 line 012: Neri carried the blue token past marker 1334100aced2. Mara watched the eastern gate until dawn.

Ledger 32 line 013: Neri carried the blue token past marker af995791f0dc. Mara watched the eastern gate until dawn.

Ledger 32 line 014: Neri carried the blue token past marker e70efb658d0e. Mara watched the eastern gate until dawn.

Ledger 32 line 015: Neri carried the blue token past marker 025afbf893c0. Mara watched the eastern gate until dawn.

Ledger 32 line 016: Neri carried the blue token past marker 21586185e674. Mara watched the eastern gate until dawn.

Ledger 32 line 017: Neri carried the blue token past marker a828f15aac00. Mara watched the eastern gate until dawn.

Ledger 32 line 018: Neri carried the blue token past marker 1bdac9a3d65d. Mara watched the eastern gate until dawn.

Ledger 32 line 019: Neri carried the blue token past marker 929c19d4c82b. Mara watched the eastern gate until dawn.

Ledger 32 line 020: Neri carried the blue token past marker bdc825e95aa4. Mara watched the eastern gate until dawn.

Ledger 32 line 021: Neri carried the blue token past marker cacc6d0d7683. Mara watched the eastern gate until dawn.

Ledger 32 line 022: Neri carried the blue token past marker 19492e3364bf. Mara watched the eastern gate until dawn.

Ledger 32 line 023: Neri carried the blue token past marker 05a1434ba166. Mara watched the eastern gate until dawn.

Ledger 32 line 024: Neri carried the blue token past marker cc901e4ab737. Mara watched the eastern gate until dawn.

Ledger 32 line 025: Neri carried the blue token past marker 4ca181e135ca. Mara watched the eastern gate until dawn.

Ledger 32 line 026: Neri carried the blue token past marker 9b40aa9426e5. Mara watched the eastern gate until dawn.

Ledger 32 line 027: Neri carried the blue token past marker 3e25347da3a3. Mara watched the eastern gate until dawn.

Ledger 32 line 028: Neri carried the blue token past marker 94ce9c264843. Mara watched the eastern gate until dawn.

Ledger 32 line 029: Neri carried the blue token past marker 0e211ff38f42. Mara watched the eastern gate until dawn.

Ledger 32 line 030: Neri carried the blue token past marker 5ee3e3e6b68b. Mara watched the eastern gate until dawn.

Ledger 32 line 031: Neri carried the blue token past marker 76af0ebd84fe. Mara watched the eastern gate until dawn.

Ledger 32 line 032: Neri carried the blue token past marker dfa5df0f382f. Mara watched the eastern gate until dawn.

Ledger 32 line 033: Neri carried the blue token past marker ab9acac158b9. Mara watched the eastern gate until dawn.

Ledger 32 line 034: Neri carried the blue token past marker 037c8a9fe672. Mara watched the eastern gate until dawn.

Ledger 32 line 035: Neri carried the blue token past marker 3d3384a47135. Mara watched the eastern gate until dawn.

Ledger 32 line 036: Neri carried the blue token past marker 9f72ea6a5a5e. Mara watched the eastern gate until dawn.

Ledger 32 line 037: Neri carried the blue token past marker e920ca682196. Mara watched the eastern gate until dawn.

Ledger 32 line 038: Neri carried the blue token past marker 355c7a7a260a. Mara watched the eastern gate until dawn.

Ledger 32 line 039: Neri carried the blue token past marker 44dff1458c4d. Mara watched the eastern gate until dawn.

Ledger 32 line 040: Neri carried the blue token past marker 24245496971b. Mara watched the eastern gate until dawn.

Ledger 32 line 041: Neri carried the blue token past marker 409f3ba95d55. Mara watched the eastern gate until dawn.

Ledger 32 line 042: Neri carried the blue token past marker f80fd0c6375f. Mara watched the eastern gate until dawn.

Ledger 32 line 043: Neri carried the blue token past marker d4de0f1aad70. Mara watched the eastern gate until dawn.

Ledger 32 line 044: Neri carried the blue token past marker 0c788fa93bde. Mara watched the eastern gate until dawn.

Ledger 32 line 045: Neri carried the blue token past marker e294835a03db. Mara watched the eastern gate until dawn.

Ledger 32 line 046: Neri carried the blue token past marker 2e6c8f4feb52. Mara watched the eastern gate until dawn.

Ledger 32 line 047: Neri carried the blue token past marker bd2fa11e5211. Mara watched the eastern gate until dawn.

Ledger 32 line 048: Neri carried the blue token past marker 46cde91c39f6. Mara watched the eastern gate until dawn.

Ledger 32 line 049: Neri carried the blue token past marker a61c5a9c43cc. Mara watched the eastern gate until dawn.

Ledger 32 line 050: Neri carried the blue token past marker be152dfa2e3b. Mara watched the eastern gate until dawn.

Ledger 32 line 051: Neri carried the blue token past marker 91ee308e61cc. Mara watched the eastern gate until dawn.

Ledger 32 line 052: Neri carried the blue token past marker c1387a1757c4. Mara watched the eastern gate until dawn.

Ledger 32 line 053: Neri carried the blue token past marker 2545d820b690. Mara watched the eastern gate until dawn.

Ledger 32 line 054: Neri carried the blue token past marker 5b99698e1f4f. Mara watched the eastern gate until dawn.

Ledger 32 line 055: Neri carried the blue token past marker 17ec6b44a747. Mara watched the eastern gate until dawn.

Ledger 32 line 056: Neri carried the blue token past marker 3c910ae6253c. Mara watched the eastern gate until dawn.

Ledger 32 line 057: Neri carried the blue token past marker 1c5feb7789d6. Mara watched the eastern gate until dawn.

Ledger 32 line 058: Neri carried the blue token past marker 5632887f10c3. Mara watched the eastern gate until dawn.

Ledger 32 line 059: Neri carried the blue token past marker 6b60e1c80e57. Mara watched the eastern gate until dawn.

Ledger 32 line 060: Neri carried the blue token past marker ad24d14ceae6. Mara watched the eastern gate until dawn.

Ledger 32 line 061: Neri carried the blue token past marker 231dbf352178. Mara watched the eastern gate until dawn.

Ledger 32 line 062: Neri carried the blue token past marker 6b36e5dfee4f. Mara watched the eastern gate until dawn.

Ledger 32 line 063: Neri carried the blue token past marker eec6cbe241fa. Mara watched the eastern gate until dawn.

Ledger 32 line 064: Neri carried the blue token past marker 45044f0b9e3c. Mara watched the eastern gate until dawn.

Ledger 32 line 065: Neri carried the blue token past marker bc04e17e8ceb. Mara watched the eastern gate until dawn.

Ledger 32 line 066: Neri carried the blue token past marker 5a4fd1e5daea. Mara watched the eastern gate until dawn.

Ledger 32 line 067: Neri carried the blue token past marker 44f742f458d1. Mara watched the eastern gate until dawn.

Ledger 32 line 068: Neri carried the blue token past marker 693c6261f25b. Mara watched the eastern gate until dawn.

Ledger 32 line 069: Neri carried the blue token past marker 77694df34fed. Mara watched the eastern gate until dawn.

Ledger 32 line 070: Neri carried the blue token past marker 69b4335ebbe8. Mara watched the eastern gate until dawn.

Ledger 32 line 071: Neri carried the blue token past marker db014d47d5cb. Mara watched the eastern gate until dawn.

Ledger 32 line 072: Neri carried the blue token past marker 49d66d6209ce. Mara watched the eastern gate until dawn.

Ledger 32 line 073: Neri carried the blue token past marker 50d1b467fecb. Mara watched the eastern gate until dawn.

Ledger 32 line 074: Neri carried the blue token past marker 3231946be563. Mara watched the eastern gate until dawn.

Ledger 32 line 075: Neri carried the blue token past marker 238d678e3cd6. Mara watched the eastern gate until dawn.

Ledger 32 line 076: Neri carried the blue token past marker c163d5e9f2b7. Mara watched the eastern gate until dawn.

Ledger 32 line 077: Neri carried the blue token past marker 6a407b2d32e3. Mara watched the eastern gate until dawn.

Ledger 32 line 078: Neri carried the blue token past marker a99449754a0b. Mara watched the eastern gate until dawn.

Ledger 32 line 079: Neri carried the blue token past marker d18b01e08c1c. Mara watched the eastern gate until dawn.

Ledger 32 line 080: Neri carried the blue token past marker 423fc591781e. Mara watched the eastern gate until dawn.

Ledger 32 line 081: Neri carried the blue token past marker 0414b20dae61. Mara watched the eastern gate until dawn.

Ledger 32 line 082: Neri carried the blue token past marker cfd72ec06664. Mara watched the eastern gate until dawn.

Ledger 32 line 083: Neri carried the blue token past marker 0cc0f407e732. Mara watched the eastern gate until dawn.

Ledger 32 line 084: Neri carried the blue token past marker c708b32dc047. Mara watched the eastern gate until dawn.

Ledger 32 line 085: Neri carried the blue token past marker 07e9a58f331e. Mara watched the eastern gate until dawn.

Ledger 32 line 086: Neri carried the blue token past marker cd5b283491e8. Mara watched the eastern gate until dawn.

Ledger 32 line 087: Neri carried the blue token past marker 34ab8df3ebe2. Mara watched the eastern gate until dawn.

Ledger 32 line 088: Neri carried the blue token past marker 7e3c784df62d. Mara watched the eastern gate until dawn.

Ledger 32 line 089: Neri carried the blue token past marker 246770442e05. Mara watched the eastern gate until dawn.

Ledger 32 line 090: Neri carried the blue token past marker c170c1b9a4c4. Mara watched the eastern gate until dawn.

Ledger 32 line 091: Neri carried the blue token past marker c84718741163. Mara watched the eastern gate until dawn.

Ledger 32 line 092: Neri carried the blue token past marker 220d30988228. Mara watched the eastern gate until dawn.

Ledger 32 line 093: Neri carried the blue token past marker 9b35c7bc0a3a. Mara watched the eastern gate until dawn.

Ledger 32 line 094: Neri carried the blue token past marker 31d92a2ab8db. Mara watched the eastern gate until dawn.

Ledger 32 line 095: Neri carried the blue token past marker c5c982ae9858. Mara watched the eastern gate until dawn.

Ledger 32 line 096: Neri carried the blue token past marker 756d309d048b. Mara watched the eastern gate until dawn.

Ledger 32 line 097: Neri carried the blue token past marker 1a74868a35e5. Mara watched the eastern gate until dawn.

Ledger 32 line 098: Neri carried the blue token past marker 4b55b77e81c4. Mara watched the eastern gate until dawn.

Ledger 32 line 099: Neri carried the blue token past marker be359b3e5533. Mara watched the eastern gate until dawn.

Ledger 32 line 100: Neri carried the blue token past marker fc250fab6de1. Mara watched the eastern gate until dawn.

Ledger 32 line 101: Neri carried the blue token past marker de909c6ded21. Mara watched the eastern gate until dawn.

Ledger 32 line 102: Neri carried the blue token past marker 8b87a9505376. Mara watched the eastern gate until dawn.

Ledger 32 line 103: Neri carried the blue token past marker 28d1255f9543. Mara watched the eastern gate until dawn.

Ledger 32 line 104: Neri carried the blue token past marker 866913ad289a. Mara watched the eastern gate until dawn.

Ledger 32 line 105: Neri carried the blue token past marker 399cb8533b3b. Mara watched the eastern gate until dawn.

Ledger 32 line 106: Neri carried the blue token past marker 16c6fd015360. Mara watched the eastern gate until dawn.

Ledger 32 line 107: Neri carried the blue token past marker cd596bdedb36. Mara watched the eastern gate until dawn.

Ledger 32 line 108: Neri carried the blue token past marker d7e08df4aa46. Mara watched the eastern gate until dawn.

Ledger 32 line 109: Neri carried the blue token past marker 584b87221797. Mara watched the eastern gate until dawn.

Ledger 32 line 110: Neri carried the blue token past marker 3937b6daf879. Mara watched the eastern gate until dawn.

Ledger 32 line 111: Neri carried the blue token past marker d05e9c5a4baa. Mara watched the eastern gate until dawn.

Ledger 32 line 112: Neri carried the blue token past marker 4222fd679d38. Mara watched the eastern gate until dawn.

Ledger 32 line 113: Neri carried the blue token past marker 3166fb10149f. Mara watched the eastern gate until dawn.

Ledger 32 line 114: Neri carried the blue token past marker 199729f95a30. Mara watched the eastern gate until dawn.

Ledger 32 line 115: Neri carried the blue token past marker 14ff6c3ab926. Mara watched the eastern gate until dawn.

Ledger 32 line 116: Neri carried the blue token past marker 1308ce0acd4e. Mara watched the eastern gate until dawn.

Ledger 32 line 117: Neri carried the blue token past marker a79f334acec7. Mara watched the eastern gate until dawn.

Ledger 32 line 118: Neri carried the blue token past marker 84d2136c41d5. Mara watched the eastern gate until dawn.

Ledger 32 line 119: Neri carried the blue token past marker 3091e9a9dd34. Mara watched the eastern gate until dawn.

Ledger 32 line 120: Neri carried the blue token past marker deffe631afed. Mara watched the eastern gate until dawn.

Ledger 32 line 121: Neri carried the blue token past marker a1877ffe2247. Mara watched the eastern gate until dawn.

Ledger 32 line 122: Neri carried the blue token past marker ae6e35f0072b. Mara watched the eastern gate until dawn.

Ledger 32 line 123: Neri carried the blue token past marker 9eb9b05f5b34. Mara watched the eastern gate until dawn.

Ledger 32 line 124: Neri carried the blue token past marker 99b0a99b2289. Mara watched the eastern gate until dawn.

Ledger 32 line 125: Neri carried the blue token past marker d43a9c6306d9. Mara watched the eastern gate until dawn.

Ledger 32 line 126: Neri carried the blue token past marker 1cf248d7686e. Mara watched the eastern gate until dawn.

Ledger 32 line 127: Neri carried the blue token past marker 361bc170030a. Mara watched the eastern gate until dawn.

Ledger 32 line 128: Neri carried the blue token past marker 829d2d4dab80. Mara watched the eastern gate until dawn.

Ledger 32 line 129: Neri carried the blue token past marker 571dfc042c9b. Mara watched the eastern gate until dawn.

Ledger 32 line 130: Neri carried the blue token past marker 11ce16a32e12. Mara watched the eastern gate until dawn.

Ledger 32 line 131: Neri carried the blue token past marker 90cbe143da33. Mara watched the eastern gate until dawn.

Ledger 32 line 132: Neri carried the blue token past marker 64cd6b18e325. Mara watched the eastern gate until dawn.

Ledger 32 line 133: Neri carried the blue token past marker 8efaae3d24da. Mara watched the eastern gate until dawn.

Ledger 32 line 134: Neri carried the blue token past marker bc6d912fb08a. Mara watched the eastern gate until dawn.

Ledger 32 line 135: Neri carried the blue token past marker 9c77f363a07c. Mara watched the eastern gate until dawn.

Ledger 32 line 136: Neri carried the blue token past marker 8b0bf8f1ed32. Mara watched the eastern gate until dawn.

Ledger 32 line 137: Neri carried the blue token past marker 8edeb7460512. Mara watched the eastern gate until dawn.

Ledger 32 line 138: Neri carried the blue token past marker 176f69120a6e. Mara watched the eastern gate until dawn.

Ledger 32 line 139: Neri carried the blue token past marker fa161a254efb. Mara watched the eastern gate until dawn.

Ledger 32 line 140: Neri carried the blue token past marker dae00e3dc855. Mara watched the eastern gate until dawn.
