---
id: scene-0016
title: Recovery ledger 16
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.161080+00:00
updated_at: 2026-10-03T12:14:52.161080+00:00
---

Ledger 16 line 001: Neri carried the blue token past marker aa02a54d3488. Mara watched the eastern gate until dawn.

Ledger 16 line 002: Neri carried the blue token past marker 14123a075eb2. Mara watched the eastern gate until dawn.

Ledger 16 line 003: Neri carried the blue token past marker c649758701cc. Mara watched the eastern gate until dawn.

Ledger 16 line 004: Neri carried the blue token past marker 26ad3df94160. Mara watched the eastern gate until dawn.

Ledger 16 line 005: Neri carried the blue token past marker 56a7807f638a. Mara watched the eastern gate until dawn.

Ledger 16 line 006: Neri carried the blue token past marker 10f0e751379e. Mara watched the eastern gate until dawn.

Ledger 16 line 007: Neri carried the blue token past marker 42f02b050bef. Mara watched the eastern gate until dawn.

Ledger 16 line 008: Neri carried the blue token past marker 4c6fe0468554. Mara watched the eastern gate until dawn.

Ledger 16 line 009: Neri carried the blue token past marker 3076d9cd0f3f. Mara watched the eastern gate until dawn.

Ledger 16 line 010: Neri carried the blue token past marker d35011ecaff1. Mara watched the eastern gate until dawn.

Ledger 16 line 011: Neri carried the blue token past marker 6bbf485ea790. Mara watched the eastern gate until dawn.

Ledger 16 line 012: Neri carried the blue token past marker 54b3938fca67. Mara watched the eastern gate until dawn.

Ledger 16 line 013: Neri carried the blue token past marker 2a2d8044cccc. Mara watched the eastern gate until dawn.

Ledger 16 line 014: Neri carried the blue token past marker 648fd87156c6. Mara watched the eastern gate until dawn.

Ledger 16 line 015: Neri carried the blue token past marker 64f2d9643d37. Mara watched the eastern gate until dawn.

Ledger 16 line 016: Neri carried the blue token past marker baa3b3948875. Mara watched the eastern gate until dawn.

Ledger 16 line 017: Neri carried the blue token past marker 4ea12b79de69. Mara watched the eastern gate until dawn.

Ledger 16 line 018: Neri carried the blue token past marker 1275c6799614. Mara watched the eastern gate until dawn.

Ledger 16 line 019: Neri carried the blue token past marker 598fb3d58424. Mara watched the eastern gate until dawn.

Ledger 16 line 020: Neri carried the blue token past marker 42c970c7a723. Mara watched the eastern gate until dawn.

Ledger 16 line 021: Neri carried the blue token past marker cb5f40766d2e. Mara watched the eastern gate until dawn.

Ledger 16 line 022: Neri carried the blue token past marker 77e60b74b10a. Mara watched the eastern gate until dawn.

Ledger 16 line 023: Neri carried the blue token past marker 636d1fbe08bd. Mara watched the eastern gate until dawn.

Ledger 16 line 024: Neri carried the blue token past marker 92350a0e4fb7. Mara watched the eastern gate until dawn.

Ledger 16 line 025: Neri carried the blue token past marker 00a49fc7de24. Mara watched the eastern gate until dawn.

Ledger 16 line 026: Neri carried the blue token past marker 830284445927. Mara watched the eastern gate until dawn.

Ledger 16 line 027: Neri carried the blue token past marker 379fb802f253. Mara watched the eastern gate until dawn.

Ledger 16 line 028: Neri carried the blue token past marker 89bce061e298. Mara watched the eastern gate until dawn.

Ledger 16 line 029: Neri carried the blue token past marker 900c22eecbcb. Mara watched the eastern gate until dawn.

Ledger 16 line 030: Neri carried the blue token past marker 5ecfd10ba892. Mara watched the eastern gate until dawn.

Ledger 16 line 031: Neri carried the blue token past marker b80491841699. Mara watched the eastern gate until dawn.

Ledger 16 line 032: Neri carried the blue token past marker cfa64e5ead63. Mara watched the eastern gate until dawn.

Ledger 16 line 033: Neri carried the blue token past marker 7b758a3e5987. Mara watched the eastern gate until dawn.

Ledger 16 line 034: Neri carried the blue token past marker 0e52da9e7b32. Mara watched the eastern gate until dawn.

Ledger 16 line 035: Neri carried the blue token past marker 448bac251153. Mara watched the eastern gate until dawn.

Ledger 16 line 036: Neri carried the blue token past marker b572efa36829. Mara watched the eastern gate until dawn.

Ledger 16 line 037: Neri carried the blue token past marker 4953e4bd74cd. Mara watched the eastern gate until dawn.

Ledger 16 line 038: Neri carried the blue token past marker caa36bd68e36. Mara watched the eastern gate until dawn.

Ledger 16 line 039: Neri carried the blue token past marker fc4f58774fa8. Mara watched the eastern gate until dawn.

Ledger 16 line 040: Neri carried the blue token past marker b4647e58997a. Mara watched the eastern gate until dawn.

Ledger 16 line 041: Neri carried the blue token past marker f0abfbe9fc28. Mara watched the eastern gate until dawn.

Ledger 16 line 042: Neri carried the blue token past marker 4475981ec769. Mara watched the eastern gate until dawn.

Ledger 16 line 043: Neri carried the blue token past marker be5e261d8762. Mara watched the eastern gate until dawn.

Ledger 16 line 044: Neri carried the blue token past marker 033abf252ca2. Mara watched the eastern gate until dawn.

Ledger 16 line 045: Neri carried the blue token past marker 4867929ce20a. Mara watched the eastern gate until dawn.

Ledger 16 line 046: Neri carried the blue token past marker ddb3ecb486c5. Mara watched the eastern gate until dawn.

Ledger 16 line 047: Neri carried the blue token past marker 35e100f353e8. Mara watched the eastern gate until dawn.

Ledger 16 line 048: Neri carried the blue token past marker d19bb1ae4866. Mara watched the eastern gate until dawn.

Ledger 16 line 049: Neri carried the blue token past marker 929e415cb8c6. Mara watched the eastern gate until dawn.

Ledger 16 line 050: Neri carried the blue token past marker c37c4ca9b3b7. Mara watched the eastern gate until dawn.

Ledger 16 line 051: Neri carried the blue token past marker 36ac9874b8cd. Mara watched the eastern gate until dawn.

Ledger 16 line 052: Neri carried the blue token past marker b33d469ef331. Mara watched the eastern gate until dawn.

Ledger 16 line 053: Neri carried the blue token past marker 3ad8610b193a. Mara watched the eastern gate until dawn.

Ledger 16 line 054: Neri carried the blue token past marker 18bd6b501dce. Mara watched the eastern gate until dawn.

Ledger 16 line 055: Neri carried the blue token past marker 4919b45095cb. Mara watched the eastern gate until dawn.

Ledger 16 line 056: Neri carried the blue token past marker 39cf12972d76. Mara watched the eastern gate until dawn.

Ledger 16 line 057: Neri carried the blue token past marker 0d5dfc022bc1. Mara watched the eastern gate until dawn.

Ledger 16 line 058: Neri carried the blue token past marker abcf496eab87. Mara watched the eastern gate until dawn.

Ledger 16 line 059: Neri carried the blue token past marker 0f1a33e9b2b2. Mara watched the eastern gate until dawn.

Ledger 16 line 060: Neri carried the blue token past marker e7eb35c01774. Mara watched the eastern gate until dawn.

Ledger 16 line 061: Neri carried the blue token past marker 86885dff9820. Mara watched the eastern gate until dawn.

Ledger 16 line 062: Neri carried the blue token past marker 342f99f0b1de. Mara watched the eastern gate until dawn.

Ledger 16 line 063: Neri carried the blue token past marker bef549ebd143. Mara watched the eastern gate until dawn.

Ledger 16 line 064: Neri carried the blue token past marker 868b4aa46ea4. Mara watched the eastern gate until dawn.

Ledger 16 line 065: Neri carried the blue token past marker f0aaaac516af. Mara watched the eastern gate until dawn.

Ledger 16 line 066: Neri carried the blue token past marker 3319d46c8732. Mara watched the eastern gate until dawn.

Ledger 16 line 067: Neri carried the blue token past marker c1b6e4953e3c. Mara watched the eastern gate until dawn.

Ledger 16 line 068: Neri carried the blue token past marker 9a094f3c3595. Mara watched the eastern gate until dawn.

Ledger 16 line 069: Neri carried the blue token past marker e0236eae8f82. Mara watched the eastern gate until dawn.

Ledger 16 line 070: Neri carried the blue token past marker 95d6c532f56b. Mara watched the eastern gate until dawn.

Ledger 16 line 071: Neri carried the blue token past marker 92c30404ced7. Mara watched the eastern gate until dawn.

Ledger 16 line 072: Neri carried the blue token past marker 37c944ed238a. Mara watched the eastern gate until dawn.

Ledger 16 line 073: Neri carried the blue token past marker 68f16393b5b2. Mara watched the eastern gate until dawn.

Ledger 16 line 074: Neri carried the blue token past marker bb8904f17948. Mara watched the eastern gate until dawn.

Ledger 16 line 075: Neri carried the blue token past marker aacce316dd19. Mara watched the eastern gate until dawn.

Ledger 16 line 076: Neri carried the blue token past marker 3615f2094363. Mara watched the eastern gate until dawn.

Ledger 16 line 077: Neri carried the blue token past marker 4f2fa318453f. Mara watched the eastern gate until dawn.

Ledger 16 line 078: Neri carried the blue token past marker 312cb5ff7c8f. Mara watched the eastern gate until dawn.

Ledger 16 line 079: Neri carried the blue token past marker 9a28420024d2. Mara watched the eastern gate until dawn.

Ledger 16 line 080: Neri carried the blue token past marker 017a1f78da9f. Mara watched the eastern gate until dawn.

Ledger 16 line 081: Neri carried the blue token past marker 6c539022e788. Mara watched the eastern gate until dawn.

Ledger 16 line 082: Neri carried the blue token past marker 409fc1eaf3b4. Mara watched the eastern gate until dawn.

Ledger 16 line 083: Neri carried the blue token past marker f56acb542445. Mara watched the eastern gate until dawn.

Ledger 16 line 084: Neri carried the blue token past marker e6630a256178. Mara watched the eastern gate until dawn.

Ledger 16 line 085: Neri carried the blue token past marker 7eeb6ce7c7bb. Mara watched the eastern gate until dawn.

Ledger 16 line 086: Neri carried the blue token past marker 17dc78f5c7e1. Mara watched the eastern gate until dawn.

Ledger 16 line 087: Neri carried the blue token past marker b35417ec8109. Mara watched the eastern gate until dawn.

Ledger 16 line 088: Neri carried the blue token past marker bcbfde858b59. Mara watched the eastern gate until dawn.

Ledger 16 line 089: Neri carried the blue token past marker 636b6303505a. Mara watched the eastern gate until dawn.

Ledger 16 line 090: Neri carried the blue token past marker 761d992b22d6. Mara watched the eastern gate until dawn.

Ledger 16 line 091: Neri carried the blue token past marker d34eb4f6503b. Mara watched the eastern gate until dawn.

Ledger 16 line 092: Neri carried the blue token past marker c0badbca04fe. Mara watched the eastern gate until dawn.

Ledger 16 line 093: Neri carried the blue token past marker add6dab833de. Mara watched the eastern gate until dawn.

Ledger 16 line 094: Neri carried the blue token past marker c7b705c042a5. Mara watched the eastern gate until dawn.

Ledger 16 line 095: Neri carried the blue token past marker bbc3363096a7. Mara watched the eastern gate until dawn.

Ledger 16 line 096: Neri carried the blue token past marker b5b97d1bde98. Mara watched the eastern gate until dawn.

Ledger 16 line 097: Neri carried the blue token past marker 49a618e69108. Mara watched the eastern gate until dawn.

Ledger 16 line 098: Neri carried the blue token past marker 73fe7218b5f8. Mara watched the eastern gate until dawn.

Ledger 16 line 099: Neri carried the blue token past marker 180dcc8acf84. Mara watched the eastern gate until dawn.

Ledger 16 line 100: Neri carried the blue token past marker 12b0d57c454a. Mara watched the eastern gate until dawn.

Ledger 16 line 101: Neri carried the blue token past marker d50bcdde36a8. Mara watched the eastern gate until dawn.

Ledger 16 line 102: Neri carried the blue token past marker ad27f4087b94. Mara watched the eastern gate until dawn.

Ledger 16 line 103: Neri carried the blue token past marker a9a919c98a95. Mara watched the eastern gate until dawn.

Ledger 16 line 104: Neri carried the blue token past marker 7bcbe0fadbf9. Mara watched the eastern gate until dawn.

Ledger 16 line 105: Neri carried the blue token past marker a26162b09187. Mara watched the eastern gate until dawn.

Ledger 16 line 106: Neri carried the blue token past marker 3372a506f439. Mara watched the eastern gate until dawn.

Ledger 16 line 107: Neri carried the blue token past marker f32d061d3df3. Mara watched the eastern gate until dawn.

Ledger 16 line 108: Neri carried the blue token past marker 4a175a0feb02. Mara watched the eastern gate until dawn.

Ledger 16 line 109: Neri carried the blue token past marker bbfcf80727b7. Mara watched the eastern gate until dawn.

Ledger 16 line 110: Neri carried the blue token past marker 8163f606ba3c. Mara watched the eastern gate until dawn.

Ledger 16 line 111: Neri carried the blue token past marker ebb22e5546f7. Mara watched the eastern gate until dawn.

Ledger 16 line 112: Neri carried the blue token past marker c0b31a3db790. Mara watched the eastern gate until dawn.

Ledger 16 line 113: Neri carried the blue token past marker 364efc6bf9b1. Mara watched the eastern gate until dawn.

Ledger 16 line 114: Neri carried the blue token past marker 99bc5d8fcc3b. Mara watched the eastern gate until dawn.

Ledger 16 line 115: Neri carried the blue token past marker 50e140589c0f. Mara watched the eastern gate until dawn.

Ledger 16 line 116: Neri carried the blue token past marker 1fe448be7593. Mara watched the eastern gate until dawn.

Ledger 16 line 117: Neri carried the blue token past marker 60b11ae68d8f. Mara watched the eastern gate until dawn.

Ledger 16 line 118: Neri carried the blue token past marker 363c988a95d1. Mara watched the eastern gate until dawn.

Ledger 16 line 119: Neri carried the blue token past marker 4d97da0b7991. Mara watched the eastern gate until dawn.

Ledger 16 line 120: Neri carried the blue token past marker 223613ce6f0a. Mara watched the eastern gate until dawn.

Ledger 16 line 121: Neri carried the blue token past marker b28338ed6768. Mara watched the eastern gate until dawn.

Ledger 16 line 122: Neri carried the blue token past marker 07df03fd83c9. Mara watched the eastern gate until dawn.

Ledger 16 line 123: Neri carried the blue token past marker 33181eae9ccb. Mara watched the eastern gate until dawn.

Ledger 16 line 124: Neri carried the blue token past marker e7fe64799c60. Mara watched the eastern gate until dawn.

Ledger 16 line 125: Neri carried the blue token past marker 8323d6ec6d8d. Mara watched the eastern gate until dawn.

Ledger 16 line 126: Neri carried the blue token past marker 50005ead07d9. Mara watched the eastern gate until dawn.

Ledger 16 line 127: Neri carried the blue token past marker 487ffe1559df. Mara watched the eastern gate until dawn.

Ledger 16 line 128: Neri carried the blue token past marker e83d3ca0653d. Mara watched the eastern gate until dawn.

Ledger 16 line 129: Neri carried the blue token past marker e6ab28fbcced. Mara watched the eastern gate until dawn.

Ledger 16 line 130: Neri carried the blue token past marker 9f755a472adf. Mara watched the eastern gate until dawn.

Ledger 16 line 131: Neri carried the blue token past marker c1be26b2faa1. Mara watched the eastern gate until dawn.

Ledger 16 line 132: Neri carried the blue token past marker a5d8edc68c44. Mara watched the eastern gate until dawn.

Ledger 16 line 133: Neri carried the blue token past marker ddcf883d4f45. Mara watched the eastern gate until dawn.

Ledger 16 line 134: Neri carried the blue token past marker 4541607ddbc5. Mara watched the eastern gate until dawn.

Ledger 16 line 135: Neri carried the blue token past marker 58bd335f84ec. Mara watched the eastern gate until dawn.

Ledger 16 line 136: Neri carried the blue token past marker 99fe8518fb7d. Mara watched the eastern gate until dawn.

Ledger 16 line 137: Neri carried the blue token past marker 6400bb818199. Mara watched the eastern gate until dawn.

Ledger 16 line 138: Neri carried the blue token past marker a95a3dfa03aa. Mara watched the eastern gate until dawn.

Ledger 16 line 139: Neri carried the blue token past marker 451bf170d537. Mara watched the eastern gate until dawn.

Ledger 16 line 140: Neri carried the blue token past marker d400ef5f2a97. Mara watched the eastern gate until dawn.
