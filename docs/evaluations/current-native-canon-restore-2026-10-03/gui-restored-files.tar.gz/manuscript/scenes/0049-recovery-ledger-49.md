---
id: scene-0049
title: Recovery ledger 49
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.178557+00:00
updated_at: 2026-10-03T12:14:52.178557+00:00
---

Ledger 49 line 001: Neri carried the blue token past marker 0d4b0625f834. Mara watched the eastern gate until dawn.

Ledger 49 line 002: Neri carried the blue token past marker 63b10af7e27c. Mara watched the eastern gate until dawn.

Ledger 49 line 003: Neri carried the blue token past marker 550934b82d95. Mara watched the eastern gate until dawn.

Ledger 49 line 004: Neri carried the blue token past marker 9b22b39becc7. Mara watched the eastern gate until dawn.

Ledger 49 line 005: Neri carried the blue token past marker a90ba8eab63e. Mara watched the eastern gate until dawn.

Ledger 49 line 006: Neri carried the blue token past marker 95295dbd0e76. Mara watched the eastern gate until dawn.

Ledger 49 line 007: Neri carried the blue token past marker 7a402abe8085. Mara watched the eastern gate until dawn.

Ledger 49 line 008: Neri carried the blue token past marker eab062904c44. Mara watched the eastern gate until dawn.

Ledger 49 line 009: Neri carried the blue token past marker 2d8e76cfb8d6. Mara watched the eastern gate until dawn.

Ledger 49 line 010: Neri carried the blue token past marker cfd11b2d216c. Mara watched the eastern gate until dawn.

Ledger 49 line 011: Neri carried the blue token past marker b7b7c0bc212f. Mara watched the eastern gate until dawn.

Ledger 49 line 012: Neri carried the blue token past marker 4246f2f981cf. Mara watched the eastern gate until dawn.

Ledger 49 line 013: Neri carried the blue token past marker fe42266d031c. Mara watched the eastern gate until dawn.

Ledger 49 line 014: Neri carried the blue token past marker 6dd528c70510. Mara watched the eastern gate until dawn.

Ledger 49 line 015: Neri carried the blue token past marker ac4650df90ca. Mara watched the eastern gate until dawn.

Ledger 49 line 016: Neri carried the blue token past marker 80d9366e8ded. Mara watched the eastern gate until dawn.

Ledger 49 line 017: Neri carried the blue token past marker bf89da23af7d. Mara watched the eastern gate until dawn.

Ledger 49 line 018: Neri carried the blue token past marker 5be711654ec7. Mara watched the eastern gate until dawn.

Ledger 49 line 019: Neri carried the blue token past marker feaa771f87f1. Mara watched the eastern gate until dawn.

Ledger 49 line 020: Neri carried the blue token past marker 30672e51fad5. Mara watched the eastern gate until dawn.

Ledger 49 line 021: Neri carried the blue token past marker 7630aab0f368. Mara watched the eastern gate until dawn.

Ledger 49 line 022: Neri carried the blue token past marker 7d16a07ccdbf. Mara watched the eastern gate until dawn.

Ledger 49 line 023: Neri carried the blue token past marker 4fda3055460f. Mara watched the eastern gate until dawn.

Ledger 49 line 024: Neri carried the blue token past marker 3913aa40bb26. Mara watched the eastern gate until dawn.

Ledger 49 line 025: Neri carried the blue token past marker 1c12434d98a0. Mara watched the eastern gate until dawn.

Ledger 49 line 026: Neri carried the blue token past marker d86c6adcc4f4. Mara watched the eastern gate until dawn.

Ledger 49 line 027: Neri carried the blue token past marker abb45c5c498a. Mara watched the eastern gate until dawn.

Ledger 49 line 028: Neri carried the blue token past marker 11472cb36b3f. Mara watched the eastern gate until dawn.

Ledger 49 line 029: Neri carried the blue token past marker ea56233d797c. Mara watched the eastern gate until dawn.

Ledger 49 line 030: Neri carried the blue token past marker 246ce02c5ac8. Mara watched the eastern gate until dawn.

Ledger 49 line 031: Neri carried the blue token past marker 04d9b1837282. Mara watched the eastern gate until dawn.

Ledger 49 line 032: Neri carried the blue token past marker d4c556c645e7. Mara watched the eastern gate until dawn.

Ledger 49 line 033: Neri carried the blue token past marker 52ab0b8c5c8d. Mara watched the eastern gate until dawn.

Ledger 49 line 034: Neri carried the blue token past marker f1fa8c890cc7. Mara watched the eastern gate until dawn.

Ledger 49 line 035: Neri carried the blue token past marker a8b87d45e480. Mara watched the eastern gate until dawn.

Ledger 49 line 036: Neri carried the blue token past marker 7f507ec20c42. Mara watched the eastern gate until dawn.

Ledger 49 line 037: Neri carried the blue token past marker 52acd37462ae. Mara watched the eastern gate until dawn.

Ledger 49 line 038: Neri carried the blue token past marker 8dde32fcbeaa. Mara watched the eastern gate until dawn.

Ledger 49 line 039: Neri carried the blue token past marker 203a85a1903e. Mara watched the eastern gate until dawn.

Ledger 49 line 040: Neri carried the blue token past marker e5ef3f8cc134. Mara watched the eastern gate until dawn.

Ledger 49 line 041: Neri carried the blue token past marker 80e9b408bdf4. Mara watched the eastern gate until dawn.

Ledger 49 line 042: Neri carried the blue token past marker dc994975c880. Mara watched the eastern gate until dawn.

Ledger 49 line 043: Neri carried the blue token past marker f6d52b3ca3b4. Mara watched the eastern gate until dawn.

Ledger 49 line 044: Neri carried the blue token past marker 3f20305c144e. Mara watched the eastern gate until dawn.

Ledger 49 line 045: Neri carried the blue token past marker d5c4a6b44374. Mara watched the eastern gate until dawn.

Ledger 49 line 046: Neri carried the blue token past marker 34fc5369c3a0. Mara watched the eastern gate until dawn.

Ledger 49 line 047: Neri carried the blue token past marker 13c97e8d37a8. Mara watched the eastern gate until dawn.

Ledger 49 line 048: Neri carried the blue token past marker a675bdae332a. Mara watched the eastern gate until dawn.

Ledger 49 line 049: Neri carried the blue token past marker f4fd1beb8bcf. Mara watched the eastern gate until dawn.

Ledger 49 line 050: Neri carried the blue token past marker 15159cba3031. Mara watched the eastern gate until dawn.

Ledger 49 line 051: Neri carried the blue token past marker 09ea9f914c52. Mara watched the eastern gate until dawn.

Ledger 49 line 052: Neri carried the blue token past marker 2c87d12c31e8. Mara watched the eastern gate until dawn.

Ledger 49 line 053: Neri carried the blue token past marker a49a7061594b. Mara watched the eastern gate until dawn.

Ledger 49 line 054: Neri carried the blue token past marker 8f34d5cbbad8. Mara watched the eastern gate until dawn.

Ledger 49 line 055: Neri carried the blue token past marker 416f2148b7d0. Mara watched the eastern gate until dawn.

Ledger 49 line 056: Neri carried the blue token past marker eeac43ae7244. Mara watched the eastern gate until dawn.

Ledger 49 line 057: Neri carried the blue token past marker 58cd98aaf8d2. Mara watched the eastern gate until dawn.

Ledger 49 line 058: Neri carried the blue token past marker 6f6849590b6d. Mara watched the eastern gate until dawn.

Ledger 49 line 059: Neri carried the blue token past marker 414a382d5589. Mara watched the eastern gate until dawn.

Ledger 49 line 060: Neri carried the blue token past marker b158a05f742d. Mara watched the eastern gate until dawn.

Ledger 49 line 061: Neri carried the blue token past marker 233e4d9d828f. Mara watched the eastern gate until dawn.

Ledger 49 line 062: Neri carried the blue token past marker afdd2a31cbf1. Mara watched the eastern gate until dawn.

Ledger 49 line 063: Neri carried the blue token past marker 148b5c8b19dd. Mara watched the eastern gate until dawn.

Ledger 49 line 064: Neri carried the blue token past marker dcc1b354f44d. Mara watched the eastern gate until dawn.

Ledger 49 line 065: Neri carried the blue token past marker cb518961ea04. Mara watched the eastern gate until dawn.

Ledger 49 line 066: Neri carried the blue token past marker 640027bcedbc. Mara watched the eastern gate until dawn.

Ledger 49 line 067: Neri carried the blue token past marker a5514b732828. Mara watched the eastern gate until dawn.

Ledger 49 line 068: Neri carried the blue token past marker 7456a14ed667. Mara watched the eastern gate until dawn.

Ledger 49 line 069: Neri carried the blue token past marker 2d7f4b01f179. Mara watched the eastern gate until dawn.

Ledger 49 line 070: Neri carried the blue token past marker 3cfed555b4d4. Mara watched the eastern gate until dawn.

Ledger 49 line 071: Neri carried the blue token past marker 24f9026bc216. Mara watched the eastern gate until dawn.

Ledger 49 line 072: Neri carried the blue token past marker 04d2fefebde9. Mara watched the eastern gate until dawn.

Ledger 49 line 073: Neri carried the blue token past marker 437a8b3b4d36. Mara watched the eastern gate until dawn.

Ledger 49 line 074: Neri carried the blue token past marker a7ce4d7e9abb. Mara watched the eastern gate until dawn.

Ledger 49 line 075: Neri carried the blue token past marker bd6a15951e89. Mara watched the eastern gate until dawn.

Ledger 49 line 076: Neri carried the blue token past marker 6eb65006173e. Mara watched the eastern gate until dawn.

Ledger 49 line 077: Neri carried the blue token past marker b64bba157d2a. Mara watched the eastern gate until dawn.

Ledger 49 line 078: Neri carried the blue token past marker b4c8a0c6e651. Mara watched the eastern gate until dawn.

Ledger 49 line 079: Neri carried the blue token past marker 09712af31bd8. Mara watched the eastern gate until dawn.

Ledger 49 line 080: Neri carried the blue token past marker c9e3cd863045. Mara watched the eastern gate until dawn.

Ledger 49 line 081: Neri carried the blue token past marker 40360180564a. Mara watched the eastern gate until dawn.

Ledger 49 line 082: Neri carried the blue token past marker 7c37afeb8df7. Mara watched the eastern gate until dawn.

Ledger 49 line 083: Neri carried the blue token past marker 3f53e84bddac. Mara watched the eastern gate until dawn.

Ledger 49 line 084: Neri carried the blue token past marker e26c669948f9. Mara watched the eastern gate until dawn.

Ledger 49 line 085: Neri carried the blue token past marker bfc28fed3154. Mara watched the eastern gate until dawn.

Ledger 49 line 086: Neri carried the blue token past marker 9ce69e86c853. Mara watched the eastern gate until dawn.

Ledger 49 line 087: Neri carried the blue token past marker d26a74f6542a. Mara watched the eastern gate until dawn.

Ledger 49 line 088: Neri carried the blue token past marker 19143411f0a8. Mara watched the eastern gate until dawn.

Ledger 49 line 089: Neri carried the blue token past marker 56c95991bcf4. Mara watched the eastern gate until dawn.

Ledger 49 line 090: Neri carried the blue token past marker 57df2308a973. Mara watched the eastern gate until dawn.

Ledger 49 line 091: Neri carried the blue token past marker 399635374b33. Mara watched the eastern gate until dawn.

Ledger 49 line 092: Neri carried the blue token past marker 2b390059866f. Mara watched the eastern gate until dawn.

Ledger 49 line 093: Neri carried the blue token past marker 7cc1387246e1. Mara watched the eastern gate until dawn.

Ledger 49 line 094: Neri carried the blue token past marker fe28d0c12504. Mara watched the eastern gate until dawn.

Ledger 49 line 095: Neri carried the blue token past marker 4589cce4e1e0. Mara watched the eastern gate until dawn.

Ledger 49 line 096: Neri carried the blue token past marker 9f53ade3b6dc. Mara watched the eastern gate until dawn.

Ledger 49 line 097: Neri carried the blue token past marker 9a55ebd0bbf6. Mara watched the eastern gate until dawn.

Ledger 49 line 098: Neri carried the blue token past marker bbc001ad40fc. Mara watched the eastern gate until dawn.

Ledger 49 line 099: Neri carried the blue token past marker cdd9a1e64b62. Mara watched the eastern gate until dawn.

Ledger 49 line 100: Neri carried the blue token past marker bce618c2c11b. Mara watched the eastern gate until dawn.

Ledger 49 line 101: Neri carried the blue token past marker d64d09429993. Mara watched the eastern gate until dawn.

Ledger 49 line 102: Neri carried the blue token past marker bba6584fc7a6. Mara watched the eastern gate until dawn.

Ledger 49 line 103: Neri carried the blue token past marker fc185ed69175. Mara watched the eastern gate until dawn.

Ledger 49 line 104: Neri carried the blue token past marker 500250d27945. Mara watched the eastern gate until dawn.

Ledger 49 line 105: Neri carried the blue token past marker 5d28f6886482. Mara watched the eastern gate until dawn.

Ledger 49 line 106: Neri carried the blue token past marker c75d9ead2151. Mara watched the eastern gate until dawn.

Ledger 49 line 107: Neri carried the blue token past marker 62d213402dde. Mara watched the eastern gate until dawn.

Ledger 49 line 108: Neri carried the blue token past marker bf65dadf2667. Mara watched the eastern gate until dawn.

Ledger 49 line 109: Neri carried the blue token past marker 4f852b13aa54. Mara watched the eastern gate until dawn.

Ledger 49 line 110: Neri carried the blue token past marker ae4a9cc8a3b0. Mara watched the eastern gate until dawn.

Ledger 49 line 111: Neri carried the blue token past marker aa90cc43b068. Mara watched the eastern gate until dawn.

Ledger 49 line 112: Neri carried the blue token past marker 7bf1a8703e4e. Mara watched the eastern gate until dawn.

Ledger 49 line 113: Neri carried the blue token past marker 5a158e64d7c9. Mara watched the eastern gate until dawn.

Ledger 49 line 114: Neri carried the blue token past marker 31413caa27a6. Mara watched the eastern gate until dawn.

Ledger 49 line 115: Neri carried the blue token past marker 67aed9849005. Mara watched the eastern gate until dawn.

Ledger 49 line 116: Neri carried the blue token past marker 3e23d4331c53. Mara watched the eastern gate until dawn.

Ledger 49 line 117: Neri carried the blue token past marker 8b94c63bbae5. Mara watched the eastern gate until dawn.

Ledger 49 line 118: Neri carried the blue token past marker 96c7cbc4ca52. Mara watched the eastern gate until dawn.

Ledger 49 line 119: Neri carried the blue token past marker 0a061640b5d7. Mara watched the eastern gate until dawn.

Ledger 49 line 120: Neri carried the blue token past marker 1d7e5570f996. Mara watched the eastern gate until dawn.

Ledger 49 line 121: Neri carried the blue token past marker e12bd3df0172. Mara watched the eastern gate until dawn.

Ledger 49 line 122: Neri carried the blue token past marker 943a33b51128. Mara watched the eastern gate until dawn.

Ledger 49 line 123: Neri carried the blue token past marker db8f4ee06234. Mara watched the eastern gate until dawn.

Ledger 49 line 124: Neri carried the blue token past marker c3e3372fcd0b. Mara watched the eastern gate until dawn.

Ledger 49 line 125: Neri carried the blue token past marker b9c4a6d91a00. Mara watched the eastern gate until dawn.

Ledger 49 line 126: Neri carried the blue token past marker 533db6669bcc. Mara watched the eastern gate until dawn.

Ledger 49 line 127: Neri carried the blue token past marker bf935e42b50f. Mara watched the eastern gate until dawn.

Ledger 49 line 128: Neri carried the blue token past marker 1f40e57c7aa6. Mara watched the eastern gate until dawn.

Ledger 49 line 129: Neri carried the blue token past marker 7ab4938c59ef. Mara watched the eastern gate until dawn.

Ledger 49 line 130: Neri carried the blue token past marker c36ee20c020b. Mara watched the eastern gate until dawn.

Ledger 49 line 131: Neri carried the blue token past marker 5ddcb0da7d03. Mara watched the eastern gate until dawn.

Ledger 49 line 132: Neri carried the blue token past marker 58de62be3fbb. Mara watched the eastern gate until dawn.

Ledger 49 line 133: Neri carried the blue token past marker 24ac3ddcb658. Mara watched the eastern gate until dawn.

Ledger 49 line 134: Neri carried the blue token past marker 6289292d84e3. Mara watched the eastern gate until dawn.

Ledger 49 line 135: Neri carried the blue token past marker f943e34f4464. Mara watched the eastern gate until dawn.

Ledger 49 line 136: Neri carried the blue token past marker b17b6b0285df. Mara watched the eastern gate until dawn.

Ledger 49 line 137: Neri carried the blue token past marker e17e78949d0d. Mara watched the eastern gate until dawn.

Ledger 49 line 138: Neri carried the blue token past marker e491cea5e4ee. Mara watched the eastern gate until dawn.

Ledger 49 line 139: Neri carried the blue token past marker 694a4d87f208. Mara watched the eastern gate until dawn.

Ledger 49 line 140: Neri carried the blue token past marker 553f3d6b3b9f. Mara watched the eastern gate until dawn.
