---
id: scene-0006
title: Recovery ledger 06
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.156045+00:00
updated_at: 2026-10-03T12:14:52.156045+00:00
---

Ledger 06 line 001: Neri carried the blue token past marker 9cbc80327ac3. Mara watched the eastern gate until dawn.

Ledger 06 line 002: Neri carried the blue token past marker e06d7a2908be. Mara watched the eastern gate until dawn.

Ledger 06 line 003: Neri carried the blue token past marker 2717ece0b13e. Mara watched the eastern gate until dawn.

Ledger 06 line 004: Neri carried the blue token past marker eca69b1009f5. Mara watched the eastern gate until dawn.

Ledger 06 line 005: Neri carried the blue token past marker 3fb6418f5c17. Mara watched the eastern gate until dawn.

Ledger 06 line 006: Neri carried the blue token past marker b9a6062358fc. Mara watched the eastern gate until dawn.

Ledger 06 line 007: Neri carried the blue token past marker 71feb18fd29f. Mara watched the eastern gate until dawn.

Ledger 06 line 008: Neri carried the blue token past marker 07bee9bddf75. Mara watched the eastern gate until dawn.

Ledger 06 line 009: Neri carried the blue token past marker e61a4dbddf44. Mara watched the eastern gate until dawn.

Ledger 06 line 010: Neri carried the blue token past marker 0b896dab987a. Mara watched the eastern gate until dawn.

Ledger 06 line 011: Neri carried the blue token past marker d76174df2d7d. Mara watched the eastern gate until dawn.

Ledger 06 line 012: Neri carried the blue token past marker dd1bd898f6c1. Mara watched the eastern gate until dawn.

Ledger 06 line 013: Neri carried the blue token past marker b485ba57705f. Mara watched the eastern gate until dawn.

Ledger 06 line 014: Neri carried the blue token past marker 1d65e5db7745. Mara watched the eastern gate until dawn.

Ledger 06 line 015: Neri carried the blue token past marker 45699baefbf2. Mara watched the eastern gate until dawn.

Ledger 06 line 016: Neri carried the blue token past marker c2c8be2013e5. Mara watched the eastern gate until dawn.

Ledger 06 line 017: Neri carried the blue token past marker 9a802b8259e6. Mara watched the eastern gate until dawn.

Ledger 06 line 018: Neri carried the blue token past marker 87619bd0c4bc. Mara watched the eastern gate until dawn.

Ledger 06 line 019: Neri carried the blue token past marker e6feee4043e6. Mara watched the eastern gate until dawn.

Ledger 06 line 020: Neri carried the blue token past marker 5bff5ac4572a. Mara watched the eastern gate until dawn.

Ledger 06 line 021: Neri carried the blue token past marker 1444607198d8. Mara watched the eastern gate until dawn.

Ledger 06 line 022: Neri carried the blue token past marker 385efab8007a. Mara watched the eastern gate until dawn.

Ledger 06 line 023: Neri carried the blue token past marker 05353fdab64e. Mara watched the eastern gate until dawn.

Ledger 06 line 024: Neri carried the blue token past marker 3e9fef712e2c. Mara watched the eastern gate until dawn.

Ledger 06 line 025: Neri carried the blue token past marker 690916f7056a. Mara watched the eastern gate until dawn.

Ledger 06 line 026: Neri carried the blue token past marker baf1e73a7dbb. Mara watched the eastern gate until dawn.

Ledger 06 line 027: Neri carried the blue token past marker f7c6ed0d4096. Mara watched the eastern gate until dawn.

Ledger 06 line 028: Neri carried the blue token past marker 0ca754d38b95. Mara watched the eastern gate until dawn.

Ledger 06 line 029: Neri carried the blue token past marker 153cb7e85966. Mara watched the eastern gate until dawn.

Ledger 06 line 030: Neri carried the blue token past marker de2c4db5ceb3. Mara watched the eastern gate until dawn.

Ledger 06 line 031: Neri carried the blue token past marker 25a96d9e79f6. Mara watched the eastern gate until dawn.

Ledger 06 line 032: Neri carried the blue token past marker 9e9b8c413d1d. Mara watched the eastern gate until dawn.

Ledger 06 line 033: Neri carried the blue token past marker cadfb3dbee0e. Mara watched the eastern gate until dawn.

Ledger 06 line 034: Neri carried the blue token past marker 30a359cb434b. Mara watched the eastern gate until dawn.

Ledger 06 line 035: Neri carried the blue token past marker f8856689b012. Mara watched the eastern gate until dawn.

Ledger 06 line 036: Neri carried the blue token past marker c5d8724097c7. Mara watched the eastern gate until dawn.

Ledger 06 line 037: Neri carried the blue token past marker a3c93462e58b. Mara watched the eastern gate until dawn.

Ledger 06 line 038: Neri carried the blue token past marker e59690d142d7. Mara watched the eastern gate until dawn.

Ledger 06 line 039: Neri carried the blue token past marker 0afcf89d8d01. Mara watched the eastern gate until dawn.

Ledger 06 line 040: Neri carried the blue token past marker fc947f458727. Mara watched the eastern gate until dawn.

Ledger 06 line 041: Neri carried the blue token past marker e6c3e40c3925. Mara watched the eastern gate until dawn.

Ledger 06 line 042: Neri carried the blue token past marker efd79c7632e1. Mara watched the eastern gate until dawn.

Ledger 06 line 043: Neri carried the blue token past marker 124a95a8d3ec. Mara watched the eastern gate until dawn.

Ledger 06 line 044: Neri carried the blue token past marker 3f4184f05861. Mara watched the eastern gate until dawn.

Ledger 06 line 045: Neri carried the blue token past marker 02d3c160af41. Mara watched the eastern gate until dawn.

Ledger 06 line 046: Neri carried the blue token past marker 4a72e06babf8. Mara watched the eastern gate until dawn.

Ledger 06 line 047: Neri carried the blue token past marker 8b29a320e038. Mara watched the eastern gate until dawn.

Ledger 06 line 048: Neri carried the blue token past marker c09ab60e9280. Mara watched the eastern gate until dawn.

Ledger 06 line 049: Neri carried the blue token past marker 382ede7335c2. Mara watched the eastern gate until dawn.

Ledger 06 line 050: Neri carried the blue token past marker 382a54140adc. Mara watched the eastern gate until dawn.

Ledger 06 line 051: Neri carried the blue token past marker 11480a5e464c. Mara watched the eastern gate until dawn.

Ledger 06 line 052: Neri carried the blue token past marker 6ca66662fee0. Mara watched the eastern gate until dawn.

Ledger 06 line 053: Neri carried the blue token past marker 720581000bba. Mara watched the eastern gate until dawn.

Ledger 06 line 054: Neri carried the blue token past marker 9f2406f059c5. Mara watched the eastern gate until dawn.

Ledger 06 line 055: Neri carried the blue token past marker cc47c577f298. Mara watched the eastern gate until dawn.

Ledger 06 line 056: Neri carried the blue token past marker 1be706443586. Mara watched the eastern gate until dawn.

Ledger 06 line 057: Neri carried the blue token past marker 38014209fd8a. Mara watched the eastern gate until dawn.

Ledger 06 line 058: Neri carried the blue token past marker 3a9c3d2c4669. Mara watched the eastern gate until dawn.

Ledger 06 line 059: Neri carried the blue token past marker cad047dd7809. Mara watched the eastern gate until dawn.

Ledger 06 line 060: Neri carried the blue token past marker c7bd61a41534. Mara watched the eastern gate until dawn.

Ledger 06 line 061: Neri carried the blue token past marker 71b1c1ed76fd. Mara watched the eastern gate until dawn.

Ledger 06 line 062: Neri carried the blue token past marker 0448a1b0fca3. Mara watched the eastern gate until dawn.

Ledger 06 line 063: Neri carried the blue token past marker 60586bc47a9f. Mara watched the eastern gate until dawn.

Ledger 06 line 064: Neri carried the blue token past marker 7a4bf0349502. Mara watched the eastern gate until dawn.

Ledger 06 line 065: Neri carried the blue token past marker f3e3460155fc. Mara watched the eastern gate until dawn.

Ledger 06 line 066: Neri carried the blue token past marker e88821b62f0e. Mara watched the eastern gate until dawn.

Ledger 06 line 067: Neri carried the blue token past marker acc9ae30e92d. Mara watched the eastern gate until dawn.

Ledger 06 line 068: Neri carried the blue token past marker a75049146731. Mara watched the eastern gate until dawn.

Ledger 06 line 069: Neri carried the blue token past marker a322f048497d. Mara watched the eastern gate until dawn.

Ledger 06 line 070: Neri carried the blue token past marker 63c73eb76b5c. Mara watched the eastern gate until dawn.

Ledger 06 line 071: Neri carried the blue token past marker 4d508cd3f59a. Mara watched the eastern gate until dawn.

Ledger 06 line 072: Neri carried the blue token past marker 3d18526a4b32. Mara watched the eastern gate until dawn.

Ledger 06 line 073: Neri carried the blue token past marker be9a6829275d. Mara watched the eastern gate until dawn.

Ledger 06 line 074: Neri carried the blue token past marker 6667c3947942. Mara watched the eastern gate until dawn.

Ledger 06 line 075: Neri carried the blue token past marker 13bbf6bd0f8b. Mara watched the eastern gate until dawn.

Ledger 06 line 076: Neri carried the blue token past marker 98ed69555e6f. Mara watched the eastern gate until dawn.

Ledger 06 line 077: Neri carried the blue token past marker 091f2ec9d29c. Mara watched the eastern gate until dawn.

Ledger 06 line 078: Neri carried the blue token past marker b1168a8e095b. Mara watched the eastern gate until dawn.

Ledger 06 line 079: Neri carried the blue token past marker be354d7b9032. Mara watched the eastern gate until dawn.

Ledger 06 line 080: Neri carried the blue token past marker fd56a704c565. Mara watched the eastern gate until dawn.

Ledger 06 line 081: Neri carried the blue token past marker b43fdc3e9734. Mara watched the eastern gate until dawn.

Ledger 06 line 082: Neri carried the blue token past marker f252cd0fbdee. Mara watched the eastern gate until dawn.

Ledger 06 line 083: Neri carried the blue token past marker 8d494af60772. Mara watched the eastern gate until dawn.

Ledger 06 line 084: Neri carried the blue token past marker a9628aac11fb. Mara watched the eastern gate until dawn.

Ledger 06 line 085: Neri carried the blue token past marker 5683591943e0. Mara watched the eastern gate until dawn.

Ledger 06 line 086: Neri carried the blue token past marker 302633e25152. Mara watched the eastern gate until dawn.

Ledger 06 line 087: Neri carried the blue token past marker d00fb30c4ca8. Mara watched the eastern gate until dawn.

Ledger 06 line 088: Neri carried the blue token past marker d36b471f4ce4. Mara watched the eastern gate until dawn.

Ledger 06 line 089: Neri carried the blue token past marker e54b2b8f4a78. Mara watched the eastern gate until dawn.

Ledger 06 line 090: Neri carried the blue token past marker 661081849904. Mara watched the eastern gate until dawn.

Ledger 06 line 091: Neri carried the blue token past marker 158499d8bc52. Mara watched the eastern gate until dawn.

Ledger 06 line 092: Neri carried the blue token past marker c17cd2d0131c. Mara watched the eastern gate until dawn.

Ledger 06 line 093: Neri carried the blue token past marker 5263f98629fc. Mara watched the eastern gate until dawn.

Ledger 06 line 094: Neri carried the blue token past marker d5ce6cad726b. Mara watched the eastern gate until dawn.

Ledger 06 line 095: Neri carried the blue token past marker 00beb3c560bc. Mara watched the eastern gate until dawn.

Ledger 06 line 096: Neri carried the blue token past marker 4b1c8830d754. Mara watched the eastern gate until dawn.

Ledger 06 line 097: Neri carried the blue token past marker 3bebddfe0bf8. Mara watched the eastern gate until dawn.

Ledger 06 line 098: Neri carried the blue token past marker 4bb215749203. Mara watched the eastern gate until dawn.

Ledger 06 line 099: Neri carried the blue token past marker d869bdae48a9. Mara watched the eastern gate until dawn.

Ledger 06 line 100: Neri carried the blue token past marker 58785c16c921. Mara watched the eastern gate until dawn.

Ledger 06 line 101: Neri carried the blue token past marker db2b8cbf09b8. Mara watched the eastern gate until dawn.

Ledger 06 line 102: Neri carried the blue token past marker 9d85dd795f16. Mara watched the eastern gate until dawn.

Ledger 06 line 103: Neri carried the blue token past marker ea68f37bba6d. Mara watched the eastern gate until dawn.

Ledger 06 line 104: Neri carried the blue token past marker a02632a426b3. Mara watched the eastern gate until dawn.

Ledger 06 line 105: Neri carried the blue token past marker 6f9ab8cf9ba9. Mara watched the eastern gate until dawn.

Ledger 06 line 106: Neri carried the blue token past marker 5d53a1928919. Mara watched the eastern gate until dawn.

Ledger 06 line 107: Neri carried the blue token past marker 981cf290ae0d. Mara watched the eastern gate until dawn.

Ledger 06 line 108: Neri carried the blue token past marker f543b574ac6d. Mara watched the eastern gate until dawn.

Ledger 06 line 109: Neri carried the blue token past marker 51b06de11cf5. Mara watched the eastern gate until dawn.

Ledger 06 line 110: Neri carried the blue token past marker 34494ed5200d. Mara watched the eastern gate until dawn.

Ledger 06 line 111: Neri carried the blue token past marker 0bbc018d7762. Mara watched the eastern gate until dawn.

Ledger 06 line 112: Neri carried the blue token past marker ad4df2f0c3b3. Mara watched the eastern gate until dawn.

Ledger 06 line 113: Neri carried the blue token past marker f360701105b6. Mara watched the eastern gate until dawn.

Ledger 06 line 114: Neri carried the blue token past marker 7a3ce2f6fb37. Mara watched the eastern gate until dawn.

Ledger 06 line 115: Neri carried the blue token past marker 5924e25ccbdc. Mara watched the eastern gate until dawn.

Ledger 06 line 116: Neri carried the blue token past marker 810620fcfece. Mara watched the eastern gate until dawn.

Ledger 06 line 117: Neri carried the blue token past marker 78c7fa8f196b. Mara watched the eastern gate until dawn.

Ledger 06 line 118: Neri carried the blue token past marker 1a8e1e19d6e5. Mara watched the eastern gate until dawn.

Ledger 06 line 119: Neri carried the blue token past marker 5ba04aa29560. Mara watched the eastern gate until dawn.

Ledger 06 line 120: Neri carried the blue token past marker bc38d899f930. Mara watched the eastern gate until dawn.

Ledger 06 line 121: Neri carried the blue token past marker 4a35bfd2a528. Mara watched the eastern gate until dawn.

Ledger 06 line 122: Neri carried the blue token past marker 372f8d3c99a2. Mara watched the eastern gate until dawn.

Ledger 06 line 123: Neri carried the blue token past marker 54f8a4436d23. Mara watched the eastern gate until dawn.

Ledger 06 line 124: Neri carried the blue token past marker 61b0ccd498c6. Mara watched the eastern gate until dawn.

Ledger 06 line 125: Neri carried the blue token past marker a2fefd3e6849. Mara watched the eastern gate until dawn.

Ledger 06 line 126: Neri carried the blue token past marker 32c7cf2b07ec. Mara watched the eastern gate until dawn.

Ledger 06 line 127: Neri carried the blue token past marker eff11c7264b9. Mara watched the eastern gate until dawn.

Ledger 06 line 128: Neri carried the blue token past marker b87108f90ff8. Mara watched the eastern gate until dawn.

Ledger 06 line 129: Neri carried the blue token past marker 763223cc9407. Mara watched the eastern gate until dawn.

Ledger 06 line 130: Neri carried the blue token past marker fb75cc089cf9. Mara watched the eastern gate until dawn.

Ledger 06 line 131: Neri carried the blue token past marker 8be540066e74. Mara watched the eastern gate until dawn.

Ledger 06 line 132: Neri carried the blue token past marker 887c713074d4. Mara watched the eastern gate until dawn.

Ledger 06 line 133: Neri carried the blue token past marker 344ec08f7927. Mara watched the eastern gate until dawn.

Ledger 06 line 134: Neri carried the blue token past marker b2670826eb1e. Mara watched the eastern gate until dawn.

Ledger 06 line 135: Neri carried the blue token past marker cf368195a5a5. Mara watched the eastern gate until dawn.

Ledger 06 line 136: Neri carried the blue token past marker 4f2274eb9dac. Mara watched the eastern gate until dawn.

Ledger 06 line 137: Neri carried the blue token past marker c0d2c2dc40c8. Mara watched the eastern gate until dawn.

Ledger 06 line 138: Neri carried the blue token past marker 6a402f1a9730. Mara watched the eastern gate until dawn.

Ledger 06 line 139: Neri carried the blue token past marker 988c360ec41d. Mara watched the eastern gate until dawn.

Ledger 06 line 140: Neri carried the blue token past marker 92d98c9aedfa. Mara watched the eastern gate until dawn.
