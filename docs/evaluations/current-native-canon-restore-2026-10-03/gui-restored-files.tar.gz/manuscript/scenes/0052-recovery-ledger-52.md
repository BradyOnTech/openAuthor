---
id: scene-0052
title: Recovery ledger 52
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.180080+00:00
updated_at: 2026-10-03T12:14:52.180080+00:00
---

Ledger 52 line 001: Neri carried the blue token past marker 522f88cffd3e. Mara watched the eastern gate until dawn.

Ledger 52 line 002: Neri carried the blue token past marker bb27a9d1f951. Mara watched the eastern gate until dawn.

Ledger 52 line 003: Neri carried the blue token past marker f03ccb2cdfaf. Mara watched the eastern gate until dawn.

Ledger 52 line 004: Neri carried the blue token past marker 7af35f3df1f3. Mara watched the eastern gate until dawn.

Ledger 52 line 005: Neri carried the blue token past marker e5a02b2138bf. Mara watched the eastern gate until dawn.

Ledger 52 line 006: Neri carried the blue token past marker b1a6094a737b. Mara watched the eastern gate until dawn.

Ledger 52 line 007: Neri carried the blue token past marker 7cadd22e5942. Mara watched the eastern gate until dawn.

Ledger 52 line 008: Neri carried the blue token past marker 13e305b89fc2. Mara watched the eastern gate until dawn.

Ledger 52 line 009: Neri carried the blue token past marker f1551a668edc. Mara watched the eastern gate until dawn.

Ledger 52 line 010: Neri carried the blue token past marker bbf437f92cf0. Mara watched the eastern gate until dawn.

Ledger 52 line 011: Neri carried the blue token past marker 616a0c09993b. Mara watched the eastern gate until dawn.

Ledger 52 line 012: Neri carried the blue token past marker bc257447a6fb. Mara watched the eastern gate until dawn.

Ledger 52 line 013: Neri carried the blue token past marker d69a8dbaad91. Mara watched the eastern gate until dawn.

Ledger 52 line 014: Neri carried the blue token past marker c8d112bb13c5. Mara watched the eastern gate until dawn.

Ledger 52 line 015: Neri carried the blue token past marker 9c8613f0d078. Mara watched the eastern gate until dawn.

Ledger 52 line 016: Neri carried the blue token past marker 8963e6f7a053. Mara watched the eastern gate until dawn.

Ledger 52 line 017: Neri carried the blue token past marker cf5489e7d052. Mara watched the eastern gate until dawn.

Ledger 52 line 018: Neri carried the blue token past marker 5c9b349e8ce5. Mara watched the eastern gate until dawn.

Ledger 52 line 019: Neri carried the blue token past marker 52cfc05fb6b9. Mara watched the eastern gate until dawn.

Ledger 52 line 020: Neri carried the blue token past marker 719f7d0086bc. Mara watched the eastern gate until dawn.

Ledger 52 line 021: Neri carried the blue token past marker 708120f23ccf. Mara watched the eastern gate until dawn.

Ledger 52 line 022: Neri carried the blue token past marker e82754e5ff2f. Mara watched the eastern gate until dawn.

Ledger 52 line 023: Neri carried the blue token past marker cebdf950e225. Mara watched the eastern gate until dawn.

Ledger 52 line 024: Neri carried the blue token past marker 0df47fe832c8. Mara watched the eastern gate until dawn.

Ledger 52 line 025: Neri carried the blue token past marker ac311cda8cbe. Mara watched the eastern gate until dawn.

Ledger 52 line 026: Neri carried the blue token past marker 26f3ce6cee0c. Mara watched the eastern gate until dawn.

Ledger 52 line 027: Neri carried the blue token past marker c407a11277d7. Mara watched the eastern gate until dawn.

Ledger 52 line 028: Neri carried the blue token past marker d8f402a6f9ea. Mara watched the eastern gate until dawn.

Ledger 52 line 029: Neri carried the blue token past marker ceaba85cbd42. Mara watched the eastern gate until dawn.

Ledger 52 line 030: Neri carried the blue token past marker 2a9e9c98a4bb. Mara watched the eastern gate until dawn.

Ledger 52 line 031: Neri carried the blue token past marker 0ac883dea1c4. Mara watched the eastern gate until dawn.

Ledger 52 line 032: Neri carried the blue token past marker 38754ed98455. Mara watched the eastern gate until dawn.

Ledger 52 line 033: Neri carried the blue token past marker f77fae4fdf2f. Mara watched the eastern gate until dawn.

Ledger 52 line 034: Neri carried the blue token past marker 0aeeba54a14a. Mara watched the eastern gate until dawn.

Ledger 52 line 035: Neri carried the blue token past marker cc01a23b0c82. Mara watched the eastern gate until dawn.

Ledger 52 line 036: Neri carried the blue token past marker e03362700a29. Mara watched the eastern gate until dawn.

Ledger 52 line 037: Neri carried the blue token past marker d7f807970139. Mara watched the eastern gate until dawn.

Ledger 52 line 038: Neri carried the blue token past marker 6dff99ba99fb. Mara watched the eastern gate until dawn.

Ledger 52 line 039: Neri carried the blue token past marker 1752f55cc0f2. Mara watched the eastern gate until dawn.

Ledger 52 line 040: Neri carried the blue token past marker 5538d3b28051. Mara watched the eastern gate until dawn.

Ledger 52 line 041: Neri carried the blue token past marker a3ec28f118d8. Mara watched the eastern gate until dawn.

Ledger 52 line 042: Neri carried the blue token past marker 22645b5807e1. Mara watched the eastern gate until dawn.

Ledger 52 line 043: Neri carried the blue token past marker 1991c411df2a. Mara watched the eastern gate until dawn.

Ledger 52 line 044: Neri carried the blue token past marker aedd9ab6e1a7. Mara watched the eastern gate until dawn.

Ledger 52 line 045: Neri carried the blue token past marker 7689e7afea8b. Mara watched the eastern gate until dawn.

Ledger 52 line 046: Neri carried the blue token past marker 53a7849826ad. Mara watched the eastern gate until dawn.

Ledger 52 line 047: Neri carried the blue token past marker e4c821e52ae3. Mara watched the eastern gate until dawn.

Ledger 52 line 048: Neri carried the blue token past marker dfd30f26c14b. Mara watched the eastern gate until dawn.

Ledger 52 line 049: Neri carried the blue token past marker b08cf6581990. Mara watched the eastern gate until dawn.

Ledger 52 line 050: Neri carried the blue token past marker c2c16a879ff5. Mara watched the eastern gate until dawn.

Ledger 52 line 051: Neri carried the blue token past marker dd3609ef9503. Mara watched the eastern gate until dawn.

Ledger 52 line 052: Neri carried the blue token past marker 7e4f9137a76d. Mara watched the eastern gate until dawn.

Ledger 52 line 053: Neri carried the blue token past marker b6cbb5213c50. Mara watched the eastern gate until dawn.

Ledger 52 line 054: Neri carried the blue token past marker fb36a1b893c9. Mara watched the eastern gate until dawn.

Ledger 52 line 055: Neri carried the blue token past marker 8ec42866457a. Mara watched the eastern gate until dawn.

Ledger 52 line 056: Neri carried the blue token past marker 88a1265f0562. Mara watched the eastern gate until dawn.

Ledger 52 line 057: Neri carried the blue token past marker 0257ec3916f1. Mara watched the eastern gate until dawn.

Ledger 52 line 058: Neri carried the blue token past marker 16610150906a. Mara watched the eastern gate until dawn.

Ledger 52 line 059: Neri carried the blue token past marker 04eac402ca44. Mara watched the eastern gate until dawn.

Ledger 52 line 060: Neri carried the blue token past marker 8aa5680bd16f. Mara watched the eastern gate until dawn.

Ledger 52 line 061: Neri carried the blue token past marker fd273dafe6f2. Mara watched the eastern gate until dawn.

Ledger 52 line 062: Neri carried the blue token past marker 27bbc2ab69e0. Mara watched the eastern gate until dawn.

Ledger 52 line 063: Neri carried the blue token past marker 395262af21aa. Mara watched the eastern gate until dawn.

Ledger 52 line 064: Neri carried the blue token past marker 3a3ff556d241. Mara watched the eastern gate until dawn.

Ledger 52 line 065: Neri carried the blue token past marker 18d08fa65fdc. Mara watched the eastern gate until dawn.

Ledger 52 line 066: Neri carried the blue token past marker 86753b7b4eb7. Mara watched the eastern gate until dawn.

Ledger 52 line 067: Neri carried the blue token past marker 4c7207990fdf. Mara watched the eastern gate until dawn.

Ledger 52 line 068: Neri carried the blue token past marker 92f4b6fd6b05. Mara watched the eastern gate until dawn.

Ledger 52 line 069: Neri carried the blue token past marker c5bc86930b02. Mara watched the eastern gate until dawn.

Ledger 52 line 070: Neri carried the blue token past marker 65258b56cc28. Mara watched the eastern gate until dawn.

Ledger 52 line 071: Neri carried the blue token past marker f5b720afd770. Mara watched the eastern gate until dawn.

Ledger 52 line 072: Neri carried the blue token past marker 5853ce71c265. Mara watched the eastern gate until dawn.

Ledger 52 line 073: Neri carried the blue token past marker 79c6740954d2. Mara watched the eastern gate until dawn.

Ledger 52 line 074: Neri carried the blue token past marker d62bce6a6403. Mara watched the eastern gate until dawn.

Ledger 52 line 075: Neri carried the blue token past marker 13263f79fa05. Mara watched the eastern gate until dawn.

Ledger 52 line 076: Neri carried the blue token past marker c2cbdd5f6d62. Mara watched the eastern gate until dawn.

Ledger 52 line 077: Neri carried the blue token past marker d5993176a705. Mara watched the eastern gate until dawn.

Ledger 52 line 078: Neri carried the blue token past marker 3d57f165c6a8. Mara watched the eastern gate until dawn.

Ledger 52 line 079: Neri carried the blue token past marker 92a3f9254695. Mara watched the eastern gate until dawn.

Ledger 52 line 080: Neri carried the blue token past marker 823955bdbd81. Mara watched the eastern gate until dawn.

Ledger 52 line 081: Neri carried the blue token past marker 62f23d72f0d9. Mara watched the eastern gate until dawn.

Ledger 52 line 082: Neri carried the blue token past marker 8b0742aa1e7a. Mara watched the eastern gate until dawn.

Ledger 52 line 083: Neri carried the blue token past marker e1dfb453eaf9. Mara watched the eastern gate until dawn.

Ledger 52 line 084: Neri carried the blue token past marker 610466feaf24. Mara watched the eastern gate until dawn.

Ledger 52 line 085: Neri carried the blue token past marker 375eabbe2a44. Mara watched the eastern gate until dawn.

Ledger 52 line 086: Neri carried the blue token past marker e2c619f7f65d. Mara watched the eastern gate until dawn.

Ledger 52 line 087: Neri carried the blue token past marker 4c8a96505e95. Mara watched the eastern gate until dawn.

Ledger 52 line 088: Neri carried the blue token past marker b30e06e044c1. Mara watched the eastern gate until dawn.

Ledger 52 line 089: Neri carried the blue token past marker 39539b1cd011. Mara watched the eastern gate until dawn.

Ledger 52 line 090: Neri carried the blue token past marker 4e07ce14c5a3. Mara watched the eastern gate until dawn.

Ledger 52 line 091: Neri carried the blue token past marker 3981eeefc19b. Mara watched the eastern gate until dawn.

Ledger 52 line 092: Neri carried the blue token past marker 8efe9bbbd4a0. Mara watched the eastern gate until dawn.

Ledger 52 line 093: Neri carried the blue token past marker e079d65c5921. Mara watched the eastern gate until dawn.

Ledger 52 line 094: Neri carried the blue token past marker f824d1c02e69. Mara watched the eastern gate until dawn.

Ledger 52 line 095: Neri carried the blue token past marker 4e3c7af3200f. Mara watched the eastern gate until dawn.

Ledger 52 line 096: Neri carried the blue token past marker 6595fc06dce8. Mara watched the eastern gate until dawn.

Ledger 52 line 097: Neri carried the blue token past marker 64424fdb7511. Mara watched the eastern gate until dawn.

Ledger 52 line 098: Neri carried the blue token past marker 52977f37a08e. Mara watched the eastern gate until dawn.

Ledger 52 line 099: Neri carried the blue token past marker 55ce1e95b3da. Mara watched the eastern gate until dawn.

Ledger 52 line 100: Neri carried the blue token past marker 8a1c9669b23b. Mara watched the eastern gate until dawn.

Ledger 52 line 101: Neri carried the blue token past marker 824e96d3adb9. Mara watched the eastern gate until dawn.

Ledger 52 line 102: Neri carried the blue token past marker f6b6f64d693c. Mara watched the eastern gate until dawn.

Ledger 52 line 103: Neri carried the blue token past marker 24d58b923502. Mara watched the eastern gate until dawn.

Ledger 52 line 104: Neri carried the blue token past marker 01cd34bab37d. Mara watched the eastern gate until dawn.

Ledger 52 line 105: Neri carried the blue token past marker c00833d914fc. Mara watched the eastern gate until dawn.

Ledger 52 line 106: Neri carried the blue token past marker 5e6f577b7c8c. Mara watched the eastern gate until dawn.

Ledger 52 line 107: Neri carried the blue token past marker a2fe3fe229f9. Mara watched the eastern gate until dawn.

Ledger 52 line 108: Neri carried the blue token past marker 1f26ca2c42d5. Mara watched the eastern gate until dawn.

Ledger 52 line 109: Neri carried the blue token past marker d2c50a7ee60a. Mara watched the eastern gate until dawn.

Ledger 52 line 110: Neri carried the blue token past marker 3d865d9b89b1. Mara watched the eastern gate until dawn.

Ledger 52 line 111: Neri carried the blue token past marker 9c5cc00a46b0. Mara watched the eastern gate until dawn.

Ledger 52 line 112: Neri carried the blue token past marker 65bf63d69e1b. Mara watched the eastern gate until dawn.

Ledger 52 line 113: Neri carried the blue token past marker febb2269c76a. Mara watched the eastern gate until dawn.

Ledger 52 line 114: Neri carried the blue token past marker 0c04860fac23. Mara watched the eastern gate until dawn.

Ledger 52 line 115: Neri carried the blue token past marker 3ba647f71a8d. Mara watched the eastern gate until dawn.

Ledger 52 line 116: Neri carried the blue token past marker 931ce1c1aecb. Mara watched the eastern gate until dawn.

Ledger 52 line 117: Neri carried the blue token past marker a30a62b32861. Mara watched the eastern gate until dawn.

Ledger 52 line 118: Neri carried the blue token past marker eeb80b565220. Mara watched the eastern gate until dawn.

Ledger 52 line 119: Neri carried the blue token past marker 5a9f9e8051e1. Mara watched the eastern gate until dawn.

Ledger 52 line 120: Neri carried the blue token past marker 52d36114ad60. Mara watched the eastern gate until dawn.

Ledger 52 line 121: Neri carried the blue token past marker b5705313fcfb. Mara watched the eastern gate until dawn.

Ledger 52 line 122: Neri carried the blue token past marker f4c2e47d8210. Mara watched the eastern gate until dawn.

Ledger 52 line 123: Neri carried the blue token past marker 6625da7cd372. Mara watched the eastern gate until dawn.

Ledger 52 line 124: Neri carried the blue token past marker 0cf6a7aaeaca. Mara watched the eastern gate until dawn.

Ledger 52 line 125: Neri carried the blue token past marker d3cd99abd477. Mara watched the eastern gate until dawn.

Ledger 52 line 126: Neri carried the blue token past marker 4b4db1ee40c5. Mara watched the eastern gate until dawn.

Ledger 52 line 127: Neri carried the blue token past marker 65ca2d4532b9. Mara watched the eastern gate until dawn.

Ledger 52 line 128: Neri carried the blue token past marker 44353232f6b9. Mara watched the eastern gate until dawn.

Ledger 52 line 129: Neri carried the blue token past marker 5f4d891023ca. Mara watched the eastern gate until dawn.

Ledger 52 line 130: Neri carried the blue token past marker a2918dffb8cc. Mara watched the eastern gate until dawn.

Ledger 52 line 131: Neri carried the blue token past marker abbae288095e. Mara watched the eastern gate until dawn.

Ledger 52 line 132: Neri carried the blue token past marker 652f04289351. Mara watched the eastern gate until dawn.

Ledger 52 line 133: Neri carried the blue token past marker 468388427de3. Mara watched the eastern gate until dawn.

Ledger 52 line 134: Neri carried the blue token past marker b3d7e861d975. Mara watched the eastern gate until dawn.

Ledger 52 line 135: Neri carried the blue token past marker c963b0cbd461. Mara watched the eastern gate until dawn.

Ledger 52 line 136: Neri carried the blue token past marker ee7e3a49b1a7. Mara watched the eastern gate until dawn.

Ledger 52 line 137: Neri carried the blue token past marker 2cab312bbd90. Mara watched the eastern gate until dawn.

Ledger 52 line 138: Neri carried the blue token past marker b1dc324dada1. Mara watched the eastern gate until dawn.

Ledger 52 line 139: Neri carried the blue token past marker a04e6dfe08c0. Mara watched the eastern gate until dawn.

Ledger 52 line 140: Neri carried the blue token past marker d2c4bd49f7bd. Mara watched the eastern gate until dawn.
