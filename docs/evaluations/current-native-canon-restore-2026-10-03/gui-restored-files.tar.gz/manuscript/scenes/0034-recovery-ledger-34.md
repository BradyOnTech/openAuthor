---
id: scene-0034
title: Recovery ledger 34
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.170664+00:00
updated_at: 2026-10-03T12:14:52.170664+00:00
---

Ledger 34 line 001: Neri carried the blue token past marker 81e79233405d. Mara watched the eastern gate until dawn.

Ledger 34 line 002: Neri carried the blue token past marker 2bb676e3a9ad. Mara watched the eastern gate until dawn.

Ledger 34 line 003: Neri carried the blue token past marker cc732387774b. Mara watched the eastern gate until dawn.

Ledger 34 line 004: Neri carried the blue token past marker 9848147f22b9. Mara watched the eastern gate until dawn.

Ledger 34 line 005: Neri carried the blue token past marker 5c087aa66c58. Mara watched the eastern gate until dawn.

Ledger 34 line 006: Neri carried the blue token past marker ac0a926c484c. Mara watched the eastern gate until dawn.

Ledger 34 line 007: Neri carried the blue token past marker b154a6b7cd0c. Mara watched the eastern gate until dawn.

Ledger 34 line 008: Neri carried the blue token past marker e9c1dc9ad9bd. Mara watched the eastern gate until dawn.

Ledger 34 line 009: Neri carried the blue token past marker 0a990dab4f3e. Mara watched the eastern gate until dawn.

Ledger 34 line 010: Neri carried the blue token past marker ff94d0ace244. Mara watched the eastern gate until dawn.

Ledger 34 line 011: Neri carried the blue token past marker 841f1f23d81b. Mara watched the eastern gate until dawn.

Ledger 34 line 012: Neri carried the blue token past marker b46e96f6eb0d. Mara watched the eastern gate until dawn.

Ledger 34 line 013: Neri carried the blue token past marker 14404d5bfb79. Mara watched the eastern gate until dawn.

Ledger 34 line 014: Neri carried the blue token past marker 7c044cc71f86. Mara watched the eastern gate until dawn.

Ledger 34 line 015: Neri carried the blue token past marker 1869a31a4eb9. Mara watched the eastern gate until dawn.

Ledger 34 line 016: Neri carried the blue token past marker d28d53d40703. Mara watched the eastern gate until dawn.

Ledger 34 line 017: Neri carried the blue token past marker 810715ebc1bf. Mara watched the eastern gate until dawn.

Ledger 34 line 018: Neri carried the blue token past marker f04326809311. Mara watched the eastern gate until dawn.

Ledger 34 line 019: Neri carried the blue token past marker c5cd8ea87f0e. Mara watched the eastern gate until dawn.

Ledger 34 line 020: Neri carried the blue token past marker 5fc29b4f45d8. Mara watched the eastern gate until dawn.

Ledger 34 line 021: Neri carried the blue token past marker 2e7b099b0736. Mara watched the eastern gate until dawn.

Ledger 34 line 022: Neri carried the blue token past marker ab222075805d. Mara watched the eastern gate until dawn.

Ledger 34 line 023: Neri carried the blue token past marker 10ba018d08ee. Mara watched the eastern gate until dawn.

Ledger 34 line 024: Neri carried the blue token past marker e219852cc589. Mara watched the eastern gate until dawn.

Ledger 34 line 025: Neri carried the blue token past marker 323f96560fa8. Mara watched the eastern gate until dawn.

Ledger 34 line 026: Neri carried the blue token past marker 86e3c88c933d. Mara watched the eastern gate until dawn.

Ledger 34 line 027: Neri carried the blue token past marker 148ea3a3799b. Mara watched the eastern gate until dawn.

Ledger 34 line 028: Neri carried the blue token past marker 2628468e1e13. Mara watched the eastern gate until dawn.

Ledger 34 line 029: Neri carried the blue token past marker 3ff0362c81d4. Mara watched the eastern gate until dawn.

Ledger 34 line 030: Neri carried the blue token past marker dfb3966a2241. Mara watched the eastern gate until dawn.

Ledger 34 line 031: Neri carried the blue token past marker 52b8b7d4a816. Mara watched the eastern gate until dawn.

Ledger 34 line 032: Neri carried the blue token past marker ec24ae29f390. Mara watched the eastern gate until dawn.

Ledger 34 line 033: Neri carried the blue token past marker cdd193d649d2. Mara watched the eastern gate until dawn.

Ledger 34 line 034: Neri carried the blue token past marker 0d991575105c. Mara watched the eastern gate until dawn.

Ledger 34 line 035: Neri carried the blue token past marker 6188862f3d5e. Mara watched the eastern gate until dawn.

Ledger 34 line 036: Neri carried the blue token past marker 1ff378a36c9e. Mara watched the eastern gate until dawn.

Ledger 34 line 037: Neri carried the blue token past marker 93b414d194c5. Mara watched the eastern gate until dawn.

Ledger 34 line 038: Neri carried the blue token past marker f184c73a392a. Mara watched the eastern gate until dawn.

Ledger 34 line 039: Neri carried the blue token past marker 7d23ac970b1a. Mara watched the eastern gate until dawn.

Ledger 34 line 040: Neri carried the blue token past marker d71b8acaa97a. Mara watched the eastern gate until dawn.

Ledger 34 line 041: Neri carried the blue token past marker e9fff4cd89ed. Mara watched the eastern gate until dawn.

Ledger 34 line 042: Neri carried the blue token past marker 01f78b24579e. Mara watched the eastern gate until dawn.

Ledger 34 line 043: Neri carried the blue token past marker d927ccc98b8d. Mara watched the eastern gate until dawn.

Ledger 34 line 044: Neri carried the blue token past marker 48f0f6b4fda6. Mara watched the eastern gate until dawn.

Ledger 34 line 045: Neri carried the blue token past marker 766af2dd07ff. Mara watched the eastern gate until dawn.

Ledger 34 line 046: Neri carried the blue token past marker e4faafc0df8a. Mara watched the eastern gate until dawn.

Ledger 34 line 047: Neri carried the blue token past marker 8b04fc854746. Mara watched the eastern gate until dawn.

Ledger 34 line 048: Neri carried the blue token past marker e1fc7b5a0716. Mara watched the eastern gate until dawn.

Ledger 34 line 049: Neri carried the blue token past marker 3ddc1b1e4386. Mara watched the eastern gate until dawn.

Ledger 34 line 050: Neri carried the blue token past marker 5f1708f70b3c. Mara watched the eastern gate until dawn.

Ledger 34 line 051: Neri carried the blue token past marker 159d30d0ce04. Mara watched the eastern gate until dawn.

Ledger 34 line 052: Neri carried the blue token past marker a38fca9b40b6. Mara watched the eastern gate until dawn.

Ledger 34 line 053: Neri carried the blue token past marker 9a9457195090. Mara watched the eastern gate until dawn.

Ledger 34 line 054: Neri carried the blue token past marker 2bf5f3298a9e. Mara watched the eastern gate until dawn.

Ledger 34 line 055: Neri carried the blue token past marker d261f46a9cf8. Mara watched the eastern gate until dawn.

Ledger 34 line 056: Neri carried the blue token past marker f69df48ec052. Mara watched the eastern gate until dawn.

Ledger 34 line 057: Neri carried the blue token past marker 0ebfa5ac733c. Mara watched the eastern gate until dawn.

Ledger 34 line 058: Neri carried the blue token past marker 19bcdee88085. Mara watched the eastern gate until dawn.

Ledger 34 line 059: Neri carried the blue token past marker bbaca736263e. Mara watched the eastern gate until dawn.

Ledger 34 line 060: Neri carried the blue token past marker 22ed60a05990. Mara watched the eastern gate until dawn.

Ledger 34 line 061: Neri carried the blue token past marker 9fee74872c71. Mara watched the eastern gate until dawn.

Ledger 34 line 062: Neri carried the blue token past marker 48f8c321e735. Mara watched the eastern gate until dawn.

Ledger 34 line 063: Neri carried the blue token past marker 0ecd5fa52c1d. Mara watched the eastern gate until dawn.

Ledger 34 line 064: Neri carried the blue token past marker 68b75a05292b. Mara watched the eastern gate until dawn.

Ledger 34 line 065: Neri carried the blue token past marker eac41349ef78. Mara watched the eastern gate until dawn.

Ledger 34 line 066: Neri carried the blue token past marker d65cb5f51284. Mara watched the eastern gate until dawn.

Ledger 34 line 067: Neri carried the blue token past marker d77ee6f9d49e. Mara watched the eastern gate until dawn.

Ledger 34 line 068: Neri carried the blue token past marker eac6b2f9dfcb. Mara watched the eastern gate until dawn.

Ledger 34 line 069: Neri carried the blue token past marker a4560cc0f6f5. Mara watched the eastern gate until dawn.

Ledger 34 line 070: Neri carried the blue token past marker f6f2c1182111. Mara watched the eastern gate until dawn.

Ledger 34 line 071: Neri carried the blue token past marker dabce18cbd5e. Mara watched the eastern gate until dawn.

Ledger 34 line 072: Neri carried the blue token past marker 14c96a2502c4. Mara watched the eastern gate until dawn.

Ledger 34 line 073: Neri carried the blue token past marker d098c04cb62e. Mara watched the eastern gate until dawn.

Ledger 34 line 074: Neri carried the blue token past marker 1f62c64f80bb. Mara watched the eastern gate until dawn.

Ledger 34 line 075: Neri carried the blue token past marker b8daf339b5ea. Mara watched the eastern gate until dawn.

Ledger 34 line 076: Neri carried the blue token past marker 4cd7a4c7d8e0. Mara watched the eastern gate until dawn.

Ledger 34 line 077: Neri carried the blue token past marker 81144db4ee2d. Mara watched the eastern gate until dawn.

Ledger 34 line 078: Neri carried the blue token past marker 4af906572390. Mara watched the eastern gate until dawn.

Ledger 34 line 079: Neri carried the blue token past marker cfb66ea65398. Mara watched the eastern gate until dawn.

Ledger 34 line 080: Neri carried the blue token past marker 4b2bfdea91aa. Mara watched the eastern gate until dawn.

Ledger 34 line 081: Neri carried the blue token past marker 422e416bab9e. Mara watched the eastern gate until dawn.

Ledger 34 line 082: Neri carried the blue token past marker 70f9c53c6a40. Mara watched the eastern gate until dawn.

Ledger 34 line 083: Neri carried the blue token past marker 8a80f05677de. Mara watched the eastern gate until dawn.

Ledger 34 line 084: Neri carried the blue token past marker d118876614c7. Mara watched the eastern gate until dawn.

Ledger 34 line 085: Neri carried the blue token past marker 309f69535ab3. Mara watched the eastern gate until dawn.

Ledger 34 line 086: Neri carried the blue token past marker 65305ba0998b. Mara watched the eastern gate until dawn.

Ledger 34 line 087: Neri carried the blue token past marker e9fafb32e6ae. Mara watched the eastern gate until dawn.

Ledger 34 line 088: Neri carried the blue token past marker 28fef6fe50b3. Mara watched the eastern gate until dawn.

Ledger 34 line 089: Neri carried the blue token past marker 0a80569b785e. Mara watched the eastern gate until dawn.

Ledger 34 line 090: Neri carried the blue token past marker 6403a5148572. Mara watched the eastern gate until dawn.

Ledger 34 line 091: Neri carried the blue token past marker 25d293820787. Mara watched the eastern gate until dawn.

Ledger 34 line 092: Neri carried the blue token past marker 1502ee51edf5. Mara watched the eastern gate until dawn.

Ledger 34 line 093: Neri carried the blue token past marker 75be53064813. Mara watched the eastern gate until dawn.

Ledger 34 line 094: Neri carried the blue token past marker 9993a50032c7. Mara watched the eastern gate until dawn.

Ledger 34 line 095: Neri carried the blue token past marker b989c67c2deb. Mara watched the eastern gate until dawn.

Ledger 34 line 096: Neri carried the blue token past marker cdddd74a9cc6. Mara watched the eastern gate until dawn.

Ledger 34 line 097: Neri carried the blue token past marker 9ff73b538da0. Mara watched the eastern gate until dawn.

Ledger 34 line 098: Neri carried the blue token past marker f673a779f0d7. Mara watched the eastern gate until dawn.

Ledger 34 line 099: Neri carried the blue token past marker 441bd458b02f. Mara watched the eastern gate until dawn.

Ledger 34 line 100: Neri carried the blue token past marker 5ff6094c2ceb. Mara watched the eastern gate until dawn.

Ledger 34 line 101: Neri carried the blue token past marker 6446aa9e8d94. Mara watched the eastern gate until dawn.

Ledger 34 line 102: Neri carried the blue token past marker bda59159d13c. Mara watched the eastern gate until dawn.

Ledger 34 line 103: Neri carried the blue token past marker 168968ae6df9. Mara watched the eastern gate until dawn.

Ledger 34 line 104: Neri carried the blue token past marker 78214d21f241. Mara watched the eastern gate until dawn.

Ledger 34 line 105: Neri carried the blue token past marker 4237b303327d. Mara watched the eastern gate until dawn.

Ledger 34 line 106: Neri carried the blue token past marker 2a528d00f4d5. Mara watched the eastern gate until dawn.

Ledger 34 line 107: Neri carried the blue token past marker 8d727a146c5c. Mara watched the eastern gate until dawn.

Ledger 34 line 108: Neri carried the blue token past marker 396bb47f80b6. Mara watched the eastern gate until dawn.

Ledger 34 line 109: Neri carried the blue token past marker eafca0093267. Mara watched the eastern gate until dawn.

Ledger 34 line 110: Neri carried the blue token past marker 0aa11a17ab2a. Mara watched the eastern gate until dawn.

Ledger 34 line 111: Neri carried the blue token past marker 9ca80013c5fb. Mara watched the eastern gate until dawn.

Ledger 34 line 112: Neri carried the blue token past marker 197b590390a8. Mara watched the eastern gate until dawn.

Ledger 34 line 113: Neri carried the blue token past marker 2761484c840c. Mara watched the eastern gate until dawn.

Ledger 34 line 114: Neri carried the blue token past marker 12e6f0368590. Mara watched the eastern gate until dawn.

Ledger 34 line 115: Neri carried the blue token past marker 9740bb0ed2db. Mara watched the eastern gate until dawn.

Ledger 34 line 116: Neri carried the blue token past marker 94200c4b2395. Mara watched the eastern gate until dawn.

Ledger 34 line 117: Neri carried the blue token past marker 9af9bb2f1c75. Mara watched the eastern gate until dawn.

Ledger 34 line 118: Neri carried the blue token past marker 8e6e338e98f6. Mara watched the eastern gate until dawn.

Ledger 34 line 119: Neri carried the blue token past marker 74d562f93367. Mara watched the eastern gate until dawn.

Ledger 34 line 120: Neri carried the blue token past marker 84f74d34d342. Mara watched the eastern gate until dawn.

Ledger 34 line 121: Neri carried the blue token past marker 2d750c74f89e. Mara watched the eastern gate until dawn.

Ledger 34 line 122: Neri carried the blue token past marker c23169bb1182. Mara watched the eastern gate until dawn.

Ledger 34 line 123: Neri carried the blue token past marker f71a135ef974. Mara watched the eastern gate until dawn.

Ledger 34 line 124: Neri carried the blue token past marker 10322d34a011. Mara watched the eastern gate until dawn.

Ledger 34 line 125: Neri carried the blue token past marker 85a21a34c3eb. Mara watched the eastern gate until dawn.

Ledger 34 line 126: Neri carried the blue token past marker 6aa0ed86cca2. Mara watched the eastern gate until dawn.

Ledger 34 line 127: Neri carried the blue token past marker 514844bd83fc. Mara watched the eastern gate until dawn.

Ledger 34 line 128: Neri carried the blue token past marker 4f3f4da2ee4b. Mara watched the eastern gate until dawn.

Ledger 34 line 129: Neri carried the blue token past marker b4ac3b829431. Mara watched the eastern gate until dawn.

Ledger 34 line 130: Neri carried the blue token past marker 8ba477c52b46. Mara watched the eastern gate until dawn.

Ledger 34 line 131: Neri carried the blue token past marker a3acdea1d47a. Mara watched the eastern gate until dawn.

Ledger 34 line 132: Neri carried the blue token past marker 78ecc000bdf1. Mara watched the eastern gate until dawn.

Ledger 34 line 133: Neri carried the blue token past marker 690be057ebeb. Mara watched the eastern gate until dawn.

Ledger 34 line 134: Neri carried the blue token past marker 663fafbc8000. Mara watched the eastern gate until dawn.

Ledger 34 line 135: Neri carried the blue token past marker 0b392b2adb1f. Mara watched the eastern gate until dawn.

Ledger 34 line 136: Neri carried the blue token past marker 3dd7a3a80317. Mara watched the eastern gate until dawn.

Ledger 34 line 137: Neri carried the blue token past marker 62f14651fe6c. Mara watched the eastern gate until dawn.

Ledger 34 line 138: Neri carried the blue token past marker 35918e1e2957. Mara watched the eastern gate until dawn.

Ledger 34 line 139: Neri carried the blue token past marker 53a93bf64ac7. Mara watched the eastern gate until dawn.

Ledger 34 line 140: Neri carried the blue token past marker 91fecdb7a304. Mara watched the eastern gate until dawn.
