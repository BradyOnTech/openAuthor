---
id: scene-0063
title: Recovery ledger 63
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.186765+00:00
updated_at: 2026-10-03T12:14:52.186765+00:00
---

Ledger 63 line 001: Neri carried the blue token past marker c907dcf1e2ad. Mara watched the eastern gate until dawn.

Ledger 63 line 002: Neri carried the blue token past marker c743c3a9a08e. Mara watched the eastern gate until dawn.

Ledger 63 line 003: Neri carried the blue token past marker de399997b9e4. Mara watched the eastern gate until dawn.

Ledger 63 line 004: Neri carried the blue token past marker 395ddebbaa93. Mara watched the eastern gate until dawn.

Ledger 63 line 005: Neri carried the blue token past marker 5d558d46505f. Mara watched the eastern gate until dawn.

Ledger 63 line 006: Neri carried the blue token past marker 5db4fa7481cc. Mara watched the eastern gate until dawn.

Ledger 63 line 007: Neri carried the blue token past marker cbb44bb3008c. Mara watched the eastern gate until dawn.

Ledger 63 line 008: Neri carried the blue token past marker f6e0c6c7b327. Mara watched the eastern gate until dawn.

Ledger 63 line 009: Neri carried the blue token past marker 5712a32adb2e. Mara watched the eastern gate until dawn.

Ledger 63 line 010: Neri carried the blue token past marker 5f0bc1c4c662. Mara watched the eastern gate until dawn.

Ledger 63 line 011: Neri carried the blue token past marker 7ba97b56c247. Mara watched the eastern gate until dawn.

Ledger 63 line 012: Neri carried the blue token past marker a767173e9a0e. Mara watched the eastern gate until dawn.

Ledger 63 line 013: Neri carried the blue token past marker d1ac07e8725b. Mara watched the eastern gate until dawn.

Ledger 63 line 014: Neri carried the blue token past marker 0435ee6ef3ab. Mara watched the eastern gate until dawn.

Ledger 63 line 015: Neri carried the blue token past marker 7a0dcaed26dd. Mara watched the eastern gate until dawn.

Ledger 63 line 016: Neri carried the blue token past marker 2e3269564cbb. Mara watched the eastern gate until dawn.

Ledger 63 line 017: Neri carried the blue token past marker 3db9110c8e78. Mara watched the eastern gate until dawn.

Ledger 63 line 018: Neri carried the blue token past marker 962df13040af. Mara watched the eastern gate until dawn.

Ledger 63 line 019: Neri carried the blue token past marker 28d0aa5309d4. Mara watched the eastern gate until dawn.

Ledger 63 line 020: Neri carried the blue token past marker 4bc512b5b8bb. Mara watched the eastern gate until dawn.

Ledger 63 line 021: Neri carried the blue token past marker 34b4ffcd85ab. Mara watched the eastern gate until dawn.

Ledger 63 line 022: Neri carried the blue token past marker 2cbdcac7a6a9. Mara watched the eastern gate until dawn.

Ledger 63 line 023: Neri carried the blue token past marker 633171f8ed3b. Mara watched the eastern gate until dawn.

Ledger 63 line 024: Neri carried the blue token past marker 5a63f553ee5c. Mara watched the eastern gate until dawn.

Ledger 63 line 025: Neri carried the blue token past marker faf587a58543. Mara watched the eastern gate until dawn.

Ledger 63 line 026: Neri carried the blue token past marker 3d3159a56d7c. Mara watched the eastern gate until dawn.

Ledger 63 line 027: Neri carried the blue token past marker 13d115c86ebc. Mara watched the eastern gate until dawn.

Ledger 63 line 028: Neri carried the blue token past marker 1bb4975ecea0. Mara watched the eastern gate until dawn.

Ledger 63 line 029: Neri carried the blue token past marker aa4010fad678. Mara watched the eastern gate until dawn.

Ledger 63 line 030: Neri carried the blue token past marker d1ed19ff2ce6. Mara watched the eastern gate until dawn.

Ledger 63 line 031: Neri carried the blue token past marker 40e1696fdef4. Mara watched the eastern gate until dawn.

Ledger 63 line 032: Neri carried the blue token past marker 4f49541d6023. Mara watched the eastern gate until dawn.

Ledger 63 line 033: Neri carried the blue token past marker ddd726821c13. Mara watched the eastern gate until dawn.

Ledger 63 line 034: Neri carried the blue token past marker 693c609f78af. Mara watched the eastern gate until dawn.

Ledger 63 line 035: Neri carried the blue token past marker c9cc02dfeae5. Mara watched the eastern gate until dawn.

Ledger 63 line 036: Neri carried the blue token past marker 8fceb2882340. Mara watched the eastern gate until dawn.

Ledger 63 line 037: Neri carried the blue token past marker 4c7edef8716e. Mara watched the eastern gate until dawn.

Ledger 63 line 038: Neri carried the blue token past marker 4dbfc3b1f56d. Mara watched the eastern gate until dawn.

Ledger 63 line 039: Neri carried the blue token past marker 62bc3b8e54fb. Mara watched the eastern gate until dawn.

Ledger 63 line 040: Neri carried the blue token past marker 178572d455b8. Mara watched the eastern gate until dawn.

Ledger 63 line 041: Neri carried the blue token past marker c774d9fa59bc. Mara watched the eastern gate until dawn.

Ledger 63 line 042: Neri carried the blue token past marker da53f64363a6. Mara watched the eastern gate until dawn.

Ledger 63 line 043: Neri carried the blue token past marker fffaeec4f103. Mara watched the eastern gate until dawn.

Ledger 63 line 044: Neri carried the blue token past marker 2297431badf8. Mara watched the eastern gate until dawn.

Ledger 63 line 045: Neri carried the blue token past marker b9f6fcdb8b35. Mara watched the eastern gate until dawn.

Ledger 63 line 046: Neri carried the blue token past marker 3f577e778434. Mara watched the eastern gate until dawn.

Ledger 63 line 047: Neri carried the blue token past marker 676ec9e82e34. Mara watched the eastern gate until dawn.

Ledger 63 line 048: Neri carried the blue token past marker c7bbc7801bb2. Mara watched the eastern gate until dawn.

Ledger 63 line 049: Neri carried the blue token past marker b76a95a45659. Mara watched the eastern gate until dawn.

Ledger 63 line 050: Neri carried the blue token past marker 8e44d5adf142. Mara watched the eastern gate until dawn.

Ledger 63 line 051: Neri carried the blue token past marker 4c678dc86b03. Mara watched the eastern gate until dawn.

Ledger 63 line 052: Neri carried the blue token past marker da46d89f3393. Mara watched the eastern gate until dawn.

Ledger 63 line 053: Neri carried the blue token past marker 516810b6db25. Mara watched the eastern gate until dawn.

Ledger 63 line 054: Neri carried the blue token past marker 620f2a5f6c02. Mara watched the eastern gate until dawn.

Ledger 63 line 055: Neri carried the blue token past marker d012be80a0aa. Mara watched the eastern gate until dawn.

Ledger 63 line 056: Neri carried the blue token past marker f6a90d2d98c6. Mara watched the eastern gate until dawn.

Ledger 63 line 057: Neri carried the blue token past marker 00b0ef965807. Mara watched the eastern gate until dawn.

Ledger 63 line 058: Neri carried the blue token past marker 3522e8d624a2. Mara watched the eastern gate until dawn.

Ledger 63 line 059: Neri carried the blue token past marker fe3f3dd40f9f. Mara watched the eastern gate until dawn.

Ledger 63 line 060: Neri carried the blue token past marker b0c30bf43ca5. Mara watched the eastern gate until dawn.

Ledger 63 line 061: Neri carried the blue token past marker 33ac394480d3. Mara watched the eastern gate until dawn.

Ledger 63 line 062: Neri carried the blue token past marker b8edb4cc1e03. Mara watched the eastern gate until dawn.

Ledger 63 line 063: Neri carried the blue token past marker 40176d864c80. Mara watched the eastern gate until dawn.

Ledger 63 line 064: Neri carried the blue token past marker 4aa7ee7c24d1. Mara watched the eastern gate until dawn.

Ledger 63 line 065: Neri carried the blue token past marker 38dcd8d37775. Mara watched the eastern gate until dawn.

Ledger 63 line 066: Neri carried the blue token past marker 9ddb9140b626. Mara watched the eastern gate until dawn.

Ledger 63 line 067: Neri carried the blue token past marker 8f1f51220db7. Mara watched the eastern gate until dawn.

Ledger 63 line 068: Neri carried the blue token past marker ea0b35a8157c. Mara watched the eastern gate until dawn.

Ledger 63 line 069: Neri carried the blue token past marker 8b25d883edaf. Mara watched the eastern gate until dawn.

Ledger 63 line 070: Neri carried the blue token past marker 81f2694e1003. Mara watched the eastern gate until dawn.

Ledger 63 line 071: Neri carried the blue token past marker b4544c15d515. Mara watched the eastern gate until dawn.

Ledger 63 line 072: Neri carried the blue token past marker 7e1b14c371bf. Mara watched the eastern gate until dawn.

Ledger 63 line 073: Neri carried the blue token past marker 84c967aaa26a. Mara watched the eastern gate until dawn.

Ledger 63 line 074: Neri carried the blue token past marker 1342b32de068. Mara watched the eastern gate until dawn.

Ledger 63 line 075: Neri carried the blue token past marker 89b0f084a3b1. Mara watched the eastern gate until dawn.

Ledger 63 line 076: Neri carried the blue token past marker 99599776ece4. Mara watched the eastern gate until dawn.

Ledger 63 line 077: Neri carried the blue token past marker 26c624516ec9. Mara watched the eastern gate until dawn.

Ledger 63 line 078: Neri carried the blue token past marker dc3c543a3196. Mara watched the eastern gate until dawn.

Ledger 63 line 079: Neri carried the blue token past marker 28195baa94b3. Mara watched the eastern gate until dawn.

Ledger 63 line 080: Neri carried the blue token past marker 68eba7956629. Mara watched the eastern gate until dawn.

Ledger 63 line 081: Neri carried the blue token past marker 026260f9a0c0. Mara watched the eastern gate until dawn.

Ledger 63 line 082: Neri carried the blue token past marker c43b9f3d2b20. Mara watched the eastern gate until dawn.

Ledger 63 line 083: Neri carried the blue token past marker 889a1a8ecc48. Mara watched the eastern gate until dawn.

Ledger 63 line 084: Neri carried the blue token past marker 07e64ea9a2fc. Mara watched the eastern gate until dawn.

Ledger 63 line 085: Neri carried the blue token past marker 702c2db91e3e. Mara watched the eastern gate until dawn.

Ledger 63 line 086: Neri carried the blue token past marker 7ddc23d8d551. Mara watched the eastern gate until dawn.

Ledger 63 line 087: Neri carried the blue token past marker a6a852e76d06. Mara watched the eastern gate until dawn.

Ledger 63 line 088: Neri carried the blue token past marker 260108990320. Mara watched the eastern gate until dawn.

Ledger 63 line 089: Neri carried the blue token past marker 7c6e20da40d7. Mara watched the eastern gate until dawn.

Ledger 63 line 090: Neri carried the blue token past marker 116a9e34fb86. Mara watched the eastern gate until dawn.

Ledger 63 line 091: Neri carried the blue token past marker 3525aabdb809. Mara watched the eastern gate until dawn.

Ledger 63 line 092: Neri carried the blue token past marker 5fa5c33227c3. Mara watched the eastern gate until dawn.

Ledger 63 line 093: Neri carried the blue token past marker 2f322ca70573. Mara watched the eastern gate until dawn.

Ledger 63 line 094: Neri carried the blue token past marker a248cc2c0681. Mara watched the eastern gate until dawn.

Ledger 63 line 095: Neri carried the blue token past marker 8b1a4fa51642. Mara watched the eastern gate until dawn.

Ledger 63 line 096: Neri carried the blue token past marker 04796c92bae5. Mara watched the eastern gate until dawn.

Ledger 63 line 097: Neri carried the blue token past marker eac9edf1a2d2. Mara watched the eastern gate until dawn.

Ledger 63 line 098: Neri carried the blue token past marker ae48157339fc. Mara watched the eastern gate until dawn.

Ledger 63 line 099: Neri carried the blue token past marker ca47ae3f360d. Mara watched the eastern gate until dawn.

Ledger 63 line 100: Neri carried the blue token past marker d7a0196a1133. Mara watched the eastern gate until dawn.

Ledger 63 line 101: Neri carried the blue token past marker 1806c0562f1c. Mara watched the eastern gate until dawn.

Ledger 63 line 102: Neri carried the blue token past marker 534cb89c0960. Mara watched the eastern gate until dawn.

Ledger 63 line 103: Neri carried the blue token past marker a7734dc6e13e. Mara watched the eastern gate until dawn.

Ledger 63 line 104: Neri carried the blue token past marker 50ea5ccd0a47. Mara watched the eastern gate until dawn.

Ledger 63 line 105: Neri carried the blue token past marker b2aa7acff5c7. Mara watched the eastern gate until dawn.

Ledger 63 line 106: Neri carried the blue token past marker fe80c797d94c. Mara watched the eastern gate until dawn.

Ledger 63 line 107: Neri carried the blue token past marker e53b359b9f41. Mara watched the eastern gate until dawn.

Ledger 63 line 108: Neri carried the blue token past marker 618d717583a0. Mara watched the eastern gate until dawn.

Ledger 63 line 109: Neri carried the blue token past marker 7a9bf119c045. Mara watched the eastern gate until dawn.

Ledger 63 line 110: Neri carried the blue token past marker ec88e9bf5bd8. Mara watched the eastern gate until dawn.

Ledger 63 line 111: Neri carried the blue token past marker 6ceb89038be6. Mara watched the eastern gate until dawn.

Ledger 63 line 112: Neri carried the blue token past marker 58abcc99c87a. Mara watched the eastern gate until dawn.

Ledger 63 line 113: Neri carried the blue token past marker 652a723cb050. Mara watched the eastern gate until dawn.

Ledger 63 line 114: Neri carried the blue token past marker 5dd3ff0460c6. Mara watched the eastern gate until dawn.

Ledger 63 line 115: Neri carried the blue token past marker ec7eb504fe6d. Mara watched the eastern gate until dawn.

Ledger 63 line 116: Neri carried the blue token past marker 0f22af960b93. Mara watched the eastern gate until dawn.

Ledger 63 line 117: Neri carried the blue token past marker 876a227f09cb. Mara watched the eastern gate until dawn.

Ledger 63 line 118: Neri carried the blue token past marker 985fb8c02dbd. Mara watched the eastern gate until dawn.

Ledger 63 line 119: Neri carried the blue token past marker 0021169850e2. Mara watched the eastern gate until dawn.

Ledger 63 line 120: Neri carried the blue token past marker b894db00b361. Mara watched the eastern gate until dawn.

Ledger 63 line 121: Neri carried the blue token past marker e988c9c6f7f9. Mara watched the eastern gate until dawn.

Ledger 63 line 122: Neri carried the blue token past marker face3c9df057. Mara watched the eastern gate until dawn.

Ledger 63 line 123: Neri carried the blue token past marker 1255c4098158. Mara watched the eastern gate until dawn.

Ledger 63 line 124: Neri carried the blue token past marker 6c9aa51f6350. Mara watched the eastern gate until dawn.

Ledger 63 line 125: Neri carried the blue token past marker 13d5b5ec5103. Mara watched the eastern gate until dawn.

Ledger 63 line 126: Neri carried the blue token past marker 395fe66aef81. Mara watched the eastern gate until dawn.

Ledger 63 line 127: Neri carried the blue token past marker c456bf27b34d. Mara watched the eastern gate until dawn.

Ledger 63 line 128: Neri carried the blue token past marker 728b7fd943ec. Mara watched the eastern gate until dawn.

Ledger 63 line 129: Neri carried the blue token past marker 160fac5a4d6d. Mara watched the eastern gate until dawn.

Ledger 63 line 130: Neri carried the blue token past marker 1b9f2edae224. Mara watched the eastern gate until dawn.

Ledger 63 line 131: Neri carried the blue token past marker 5bc301f2076e. Mara watched the eastern gate until dawn.

Ledger 63 line 132: Neri carried the blue token past marker 5ea32f4ab431. Mara watched the eastern gate until dawn.

Ledger 63 line 133: Neri carried the blue token past marker c87c8b4bc293. Mara watched the eastern gate until dawn.

Ledger 63 line 134: Neri carried the blue token past marker 82e535e583e5. Mara watched the eastern gate until dawn.

Ledger 63 line 135: Neri carried the blue token past marker 6d8ef653a989. Mara watched the eastern gate until dawn.

Ledger 63 line 136: Neri carried the blue token past marker f5d4af0a6ae6. Mara watched the eastern gate until dawn.

Ledger 63 line 137: Neri carried the blue token past marker 2db06d2244a3. Mara watched the eastern gate until dawn.

Ledger 63 line 138: Neri carried the blue token past marker d73694f1ec76. Mara watched the eastern gate until dawn.

Ledger 63 line 139: Neri carried the blue token past marker ff13501e4f27. Mara watched the eastern gate until dawn.

Ledger 63 line 140: Neri carried the blue token past marker eb5356a23f53. Mara watched the eastern gate until dawn.
