---
id: scene-0008
title: Recovery ledger 08
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.157018+00:00
updated_at: 2026-10-03T12:14:52.157018+00:00
---

Ledger 08 line 001: Neri carried the blue token past marker d42a258c590b. Mara watched the eastern gate until dawn.

Ledger 08 line 002: Neri carried the blue token past marker f6c1014ce6d1. Mara watched the eastern gate until dawn.

Ledger 08 line 003: Neri carried the blue token past marker 5bdb15b49f6c. Mara watched the eastern gate until dawn.

Ledger 08 line 004: Neri carried the blue token past marker 05a2ac3d8111. Mara watched the eastern gate until dawn.

Ledger 08 line 005: Neri carried the blue token past marker 59890c6bca99. Mara watched the eastern gate until dawn.

Ledger 08 line 006: Neri carried the blue token past marker 0169ec7d87ba. Mara watched the eastern gate until dawn.

Ledger 08 line 007: Neri carried the blue token past marker 40b9e7a33d8f. Mara watched the eastern gate until dawn.

Ledger 08 line 008: Neri carried the blue token past marker e57831a7be36. Mara watched the eastern gate until dawn.

Ledger 08 line 009: Neri carried the blue token past marker 0ca19c5b4ffa. Mara watched the eastern gate until dawn.

Ledger 08 line 010: Neri carried the blue token past marker 5dbc6b15dd3c. Mara watched the eastern gate until dawn.

Ledger 08 line 011: Neri carried the blue token past marker adfbbf7e585e. Mara watched the eastern gate until dawn.

Ledger 08 line 012: Neri carried the blue token past marker 7a272c56afdc. Mara watched the eastern gate until dawn.

Ledger 08 line 013: Neri carried the blue token past marker d93d9e224c62. Mara watched the eastern gate until dawn.

Ledger 08 line 014: Neri carried the blue token past marker 53dfa88c25d4. Mara watched the eastern gate until dawn.

Ledger 08 line 015: Neri carried the blue token past marker 2c8d109e1c0d. Mara watched the eastern gate until dawn.

Ledger 08 line 016: Neri carried the blue token past marker 82c8be1d2e1f. Mara watched the eastern gate until dawn.

Ledger 08 line 017: Neri carried the blue token past marker dfc7e758d283. Mara watched the eastern gate until dawn.

Ledger 08 line 018: Neri carried the blue token past marker e1c61adce077. Mara watched the eastern gate until dawn.

Ledger 08 line 019: Neri carried the blue token past marker b4236e7fae4b. Mara watched the eastern gate until dawn.

Ledger 08 line 020: Neri carried the blue token past marker b3a5ed32da57. Mara watched the eastern gate until dawn.

Ledger 08 line 021: Neri carried the blue token past marker 5181ef31a0c0. Mara watched the eastern gate until dawn.

Ledger 08 line 022: Neri carried the blue token past marker 76a9d5fe8332. Mara watched the eastern gate until dawn.

Ledger 08 line 023: Neri carried the blue token past marker 0b5c00b2486e. Mara watched the eastern gate until dawn.

Ledger 08 line 024: Neri carried the blue token past marker 5a13b88d67ae. Mara watched the eastern gate until dawn.

Ledger 08 line 025: Neri carried the blue token past marker 14b5f1d67b3d. Mara watched the eastern gate until dawn.

Ledger 08 line 026: Neri carried the blue token past marker 978be0e9cb51. Mara watched the eastern gate until dawn.

Ledger 08 line 027: Neri carried the blue token past marker 78f3b00a6097. Mara watched the eastern gate until dawn.

Ledger 08 line 028: Neri carried the blue token past marker 63b9c710e514. Mara watched the eastern gate until dawn.

Ledger 08 line 029: Neri carried the blue token past marker 305ab9bb8d8e. Mara watched the eastern gate until dawn.

Ledger 08 line 030: Neri carried the blue token past marker e487dd9b3324. Mara watched the eastern gate until dawn.

Ledger 08 line 031: Neri carried the blue token past marker 5deb3267619c. Mara watched the eastern gate until dawn.

Ledger 08 line 032: Neri carried the blue token past marker d4b0e6b60b5e. Mara watched the eastern gate until dawn.

Ledger 08 line 033: Neri carried the blue token past marker 67049845dd70. Mara watched the eastern gate until dawn.

Ledger 08 line 034: Neri carried the blue token past marker 35445e778501. Mara watched the eastern gate until dawn.

Ledger 08 line 035: Neri carried the blue token past marker 80a61d3eda8d. Mara watched the eastern gate until dawn.

Ledger 08 line 036: Neri carried the blue token past marker 3b884f9c6606. Mara watched the eastern gate until dawn.

Ledger 08 line 037: Neri carried the blue token past marker 05ebc43f1a64. Mara watched the eastern gate until dawn.

Ledger 08 line 038: Neri carried the blue token past marker d6df9afe2eb0. Mara watched the eastern gate until dawn.

Ledger 08 line 039: Neri carried the blue token past marker 31185af6e944. Mara watched the eastern gate until dawn.

Ledger 08 line 040: Neri carried the blue token past marker b25439c7d84d. Mara watched the eastern gate until dawn.

Ledger 08 line 041: Neri carried the blue token past marker f1aa3b34e5b6. Mara watched the eastern gate until dawn.

Ledger 08 line 042: Neri carried the blue token past marker b5c68c9fb601. Mara watched the eastern gate until dawn.

Ledger 08 line 043: Neri carried the blue token past marker a74aead4d7c4. Mara watched the eastern gate until dawn.

Ledger 08 line 044: Neri carried the blue token past marker f366e6a99866. Mara watched the eastern gate until dawn.

Ledger 08 line 045: Neri carried the blue token past marker c5d22653f6f9. Mara watched the eastern gate until dawn.

Ledger 08 line 046: Neri carried the blue token past marker 82a9ea84f548. Mara watched the eastern gate until dawn.

Ledger 08 line 047: Neri carried the blue token past marker b212bac58123. Mara watched the eastern gate until dawn.

Ledger 08 line 048: Neri carried the blue token past marker f4aa827d378b. Mara watched the eastern gate until dawn.

Ledger 08 line 049: Neri carried the blue token past marker 63d8552d2664. Mara watched the eastern gate until dawn.

Ledger 08 line 050: Neri carried the blue token past marker 47ba744b2bf4. Mara watched the eastern gate until dawn.

Ledger 08 line 051: Neri carried the blue token past marker b809e4c4d3ba. Mara watched the eastern gate until dawn.

Ledger 08 line 052: Neri carried the blue token past marker e515d7ad4cc5. Mara watched the eastern gate until dawn.

Ledger 08 line 053: Neri carried the blue token past marker 0f8e2db21905. Mara watched the eastern gate until dawn.

Ledger 08 line 054: Neri carried the blue token past marker 794dfb5228cd. Mara watched the eastern gate until dawn.

Ledger 08 line 055: Neri carried the blue token past marker a3813f87593a. Mara watched the eastern gate until dawn.

Ledger 08 line 056: Neri carried the blue token past marker ca63b0c76b69. Mara watched the eastern gate until dawn.

Ledger 08 line 057: Neri carried the blue token past marker 073ecb57f0b9. Mara watched the eastern gate until dawn.

Ledger 08 line 058: Neri carried the blue token past marker 11fa18a1f5ea. Mara watched the eastern gate until dawn.

Ledger 08 line 059: Neri carried the blue token past marker 199a1d6de00e. Mara watched the eastern gate until dawn.

Ledger 08 line 060: Neri carried the blue token past marker 9fe1017e9e43. Mara watched the eastern gate until dawn.

Ledger 08 line 061: Neri carried the blue token past marker 612a8562d1be. Mara watched the eastern gate until dawn.

Ledger 08 line 062: Neri carried the blue token past marker 6b4a46953953. Mara watched the eastern gate until dawn.

Ledger 08 line 063: Neri carried the blue token past marker b302e2434b39. Mara watched the eastern gate until dawn.

Ledger 08 line 064: Neri carried the blue token past marker 0f1d1b40dfc8. Mara watched the eastern gate until dawn.

Ledger 08 line 065: Neri carried the blue token past marker 7ba0a45c1ab3. Mara watched the eastern gate until dawn.

Ledger 08 line 066: Neri carried the blue token past marker 9b544f158f05. Mara watched the eastern gate until dawn.

Ledger 08 line 067: Neri carried the blue token past marker 89cb647a63df. Mara watched the eastern gate until dawn.

Ledger 08 line 068: Neri carried the blue token past marker 0744bbf5639e. Mara watched the eastern gate until dawn.

Ledger 08 line 069: Neri carried the blue token past marker 1133a50214c6. Mara watched the eastern gate until dawn.

Ledger 08 line 070: Neri carried the blue token past marker 09540d28e6a7. Mara watched the eastern gate until dawn.

Ledger 08 line 071: Neri carried the blue token past marker a9a98afbee23. Mara watched the eastern gate until dawn.

Ledger 08 line 072: Neri carried the blue token past marker 6376c074f55d. Mara watched the eastern gate until dawn.

Ledger 08 line 073: Neri carried the blue token past marker 932285d8bf25. Mara watched the eastern gate until dawn.

Ledger 08 line 074: Neri carried the blue token past marker ce94c35e6d0b. Mara watched the eastern gate until dawn.

Ledger 08 line 075: Neri carried the blue token past marker 0d105fc07d66. Mara watched the eastern gate until dawn.

Ledger 08 line 076: Neri carried the blue token past marker 877445d61316. Mara watched the eastern gate until dawn.

Ledger 08 line 077: Neri carried the blue token past marker 51c1c3fff301. Mara watched the eastern gate until dawn.

Ledger 08 line 078: Neri carried the blue token past marker 1350cd8b074a. Mara watched the eastern gate until dawn.

Ledger 08 line 079: Neri carried the blue token past marker fe2a75320761. Mara watched the eastern gate until dawn.

Ledger 08 line 080: Neri carried the blue token past marker 8ee0a29caf05. Mara watched the eastern gate until dawn.

Ledger 08 line 081: Neri carried the blue token past marker 3a14ecd70b95. Mara watched the eastern gate until dawn.

Ledger 08 line 082: Neri carried the blue token past marker b520cd8eff9f. Mara watched the eastern gate until dawn.

Ledger 08 line 083: Neri carried the blue token past marker a07dde33cec7. Mara watched the eastern gate until dawn.

Ledger 08 line 084: Neri carried the blue token past marker 88034f44448a. Mara watched the eastern gate until dawn.

Ledger 08 line 085: Neri carried the blue token past marker 8bc76f9dc830. Mara watched the eastern gate until dawn.

Ledger 08 line 086: Neri carried the blue token past marker 88ae33846efc. Mara watched the eastern gate until dawn.

Ledger 08 line 087: Neri carried the blue token past marker 9ea91c6e490a. Mara watched the eastern gate until dawn.

Ledger 08 line 088: Neri carried the blue token past marker 1fdbf8791f31. Mara watched the eastern gate until dawn.

Ledger 08 line 089: Neri carried the blue token past marker ad27a69e5d85. Mara watched the eastern gate until dawn.

Ledger 08 line 090: Neri carried the blue token past marker d9671fc83a95. Mara watched the eastern gate until dawn.

Ledger 08 line 091: Neri carried the blue token past marker 5dbd35c643ab. Mara watched the eastern gate until dawn.

Ledger 08 line 092: Neri carried the blue token past marker 273f27a380de. Mara watched the eastern gate until dawn.

Ledger 08 line 093: Neri carried the blue token past marker fe318fa05b89. Mara watched the eastern gate until dawn.

Ledger 08 line 094: Neri carried the blue token past marker 5836103c4c79. Mara watched the eastern gate until dawn.

Ledger 08 line 095: Neri carried the blue token past marker e40921f2f294. Mara watched the eastern gate until dawn.

Ledger 08 line 096: Neri carried the blue token past marker c3093f16a98a. Mara watched the eastern gate until dawn.

Ledger 08 line 097: Neri carried the blue token past marker 1d4e759f85fc. Mara watched the eastern gate until dawn.

Ledger 08 line 098: Neri carried the blue token past marker 21b9a6d5dca3. Mara watched the eastern gate until dawn.

Ledger 08 line 099: Neri carried the blue token past marker 3d9c5b1628a0. Mara watched the eastern gate until dawn.

Ledger 08 line 100: Neri carried the blue token past marker c2b4e559d45c. Mara watched the eastern gate until dawn.

Ledger 08 line 101: Neri carried the blue token past marker 9bff59f2867d. Mara watched the eastern gate until dawn.

Ledger 08 line 102: Neri carried the blue token past marker 368f0b2126a7. Mara watched the eastern gate until dawn.

Ledger 08 line 103: Neri carried the blue token past marker 72a46704d310. Mara watched the eastern gate until dawn.

Ledger 08 line 104: Neri carried the blue token past marker a6ae095979bd. Mara watched the eastern gate until dawn.

Ledger 08 line 105: Neri carried the blue token past marker 9141ddb66539. Mara watched the eastern gate until dawn.

Ledger 08 line 106: Neri carried the blue token past marker c5f557301e53. Mara watched the eastern gate until dawn.

Ledger 08 line 107: Neri carried the blue token past marker 9c4d27d48f17. Mara watched the eastern gate until dawn.

Ledger 08 line 108: Neri carried the blue token past marker 2d69314561de. Mara watched the eastern gate until dawn.

Ledger 08 line 109: Neri carried the blue token past marker 60525b25009d. Mara watched the eastern gate until dawn.

Ledger 08 line 110: Neri carried the blue token past marker 882b0aa47743. Mara watched the eastern gate until dawn.

Ledger 08 line 111: Neri carried the blue token past marker 8c4e7118c179. Mara watched the eastern gate until dawn.

Ledger 08 line 112: Neri carried the blue token past marker 4cd897436f4d. Mara watched the eastern gate until dawn.

Ledger 08 line 113: Neri carried the blue token past marker 0458dbc98e04. Mara watched the eastern gate until dawn.

Ledger 08 line 114: Neri carried the blue token past marker 5dca61c05cd0. Mara watched the eastern gate until dawn.

Ledger 08 line 115: Neri carried the blue token past marker fd05176596fc. Mara watched the eastern gate until dawn.

Ledger 08 line 116: Neri carried the blue token past marker c0db98fc120e. Mara watched the eastern gate until dawn.

Ledger 08 line 117: Neri carried the blue token past marker 70287a402c42. Mara watched the eastern gate until dawn.

Ledger 08 line 118: Neri carried the blue token past marker 6d520a68cbfb. Mara watched the eastern gate until dawn.

Ledger 08 line 119: Neri carried the blue token past marker acc2e94240b4. Mara watched the eastern gate until dawn.

Ledger 08 line 120: Neri carried the blue token past marker 34143a005058. Mara watched the eastern gate until dawn.

Ledger 08 line 121: Neri carried the blue token past marker bf48831d5e11. Mara watched the eastern gate until dawn.

Ledger 08 line 122: Neri carried the blue token past marker fefb7cfe5ab6. Mara watched the eastern gate until dawn.

Ledger 08 line 123: Neri carried the blue token past marker 582ac878e319. Mara watched the eastern gate until dawn.

Ledger 08 line 124: Neri carried the blue token past marker afa8e3819cff. Mara watched the eastern gate until dawn.

Ledger 08 line 125: Neri carried the blue token past marker 8e3048fb5402. Mara watched the eastern gate until dawn.

Ledger 08 line 126: Neri carried the blue token past marker 31ef255f0618. Mara watched the eastern gate until dawn.

Ledger 08 line 127: Neri carried the blue token past marker e5bcc0d44a0a. Mara watched the eastern gate until dawn.

Ledger 08 line 128: Neri carried the blue token past marker 9c0285641570. Mara watched the eastern gate until dawn.

Ledger 08 line 129: Neri carried the blue token past marker 39bd4f5ca4b9. Mara watched the eastern gate until dawn.

Ledger 08 line 130: Neri carried the blue token past marker bd2167e01791. Mara watched the eastern gate until dawn.

Ledger 08 line 131: Neri carried the blue token past marker b7190dd6b4eb. Mara watched the eastern gate until dawn.

Ledger 08 line 132: Neri carried the blue token past marker a565e87faf2c. Mara watched the eastern gate until dawn.

Ledger 08 line 133: Neri carried the blue token past marker 8bf871310b69. Mara watched the eastern gate until dawn.

Ledger 08 line 134: Neri carried the blue token past marker b75651bb48f8. Mara watched the eastern gate until dawn.

Ledger 08 line 135: Neri carried the blue token past marker f6c6272c90e6. Mara watched the eastern gate until dawn.

Ledger 08 line 136: Neri carried the blue token past marker 8a073394b0ad. Mara watched the eastern gate until dawn.

Ledger 08 line 137: Neri carried the blue token past marker 61a1cdfdd4fa. Mara watched the eastern gate until dawn.

Ledger 08 line 138: Neri carried the blue token past marker a5a4bd302de7. Mara watched the eastern gate until dawn.

Ledger 08 line 139: Neri carried the blue token past marker 5ecc6f38b9f2. Mara watched the eastern gate until dawn.

Ledger 08 line 140: Neri carried the blue token past marker 86620e0eb29c. Mara watched the eastern gate until dawn.
