---
id: scene-0030
title: Recovery ledger 30
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.168403+00:00
updated_at: 2026-10-03T12:14:52.168403+00:00
---

Ledger 30 line 001: Neri carried the blue token past marker 09af3e67a996. Mara watched the eastern gate until dawn.

Ledger 30 line 002: Neri carried the blue token past marker 79d4b83be44f. Mara watched the eastern gate until dawn.

Ledger 30 line 003: Neri carried the blue token past marker 00183ce31024. Mara watched the eastern gate until dawn.

Ledger 30 line 004: Neri carried the blue token past marker 61de1074274e. Mara watched the eastern gate until dawn.

Ledger 30 line 005: Neri carried the blue token past marker 35c95c2ecc6e. Mara watched the eastern gate until dawn.

Ledger 30 line 006: Neri carried the blue token past marker 1e0a75791b4c. Mara watched the eastern gate until dawn.

Ledger 30 line 007: Neri carried the blue token past marker a2135083e9b3. Mara watched the eastern gate until dawn.

Ledger 30 line 008: Neri carried the blue token past marker 084830e91a90. Mara watched the eastern gate until dawn.

Ledger 30 line 009: Neri carried the blue token past marker 4c274f9bdd79. Mara watched the eastern gate until dawn.

Ledger 30 line 010: Neri carried the blue token past marker 961ecfdba011. Mara watched the eastern gate until dawn.

Ledger 30 line 011: Neri carried the blue token past marker 1f23c9e1d472. Mara watched the eastern gate until dawn.

Ledger 30 line 012: Neri carried the blue token past marker 979126ce5449. Mara watched the eastern gate until dawn.

Ledger 30 line 013: Neri carried the blue token past marker fa7090614608. Mara watched the eastern gate until dawn.

Ledger 30 line 014: Neri carried the blue token past marker 7d9f29ec7506. Mara watched the eastern gate until dawn.

Ledger 30 line 015: Neri carried the blue token past marker d85cdaeb1e3a. Mara watched the eastern gate until dawn.

Ledger 30 line 016: Neri carried the blue token past marker 3b0b87b1e55e. Mara watched the eastern gate until dawn.

Ledger 30 line 017: Neri carried the blue token past marker 636f9e39f7b6. Mara watched the eastern gate until dawn.

Ledger 30 line 018: Neri carried the blue token past marker 81ff215a87fa. Mara watched the eastern gate until dawn.

Ledger 30 line 019: Neri carried the blue token past marker 5cd91b46c79a. Mara watched the eastern gate until dawn.

Ledger 30 line 020: Neri carried the blue token past marker 19455beae6dc. Mara watched the eastern gate until dawn.

Ledger 30 line 021: Neri carried the blue token past marker 2aa2d2536af7. Mara watched the eastern gate until dawn.

Ledger 30 line 022: Neri carried the blue token past marker 5c7d3302a532. Mara watched the eastern gate until dawn.

Ledger 30 line 023: Neri carried the blue token past marker b1d07f8f00e4. Mara watched the eastern gate until dawn.

Ledger 30 line 024: Neri carried the blue token past marker 0072e125ba03. Mara watched the eastern gate until dawn.

Ledger 30 line 025: Neri carried the blue token past marker 04db609bd7b1. Mara watched the eastern gate until dawn.

Ledger 30 line 026: Neri carried the blue token past marker 0da11b2f3fb2. Mara watched the eastern gate until dawn.

Ledger 30 line 027: Neri carried the blue token past marker 28fd5c963306. Mara watched the eastern gate until dawn.

Ledger 30 line 028: Neri carried the blue token past marker 059a15001324. Mara watched the eastern gate until dawn.

Ledger 30 line 029: Neri carried the blue token past marker 58394f15a120. Mara watched the eastern gate until dawn.

Ledger 30 line 030: Neri carried the blue token past marker b7ca6d6b3f23. Mara watched the eastern gate until dawn.

Ledger 30 line 031: Neri carried the blue token past marker 363b62b92fc2. Mara watched the eastern gate until dawn.

Ledger 30 line 032: Neri carried the blue token past marker fda3e6f7d479. Mara watched the eastern gate until dawn.

Ledger 30 line 033: Neri carried the blue token past marker a4aa53825fed. Mara watched the eastern gate until dawn.

Ledger 30 line 034: Neri carried the blue token past marker 5d5494c61b03. Mara watched the eastern gate until dawn.

Ledger 30 line 035: Neri carried the blue token past marker 7df1586e50bc. Mara watched the eastern gate until dawn.

Ledger 30 line 036: Neri carried the blue token past marker ef5db989fd21. Mara watched the eastern gate until dawn.

Ledger 30 line 037: Neri carried the blue token past marker d67b00bc537a. Mara watched the eastern gate until dawn.

Ledger 30 line 038: Neri carried the blue token past marker 48edae66cbee. Mara watched the eastern gate until dawn.

Ledger 30 line 039: Neri carried the blue token past marker 47d3a1157e52. Mara watched the eastern gate until dawn.

Ledger 30 line 040: Neri carried the blue token past marker 99454f96254a. Mara watched the eastern gate until dawn.

Ledger 30 line 041: Neri carried the blue token past marker fb4906980695. Mara watched the eastern gate until dawn.

Ledger 30 line 042: Neri carried the blue token past marker a643c935a6fb. Mara watched the eastern gate until dawn.

Ledger 30 line 043: Neri carried the blue token past marker d5700a1a5ad3. Mara watched the eastern gate until dawn.

Ledger 30 line 044: Neri carried the blue token past marker 68594e4b5d4d. Mara watched the eastern gate until dawn.

Ledger 30 line 045: Neri carried the blue token past marker 808a6df7e23b. Mara watched the eastern gate until dawn.

Ledger 30 line 046: Neri carried the blue token past marker 8986b37b24c5. Mara watched the eastern gate until dawn.

Ledger 30 line 047: Neri carried the blue token past marker ee87ad32e56f. Mara watched the eastern gate until dawn.

Ledger 30 line 048: Neri carried the blue token past marker a226538761ee. Mara watched the eastern gate until dawn.

Ledger 30 line 049: Neri carried the blue token past marker 5e30435a4fb9. Mara watched the eastern gate until dawn.

Ledger 30 line 050: Neri carried the blue token past marker e36268974ac5. Mara watched the eastern gate until dawn.

Ledger 30 line 051: Neri carried the blue token past marker c22e4f0b5e68. Mara watched the eastern gate until dawn.

Ledger 30 line 052: Neri carried the blue token past marker 252910ac3463. Mara watched the eastern gate until dawn.

Ledger 30 line 053: Neri carried the blue token past marker d3d8e7ccc6c1. Mara watched the eastern gate until dawn.

Ledger 30 line 054: Neri carried the blue token past marker 081bb885adb9. Mara watched the eastern gate until dawn.

Ledger 30 line 055: Neri carried the blue token past marker 0650aa107187. Mara watched the eastern gate until dawn.

Ledger 30 line 056: Neri carried the blue token past marker 9fa1c4092358. Mara watched the eastern gate until dawn.

Ledger 30 line 057: Neri carried the blue token past marker f9a153b63849. Mara watched the eastern gate until dawn.

Ledger 30 line 058: Neri carried the blue token past marker 750b3ee19751. Mara watched the eastern gate until dawn.

Ledger 30 line 059: Neri carried the blue token past marker 481763701daf. Mara watched the eastern gate until dawn.

Ledger 30 line 060: Neri carried the blue token past marker 98b5a9b40b75. Mara watched the eastern gate until dawn.

Ledger 30 line 061: Neri carried the blue token past marker 3a7607ef7ae9. Mara watched the eastern gate until dawn.

Ledger 30 line 062: Neri carried the blue token past marker aed4ab8993e5. Mara watched the eastern gate until dawn.

Ledger 30 line 063: Neri carried the blue token past marker e705a17d690d. Mara watched the eastern gate until dawn.

Ledger 30 line 064: Neri carried the blue token past marker f2c2c463f751. Mara watched the eastern gate until dawn.

Ledger 30 line 065: Neri carried the blue token past marker b42321268376. Mara watched the eastern gate until dawn.

Ledger 30 line 066: Neri carried the blue token past marker 542e064d92dc. Mara watched the eastern gate until dawn.

Ledger 30 line 067: Neri carried the blue token past marker 777648aa62cf. Mara watched the eastern gate until dawn.

Ledger 30 line 068: Neri carried the blue token past marker 28f1aaf21f45. Mara watched the eastern gate until dawn.

Ledger 30 line 069: Neri carried the blue token past marker 929a9dcdcb77. Mara watched the eastern gate until dawn.

Ledger 30 line 070: Neri carried the blue token past marker 120bf4fec2f3. Mara watched the eastern gate until dawn.

Ledger 30 line 071: Neri carried the blue token past marker 81f8ebccb5c1. Mara watched the eastern gate until dawn.

Ledger 30 line 072: Neri carried the blue token past marker e0dd42289a90. Mara watched the eastern gate until dawn.

Ledger 30 line 073: Neri carried the blue token past marker b99e78d9d3cd. Mara watched the eastern gate until dawn.

Ledger 30 line 074: Neri carried the blue token past marker ab78ae2c013e. Mara watched the eastern gate until dawn.

Ledger 30 line 075: Neri carried the blue token past marker 15baf8da2f10. Mara watched the eastern gate until dawn.

Ledger 30 line 076: Neri carried the blue token past marker 682e09bb0fe9. Mara watched the eastern gate until dawn.

Ledger 30 line 077: Neri carried the blue token past marker 217e8cd328cd. Mara watched the eastern gate until dawn.

Ledger 30 line 078: Neri carried the blue token past marker dbf22c6fc3a4. Mara watched the eastern gate until dawn.

Ledger 30 line 079: Neri carried the blue token past marker d742999d55a7. Mara watched the eastern gate until dawn.

Ledger 30 line 080: Neri carried the blue token past marker b9654bd5d421. Mara watched the eastern gate until dawn.

Ledger 30 line 081: Neri carried the blue token past marker 3324e87a5e15. Mara watched the eastern gate until dawn.

Ledger 30 line 082: Neri carried the blue token past marker 044250fb3700. Mara watched the eastern gate until dawn.

Ledger 30 line 083: Neri carried the blue token past marker c1f1fcbe194a. Mara watched the eastern gate until dawn.

Ledger 30 line 084: Neri carried the blue token past marker 9b75b4da1cd5. Mara watched the eastern gate until dawn.

Ledger 30 line 085: Neri carried the blue token past marker 6468b8307d5e. Mara watched the eastern gate until dawn.

Ledger 30 line 086: Neri carried the blue token past marker 01f3e6b81cac. Mara watched the eastern gate until dawn.

Ledger 30 line 087: Neri carried the blue token past marker 431f415b3c22. Mara watched the eastern gate until dawn.

Ledger 30 line 088: Neri carried the blue token past marker 2aae86bc8c55. Mara watched the eastern gate until dawn.

Ledger 30 line 089: Neri carried the blue token past marker 4cfc650f0ea7. Mara watched the eastern gate until dawn.

Ledger 30 line 090: Neri carried the blue token past marker cedb569a8629. Mara watched the eastern gate until dawn.

Ledger 30 line 091: Neri carried the blue token past marker a85ba27bd8d5. Mara watched the eastern gate until dawn.

Ledger 30 line 092: Neri carried the blue token past marker 7aa45f807d7a. Mara watched the eastern gate until dawn.

Ledger 30 line 093: Neri carried the blue token past marker 3f5c243ac5f6. Mara watched the eastern gate until dawn.

Ledger 30 line 094: Neri carried the blue token past marker 673419859982. Mara watched the eastern gate until dawn.

Ledger 30 line 095: Neri carried the blue token past marker 101decf9315f. Mara watched the eastern gate until dawn.

Ledger 30 line 096: Neri carried the blue token past marker fd8e13b0ac5e. Mara watched the eastern gate until dawn.

Ledger 30 line 097: Neri carried the blue token past marker 1015fd06c1e4. Mara watched the eastern gate until dawn.

Ledger 30 line 098: Neri carried the blue token past marker e4c832428911. Mara watched the eastern gate until dawn.

Ledger 30 line 099: Neri carried the blue token past marker e2c584deac16. Mara watched the eastern gate until dawn.

Ledger 30 line 100: Neri carried the blue token past marker d1e2bf7f5306. Mara watched the eastern gate until dawn.

Ledger 30 line 101: Neri carried the blue token past marker 3be73bb2b4ac. Mara watched the eastern gate until dawn.

Ledger 30 line 102: Neri carried the blue token past marker ef4627e6d9f8. Mara watched the eastern gate until dawn.

Ledger 30 line 103: Neri carried the blue token past marker ab688451076c. Mara watched the eastern gate until dawn.

Ledger 30 line 104: Neri carried the blue token past marker 8080bb6304b9. Mara watched the eastern gate until dawn.

Ledger 30 line 105: Neri carried the blue token past marker 73d00d10b7f9. Mara watched the eastern gate until dawn.

Ledger 30 line 106: Neri carried the blue token past marker 332a8d575ae8. Mara watched the eastern gate until dawn.

Ledger 30 line 107: Neri carried the blue token past marker 381857f30139. Mara watched the eastern gate until dawn.

Ledger 30 line 108: Neri carried the blue token past marker c9d280e6af72. Mara watched the eastern gate until dawn.

Ledger 30 line 109: Neri carried the blue token past marker 9f99bb7a717b. Mara watched the eastern gate until dawn.

Ledger 30 line 110: Neri carried the blue token past marker 5d8cc268c9d9. Mara watched the eastern gate until dawn.

Ledger 30 line 111: Neri carried the blue token past marker 3feddc831cac. Mara watched the eastern gate until dawn.

Ledger 30 line 112: Neri carried the blue token past marker 8d569df7d7a5. Mara watched the eastern gate until dawn.

Ledger 30 line 113: Neri carried the blue token past marker a2864b017f41. Mara watched the eastern gate until dawn.

Ledger 30 line 114: Neri carried the blue token past marker a23348a657ab. Mara watched the eastern gate until dawn.

Ledger 30 line 115: Neri carried the blue token past marker e32fce4e8e39. Mara watched the eastern gate until dawn.

Ledger 30 line 116: Neri carried the blue token past marker 91783b388fae. Mara watched the eastern gate until dawn.

Ledger 30 line 117: Neri carried the blue token past marker 8e58e1f642f1. Mara watched the eastern gate until dawn.

Ledger 30 line 118: Neri carried the blue token past marker 0435074e5649. Mara watched the eastern gate until dawn.

Ledger 30 line 119: Neri carried the blue token past marker 79b931a5f18f. Mara watched the eastern gate until dawn.

Ledger 30 line 120: Neri carried the blue token past marker 8b84ddddaa76. Mara watched the eastern gate until dawn.

Ledger 30 line 121: Neri carried the blue token past marker fafe5d96130b. Mara watched the eastern gate until dawn.

Ledger 30 line 122: Neri carried the blue token past marker 88a9e20fcf12. Mara watched the eastern gate until dawn.

Ledger 30 line 123: Neri carried the blue token past marker b98916f0b84e. Mara watched the eastern gate until dawn.

Ledger 30 line 124: Neri carried the blue token past marker 23dfaa320054. Mara watched the eastern gate until dawn.

Ledger 30 line 125: Neri carried the blue token past marker ec9cf6ed0aae. Mara watched the eastern gate until dawn.

Ledger 30 line 126: Neri carried the blue token past marker 8e83da826a68. Mara watched the eastern gate until dawn.

Ledger 30 line 127: Neri carried the blue token past marker 20c2cc86977c. Mara watched the eastern gate until dawn.

Ledger 30 line 128: Neri carried the blue token past marker 39f1e1e5fddb. Mara watched the eastern gate until dawn.

Ledger 30 line 129: Neri carried the blue token past marker 04bede9cae60. Mara watched the eastern gate until dawn.

Ledger 30 line 130: Neri carried the blue token past marker b7fd7e40359d. Mara watched the eastern gate until dawn.

Ledger 30 line 131: Neri carried the blue token past marker b3d32a54f4f7. Mara watched the eastern gate until dawn.

Ledger 30 line 132: Neri carried the blue token past marker 6b95cacd1495. Mara watched the eastern gate until dawn.

Ledger 30 line 133: Neri carried the blue token past marker 9e002eaabea0. Mara watched the eastern gate until dawn.

Ledger 30 line 134: Neri carried the blue token past marker 7942f255583b. Mara watched the eastern gate until dawn.

Ledger 30 line 135: Neri carried the blue token past marker 385249d6cb74. Mara watched the eastern gate until dawn.

Ledger 30 line 136: Neri carried the blue token past marker a1bebcf7e091. Mara watched the eastern gate until dawn.

Ledger 30 line 137: Neri carried the blue token past marker 80dd32379504. Mara watched the eastern gate until dawn.

Ledger 30 line 138: Neri carried the blue token past marker 9e51c108216b. Mara watched the eastern gate until dawn.

Ledger 30 line 139: Neri carried the blue token past marker 99ec3a341756. Mara watched the eastern gate until dawn.

Ledger 30 line 140: Neri carried the blue token past marker e850a31e7536. Mara watched the eastern gate until dawn.
