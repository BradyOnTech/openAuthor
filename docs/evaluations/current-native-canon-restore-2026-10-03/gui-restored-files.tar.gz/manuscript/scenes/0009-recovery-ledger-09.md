---
id: scene-0009
title: Recovery ledger 09
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.157484+00:00
updated_at: 2026-10-03T12:14:52.157484+00:00
---

Ledger 09 line 001: Neri carried the blue token past marker 465db89f7203. Mara watched the eastern gate until dawn.

Ledger 09 line 002: Neri carried the blue token past marker 8eb625d3c059. Mara watched the eastern gate until dawn.

Ledger 09 line 003: Neri carried the blue token past marker d108ac7694c4. Mara watched the eastern gate until dawn.

Ledger 09 line 004: Neri carried the blue token past marker aceea6527219. Mara watched the eastern gate until dawn.

Ledger 09 line 005: Neri carried the blue token past marker 7af8536c5a4c. Mara watched the eastern gate until dawn.

Ledger 09 line 006: Neri carried the blue token past marker f3981b386ec2. Mara watched the eastern gate until dawn.

Ledger 09 line 007: Neri carried the blue token past marker 7ed0a593a2d9. Mara watched the eastern gate until dawn.

Ledger 09 line 008: Neri carried the blue token past marker 94bde72ac7ab. Mara watched the eastern gate until dawn.

Ledger 09 line 009: Neri carried the blue token past marker 7ec3d7b0d7f2. Mara watched the eastern gate until dawn.

Ledger 09 line 010: Neri carried the blue token past marker e1df727a224c. Mara watched the eastern gate until dawn.

Ledger 09 line 011: Neri carried the blue token past marker c6bf1e8db187. Mara watched the eastern gate until dawn.

Ledger 09 line 012: Neri carried the blue token past marker d153c31a713b. Mara watched the eastern gate until dawn.

Ledger 09 line 013: Neri carried the blue token past marker 688889e88550. Mara watched the eastern gate until dawn.

Ledger 09 line 014: Neri carried the blue token past marker d75ad8a3d75a. Mara watched the eastern gate until dawn.

Ledger 09 line 015: Neri carried the blue token past marker 6f380c37212a. Mara watched the eastern gate until dawn.

Ledger 09 line 016: Neri carried the blue token past marker 31540b43fa20. Mara watched the eastern gate until dawn.

Ledger 09 line 017: Neri carried the blue token past marker 99b5184e16d2. Mara watched the eastern gate until dawn.

Ledger 09 line 018: Neri carried the blue token past marker 788215d223d9. Mara watched the eastern gate until dawn.

Ledger 09 line 019: Neri carried the blue token past marker 536d5b2d6850. Mara watched the eastern gate until dawn.

Ledger 09 line 020: Neri carried the blue token past marker 958d3f8cb040. Mara watched the eastern gate until dawn.

Ledger 09 line 021: Neri carried the blue token past marker 58136e64fa49. Mara watched the eastern gate until dawn.

Ledger 09 line 022: Neri carried the blue token past marker 231de84cffb5. Mara watched the eastern gate until dawn.

Ledger 09 line 023: Neri carried the blue token past marker 2c9721e37e7b. Mara watched the eastern gate until dawn.

Ledger 09 line 024: Neri carried the blue token past marker f86a77ed74f4. Mara watched the eastern gate until dawn.

Ledger 09 line 025: Neri carried the blue token past marker ba9970672690. Mara watched the eastern gate until dawn.

Ledger 09 line 026: Neri carried the blue token past marker 933bf7bb4b5f. Mara watched the eastern gate until dawn.

Ledger 09 line 027: Neri carried the blue token past marker 245912546f7c. Mara watched the eastern gate until dawn.

Ledger 09 line 028: Neri carried the blue token past marker c9a7191876de. Mara watched the eastern gate until dawn.

Ledger 09 line 029: Neri carried the blue token past marker 4980c39e9bf9. Mara watched the eastern gate until dawn.

Ledger 09 line 030: Neri carried the blue token past marker ec8fd5973e31. Mara watched the eastern gate until dawn.

Ledger 09 line 031: Neri carried the blue token past marker f4aae59e4a91. Mara watched the eastern gate until dawn.

Ledger 09 line 032: Neri carried the blue token past marker 6713afa927ae. Mara watched the eastern gate until dawn.

Ledger 09 line 033: Neri carried the blue token past marker 6c72375d1cfe. Mara watched the eastern gate until dawn.

Ledger 09 line 034: Neri carried the blue token past marker 6b911586db9e. Mara watched the eastern gate until dawn.

Ledger 09 line 035: Neri carried the blue token past marker f73f8f67595f. Mara watched the eastern gate until dawn.

Ledger 09 line 036: Neri carried the blue token past marker e5293623414b. Mara watched the eastern gate until dawn.

Ledger 09 line 037: Neri carried the blue token past marker bd8e36752380. Mara watched the eastern gate until dawn.

Ledger 09 line 038: Neri carried the blue token past marker c68a21703708. Mara watched the eastern gate until dawn.

Ledger 09 line 039: Neri carried the blue token past marker 94f61bb34b2d. Mara watched the eastern gate until dawn.

Ledger 09 line 040: Neri carried the blue token past marker 87a905a6c565. Mara watched the eastern gate until dawn.

Ledger 09 line 041: Neri carried the blue token past marker 6367892e08b0. Mara watched the eastern gate until dawn.

Ledger 09 line 042: Neri carried the blue token past marker bd481afb522f. Mara watched the eastern gate until dawn.

Ledger 09 line 043: Neri carried the blue token past marker 82ea6e399f88. Mara watched the eastern gate until dawn.

Ledger 09 line 044: Neri carried the blue token past marker 0716b349832f. Mara watched the eastern gate until dawn.

Ledger 09 line 045: Neri carried the blue token past marker d6a1785cd7a2. Mara watched the eastern gate until dawn.

Ledger 09 line 046: Neri carried the blue token past marker b349a01a63f9. Mara watched the eastern gate until dawn.

Ledger 09 line 047: Neri carried the blue token past marker ceed6db4a28f. Mara watched the eastern gate until dawn.

Ledger 09 line 048: Neri carried the blue token past marker a3ebc0e48353. Mara watched the eastern gate until dawn.

Ledger 09 line 049: Neri carried the blue token past marker 1ec7a7f61b38. Mara watched the eastern gate until dawn.

Ledger 09 line 050: Neri carried the blue token past marker d5e954bf4fad. Mara watched the eastern gate until dawn.

Ledger 09 line 051: Neri carried the blue token past marker 0f3d437e854b. Mara watched the eastern gate until dawn.

Ledger 09 line 052: Neri carried the blue token past marker e72208d46068. Mara watched the eastern gate until dawn.

Ledger 09 line 053: Neri carried the blue token past marker a34a35473757. Mara watched the eastern gate until dawn.

Ledger 09 line 054: Neri carried the blue token past marker 50aa75b094c4. Mara watched the eastern gate until dawn.

Ledger 09 line 055: Neri carried the blue token past marker 591820cf1bb0. Mara watched the eastern gate until dawn.

Ledger 09 line 056: Neri carried the blue token past marker 5f73d615c2a8. Mara watched the eastern gate until dawn.

Ledger 09 line 057: Neri carried the blue token past marker ea885cf33322. Mara watched the eastern gate until dawn.

Ledger 09 line 058: Neri carried the blue token past marker 414580438454. Mara watched the eastern gate until dawn.

Ledger 09 line 059: Neri carried the blue token past marker a8d2768daa14. Mara watched the eastern gate until dawn.

Ledger 09 line 060: Neri carried the blue token past marker 63bbaa694b8c. Mara watched the eastern gate until dawn.

Ledger 09 line 061: Neri carried the blue token past marker fa14703b27e1. Mara watched the eastern gate until dawn.

Ledger 09 line 062: Neri carried the blue token past marker 963e60fb7055. Mara watched the eastern gate until dawn.

Ledger 09 line 063: Neri carried the blue token past marker 34fe9f53d8bc. Mara watched the eastern gate until dawn.

Ledger 09 line 064: Neri carried the blue token past marker 7135e421b6a8. Mara watched the eastern gate until dawn.

Ledger 09 line 065: Neri carried the blue token past marker f76bc0cc2c45. Mara watched the eastern gate until dawn.

Ledger 09 line 066: Neri carried the blue token past marker a80bc70e109e. Mara watched the eastern gate until dawn.

Ledger 09 line 067: Neri carried the blue token past marker cef0d33f985c. Mara watched the eastern gate until dawn.

Ledger 09 line 068: Neri carried the blue token past marker 56e135a13c73. Mara watched the eastern gate until dawn.

Ledger 09 line 069: Neri carried the blue token past marker 41d0b5a0ee54. Mara watched the eastern gate until dawn.

Ledger 09 line 070: Neri carried the blue token past marker 8f26b7b177a5. Mara watched the eastern gate until dawn.

Ledger 09 line 071: Neri carried the blue token past marker c915ab98f62e. Mara watched the eastern gate until dawn.

Ledger 09 line 072: Neri carried the blue token past marker f433083b6289. Mara watched the eastern gate until dawn.

Ledger 09 line 073: Neri carried the blue token past marker 2d1148a7ca0a. Mara watched the eastern gate until dawn.

Ledger 09 line 074: Neri carried the blue token past marker 02004abd30f2. Mara watched the eastern gate until dawn.

Ledger 09 line 075: Neri carried the blue token past marker bd11fad9fef8. Mara watched the eastern gate until dawn.

Ledger 09 line 076: Neri carried the blue token past marker 2fc1d1fa394a. Mara watched the eastern gate until dawn.

Ledger 09 line 077: Neri carried the blue token past marker 8f2dba4276d4. Mara watched the eastern gate until dawn.

Ledger 09 line 078: Neri carried the blue token past marker f35bc5f8dcc6. Mara watched the eastern gate until dawn.

Ledger 09 line 079: Neri carried the blue token past marker 121a02ed7cd4. Mara watched the eastern gate until dawn.

Ledger 09 line 080: Neri carried the blue token past marker 778af649cfbe. Mara watched the eastern gate until dawn.

Ledger 09 line 081: Neri carried the blue token past marker 50e179c3cb00. Mara watched the eastern gate until dawn.

Ledger 09 line 082: Neri carried the blue token past marker 432792c7eb40. Mara watched the eastern gate until dawn.

Ledger 09 line 083: Neri carried the blue token past marker 4cc508e383ce. Mara watched the eastern gate until dawn.

Ledger 09 line 084: Neri carried the blue token past marker 9b4ad86b3407. Mara watched the eastern gate until dawn.

Ledger 09 line 085: Neri carried the blue token past marker 81d8255c039d. Mara watched the eastern gate until dawn.

Ledger 09 line 086: Neri carried the blue token past marker 16eef6418f83. Mara watched the eastern gate until dawn.

Ledger 09 line 087: Neri carried the blue token past marker 91cc204e5bdc. Mara watched the eastern gate until dawn.

Ledger 09 line 088: Neri carried the blue token past marker 245412b4a7a1. Mara watched the eastern gate until dawn.

Ledger 09 line 089: Neri carried the blue token past marker 8bcb99829ab0. Mara watched the eastern gate until dawn.

Ledger 09 line 090: Neri carried the blue token past marker 261a56228a29. Mara watched the eastern gate until dawn.

Ledger 09 line 091: Neri carried the blue token past marker 65a238739775. Mara watched the eastern gate until dawn.

Ledger 09 line 092: Neri carried the blue token past marker 5f2b87466833. Mara watched the eastern gate until dawn.

Ledger 09 line 093: Neri carried the blue token past marker 41cf311cf297. Mara watched the eastern gate until dawn.

Ledger 09 line 094: Neri carried the blue token past marker 4a066b39befa. Mara watched the eastern gate until dawn.

Ledger 09 line 095: Neri carried the blue token past marker f6d1161c9692. Mara watched the eastern gate until dawn.

Ledger 09 line 096: Neri carried the blue token past marker ca0ceac3e3d3. Mara watched the eastern gate until dawn.

Ledger 09 line 097: Neri carried the blue token past marker e145c3e21f64. Mara watched the eastern gate until dawn.

Ledger 09 line 098: Neri carried the blue token past marker 55c6ee8b605e. Mara watched the eastern gate until dawn.

Ledger 09 line 099: Neri carried the blue token past marker 2af7b5d8f297. Mara watched the eastern gate until dawn.

Ledger 09 line 100: Neri carried the blue token past marker 0d1c533053cc. Mara watched the eastern gate until dawn.

Ledger 09 line 101: Neri carried the blue token past marker 4f71c65e66e9. Mara watched the eastern gate until dawn.

Ledger 09 line 102: Neri carried the blue token past marker 0b859bda430c. Mara watched the eastern gate until dawn.

Ledger 09 line 103: Neri carried the blue token past marker eee644fb39a0. Mara watched the eastern gate until dawn.

Ledger 09 line 104: Neri carried the blue token past marker bff14bebb66a. Mara watched the eastern gate until dawn.

Ledger 09 line 105: Neri carried the blue token past marker f33c31af8a3c. Mara watched the eastern gate until dawn.

Ledger 09 line 106: Neri carried the blue token past marker 0ad991999166. Mara watched the eastern gate until dawn.

Ledger 09 line 107: Neri carried the blue token past marker 708aee52cd45. Mara watched the eastern gate until dawn.

Ledger 09 line 108: Neri carried the blue token past marker 52e6e5003fd6. Mara watched the eastern gate until dawn.

Ledger 09 line 109: Neri carried the blue token past marker 644c432e99ec. Mara watched the eastern gate until dawn.

Ledger 09 line 110: Neri carried the blue token past marker 8ab8bc9930f0. Mara watched the eastern gate until dawn.

Ledger 09 line 111: Neri carried the blue token past marker 73c7efd52d83. Mara watched the eastern gate until dawn.

Ledger 09 line 112: Neri carried the blue token past marker 301bf883ff31. Mara watched the eastern gate until dawn.

Ledger 09 line 113: Neri carried the blue token past marker 21027464db82. Mara watched the eastern gate until dawn.

Ledger 09 line 114: Neri carried the blue token past marker 5a9440bcd878. Mara watched the eastern gate until dawn.

Ledger 09 line 115: Neri carried the blue token past marker 57411ede598b. Mara watched the eastern gate until dawn.

Ledger 09 line 116: Neri carried the blue token past marker 7f4adf1e5224. Mara watched the eastern gate until dawn.

Ledger 09 line 117: Neri carried the blue token past marker 0c71f8fe0ea0. Mara watched the eastern gate until dawn.

Ledger 09 line 118: Neri carried the blue token past marker bd3671b0ca2b. Mara watched the eastern gate until dawn.

Ledger 09 line 119: Neri carried the blue token past marker 5556f16ba7bc. Mara watched the eastern gate until dawn.

Ledger 09 line 120: Neri carried the blue token past marker f7b8e92b136b. Mara watched the eastern gate until dawn.

Ledger 09 line 121: Neri carried the blue token past marker 2ffea3db8e60. Mara watched the eastern gate until dawn.

Ledger 09 line 122: Neri carried the blue token past marker 33f57729afbd. Mara watched the eastern gate until dawn.

Ledger 09 line 123: Neri carried the blue token past marker 0fd9458a0627. Mara watched the eastern gate until dawn.

Ledger 09 line 124: Neri carried the blue token past marker 823c5bc0e6b2. Mara watched the eastern gate until dawn.

Ledger 09 line 125: Neri carried the blue token past marker 41278ab9950f. Mara watched the eastern gate until dawn.

Ledger 09 line 126: Neri carried the blue token past marker c8c31e5642e3. Mara watched the eastern gate until dawn.

Ledger 09 line 127: Neri carried the blue token past marker dc0f9f14fdbf. Mara watched the eastern gate until dawn.

Ledger 09 line 128: Neri carried the blue token past marker 4907d67ef52b. Mara watched the eastern gate until dawn.

Ledger 09 line 129: Neri carried the blue token past marker 7a28174fc5ed. Mara watched the eastern gate until dawn.

Ledger 09 line 130: Neri carried the blue token past marker 27993ff37b7a. Mara watched the eastern gate until dawn.

Ledger 09 line 131: Neri carried the blue token past marker 5d2547298775. Mara watched the eastern gate until dawn.

Ledger 09 line 132: Neri carried the blue token past marker 2779b634a81d. Mara watched the eastern gate until dawn.

Ledger 09 line 133: Neri carried the blue token past marker 93d3a2d3d063. Mara watched the eastern gate until dawn.

Ledger 09 line 134: Neri carried the blue token past marker 6e6e270f07b0. Mara watched the eastern gate until dawn.

Ledger 09 line 135: Neri carried the blue token past marker c6c1d6dca183. Mara watched the eastern gate until dawn.

Ledger 09 line 136: Neri carried the blue token past marker edcce82820c6. Mara watched the eastern gate until dawn.

Ledger 09 line 137: Neri carried the blue token past marker 87b96734fb07. Mara watched the eastern gate until dawn.

Ledger 09 line 138: Neri carried the blue token past marker 4a161a913b78. Mara watched the eastern gate until dawn.

Ledger 09 line 139: Neri carried the blue token past marker bd1f1b1ea3d4. Mara watched the eastern gate until dawn.

Ledger 09 line 140: Neri carried the blue token past marker 73db236ecb5d. Mara watched the eastern gate until dawn.
