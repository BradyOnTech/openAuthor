---
id: scene-0056
title: Recovery ledger 56
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.182459+00:00
updated_at: 2026-10-03T12:14:52.182459+00:00
---

Ledger 56 line 001: Neri carried the blue token past marker 5143fb90d34e. Mara watched the eastern gate until dawn.

Ledger 56 line 002: Neri carried the blue token past marker 720e804846b3. Mara watched the eastern gate until dawn.

Ledger 56 line 003: Neri carried the blue token past marker a507a3d9d016. Mara watched the eastern gate until dawn.

Ledger 56 line 004: Neri carried the blue token past marker a35ec5c9f4a7. Mara watched the eastern gate until dawn.

Ledger 56 line 005: Neri carried the blue token past marker 55ded3575fed. Mara watched the eastern gate until dawn.

Ledger 56 line 006: Neri carried the blue token past marker f51a02561321. Mara watched the eastern gate until dawn.

Ledger 56 line 007: Neri carried the blue token past marker 2866810d0c9e. Mara watched the eastern gate until dawn.

Ledger 56 line 008: Neri carried the blue token past marker 8f27269e73de. Mara watched the eastern gate until dawn.

Ledger 56 line 009: Neri carried the blue token past marker 0336a4a4016b. Mara watched the eastern gate until dawn.

Ledger 56 line 010: Neri carried the blue token past marker 49baaa8d8907. Mara watched the eastern gate until dawn.

Ledger 56 line 011: Neri carried the blue token past marker 9017f55584ca. Mara watched the eastern gate until dawn.

Ledger 56 line 012: Neri carried the blue token past marker f0c0a04462cc. Mara watched the eastern gate until dawn.

Ledger 56 line 013: Neri carried the blue token past marker 198b52a4d370. Mara watched the eastern gate until dawn.

Ledger 56 line 014: Neri carried the blue token past marker 599927524ca8. Mara watched the eastern gate until dawn.

Ledger 56 line 015: Neri carried the blue token past marker faf35ddac588. Mara watched the eastern gate until dawn.

Ledger 56 line 016: Neri carried the blue token past marker 448382f30a5a. Mara watched the eastern gate until dawn.

Ledger 56 line 017: Neri carried the blue token past marker cb38dbdffd91. Mara watched the eastern gate until dawn.

Ledger 56 line 018: Neri carried the blue token past marker 0cd885c92f69. Mara watched the eastern gate until dawn.

Ledger 56 line 019: Neri carried the blue token past marker 782e58f8dfcb. Mara watched the eastern gate until dawn.

Ledger 56 line 020: Neri carried the blue token past marker 78180f1a8092. Mara watched the eastern gate until dawn.

Ledger 56 line 021: Neri carried the blue token past marker a4b986dd489d. Mara watched the eastern gate until dawn.

Ledger 56 line 022: Neri carried the blue token past marker 58d47772786e. Mara watched the eastern gate until dawn.

Ledger 56 line 023: Neri carried the blue token past marker 86b841987dd9. Mara watched the eastern gate until dawn.

Ledger 56 line 024: Neri carried the blue token past marker c1e338839b77. Mara watched the eastern gate until dawn.

Ledger 56 line 025: Neri carried the blue token past marker 91460ca4b59d. Mara watched the eastern gate until dawn.

Ledger 56 line 026: Neri carried the blue token past marker 9d5eaee0b2e0. Mara watched the eastern gate until dawn.

Ledger 56 line 027: Neri carried the blue token past marker 1464d34b0a01. Mara watched the eastern gate until dawn.

Ledger 56 line 028: Neri carried the blue token past marker ef39b83c6c2d. Mara watched the eastern gate until dawn.

Ledger 56 line 029: Neri carried the blue token past marker 78dff03622f8. Mara watched the eastern gate until dawn.

Ledger 56 line 030: Neri carried the blue token past marker 56e1f07bb3c7. Mara watched the eastern gate until dawn.

Ledger 56 line 031: Neri carried the blue token past marker e1c7d21238cf. Mara watched the eastern gate until dawn.

Ledger 56 line 032: Neri carried the blue token past marker 3bffee7a48de. Mara watched the eastern gate until dawn.

Ledger 56 line 033: Neri carried the blue token past marker 1f7134014968. Mara watched the eastern gate until dawn.

Ledger 56 line 034: Neri carried the blue token past marker 93c0aee44070. Mara watched the eastern gate until dawn.

Ledger 56 line 035: Neri carried the blue token past marker 168684930927. Mara watched the eastern gate until dawn.

Ledger 56 line 036: Neri carried the blue token past marker 5c8c7514dd73. Mara watched the eastern gate until dawn.

Ledger 56 line 037: Neri carried the blue token past marker 997fcd400856. Mara watched the eastern gate until dawn.

Ledger 56 line 038: Neri carried the blue token past marker ccfbae90b7ac. Mara watched the eastern gate until dawn.

Ledger 56 line 039: Neri carried the blue token past marker 2f4080548dbc. Mara watched the eastern gate until dawn.

Ledger 56 line 040: Neri carried the blue token past marker 8c62a3e1abc1. Mara watched the eastern gate until dawn.

Ledger 56 line 041: Neri carried the blue token past marker 954b03de7279. Mara watched the eastern gate until dawn.

Ledger 56 line 042: Neri carried the blue token past marker 266bfea1dc43. Mara watched the eastern gate until dawn.

Ledger 56 line 043: Neri carried the blue token past marker 207856f9e79b. Mara watched the eastern gate until dawn.

Ledger 56 line 044: Neri carried the blue token past marker a28977149821. Mara watched the eastern gate until dawn.

Ledger 56 line 045: Neri carried the blue token past marker c12cce663c03. Mara watched the eastern gate until dawn.

Ledger 56 line 046: Neri carried the blue token past marker 0977bcbf76e3. Mara watched the eastern gate until dawn.

Ledger 56 line 047: Neri carried the blue token past marker fa1f2974c955. Mara watched the eastern gate until dawn.

Ledger 56 line 048: Neri carried the blue token past marker 198fe9a5e0a0. Mara watched the eastern gate until dawn.

Ledger 56 line 049: Neri carried the blue token past marker 93d53018c0e6. Mara watched the eastern gate until dawn.

Ledger 56 line 050: Neri carried the blue token past marker 4fc1dfd1cb3a. Mara watched the eastern gate until dawn.

Ledger 56 line 051: Neri carried the blue token past marker b86f358c44f4. Mara watched the eastern gate until dawn.

Ledger 56 line 052: Neri carried the blue token past marker a39f28283d24. Mara watched the eastern gate until dawn.

Ledger 56 line 053: Neri carried the blue token past marker 9910022aef9e. Mara watched the eastern gate until dawn.

Ledger 56 line 054: Neri carried the blue token past marker 8de4e68dfd57. Mara watched the eastern gate until dawn.

Ledger 56 line 055: Neri carried the blue token past marker 55a9c3eacc33. Mara watched the eastern gate until dawn.

Ledger 56 line 056: Neri carried the blue token past marker 5b8903388531. Mara watched the eastern gate until dawn.

Ledger 56 line 057: Neri carried the blue token past marker 09cfb0f61cc1. Mara watched the eastern gate until dawn.

Ledger 56 line 058: Neri carried the blue token past marker 88d314a38e0f. Mara watched the eastern gate until dawn.

Ledger 56 line 059: Neri carried the blue token past marker 75f183354eeb. Mara watched the eastern gate until dawn.

Ledger 56 line 060: Neri carried the blue token past marker 0933b84c01a9. Mara watched the eastern gate until dawn.

Ledger 56 line 061: Neri carried the blue token past marker 438324c65500. Mara watched the eastern gate until dawn.

Ledger 56 line 062: Neri carried the blue token past marker 0cf33f320317. Mara watched the eastern gate until dawn.

Ledger 56 line 063: Neri carried the blue token past marker 1d46fa4ac59a. Mara watched the eastern gate until dawn.

Ledger 56 line 064: Neri carried the blue token past marker d3ca14d17363. Mara watched the eastern gate until dawn.

Ledger 56 line 065: Neri carried the blue token past marker 3584f9d34ca4. Mara watched the eastern gate until dawn.

Ledger 56 line 066: Neri carried the blue token past marker 6aa792f6d7a3. Mara watched the eastern gate until dawn.

Ledger 56 line 067: Neri carried the blue token past marker 3356c4a167e9. Mara watched the eastern gate until dawn.

Ledger 56 line 068: Neri carried the blue token past marker d0de0f97a898. Mara watched the eastern gate until dawn.

Ledger 56 line 069: Neri carried the blue token past marker 755ff16553e0. Mara watched the eastern gate until dawn.

Ledger 56 line 070: Neri carried the blue token past marker 009e29350377. Mara watched the eastern gate until dawn.

Ledger 56 line 071: Neri carried the blue token past marker a1a80ff14347. Mara watched the eastern gate until dawn.

Ledger 56 line 072: Neri carried the blue token past marker 0e98879e21ac. Mara watched the eastern gate until dawn.

Ledger 56 line 073: Neri carried the blue token past marker 2fd600468a70. Mara watched the eastern gate until dawn.

Ledger 56 line 074: Neri carried the blue token past marker c53afe6e6adf. Mara watched the eastern gate until dawn.

Ledger 56 line 075: Neri carried the blue token past marker f5d498b1f568. Mara watched the eastern gate until dawn.

Ledger 56 line 076: Neri carried the blue token past marker d28419b8258a. Mara watched the eastern gate until dawn.

Ledger 56 line 077: Neri carried the blue token past marker 30f20eb33aa0. Mara watched the eastern gate until dawn.

Ledger 56 line 078: Neri carried the blue token past marker 93e38ce43fd4. Mara watched the eastern gate until dawn.

Ledger 56 line 079: Neri carried the blue token past marker 6aa528bf2f4b. Mara watched the eastern gate until dawn.

Ledger 56 line 080: Neri carried the blue token past marker 672f8ee18ffe. Mara watched the eastern gate until dawn.

Ledger 56 line 081: Neri carried the blue token past marker 3b94d1b38df2. Mara watched the eastern gate until dawn.

Ledger 56 line 082: Neri carried the blue token past marker 35d94d0badf9. Mara watched the eastern gate until dawn.

Ledger 56 line 083: Neri carried the blue token past marker d8eac01a513a. Mara watched the eastern gate until dawn.

Ledger 56 line 084: Neri carried the blue token past marker d382ff12e65b. Mara watched the eastern gate until dawn.

Ledger 56 line 085: Neri carried the blue token past marker 68816dce460c. Mara watched the eastern gate until dawn.

Ledger 56 line 086: Neri carried the blue token past marker 439d626533b4. Mara watched the eastern gate until dawn.

Ledger 56 line 087: Neri carried the blue token past marker 3be7389a95ce. Mara watched the eastern gate until dawn.

Ledger 56 line 088: Neri carried the blue token past marker 17b29b2b7060. Mara watched the eastern gate until dawn.

Ledger 56 line 089: Neri carried the blue token past marker 797c02c62aa4. Mara watched the eastern gate until dawn.

Ledger 56 line 090: Neri carried the blue token past marker d40386d5e21e. Mara watched the eastern gate until dawn.

Ledger 56 line 091: Neri carried the blue token past marker 53bd2e2e5607. Mara watched the eastern gate until dawn.

Ledger 56 line 092: Neri carried the blue token past marker 576f1094a65b. Mara watched the eastern gate until dawn.

Ledger 56 line 093: Neri carried the blue token past marker 323cc01f6fe6. Mara watched the eastern gate until dawn.

Ledger 56 line 094: Neri carried the blue token past marker d9dda812f964. Mara watched the eastern gate until dawn.

Ledger 56 line 095: Neri carried the blue token past marker d9e8ed42357e. Mara watched the eastern gate until dawn.

Ledger 56 line 096: Neri carried the blue token past marker 76554a9759a7. Mara watched the eastern gate until dawn.

Ledger 56 line 097: Neri carried the blue token past marker 8f5eb8e4cdd7. Mara watched the eastern gate until dawn.

Ledger 56 line 098: Neri carried the blue token past marker b7803578cb7a. Mara watched the eastern gate until dawn.

Ledger 56 line 099: Neri carried the blue token past marker e1c025c4b411. Mara watched the eastern gate until dawn.

Ledger 56 line 100: Neri carried the blue token past marker 2a96ac6c4fe5. Mara watched the eastern gate until dawn.

Ledger 56 line 101: Neri carried the blue token past marker 0f38a9251789. Mara watched the eastern gate until dawn.

Ledger 56 line 102: Neri carried the blue token past marker ee20d6880a7f. Mara watched the eastern gate until dawn.

Ledger 56 line 103: Neri carried the blue token past marker c05f6a1a3818. Mara watched the eastern gate until dawn.

Ledger 56 line 104: Neri carried the blue token past marker 7b746ebc4f31. Mara watched the eastern gate until dawn.

Ledger 56 line 105: Neri carried the blue token past marker 663dcf2a1620. Mara watched the eastern gate until dawn.

Ledger 56 line 106: Neri carried the blue token past marker bba968bbfc0b. Mara watched the eastern gate until dawn.

Ledger 56 line 107: Neri carried the blue token past marker 5164622db99c. Mara watched the eastern gate until dawn.

Ledger 56 line 108: Neri carried the blue token past marker 50a7aab9235b. Mara watched the eastern gate until dawn.

Ledger 56 line 109: Neri carried the blue token past marker 7cd15dff61c8. Mara watched the eastern gate until dawn.

Ledger 56 line 110: Neri carried the blue token past marker 11ae72a0e739. Mara watched the eastern gate until dawn.

Ledger 56 line 111: Neri carried the blue token past marker 7523ddeb7001. Mara watched the eastern gate until dawn.

Ledger 56 line 112: Neri carried the blue token past marker 325fc729c0af. Mara watched the eastern gate until dawn.

Ledger 56 line 113: Neri carried the blue token past marker 55d6356e487b. Mara watched the eastern gate until dawn.

Ledger 56 line 114: Neri carried the blue token past marker 5aad84092559. Mara watched the eastern gate until dawn.

Ledger 56 line 115: Neri carried the blue token past marker 910f9693525a. Mara watched the eastern gate until dawn.

Ledger 56 line 116: Neri carried the blue token past marker dafbd3179de9. Mara watched the eastern gate until dawn.

Ledger 56 line 117: Neri carried the blue token past marker 77b2bfd17bdd. Mara watched the eastern gate until dawn.

Ledger 56 line 118: Neri carried the blue token past marker ecbba5a20c0d. Mara watched the eastern gate until dawn.

Ledger 56 line 119: Neri carried the blue token past marker 677a71268e74. Mara watched the eastern gate until dawn.

Ledger 56 line 120: Neri carried the blue token past marker 16e564d20fa2. Mara watched the eastern gate until dawn.

Ledger 56 line 121: Neri carried the blue token past marker 1c088c869b7e. Mara watched the eastern gate until dawn.

Ledger 56 line 122: Neri carried the blue token past marker 383314874457. Mara watched the eastern gate until dawn.

Ledger 56 line 123: Neri carried the blue token past marker 5f13225c8877. Mara watched the eastern gate until dawn.

Ledger 56 line 124: Neri carried the blue token past marker 471da7b1fd80. Mara watched the eastern gate until dawn.

Ledger 56 line 125: Neri carried the blue token past marker 6f44afee4543. Mara watched the eastern gate until dawn.

Ledger 56 line 126: Neri carried the blue token past marker 61dfc4f48ec1. Mara watched the eastern gate until dawn.

Ledger 56 line 127: Neri carried the blue token past marker c1986786c9f2. Mara watched the eastern gate until dawn.

Ledger 56 line 128: Neri carried the blue token past marker 4f9f96ed2d3d. Mara watched the eastern gate until dawn.

Ledger 56 line 129: Neri carried the blue token past marker 66748c8fc4aa. Mara watched the eastern gate until dawn.

Ledger 56 line 130: Neri carried the blue token past marker 7fe93f5ab065. Mara watched the eastern gate until dawn.

Ledger 56 line 131: Neri carried the blue token past marker c751b058b885. Mara watched the eastern gate until dawn.

Ledger 56 line 132: Neri carried the blue token past marker bb54db503feb. Mara watched the eastern gate until dawn.

Ledger 56 line 133: Neri carried the blue token past marker 78ceb4827032. Mara watched the eastern gate until dawn.

Ledger 56 line 134: Neri carried the blue token past marker 728776d58c93. Mara watched the eastern gate until dawn.

Ledger 56 line 135: Neri carried the blue token past marker 1bd49622b824. Mara watched the eastern gate until dawn.

Ledger 56 line 136: Neri carried the blue token past marker e6f2e948da9f. Mara watched the eastern gate until dawn.

Ledger 56 line 137: Neri carried the blue token past marker 930f156c46d5. Mara watched the eastern gate until dawn.

Ledger 56 line 138: Neri carried the blue token past marker eaf4c9a66067. Mara watched the eastern gate until dawn.

Ledger 56 line 139: Neri carried the blue token past marker 0f8eaad829e7. Mara watched the eastern gate until dawn.

Ledger 56 line 140: Neri carried the blue token past marker 6405c286ad2c. Mara watched the eastern gate until dawn.
