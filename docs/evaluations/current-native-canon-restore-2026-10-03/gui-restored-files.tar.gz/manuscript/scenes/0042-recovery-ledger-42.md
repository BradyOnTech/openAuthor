---
id: scene-0042
title: Recovery ledger 42
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.175097+00:00
updated_at: 2026-10-03T12:14:52.175097+00:00
---

Ledger 42 line 001: Neri carried the blue token past marker 2e4deec325f6. Mara watched the eastern gate until dawn.

Ledger 42 line 002: Neri carried the blue token past marker 3370c13a0c38. Mara watched the eastern gate until dawn.

Ledger 42 line 003: Neri carried the blue token past marker 108ec7f70edd. Mara watched the eastern gate until dawn.

Ledger 42 line 004: Neri carried the blue token past marker 2550f70c5857. Mara watched the eastern gate until dawn.

Ledger 42 line 005: Neri carried the blue token past marker 58918c1d4a82. Mara watched the eastern gate until dawn.

Ledger 42 line 006: Neri carried the blue token past marker 3eb659110901. Mara watched the eastern gate until dawn.

Ledger 42 line 007: Neri carried the blue token past marker 82259e15fbe0. Mara watched the eastern gate until dawn.

Ledger 42 line 008: Neri carried the blue token past marker d38b502c0d28. Mara watched the eastern gate until dawn.

Ledger 42 line 009: Neri carried the blue token past marker 5fa098f08d72. Mara watched the eastern gate until dawn.

Ledger 42 line 010: Neri carried the blue token past marker e78cd847ac9b. Mara watched the eastern gate until dawn.

Ledger 42 line 011: Neri carried the blue token past marker a1c1866bd893. Mara watched the eastern gate until dawn.

Ledger 42 line 012: Neri carried the blue token past marker 5710e03be2fb. Mara watched the eastern gate until dawn.

Ledger 42 line 013: Neri carried the blue token past marker 5e6f60ce5e61. Mara watched the eastern gate until dawn.

Ledger 42 line 014: Neri carried the blue token past marker fe1e60e3d922. Mara watched the eastern gate until dawn.

Ledger 42 line 015: Neri carried the blue token past marker 2fc510597c97. Mara watched the eastern gate until dawn.

Ledger 42 line 016: Neri carried the blue token past marker 0c7c4a9e21ec. Mara watched the eastern gate until dawn.

Ledger 42 line 017: Neri carried the blue token past marker 7cacc0e7069d. Mara watched the eastern gate until dawn.

Ledger 42 line 018: Neri carried the blue token past marker 857ccbcc17e7. Mara watched the eastern gate until dawn.

Ledger 42 line 019: Neri carried the blue token past marker abf5d7468e82. Mara watched the eastern gate until dawn.

Ledger 42 line 020: Neri carried the blue token past marker cd8926cc6758. Mara watched the eastern gate until dawn.

Ledger 42 line 021: Neri carried the blue token past marker 4a9d337ff696. Mara watched the eastern gate until dawn.

Ledger 42 line 022: Neri carried the blue token past marker 863be535f3c5. Mara watched the eastern gate until dawn.

Ledger 42 line 023: Neri carried the blue token past marker 4d213fc7b5b9. Mara watched the eastern gate until dawn.

Ledger 42 line 024: Neri carried the blue token past marker b500195d44fa. Mara watched the eastern gate until dawn.

Ledger 42 line 025: Neri carried the blue token past marker 0472308b6906. Mara watched the eastern gate until dawn.

Ledger 42 line 026: Neri carried the blue token past marker 851a3c884718. Mara watched the eastern gate until dawn.

Ledger 42 line 027: Neri carried the blue token past marker 624c192bd974. Mara watched the eastern gate until dawn.

Ledger 42 line 028: Neri carried the blue token past marker f21e454ec792. Mara watched the eastern gate until dawn.

Ledger 42 line 029: Neri carried the blue token past marker 31156aae67b3. Mara watched the eastern gate until dawn.

Ledger 42 line 030: Neri carried the blue token past marker 2cdbccf4d152. Mara watched the eastern gate until dawn.

Ledger 42 line 031: Neri carried the blue token past marker 54242f483dec. Mara watched the eastern gate until dawn.

Ledger 42 line 032: Neri carried the blue token past marker 256f935c488b. Mara watched the eastern gate until dawn.

Ledger 42 line 033: Neri carried the blue token past marker 58ceaf3769a7. Mara watched the eastern gate until dawn.

Ledger 42 line 034: Neri carried the blue token past marker 157ba3b0713b. Mara watched the eastern gate until dawn.

Ledger 42 line 035: Neri carried the blue token past marker ccf52ba0b680. Mara watched the eastern gate until dawn.

Ledger 42 line 036: Neri carried the blue token past marker f1bdfc29d710. Mara watched the eastern gate until dawn.

Ledger 42 line 037: Neri carried the blue token past marker bddd03382faf. Mara watched the eastern gate until dawn.

Ledger 42 line 038: Neri carried the blue token past marker 341a1412cd19. Mara watched the eastern gate until dawn.

Ledger 42 line 039: Neri carried the blue token past marker b3f6acd4f5f7. Mara watched the eastern gate until dawn.

Ledger 42 line 040: Neri carried the blue token past marker e675a81a9aad. Mara watched the eastern gate until dawn.

Ledger 42 line 041: Neri carried the blue token past marker 163175f30a48. Mara watched the eastern gate until dawn.

Ledger 42 line 042: Neri carried the blue token past marker bcbc33f4bffc. Mara watched the eastern gate until dawn.

Ledger 42 line 043: Neri carried the blue token past marker 28de74c3bb49. Mara watched the eastern gate until dawn.

Ledger 42 line 044: Neri carried the blue token past marker a5e1be36043f. Mara watched the eastern gate until dawn.

Ledger 42 line 045: Neri carried the blue token past marker b15e0e034bdf. Mara watched the eastern gate until dawn.

Ledger 42 line 046: Neri carried the blue token past marker 931f7b69672f. Mara watched the eastern gate until dawn.

Ledger 42 line 047: Neri carried the blue token past marker 79cdc9dc2c64. Mara watched the eastern gate until dawn.

Ledger 42 line 048: Neri carried the blue token past marker 533778b876ec. Mara watched the eastern gate until dawn.

Ledger 42 line 049: Neri carried the blue token past marker f99fa2e956d2. Mara watched the eastern gate until dawn.

Ledger 42 line 050: Neri carried the blue token past marker ef2217f98b6c. Mara watched the eastern gate until dawn.

Ledger 42 line 051: Neri carried the blue token past marker 29964d664cd7. Mara watched the eastern gate until dawn.

Ledger 42 line 052: Neri carried the blue token past marker fb1633c5a713. Mara watched the eastern gate until dawn.

Ledger 42 line 053: Neri carried the blue token past marker 3c3d7f063b98. Mara watched the eastern gate until dawn.

Ledger 42 line 054: Neri carried the blue token past marker 3263b1f95ded. Mara watched the eastern gate until dawn.

Ledger 42 line 055: Neri carried the blue token past marker 93210c86dd5e. Mara watched the eastern gate until dawn.

Ledger 42 line 056: Neri carried the blue token past marker c8cd262d932c. Mara watched the eastern gate until dawn.

Ledger 42 line 057: Neri carried the blue token past marker 1c211de4f5dc. Mara watched the eastern gate until dawn.

Ledger 42 line 058: Neri carried the blue token past marker 35ce416380b1. Mara watched the eastern gate until dawn.

Ledger 42 line 059: Neri carried the blue token past marker 4a0ed5885077. Mara watched the eastern gate until dawn.

Ledger 42 line 060: Neri carried the blue token past marker 0c119a344e4d. Mara watched the eastern gate until dawn.

Ledger 42 line 061: Neri carried the blue token past marker 961f19cb05a7. Mara watched the eastern gate until dawn.

Ledger 42 line 062: Neri carried the blue token past marker 7041f8dd147e. Mara watched the eastern gate until dawn.

Ledger 42 line 063: Neri carried the blue token past marker d57667b0b3df. Mara watched the eastern gate until dawn.

Ledger 42 line 064: Neri carried the blue token past marker cafd115e7fae. Mara watched the eastern gate until dawn.

Ledger 42 line 065: Neri carried the blue token past marker de4fc753829c. Mara watched the eastern gate until dawn.

Ledger 42 line 066: Neri carried the blue token past marker 776ba049ff58. Mara watched the eastern gate until dawn.

Ledger 42 line 067: Neri carried the blue token past marker 70a054786cea. Mara watched the eastern gate until dawn.

Ledger 42 line 068: Neri carried the blue token past marker 27d9b1721aad. Mara watched the eastern gate until dawn.

Ledger 42 line 069: Neri carried the blue token past marker 74b5c4ee4096. Mara watched the eastern gate until dawn.

Ledger 42 line 070: Neri carried the blue token past marker b7347f760400. Mara watched the eastern gate until dawn.

Ledger 42 line 071: Neri carried the blue token past marker 5a0fd740143d. Mara watched the eastern gate until dawn.

Ledger 42 line 072: Neri carried the blue token past marker 0024c325dcd7. Mara watched the eastern gate until dawn.

Ledger 42 line 073: Neri carried the blue token past marker b058ef2b963f. Mara watched the eastern gate until dawn.

Ledger 42 line 074: Neri carried the blue token past marker b06c3f437deb. Mara watched the eastern gate until dawn.

Ledger 42 line 075: Neri carried the blue token past marker f4578821ff6c. Mara watched the eastern gate until dawn.

Ledger 42 line 076: Neri carried the blue token past marker cee895791d80. Mara watched the eastern gate until dawn.

Ledger 42 line 077: Neri carried the blue token past marker 05407f6d3115. Mara watched the eastern gate until dawn.

Ledger 42 line 078: Neri carried the blue token past marker 7102ad388b39. Mara watched the eastern gate until dawn.

Ledger 42 line 079: Neri carried the blue token past marker 6fdeebce4f34. Mara watched the eastern gate until dawn.

Ledger 42 line 080: Neri carried the blue token past marker e1f7caab8df1. Mara watched the eastern gate until dawn.

Ledger 42 line 081: Neri carried the blue token past marker 17afe6ffa018. Mara watched the eastern gate until dawn.

Ledger 42 line 082: Neri carried the blue token past marker 12e6cec85e75. Mara watched the eastern gate until dawn.

Ledger 42 line 083: Neri carried the blue token past marker beac5c56afba. Mara watched the eastern gate until dawn.

Ledger 42 line 084: Neri carried the blue token past marker ae8da8f953e1. Mara watched the eastern gate until dawn.

Ledger 42 line 085: Neri carried the blue token past marker e1c8b6535833. Mara watched the eastern gate until dawn.

Ledger 42 line 086: Neri carried the blue token past marker 2c61ba246e6c. Mara watched the eastern gate until dawn.

Ledger 42 line 087: Neri carried the blue token past marker 5042b0cb6747. Mara watched the eastern gate until dawn.

Ledger 42 line 088: Neri carried the blue token past marker 533e42739492. Mara watched the eastern gate until dawn.

Ledger 42 line 089: Neri carried the blue token past marker 655f2f7477d4. Mara watched the eastern gate until dawn.

Ledger 42 line 090: Neri carried the blue token past marker 24fc476ab482. Mara watched the eastern gate until dawn.

Ledger 42 line 091: Neri carried the blue token past marker 443d974a4ed4. Mara watched the eastern gate until dawn.

Ledger 42 line 092: Neri carried the blue token past marker 1be3627ddc45. Mara watched the eastern gate until dawn.

Ledger 42 line 093: Neri carried the blue token past marker d2af230b92d7. Mara watched the eastern gate until dawn.

Ledger 42 line 094: Neri carried the blue token past marker 572aa7588edc. Mara watched the eastern gate until dawn.

Ledger 42 line 095: Neri carried the blue token past marker 7f1115939a5e. Mara watched the eastern gate until dawn.

Ledger 42 line 096: Neri carried the blue token past marker 362b59067702. Mara watched the eastern gate until dawn.

Ledger 42 line 097: Neri carried the blue token past marker 91ee9255ce03. Mara watched the eastern gate until dawn.

Ledger 42 line 098: Neri carried the blue token past marker 3feaab0dd8ca. Mara watched the eastern gate until dawn.

Ledger 42 line 099: Neri carried the blue token past marker 8812ac7a76dd. Mara watched the eastern gate until dawn.

Ledger 42 line 100: Neri carried the blue token past marker a6117e38ec7b. Mara watched the eastern gate until dawn.

Ledger 42 line 101: Neri carried the blue token past marker 06acb2dd6400. Mara watched the eastern gate until dawn.

Ledger 42 line 102: Neri carried the blue token past marker 29ed69d2df45. Mara watched the eastern gate until dawn.

Ledger 42 line 103: Neri carried the blue token past marker 6df9e272893a. Mara watched the eastern gate until dawn.

Ledger 42 line 104: Neri carried the blue token past marker 7f4efb4a3f85. Mara watched the eastern gate until dawn.

Ledger 42 line 105: Neri carried the blue token past marker ec97ea0cfa4d. Mara watched the eastern gate until dawn.

Ledger 42 line 106: Neri carried the blue token past marker acd752df144f. Mara watched the eastern gate until dawn.

Ledger 42 line 107: Neri carried the blue token past marker 198703280394. Mara watched the eastern gate until dawn.

Ledger 42 line 108: Neri carried the blue token past marker a10baa5edf5e. Mara watched the eastern gate until dawn.

Ledger 42 line 109: Neri carried the blue token past marker 979172e63d54. Mara watched the eastern gate until dawn.

Ledger 42 line 110: Neri carried the blue token past marker 3ccae136b49d. Mara watched the eastern gate until dawn.

Ledger 42 line 111: Neri carried the blue token past marker d038b88dff16. Mara watched the eastern gate until dawn.

Ledger 42 line 112: Neri carried the blue token past marker 07e08061177b. Mara watched the eastern gate until dawn.

Ledger 42 line 113: Neri carried the blue token past marker 048995fbd08a. Mara watched the eastern gate until dawn.

Ledger 42 line 114: Neri carried the blue token past marker b5fd2e88fc7f. Mara watched the eastern gate until dawn.

Ledger 42 line 115: Neri carried the blue token past marker b51407e62858. Mara watched the eastern gate until dawn.

Ledger 42 line 116: Neri carried the blue token past marker c467e4c5c6a9. Mara watched the eastern gate until dawn.

Ledger 42 line 117: Neri carried the blue token past marker 13661eaa11d0. Mara watched the eastern gate until dawn.

Ledger 42 line 118: Neri carried the blue token past marker 3e366f667674. Mara watched the eastern gate until dawn.

Ledger 42 line 119: Neri carried the blue token past marker 32d190f1b415. Mara watched the eastern gate until dawn.

Ledger 42 line 120: Neri carried the blue token past marker 3c9b5ba1d3a7. Mara watched the eastern gate until dawn.

Ledger 42 line 121: Neri carried the blue token past marker 2bc5dcb0424e. Mara watched the eastern gate until dawn.

Ledger 42 line 122: Neri carried the blue token past marker 84ab33455aa9. Mara watched the eastern gate until dawn.

Ledger 42 line 123: Neri carried the blue token past marker 32cadbc763e3. Mara watched the eastern gate until dawn.

Ledger 42 line 124: Neri carried the blue token past marker b44c87f1b0d8. Mara watched the eastern gate until dawn.

Ledger 42 line 125: Neri carried the blue token past marker d359cfff2032. Mara watched the eastern gate until dawn.

Ledger 42 line 126: Neri carried the blue token past marker f7d60b8ebd3c. Mara watched the eastern gate until dawn.

Ledger 42 line 127: Neri carried the blue token past marker 70dce0e1b8d0. Mara watched the eastern gate until dawn.

Ledger 42 line 128: Neri carried the blue token past marker 4caa5058d9dc. Mara watched the eastern gate until dawn.

Ledger 42 line 129: Neri carried the blue token past marker eecf40773f49. Mara watched the eastern gate until dawn.

Ledger 42 line 130: Neri carried the blue token past marker b2b476e71b74. Mara watched the eastern gate until dawn.

Ledger 42 line 131: Neri carried the blue token past marker 6497850e5a51. Mara watched the eastern gate until dawn.

Ledger 42 line 132: Neri carried the blue token past marker e59c93d49666. Mara watched the eastern gate until dawn.

Ledger 42 line 133: Neri carried the blue token past marker a28369f83835. Mara watched the eastern gate until dawn.

Ledger 42 line 134: Neri carried the blue token past marker 2e62320e57d8. Mara watched the eastern gate until dawn.

Ledger 42 line 135: Neri carried the blue token past marker 230649669d76. Mara watched the eastern gate until dawn.

Ledger 42 line 136: Neri carried the blue token past marker 2b756c0dad42. Mara watched the eastern gate until dawn.

Ledger 42 line 137: Neri carried the blue token past marker 35199757b495. Mara watched the eastern gate until dawn.

Ledger 42 line 138: Neri carried the blue token past marker 758735342469. Mara watched the eastern gate until dawn.

Ledger 42 line 139: Neri carried the blue token past marker 7923e9014ca9. Mara watched the eastern gate until dawn.

Ledger 42 line 140: Neri carried the blue token past marker 4d54ab9a5b2b. Mara watched the eastern gate until dawn.
