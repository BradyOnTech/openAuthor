---
id: scene-0004
title: Recovery ledger 04
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.154822+00:00
updated_at: 2026-10-03T12:14:52.154822+00:00
---

Ledger 04 line 001: Neri carried the blue token past marker da090f9d2150. Mara watched the eastern gate until dawn.

Ledger 04 line 002: Neri carried the blue token past marker 0ae38aae1700. Mara watched the eastern gate until dawn.

Ledger 04 line 003: Neri carried the blue token past marker 88a09c48f589. Mara watched the eastern gate until dawn.

Ledger 04 line 004: Neri carried the blue token past marker 0859ef921574. Mara watched the eastern gate until dawn.

Ledger 04 line 005: Neri carried the blue token past marker 1265c5694e90. Mara watched the eastern gate until dawn.

Ledger 04 line 006: Neri carried the blue token past marker 20e2bb9b84a9. Mara watched the eastern gate until dawn.

Ledger 04 line 007: Neri carried the blue token past marker fb79a3caeeac. Mara watched the eastern gate until dawn.

Ledger 04 line 008: Neri carried the blue token past marker c44ee2ebf64f. Mara watched the eastern gate until dawn.

Ledger 04 line 009: Neri carried the blue token past marker 2b4a3397494a. Mara watched the eastern gate until dawn.

Ledger 04 line 010: Neri carried the blue token past marker 9d7d942f2822. Mara watched the eastern gate until dawn.

Ledger 04 line 011: Neri carried the blue token past marker 0ebc6b5784d8. Mara watched the eastern gate until dawn.

Ledger 04 line 012: Neri carried the blue token past marker b0c3f0898140. Mara watched the eastern gate until dawn.

Ledger 04 line 013: Neri carried the blue token past marker 6e7eda212629. Mara watched the eastern gate until dawn.

Ledger 04 line 014: Neri carried the blue token past marker a5582eac5b77. Mara watched the eastern gate until dawn.

Ledger 04 line 015: Neri carried the blue token past marker 7bc53cec1810. Mara watched the eastern gate until dawn.

Ledger 04 line 016: Neri carried the blue token past marker 7b32eccc5b16. Mara watched the eastern gate until dawn.

Ledger 04 line 017: Neri carried the blue token past marker b1e493a536fb. Mara watched the eastern gate until dawn.

Ledger 04 line 018: Neri carried the blue token past marker ee602bfac062. Mara watched the eastern gate until dawn.

Ledger 04 line 019: Neri carried the blue token past marker b699e07f4b16. Mara watched the eastern gate until dawn.

Ledger 04 line 020: Neri carried the blue token past marker 33c32885764c. Mara watched the eastern gate until dawn.

Ledger 04 line 021: Neri carried the blue token past marker 3810157be499. Mara watched the eastern gate until dawn.

Ledger 04 line 022: Neri carried the blue token past marker 46bdfa1e982c. Mara watched the eastern gate until dawn.

Ledger 04 line 023: Neri carried the blue token past marker 6f6730f8acf5. Mara watched the eastern gate until dawn.

Ledger 04 line 024: Neri carried the blue token past marker 75de1f988017. Mara watched the eastern gate until dawn.

Ledger 04 line 025: Neri carried the blue token past marker 170f63c7b49f. Mara watched the eastern gate until dawn.

Ledger 04 line 026: Neri carried the blue token past marker e7645fb73a8f. Mara watched the eastern gate until dawn.

Ledger 04 line 027: Neri carried the blue token past marker 4b5bd68abc6d. Mara watched the eastern gate until dawn.

Ledger 04 line 028: Neri carried the blue token past marker 4f89197993b4. Mara watched the eastern gate until dawn.

Ledger 04 line 029: Neri carried the blue token past marker 4adeb80d1139. Mara watched the eastern gate until dawn.

Ledger 04 line 030: Neri carried the blue token past marker 98050284af53. Mara watched the eastern gate until dawn.

Ledger 04 line 031: Neri carried the blue token past marker 6fef2eca43ca. Mara watched the eastern gate until dawn.

Ledger 04 line 032: Neri carried the blue token past marker 7124add76ab4. Mara watched the eastern gate until dawn.

Ledger 04 line 033: Neri carried the blue token past marker bffb988e39fc. Mara watched the eastern gate until dawn.

Ledger 04 line 034: Neri carried the blue token past marker d27a59160c7f. Mara watched the eastern gate until dawn.

Ledger 04 line 035: Neri carried the blue token past marker f54e2fa0de08. Mara watched the eastern gate until dawn.

Ledger 04 line 036: Neri carried the blue token past marker bfcf3afd8a52. Mara watched the eastern gate until dawn.

Ledger 04 line 037: Neri carried the blue token past marker 3d87fa6c1877. Mara watched the eastern gate until dawn.

Ledger 04 line 038: Neri carried the blue token past marker a0b02d76987a. Mara watched the eastern gate until dawn.

Ledger 04 line 039: Neri carried the blue token past marker 681d4c1be4d3. Mara watched the eastern gate until dawn.

Ledger 04 line 040: Neri carried the blue token past marker a4d5972f71a0. Mara watched the eastern gate until dawn.

Ledger 04 line 041: Neri carried the blue token past marker 4e2be794c53d. Mara watched the eastern gate until dawn.

Ledger 04 line 042: Neri carried the blue token past marker aabb4067e641. Mara watched the eastern gate until dawn.

Ledger 04 line 043: Neri carried the blue token past marker 8e9078dd77c8. Mara watched the eastern gate until dawn.

Ledger 04 line 044: Neri carried the blue token past marker 61d9d4042980. Mara watched the eastern gate until dawn.

Ledger 04 line 045: Neri carried the blue token past marker 302900038c91. Mara watched the eastern gate until dawn.

Ledger 04 line 046: Neri carried the blue token past marker 53b13874b73d. Mara watched the eastern gate until dawn.

Ledger 04 line 047: Neri carried the blue token past marker 84f22b00b8a5. Mara watched the eastern gate until dawn.

Ledger 04 line 048: Neri carried the blue token past marker 6b823b6a96f1. Mara watched the eastern gate until dawn.

Ledger 04 line 049: Neri carried the blue token past marker 3b97fa0d6b01. Mara watched the eastern gate until dawn.

Ledger 04 line 050: Neri carried the blue token past marker afc30da47f40. Mara watched the eastern gate until dawn.

Ledger 04 line 051: Neri carried the blue token past marker 2071c61de945. Mara watched the eastern gate until dawn.

Ledger 04 line 052: Neri carried the blue token past marker 9ae0e0029a5a. Mara watched the eastern gate until dawn.

Ledger 04 line 053: Neri carried the blue token past marker 63f22db33e9a. Mara watched the eastern gate until dawn.

Ledger 04 line 054: Neri carried the blue token past marker c2c88491c060. Mara watched the eastern gate until dawn.

Ledger 04 line 055: Neri carried the blue token past marker 50b2dd884750. Mara watched the eastern gate until dawn.

Ledger 04 line 056: Neri carried the blue token past marker 740abdb8319d. Mara watched the eastern gate until dawn.

Ledger 04 line 057: Neri carried the blue token past marker bf570135bead. Mara watched the eastern gate until dawn.

Ledger 04 line 058: Neri carried the blue token past marker 43bd50df45e0. Mara watched the eastern gate until dawn.

Ledger 04 line 059: Neri carried the blue token past marker ca7da3fc32f8. Mara watched the eastern gate until dawn.

Ledger 04 line 060: Neri carried the blue token past marker 37d03de19dfe. Mara watched the eastern gate until dawn.

Ledger 04 line 061: Neri carried the blue token past marker 4f9646f56797. Mara watched the eastern gate until dawn.

Ledger 04 line 062: Neri carried the blue token past marker 997c2c2c642d. Mara watched the eastern gate until dawn.

Ledger 04 line 063: Neri carried the blue token past marker de13144f9951. Mara watched the eastern gate until dawn.

Ledger 04 line 064: Neri carried the blue token past marker a79ce311731c. Mara watched the eastern gate until dawn.

Ledger 04 line 065: Neri carried the blue token past marker 12df990b975f. Mara watched the eastern gate until dawn.

Ledger 04 line 066: Neri carried the blue token past marker 863a24c4c83c. Mara watched the eastern gate until dawn.

Ledger 04 line 067: Neri carried the blue token past marker 450a96da3d10. Mara watched the eastern gate until dawn.

Ledger 04 line 068: Neri carried the blue token past marker d4339b3962d0. Mara watched the eastern gate until dawn.

Ledger 04 line 069: Neri carried the blue token past marker f24f7dcd38a5. Mara watched the eastern gate until dawn.

Ledger 04 line 070: Neri carried the blue token past marker 4264d6e72c21. Mara watched the eastern gate until dawn.

Ledger 04 line 071: Neri carried the blue token past marker 277b41aef190. Mara watched the eastern gate until dawn.

Ledger 04 line 072: Neri carried the blue token past marker 7d08e50dd2bf. Mara watched the eastern gate until dawn.

Ledger 04 line 073: Neri carried the blue token past marker efc6d4701d04. Mara watched the eastern gate until dawn.

Ledger 04 line 074: Neri carried the blue token past marker 6972a21c48d4. Mara watched the eastern gate until dawn.

Ledger 04 line 075: Neri carried the blue token past marker 0a8c45ebc52d. Mara watched the eastern gate until dawn.

Ledger 04 line 076: Neri carried the blue token past marker 7edc103ff519. Mara watched the eastern gate until dawn.

Ledger 04 line 077: Neri carried the blue token past marker de8b41ab8c3a. Mara watched the eastern gate until dawn.

Ledger 04 line 078: Neri carried the blue token past marker 5677eb58773b. Mara watched the eastern gate until dawn.

Ledger 04 line 079: Neri carried the blue token past marker 065fe2e1ae06. Mara watched the eastern gate until dawn.

Ledger 04 line 080: Neri carried the blue token past marker ec8ddaa09812. Mara watched the eastern gate until dawn.

Ledger 04 line 081: Neri carried the blue token past marker 6cde625a9a18. Mara watched the eastern gate until dawn.

Ledger 04 line 082: Neri carried the blue token past marker 593e8924adbc. Mara watched the eastern gate until dawn.

Ledger 04 line 083: Neri carried the blue token past marker c7b49d335845. Mara watched the eastern gate until dawn.

Ledger 04 line 084: Neri carried the blue token past marker fe30d450ac02. Mara watched the eastern gate until dawn.

Ledger 04 line 085: Neri carried the blue token past marker fe97f06fa286. Mara watched the eastern gate until dawn.

Ledger 04 line 086: Neri carried the blue token past marker 767b71b1708c. Mara watched the eastern gate until dawn.

Ledger 04 line 087: Neri carried the blue token past marker d9bab7c1e1a6. Mara watched the eastern gate until dawn.

Ledger 04 line 088: Neri carried the blue token past marker 7c8c982307a4. Mara watched the eastern gate until dawn.

Ledger 04 line 089: Neri carried the blue token past marker d27917384c85. Mara watched the eastern gate until dawn.

Ledger 04 line 090: Neri carried the blue token past marker 5f82610db22c. Mara watched the eastern gate until dawn.

Ledger 04 line 091: Neri carried the blue token past marker cd1a8c67adca. Mara watched the eastern gate until dawn.

Ledger 04 line 092: Neri carried the blue token past marker 13e3cad016b6. Mara watched the eastern gate until dawn.

Ledger 04 line 093: Neri carried the blue token past marker 9549814572ac. Mara watched the eastern gate until dawn.

Ledger 04 line 094: Neri carried the blue token past marker f005fce17f1b. Mara watched the eastern gate until dawn.

Ledger 04 line 095: Neri carried the blue token past marker 2d18052c2bc6. Mara watched the eastern gate until dawn.

Ledger 04 line 096: Neri carried the blue token past marker 72d3ce3cea50. Mara watched the eastern gate until dawn.

Ledger 04 line 097: Neri carried the blue token past marker 82413ce12829. Mara watched the eastern gate until dawn.

Ledger 04 line 098: Neri carried the blue token past marker 1b8c1bb7e52d. Mara watched the eastern gate until dawn.

Ledger 04 line 099: Neri carried the blue token past marker 9204a01057b5. Mara watched the eastern gate until dawn.

Ledger 04 line 100: Neri carried the blue token past marker 86b2e097a0a8. Mara watched the eastern gate until dawn.

Ledger 04 line 101: Neri carried the blue token past marker 6fe460033eb9. Mara watched the eastern gate until dawn.

Ledger 04 line 102: Neri carried the blue token past marker ffdbeeea7a1a. Mara watched the eastern gate until dawn.

Ledger 04 line 103: Neri carried the blue token past marker f7744a17cee6. Mara watched the eastern gate until dawn.

Ledger 04 line 104: Neri carried the blue token past marker e440480bcfaf. Mara watched the eastern gate until dawn.

Ledger 04 line 105: Neri carried the blue token past marker 3c1a2dea3623. Mara watched the eastern gate until dawn.

Ledger 04 line 106: Neri carried the blue token past marker bb7041d478b0. Mara watched the eastern gate until dawn.

Ledger 04 line 107: Neri carried the blue token past marker f2f0844a39cd. Mara watched the eastern gate until dawn.

Ledger 04 line 108: Neri carried the blue token past marker 6d52df69caad. Mara watched the eastern gate until dawn.

Ledger 04 line 109: Neri carried the blue token past marker 0708968dfa2a. Mara watched the eastern gate until dawn.

Ledger 04 line 110: Neri carried the blue token past marker 9ed2867099d4. Mara watched the eastern gate until dawn.

Ledger 04 line 111: Neri carried the blue token past marker 8bbddc37a977. Mara watched the eastern gate until dawn.

Ledger 04 line 112: Neri carried the blue token past marker 52e8565805ed. Mara watched the eastern gate until dawn.

Ledger 04 line 113: Neri carried the blue token past marker d6179b29c9a3. Mara watched the eastern gate until dawn.

Ledger 04 line 114: Neri carried the blue token past marker 6517ac7308c6. Mara watched the eastern gate until dawn.

Ledger 04 line 115: Neri carried the blue token past marker 4c8e0bf40ebd. Mara watched the eastern gate until dawn.

Ledger 04 line 116: Neri carried the blue token past marker a6f3ab2d316c. Mara watched the eastern gate until dawn.

Ledger 04 line 117: Neri carried the blue token past marker 9eb1e572f316. Mara watched the eastern gate until dawn.

Ledger 04 line 118: Neri carried the blue token past marker 50eede9bdd6f. Mara watched the eastern gate until dawn.

Ledger 04 line 119: Neri carried the blue token past marker 51682b16ab4d. Mara watched the eastern gate until dawn.

Ledger 04 line 120: Neri carried the blue token past marker 2a3a3971a023. Mara watched the eastern gate until dawn.

Ledger 04 line 121: Neri carried the blue token past marker 778561c69540. Mara watched the eastern gate until dawn.

Ledger 04 line 122: Neri carried the blue token past marker d848d0bd9f18. Mara watched the eastern gate until dawn.

Ledger 04 line 123: Neri carried the blue token past marker 401ddc156792. Mara watched the eastern gate until dawn.

Ledger 04 line 124: Neri carried the blue token past marker b2c7d8ee162e. Mara watched the eastern gate until dawn.

Ledger 04 line 125: Neri carried the blue token past marker 978cbaf11e53. Mara watched the eastern gate until dawn.

Ledger 04 line 126: Neri carried the blue token past marker d21db6a49a98. Mara watched the eastern gate until dawn.

Ledger 04 line 127: Neri carried the blue token past marker 4a816cbb6faa. Mara watched the eastern gate until dawn.

Ledger 04 line 128: Neri carried the blue token past marker d194f2642e55. Mara watched the eastern gate until dawn.

Ledger 04 line 129: Neri carried the blue token past marker 9236bb22dab2. Mara watched the eastern gate until dawn.

Ledger 04 line 130: Neri carried the blue token past marker f7b156167817. Mara watched the eastern gate until dawn.

Ledger 04 line 131: Neri carried the blue token past marker 3ad52765687e. Mara watched the eastern gate until dawn.

Ledger 04 line 132: Neri carried the blue token past marker 6bfe27fc7166. Mara watched the eastern gate until dawn.

Ledger 04 line 133: Neri carried the blue token past marker 9f928bddd5f8. Mara watched the eastern gate until dawn.

Ledger 04 line 134: Neri carried the blue token past marker 4077d1ba132d. Mara watched the eastern gate until dawn.

Ledger 04 line 135: Neri carried the blue token past marker 132fc13b898f. Mara watched the eastern gate until dawn.

Ledger 04 line 136: Neri carried the blue token past marker ed448e1fecbd. Mara watched the eastern gate until dawn.

Ledger 04 line 137: Neri carried the blue token past marker 199ccb806eb5. Mara watched the eastern gate until dawn.

Ledger 04 line 138: Neri carried the blue token past marker 09a614364018. Mara watched the eastern gate until dawn.

Ledger 04 line 139: Neri carried the blue token past marker 3758c4f62240. Mara watched the eastern gate until dawn.

Ledger 04 line 140: Neri carried the blue token past marker b6b587c2fda5. Mara watched the eastern gate until dawn.
