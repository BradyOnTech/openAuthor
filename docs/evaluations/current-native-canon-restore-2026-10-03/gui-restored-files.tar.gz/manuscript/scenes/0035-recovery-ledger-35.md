---
id: scene-0035
title: Recovery ledger 35
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.171445+00:00
updated_at: 2026-10-03T12:14:52.171445+00:00
---

Ledger 35 line 001: Neri carried the blue token past marker 1536a7371d34. Mara watched the eastern gate until dawn.

Ledger 35 line 002: Neri carried the blue token past marker 840bca696cf9. Mara watched the eastern gate until dawn.

Ledger 35 line 003: Neri carried the blue token past marker 3e7d348f1776. Mara watched the eastern gate until dawn.

Ledger 35 line 004: Neri carried the blue token past marker 61b98d7f9a8b. Mara watched the eastern gate until dawn.

Ledger 35 line 005: Neri carried the blue token past marker 4d795e220cc9. Mara watched the eastern gate until dawn.

Ledger 35 line 006: Neri carried the blue token past marker 547f5d607574. Mara watched the eastern gate until dawn.

Ledger 35 line 007: Neri carried the blue token past marker 9ca7631b7169. Mara watched the eastern gate until dawn.

Ledger 35 line 008: Neri carried the blue token past marker c6f23875ea64. Mara watched the eastern gate until dawn.

Ledger 35 line 009: Neri carried the blue token past marker f7271eeaafd5. Mara watched the eastern gate until dawn.

Ledger 35 line 010: Neri carried the blue token past marker 77a058c87480. Mara watched the eastern gate until dawn.

Ledger 35 line 011: Neri carried the blue token past marker 6c51d0326cbb. Mara watched the eastern gate until dawn.

Ledger 35 line 012: Neri carried the blue token past marker f4bd7f3d5f7b. Mara watched the eastern gate until dawn.

Ledger 35 line 013: Neri carried the blue token past marker 2d82b596d444. Mara watched the eastern gate until dawn.

Ledger 35 line 014: Neri carried the blue token past marker 28dbda1fac3f. Mara watched the eastern gate until dawn.

Ledger 35 line 015: Neri carried the blue token past marker 4917cb1bbd58. Mara watched the eastern gate until dawn.

Ledger 35 line 016: Neri carried the blue token past marker 1ebfc2ff1137. Mara watched the eastern gate until dawn.

Ledger 35 line 017: Neri carried the blue token past marker e59009a33a34. Mara watched the eastern gate until dawn.

Ledger 35 line 018: Neri carried the blue token past marker 6632d85a64b8. Mara watched the eastern gate until dawn.

Ledger 35 line 019: Neri carried the blue token past marker f2e45e5dd4de. Mara watched the eastern gate until dawn.

Ledger 35 line 020: Neri carried the blue token past marker 03971342170b. Mara watched the eastern gate until dawn.

Ledger 35 line 021: Neri carried the blue token past marker 92e38aa812a9. Mara watched the eastern gate until dawn.

Ledger 35 line 022: Neri carried the blue token past marker 969e5af8122f. Mara watched the eastern gate until dawn.

Ledger 35 line 023: Neri carried the blue token past marker 555cbb724be0. Mara watched the eastern gate until dawn.

Ledger 35 line 024: Neri carried the blue token past marker a94776a7f68d. Mara watched the eastern gate until dawn.

Ledger 35 line 025: Neri carried the blue token past marker 7af6a3fe1c12. Mara watched the eastern gate until dawn.

Ledger 35 line 026: Neri carried the blue token past marker 24a88f6babd6. Mara watched the eastern gate until dawn.

Ledger 35 line 027: Neri carried the blue token past marker 61c2ce667351. Mara watched the eastern gate until dawn.

Ledger 35 line 028: Neri carried the blue token past marker dbc7ded287fb. Mara watched the eastern gate until dawn.

Ledger 35 line 029: Neri carried the blue token past marker 637368b03120. Mara watched the eastern gate until dawn.

Ledger 35 line 030: Neri carried the blue token past marker 96da033aad8e. Mara watched the eastern gate until dawn.

Ledger 35 line 031: Neri carried the blue token past marker 8703b79bec7c. Mara watched the eastern gate until dawn.

Ledger 35 line 032: Neri carried the blue token past marker 75191989c5ba. Mara watched the eastern gate until dawn.

Ledger 35 line 033: Neri carried the blue token past marker bdbe95d7d6ac. Mara watched the eastern gate until dawn.

Ledger 35 line 034: Neri carried the blue token past marker 5d67b6b8b82b. Mara watched the eastern gate until dawn.

Ledger 35 line 035: Neri carried the blue token past marker 02a45f1a4bf8. Mara watched the eastern gate until dawn.

Ledger 35 line 036: Neri carried the blue token past marker 6600763dffde. Mara watched the eastern gate until dawn.

Ledger 35 line 037: Neri carried the blue token past marker 33a015c21b5f. Mara watched the eastern gate until dawn.

Ledger 35 line 038: Neri carried the blue token past marker 1c1d7fcc5d2a. Mara watched the eastern gate until dawn.

Ledger 35 line 039: Neri carried the blue token past marker 3fdf0de8bd09. Mara watched the eastern gate until dawn.

Ledger 35 line 040: Neri carried the blue token past marker 17ee7ea77755. Mara watched the eastern gate until dawn.

Ledger 35 line 041: Neri carried the blue token past marker 88954f32ebb2. Mara watched the eastern gate until dawn.

Ledger 35 line 042: Neri carried the blue token past marker 66bb45caa5c1. Mara watched the eastern gate until dawn.

Ledger 35 line 043: Neri carried the blue token past marker 3588d534f57f. Mara watched the eastern gate until dawn.

Ledger 35 line 044: Neri carried the blue token past marker 787cf03e8d4b. Mara watched the eastern gate until dawn.

Ledger 35 line 045: Neri carried the blue token past marker 5b2841b630dd. Mara watched the eastern gate until dawn.

Ledger 35 line 046: Neri carried the blue token past marker 6d28679a997a. Mara watched the eastern gate until dawn.

Ledger 35 line 047: Neri carried the blue token past marker 4615b0ad246c. Mara watched the eastern gate until dawn.

Ledger 35 line 048: Neri carried the blue token past marker fae7cea9d3b0. Mara watched the eastern gate until dawn.

Ledger 35 line 049: Neri carried the blue token past marker 658cbbf2896d. Mara watched the eastern gate until dawn.

Ledger 35 line 050: Neri carried the blue token past marker 80399fd6a7bd. Mara watched the eastern gate until dawn.

Ledger 35 line 051: Neri carried the blue token past marker b8c1fa739241. Mara watched the eastern gate until dawn.

Ledger 35 line 052: Neri carried the blue token past marker 45838068d967. Mara watched the eastern gate until dawn.

Ledger 35 line 053: Neri carried the blue token past marker 9fd0b2d9182e. Mara watched the eastern gate until dawn.

Ledger 35 line 054: Neri carried the blue token past marker 13745be2d322. Mara watched the eastern gate until dawn.

Ledger 35 line 055: Neri carried the blue token past marker 85cdfeffea09. Mara watched the eastern gate until dawn.

Ledger 35 line 056: Neri carried the blue token past marker 9747986f5d8d. Mara watched the eastern gate until dawn.

Ledger 35 line 057: Neri carried the blue token past marker 1ac260a21208. Mara watched the eastern gate until dawn.

Ledger 35 line 058: Neri carried the blue token past marker 57ee0de21a5f. Mara watched the eastern gate until dawn.

Ledger 35 line 059: Neri carried the blue token past marker 44dd2164876a. Mara watched the eastern gate until dawn.

Ledger 35 line 060: Neri carried the blue token past marker 8ec9194b7904. Mara watched the eastern gate until dawn.

Ledger 35 line 061: Neri carried the blue token past marker 8956ed103221. Mara watched the eastern gate until dawn.

Ledger 35 line 062: Neri carried the blue token past marker 1feee4907408. Mara watched the eastern gate until dawn.

Ledger 35 line 063: Neri carried the blue token past marker 3b26136a1ba0. Mara watched the eastern gate until dawn.

Ledger 35 line 064: Neri carried the blue token past marker 358d7849efd1. Mara watched the eastern gate until dawn.

Ledger 35 line 065: Neri carried the blue token past marker 96b0f6837a28. Mara watched the eastern gate until dawn.

Ledger 35 line 066: Neri carried the blue token past marker 3a12e5a632b5. Mara watched the eastern gate until dawn.

Ledger 35 line 067: Neri carried the blue token past marker c217b515a446. Mara watched the eastern gate until dawn.

Ledger 35 line 068: Neri carried the blue token past marker 9761042db13e. Mara watched the eastern gate until dawn.

Ledger 35 line 069: Neri carried the blue token past marker 7294a0b1b221. Mara watched the eastern gate until dawn.

Ledger 35 line 070: Neri carried the blue token past marker 14764f7a0062. Mara watched the eastern gate until dawn.

Ledger 35 line 071: Neri carried the blue token past marker 22363aaf3278. Mara watched the eastern gate until dawn.

Ledger 35 line 072: Neri carried the blue token past marker 6ed6f73d2735. Mara watched the eastern gate until dawn.

Ledger 35 line 073: Neri carried the blue token past marker 983d94f6f6a7. Mara watched the eastern gate until dawn.

Ledger 35 line 074: Neri carried the blue token past marker 6e6d4e5a3d7d. Mara watched the eastern gate until dawn.

Ledger 35 line 075: Neri carried the blue token past marker 4a4bc1885009. Mara watched the eastern gate until dawn.

Ledger 35 line 076: Neri carried the blue token past marker 5ff20897e26a. Mara watched the eastern gate until dawn.

Ledger 35 line 077: Neri carried the blue token past marker f16b093e7d09. Mara watched the eastern gate until dawn.

Ledger 35 line 078: Neri carried the blue token past marker b95d45df1f05. Mara watched the eastern gate until dawn.

Ledger 35 line 079: Neri carried the blue token past marker 8874bb44022e. Mara watched the eastern gate until dawn.

Ledger 35 line 080: Neri carried the blue token past marker af9667c81f24. Mara watched the eastern gate until dawn.

Ledger 35 line 081: Neri carried the blue token past marker 7e6ef0295b4c. Mara watched the eastern gate until dawn.

Ledger 35 line 082: Neri carried the blue token past marker 5b8b1f4ebf45. Mara watched the eastern gate until dawn.

Ledger 35 line 083: Neri carried the blue token past marker c4166aab0db1. Mara watched the eastern gate until dawn.

Ledger 35 line 084: Neri carried the blue token past marker c57b47afb098. Mara watched the eastern gate until dawn.

Ledger 35 line 085: Neri carried the blue token past marker b8568d0740c4. Mara watched the eastern gate until dawn.

Ledger 35 line 086: Neri carried the blue token past marker 246357d14d69. Mara watched the eastern gate until dawn.

Ledger 35 line 087: Neri carried the blue token past marker c49118f8be3f. Mara watched the eastern gate until dawn.

Ledger 35 line 088: Neri carried the blue token past marker 82232fa1f5b1. Mara watched the eastern gate until dawn.

Ledger 35 line 089: Neri carried the blue token past marker ecf9666a962c. Mara watched the eastern gate until dawn.

Ledger 35 line 090: Neri carried the blue token past marker 919fc1db7a51. Mara watched the eastern gate until dawn.

Ledger 35 line 091: Neri carried the blue token past marker 978925cab010. Mara watched the eastern gate until dawn.

Ledger 35 line 092: Neri carried the blue token past marker b72e2120755b. Mara watched the eastern gate until dawn.

Ledger 35 line 093: Neri carried the blue token past marker 1e34dd8d4a63. Mara watched the eastern gate until dawn.

Ledger 35 line 094: Neri carried the blue token past marker d574ed1eb67d. Mara watched the eastern gate until dawn.

Ledger 35 line 095: Neri carried the blue token past marker 1557c6787503. Mara watched the eastern gate until dawn.

Ledger 35 line 096: Neri carried the blue token past marker f417843efdc5. Mara watched the eastern gate until dawn.

Ledger 35 line 097: Neri carried the blue token past marker b052e5a1efc2. Mara watched the eastern gate until dawn.

Ledger 35 line 098: Neri carried the blue token past marker 6f06aa6ce970. Mara watched the eastern gate until dawn.

Ledger 35 line 099: Neri carried the blue token past marker e790976c7b3d. Mara watched the eastern gate until dawn.

Ledger 35 line 100: Neri carried the blue token past marker 78e115c978dc. Mara watched the eastern gate until dawn.

Ledger 35 line 101: Neri carried the blue token past marker ff53dfc1ea65. Mara watched the eastern gate until dawn.

Ledger 35 line 102: Neri carried the blue token past marker bbbc899d15b3. Mara watched the eastern gate until dawn.

Ledger 35 line 103: Neri carried the blue token past marker 4ad640f86260. Mara watched the eastern gate until dawn.

Ledger 35 line 104: Neri carried the blue token past marker 17e89d5aa273. Mara watched the eastern gate until dawn.

Ledger 35 line 105: Neri carried the blue token past marker 5c393655dd84. Mara watched the eastern gate until dawn.

Ledger 35 line 106: Neri carried the blue token past marker 1bc472156a4c. Mara watched the eastern gate until dawn.

Ledger 35 line 107: Neri carried the blue token past marker a774e4b007da. Mara watched the eastern gate until dawn.

Ledger 35 line 108: Neri carried the blue token past marker 08cbb8dae0f5. Mara watched the eastern gate until dawn.

Ledger 35 line 109: Neri carried the blue token past marker 3f930185e7ae. Mara watched the eastern gate until dawn.

Ledger 35 line 110: Neri carried the blue token past marker e5948d122c63. Mara watched the eastern gate until dawn.

Ledger 35 line 111: Neri carried the blue token past marker f18e7af1792c. Mara watched the eastern gate until dawn.

Ledger 35 line 112: Neri carried the blue token past marker 1534ca9f684c. Mara watched the eastern gate until dawn.

Ledger 35 line 113: Neri carried the blue token past marker 172de29f6ea5. Mara watched the eastern gate until dawn.

Ledger 35 line 114: Neri carried the blue token past marker 302037d7c187. Mara watched the eastern gate until dawn.

Ledger 35 line 115: Neri carried the blue token past marker ebf81a1ddba8. Mara watched the eastern gate until dawn.

Ledger 35 line 116: Neri carried the blue token past marker ea31d6374b3d. Mara watched the eastern gate until dawn.

Ledger 35 line 117: Neri carried the blue token past marker 2303b0a90065. Mara watched the eastern gate until dawn.

Ledger 35 line 118: Neri carried the blue token past marker 80387aa8d475. Mara watched the eastern gate until dawn.

Ledger 35 line 119: Neri carried the blue token past marker 3f7a48daae48. Mara watched the eastern gate until dawn.

Ledger 35 line 120: Neri carried the blue token past marker b9c0af963a35. Mara watched the eastern gate until dawn.

Ledger 35 line 121: Neri carried the blue token past marker 66a00316d7ac. Mara watched the eastern gate until dawn.

Ledger 35 line 122: Neri carried the blue token past marker 681dbebbc41f. Mara watched the eastern gate until dawn.

Ledger 35 line 123: Neri carried the blue token past marker 7cbfd5f4250c. Mara watched the eastern gate until dawn.

Ledger 35 line 124: Neri carried the blue token past marker cf35dbd1a090. Mara watched the eastern gate until dawn.

Ledger 35 line 125: Neri carried the blue token past marker 2b3b7098f782. Mara watched the eastern gate until dawn.

Ledger 35 line 126: Neri carried the blue token past marker 2a0dd92df4af. Mara watched the eastern gate until dawn.

Ledger 35 line 127: Neri carried the blue token past marker 546df50a2597. Mara watched the eastern gate until dawn.

Ledger 35 line 128: Neri carried the blue token past marker 45340c971435. Mara watched the eastern gate until dawn.

Ledger 35 line 129: Neri carried the blue token past marker 4fa6d7fbb629. Mara watched the eastern gate until dawn.

Ledger 35 line 130: Neri carried the blue token past marker db2f047db08c. Mara watched the eastern gate until dawn.

Ledger 35 line 131: Neri carried the blue token past marker 54a9c9650c6f. Mara watched the eastern gate until dawn.

Ledger 35 line 132: Neri carried the blue token past marker 4fe0e3110fcb. Mara watched the eastern gate until dawn.

Ledger 35 line 133: Neri carried the blue token past marker aa6ee5d8f963. Mara watched the eastern gate until dawn.

Ledger 35 line 134: Neri carried the blue token past marker ac25730a1996. Mara watched the eastern gate until dawn.

Ledger 35 line 135: Neri carried the blue token past marker 9c3fdb46e112. Mara watched the eastern gate until dawn.

Ledger 35 line 136: Neri carried the blue token past marker 2acb966a505e. Mara watched the eastern gate until dawn.

Ledger 35 line 137: Neri carried the blue token past marker b8eaeeece857. Mara watched the eastern gate until dawn.

Ledger 35 line 138: Neri carried the blue token past marker 8cc73b2be69f. Mara watched the eastern gate until dawn.

Ledger 35 line 139: Neri carried the blue token past marker 58f181aa7bb2. Mara watched the eastern gate until dawn.

Ledger 35 line 140: Neri carried the blue token past marker 9fb0d458e886. Mara watched the eastern gate until dawn.
