---
id: scene-0062
title: Recovery ledger 62
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.186030+00:00
updated_at: 2026-10-03T12:14:52.186030+00:00
---

Ledger 62 line 001: Neri carried the blue token past marker 1384e6fc97c5. Mara watched the eastern gate until dawn.

Ledger 62 line 002: Neri carried the blue token past marker f7330d5510b4. Mara watched the eastern gate until dawn.

Ledger 62 line 003: Neri carried the blue token past marker 4ebf9aa998aa. Mara watched the eastern gate until dawn.

Ledger 62 line 004: Neri carried the blue token past marker 0aed3cab781d. Mara watched the eastern gate until dawn.

Ledger 62 line 005: Neri carried the blue token past marker 709faa6debe5. Mara watched the eastern gate until dawn.

Ledger 62 line 006: Neri carried the blue token past marker a8e8fe353d7d. Mara watched the eastern gate until dawn.

Ledger 62 line 007: Neri carried the blue token past marker c71630d4f048. Mara watched the eastern gate until dawn.

Ledger 62 line 008: Neri carried the blue token past marker 7af8c5863e99. Mara watched the eastern gate until dawn.

Ledger 62 line 009: Neri carried the blue token past marker 2f753374edeb. Mara watched the eastern gate until dawn.

Ledger 62 line 010: Neri carried the blue token past marker 10fc50bea37d. Mara watched the eastern gate until dawn.

Ledger 62 line 011: Neri carried the blue token past marker f2bd2d55b32b. Mara watched the eastern gate until dawn.

Ledger 62 line 012: Neri carried the blue token past marker c58ad444039d. Mara watched the eastern gate until dawn.

Ledger 62 line 013: Neri carried the blue token past marker 090961b3b8e4. Mara watched the eastern gate until dawn.

Ledger 62 line 014: Neri carried the blue token past marker 14ee7fd70ae2. Mara watched the eastern gate until dawn.

Ledger 62 line 015: Neri carried the blue token past marker 6c91a300eeea. Mara watched the eastern gate until dawn.

Ledger 62 line 016: Neri carried the blue token past marker b56558d1286f. Mara watched the eastern gate until dawn.

Ledger 62 line 017: Neri carried the blue token past marker 7a7b20b3aaae. Mara watched the eastern gate until dawn.

Ledger 62 line 018: Neri carried the blue token past marker 20679f77b2f1. Mara watched the eastern gate until dawn.

Ledger 62 line 019: Neri carried the blue token past marker cd3cfa662800. Mara watched the eastern gate until dawn.

Ledger 62 line 020: Neri carried the blue token past marker c85f9ec03610. Mara watched the eastern gate until dawn.

Ledger 62 line 021: Neri carried the blue token past marker 61dc61aaf250. Mara watched the eastern gate until dawn.

Ledger 62 line 022: Neri carried the blue token past marker 7c385568cf3a. Mara watched the eastern gate until dawn.

Ledger 62 line 023: Neri carried the blue token past marker 4864380c89b1. Mara watched the eastern gate until dawn.

Ledger 62 line 024: Neri carried the blue token past marker 94645b0bd110. Mara watched the eastern gate until dawn.

Ledger 62 line 025: Neri carried the blue token past marker 2b642607eebc. Mara watched the eastern gate until dawn.

Ledger 62 line 026: Neri carried the blue token past marker b36a2694b4c7. Mara watched the eastern gate until dawn.

Ledger 62 line 027: Neri carried the blue token past marker 7ffe31d5bd96. Mara watched the eastern gate until dawn.

Ledger 62 line 028: Neri carried the blue token past marker da2f07b6ade3. Mara watched the eastern gate until dawn.

Ledger 62 line 029: Neri carried the blue token past marker 5e39fb1dbffc. Mara watched the eastern gate until dawn.

Ledger 62 line 030: Neri carried the blue token past marker 804d71205540. Mara watched the eastern gate until dawn.

Ledger 62 line 031: Neri carried the blue token past marker d760153dba40. Mara watched the eastern gate until dawn.

Ledger 62 line 032: Neri carried the blue token past marker 267f665c83ec. Mara watched the eastern gate until dawn.

Ledger 62 line 033: Neri carried the blue token past marker 4e8d9dbcd507. Mara watched the eastern gate until dawn.

Ledger 62 line 034: Neri carried the blue token past marker 028934ee5022. Mara watched the eastern gate until dawn.

Ledger 62 line 035: Neri carried the blue token past marker 4ccd150964b1. Mara watched the eastern gate until dawn.

Ledger 62 line 036: Neri carried the blue token past marker a185a4bbffc9. Mara watched the eastern gate until dawn.

Ledger 62 line 037: Neri carried the blue token past marker 0050d24f8544. Mara watched the eastern gate until dawn.

Ledger 62 line 038: Neri carried the blue token past marker debb89c8c478. Mara watched the eastern gate until dawn.

Ledger 62 line 039: Neri carried the blue token past marker a285b3a02ebe. Mara watched the eastern gate until dawn.

Ledger 62 line 040: Neri carried the blue token past marker def06f02d393. Mara watched the eastern gate until dawn.

Ledger 62 line 041: Neri carried the blue token past marker ea483095082f. Mara watched the eastern gate until dawn.

Ledger 62 line 042: Neri carried the blue token past marker b14e8880bd71. Mara watched the eastern gate until dawn.

Ledger 62 line 043: Neri carried the blue token past marker 63c8e9fef37a. Mara watched the eastern gate until dawn.

Ledger 62 line 044: Neri carried the blue token past marker 9f20ca642063. Mara watched the eastern gate until dawn.

Ledger 62 line 045: Neri carried the blue token past marker 0317b9f1811c. Mara watched the eastern gate until dawn.

Ledger 62 line 046: Neri carried the blue token past marker 03cffc4b61e7. Mara watched the eastern gate until dawn.

Ledger 62 line 047: Neri carried the blue token past marker 3924315cf10c. Mara watched the eastern gate until dawn.

Ledger 62 line 048: Neri carried the blue token past marker ee39c3f31435. Mara watched the eastern gate until dawn.

Ledger 62 line 049: Neri carried the blue token past marker b54ce91ff2b6. Mara watched the eastern gate until dawn.

Ledger 62 line 050: Neri carried the blue token past marker 47e81abe6b96. Mara watched the eastern gate until dawn.

Ledger 62 line 051: Neri carried the blue token past marker bb0d398dc39a. Mara watched the eastern gate until dawn.

Ledger 62 line 052: Neri carried the blue token past marker e19565968a39. Mara watched the eastern gate until dawn.

Ledger 62 line 053: Neri carried the blue token past marker a619d01825e3. Mara watched the eastern gate until dawn.

Ledger 62 line 054: Neri carried the blue token past marker e8273360120d. Mara watched the eastern gate until dawn.

Ledger 62 line 055: Neri carried the blue token past marker f455c6ac6a62. Mara watched the eastern gate until dawn.

Ledger 62 line 056: Neri carried the blue token past marker 822558bb662d. Mara watched the eastern gate until dawn.

Ledger 62 line 057: Neri carried the blue token past marker 5c4248d2c9ad. Mara watched the eastern gate until dawn.

Ledger 62 line 058: Neri carried the blue token past marker 68fe8e6d1ec1. Mara watched the eastern gate until dawn.

Ledger 62 line 059: Neri carried the blue token past marker b431b7bb2e4b. Mara watched the eastern gate until dawn.

Ledger 62 line 060: Neri carried the blue token past marker 9f8f93539d86. Mara watched the eastern gate until dawn.

Ledger 62 line 061: Neri carried the blue token past marker e6c7476edb94. Mara watched the eastern gate until dawn.

Ledger 62 line 062: Neri carried the blue token past marker 88be4154c67c. Mara watched the eastern gate until dawn.

Ledger 62 line 063: Neri carried the blue token past marker 0232ff6f7249. Mara watched the eastern gate until dawn.

Ledger 62 line 064: Neri carried the blue token past marker 675ce1fc3635. Mara watched the eastern gate until dawn.

Ledger 62 line 065: Neri carried the blue token past marker 09c4ba264908. Mara watched the eastern gate until dawn.

Ledger 62 line 066: Neri carried the blue token past marker 33b9364b6b87. Mara watched the eastern gate until dawn.

Ledger 62 line 067: Neri carried the blue token past marker b2571883e309. Mara watched the eastern gate until dawn.

Ledger 62 line 068: Neri carried the blue token past marker a9a46504f7bf. Mara watched the eastern gate until dawn.

Ledger 62 line 069: Neri carried the blue token past marker db78a87a3851. Mara watched the eastern gate until dawn.

Ledger 62 line 070: Neri carried the blue token past marker aae3d5ec484f. Mara watched the eastern gate until dawn.

Ledger 62 line 071: Neri carried the blue token past marker 1dd6a258d0fd. Mara watched the eastern gate until dawn.

Ledger 62 line 072: Neri carried the blue token past marker 3fbec1398d3c. Mara watched the eastern gate until dawn.

Ledger 62 line 073: Neri carried the blue token past marker a5e79dfe01c4. Mara watched the eastern gate until dawn.

Ledger 62 line 074: Neri carried the blue token past marker 58be83086739. Mara watched the eastern gate until dawn.

Ledger 62 line 075: Neri carried the blue token past marker 474d72810a42. Mara watched the eastern gate until dawn.

Ledger 62 line 076: Neri carried the blue token past marker db2138eb1f0d. Mara watched the eastern gate until dawn.

Ledger 62 line 077: Neri carried the blue token past marker 18bcd190cd69. Mara watched the eastern gate until dawn.

Ledger 62 line 078: Neri carried the blue token past marker a66703ef3e04. Mara watched the eastern gate until dawn.

Ledger 62 line 079: Neri carried the blue token past marker 9e237a064452. Mara watched the eastern gate until dawn.

Ledger 62 line 080: Neri carried the blue token past marker 167c7dd4596b. Mara watched the eastern gate until dawn.

Ledger 62 line 081: Neri carried the blue token past marker fd26c696d7fd. Mara watched the eastern gate until dawn.

Ledger 62 line 082: Neri carried the blue token past marker 9f06bf802b21. Mara watched the eastern gate until dawn.

Ledger 62 line 083: Neri carried the blue token past marker 36bc7352bf5b. Mara watched the eastern gate until dawn.

Ledger 62 line 084: Neri carried the blue token past marker 6986356afa9e. Mara watched the eastern gate until dawn.

Ledger 62 line 085: Neri carried the blue token past marker 66d6118297ce. Mara watched the eastern gate until dawn.

Ledger 62 line 086: Neri carried the blue token past marker 5b0f21343f68. Mara watched the eastern gate until dawn.

Ledger 62 line 087: Neri carried the blue token past marker 9aa087c8bf59. Mara watched the eastern gate until dawn.

Ledger 62 line 088: Neri carried the blue token past marker a2d4a51d7830. Mara watched the eastern gate until dawn.

Ledger 62 line 089: Neri carried the blue token past marker baa992a1c2a4. Mara watched the eastern gate until dawn.

Ledger 62 line 090: Neri carried the blue token past marker 0b556aa0fdbe. Mara watched the eastern gate until dawn.

Ledger 62 line 091: Neri carried the blue token past marker 50aa5933ba14. Mara watched the eastern gate until dawn.

Ledger 62 line 092: Neri carried the blue token past marker abfc5aab3281. Mara watched the eastern gate until dawn.

Ledger 62 line 093: Neri carried the blue token past marker 72e9ab413c48. Mara watched the eastern gate until dawn.

Ledger 62 line 094: Neri carried the blue token past marker 0fdb56b2fa73. Mara watched the eastern gate until dawn.

Ledger 62 line 095: Neri carried the blue token past marker b99a38a00645. Mara watched the eastern gate until dawn.

Ledger 62 line 096: Neri carried the blue token past marker c5f322cd6a27. Mara watched the eastern gate until dawn.

Ledger 62 line 097: Neri carried the blue token past marker 5348a1a2d1e9. Mara watched the eastern gate until dawn.

Ledger 62 line 098: Neri carried the blue token past marker 7602afebf70a. Mara watched the eastern gate until dawn.

Ledger 62 line 099: Neri carried the blue token past marker 2adf4989e813. Mara watched the eastern gate until dawn.

Ledger 62 line 100: Neri carried the blue token past marker f43670e3311e. Mara watched the eastern gate until dawn.

Ledger 62 line 101: Neri carried the blue token past marker e352b05baefb. Mara watched the eastern gate until dawn.

Ledger 62 line 102: Neri carried the blue token past marker 8c68e2819e7f. Mara watched the eastern gate until dawn.

Ledger 62 line 103: Neri carried the blue token past marker 69b9a452aa04. Mara watched the eastern gate until dawn.

Ledger 62 line 104: Neri carried the blue token past marker 30463d7a469c. Mara watched the eastern gate until dawn.

Ledger 62 line 105: Neri carried the blue token past marker 82d1c841fd63. Mara watched the eastern gate until dawn.

Ledger 62 line 106: Neri carried the blue token past marker 7194f732708f. Mara watched the eastern gate until dawn.

Ledger 62 line 107: Neri carried the blue token past marker 7c127d9726e4. Mara watched the eastern gate until dawn.

Ledger 62 line 108: Neri carried the blue token past marker 6b2ecec7ff88. Mara watched the eastern gate until dawn.

Ledger 62 line 109: Neri carried the blue token past marker 57ce44a827cd. Mara watched the eastern gate until dawn.

Ledger 62 line 110: Neri carried the blue token past marker e23feec276ef. Mara watched the eastern gate until dawn.

Ledger 62 line 111: Neri carried the blue token past marker cd6149b6c8f0. Mara watched the eastern gate until dawn.

Ledger 62 line 112: Neri carried the blue token past marker 0ffcb853f16b. Mara watched the eastern gate until dawn.

Ledger 62 line 113: Neri carried the blue token past marker 3e8547bd769e. Mara watched the eastern gate until dawn.

Ledger 62 line 114: Neri carried the blue token past marker 04421efa6584. Mara watched the eastern gate until dawn.

Ledger 62 line 115: Neri carried the blue token past marker 8e6bb8b58c85. Mara watched the eastern gate until dawn.

Ledger 62 line 116: Neri carried the blue token past marker c85cd3b8c888. Mara watched the eastern gate until dawn.

Ledger 62 line 117: Neri carried the blue token past marker c073b87fbe56. Mara watched the eastern gate until dawn.

Ledger 62 line 118: Neri carried the blue token past marker 72755b79476f. Mara watched the eastern gate until dawn.

Ledger 62 line 119: Neri carried the blue token past marker 77e4bf1d8e56. Mara watched the eastern gate until dawn.

Ledger 62 line 120: Neri carried the blue token past marker fa8646013c9e. Mara watched the eastern gate until dawn.

Ledger 62 line 121: Neri carried the blue token past marker 5ff1609a1326. Mara watched the eastern gate until dawn.

Ledger 62 line 122: Neri carried the blue token past marker fcfad841e909. Mara watched the eastern gate until dawn.

Ledger 62 line 123: Neri carried the blue token past marker c0d1aca33c32. Mara watched the eastern gate until dawn.

Ledger 62 line 124: Neri carried the blue token past marker 63ce1ea8fee4. Mara watched the eastern gate until dawn.

Ledger 62 line 125: Neri carried the blue token past marker 71dae09a0f9e. Mara watched the eastern gate until dawn.

Ledger 62 line 126: Neri carried the blue token past marker ee8d61d56f16. Mara watched the eastern gate until dawn.

Ledger 62 line 127: Neri carried the blue token past marker 0c16d7b3e2fd. Mara watched the eastern gate until dawn.

Ledger 62 line 128: Neri carried the blue token past marker 4bd6b32606ad. Mara watched the eastern gate until dawn.

Ledger 62 line 129: Neri carried the blue token past marker b6a49221daba. Mara watched the eastern gate until dawn.

Ledger 62 line 130: Neri carried the blue token past marker b4fd7ddbc003. Mara watched the eastern gate until dawn.

Ledger 62 line 131: Neri carried the blue token past marker a24260591abf. Mara watched the eastern gate until dawn.

Ledger 62 line 132: Neri carried the blue token past marker 87a3a4c87844. Mara watched the eastern gate until dawn.

Ledger 62 line 133: Neri carried the blue token past marker e690e783f413. Mara watched the eastern gate until dawn.

Ledger 62 line 134: Neri carried the blue token past marker af5d93b0e75f. Mara watched the eastern gate until dawn.

Ledger 62 line 135: Neri carried the blue token past marker 1eaeec15a8c5. Mara watched the eastern gate until dawn.

Ledger 62 line 136: Neri carried the blue token past marker dd0f622cc12c. Mara watched the eastern gate until dawn.

Ledger 62 line 137: Neri carried the blue token past marker 85447460715d. Mara watched the eastern gate until dawn.

Ledger 62 line 138: Neri carried the blue token past marker d9f217e6856c. Mara watched the eastern gate until dawn.

Ledger 62 line 139: Neri carried the blue token past marker a568fea43fb1. Mara watched the eastern gate until dawn.

Ledger 62 line 140: Neri carried the blue token past marker 793548df6c49. Mara watched the eastern gate until dawn.
