---
id: scene-0017
title: Recovery ledger 17
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.161555+00:00
updated_at: 2026-10-03T12:14:52.161555+00:00
---

Ledger 17 line 001: Neri carried the blue token past marker ec3823491708. Mara watched the eastern gate until dawn.

Ledger 17 line 002: Neri carried the blue token past marker ab10b0c809a5. Mara watched the eastern gate until dawn.

Ledger 17 line 003: Neri carried the blue token past marker ebd7bbd2748e. Mara watched the eastern gate until dawn.

Ledger 17 line 004: Neri carried the blue token past marker d66f28fc07d2. Mara watched the eastern gate until dawn.

Ledger 17 line 005: Neri carried the blue token past marker c9125a318011. Mara watched the eastern gate until dawn.

Ledger 17 line 006: Neri carried the blue token past marker 13d1d8252450. Mara watched the eastern gate until dawn.

Ledger 17 line 007: Neri carried the blue token past marker 7b9b67a5374c. Mara watched the eastern gate until dawn.

Ledger 17 line 008: Neri carried the blue token past marker 4604bfbb473d. Mara watched the eastern gate until dawn.

Ledger 17 line 009: Neri carried the blue token past marker 2a2116ed0dab. Mara watched the eastern gate until dawn.

Ledger 17 line 010: Neri carried the blue token past marker b341e4d47737. Mara watched the eastern gate until dawn.

Ledger 17 line 011: Neri carried the blue token past marker 399d6262dbe3. Mara watched the eastern gate until dawn.

Ledger 17 line 012: Neri carried the blue token past marker 426cc2a5ba30. Mara watched the eastern gate until dawn.

Ledger 17 line 013: Neri carried the blue token past marker fce83339d46d. Mara watched the eastern gate until dawn.

Ledger 17 line 014: Neri carried the blue token past marker 33ea8bfc8cee. Mara watched the eastern gate until dawn.

Ledger 17 line 015: Neri carried the blue token past marker 809a57cd2bd2. Mara watched the eastern gate until dawn.

Ledger 17 line 016: Neri carried the blue token past marker 87562543231d. Mara watched the eastern gate until dawn.

Ledger 17 line 017: Neri carried the blue token past marker ccb6c6fe4fde. Mara watched the eastern gate until dawn.

Ledger 17 line 018: Neri carried the blue token past marker c4ca4833f060. Mara watched the eastern gate until dawn.

Ledger 17 line 019: Neri carried the blue token past marker 6acbd913d98d. Mara watched the eastern gate until dawn.

Ledger 17 line 020: Neri carried the blue token past marker d21e521c9608. Mara watched the eastern gate until dawn.

Ledger 17 line 021: Neri carried the blue token past marker b910ea74995f. Mara watched the eastern gate until dawn.

Ledger 17 line 022: Neri carried the blue token past marker e9a6c332d2dd. Mara watched the eastern gate until dawn.

Ledger 17 line 023: Neri carried the blue token past marker 0cf84c8fb114. Mara watched the eastern gate until dawn.

Ledger 17 line 024: Neri carried the blue token past marker 00d4a1680d71. Mara watched the eastern gate until dawn.

Ledger 17 line 025: Neri carried the blue token past marker a6252e467bc6. Mara watched the eastern gate until dawn.

Ledger 17 line 026: Neri carried the blue token past marker 6f7441f6325f. Mara watched the eastern gate until dawn.

Ledger 17 line 027: Neri carried the blue token past marker f7ac193bfcaa. Mara watched the eastern gate until dawn.

Ledger 17 line 028: Neri carried the blue token past marker f2d015e38e4a. Mara watched the eastern gate until dawn.

Ledger 17 line 029: Neri carried the blue token past marker 04ad08c6911b. Mara watched the eastern gate until dawn.

Ledger 17 line 030: Neri carried the blue token past marker efeb5b8aa4c2. Mara watched the eastern gate until dawn.

Ledger 17 line 031: Neri carried the blue token past marker b06d0801711d. Mara watched the eastern gate until dawn.

Ledger 17 line 032: Neri carried the blue token past marker 5209333e69b9. Mara watched the eastern gate until dawn.

Ledger 17 line 033: Neri carried the blue token past marker 8bf07b3a9eac. Mara watched the eastern gate until dawn.

Ledger 17 line 034: Neri carried the blue token past marker a76b3f9b1dbf. Mara watched the eastern gate until dawn.

Ledger 17 line 035: Neri carried the blue token past marker fe25d6a82020. Mara watched the eastern gate until dawn.

Ledger 17 line 036: Neri carried the blue token past marker 6cd14713aafb. Mara watched the eastern gate until dawn.

Ledger 17 line 037: Neri carried the blue token past marker 109442e060b1. Mara watched the eastern gate until dawn.

Ledger 17 line 038: Neri carried the blue token past marker d1f892570dbb. Mara watched the eastern gate until dawn.

Ledger 17 line 039: Neri carried the blue token past marker 01647395650e. Mara watched the eastern gate until dawn.

Ledger 17 line 040: Neri carried the blue token past marker a1f27d659832. Mara watched the eastern gate until dawn.

Ledger 17 line 041: Neri carried the blue token past marker 63823ff7dba5. Mara watched the eastern gate until dawn.

Ledger 17 line 042: Neri carried the blue token past marker c3ff3d9e4459. Mara watched the eastern gate until dawn.

Ledger 17 line 043: Neri carried the blue token past marker f45cf2a93046. Mara watched the eastern gate until dawn.

Ledger 17 line 044: Neri carried the blue token past marker 351918602e1e. Mara watched the eastern gate until dawn.

Ledger 17 line 045: Neri carried the blue token past marker b39273dc041d. Mara watched the eastern gate until dawn.

Ledger 17 line 046: Neri carried the blue token past marker 80976ae0842a. Mara watched the eastern gate until dawn.

Ledger 17 line 047: Neri carried the blue token past marker b0281e720500. Mara watched the eastern gate until dawn.

Ledger 17 line 048: Neri carried the blue token past marker 7f3e5fc15427. Mara watched the eastern gate until dawn.

Ledger 17 line 049: Neri carried the blue token past marker a8e41fa0a234. Mara watched the eastern gate until dawn.

Ledger 17 line 050: Neri carried the blue token past marker 7ce1153b0250. Mara watched the eastern gate until dawn.

Ledger 17 line 051: Neri carried the blue token past marker 8de0d64228dd. Mara watched the eastern gate until dawn.

Ledger 17 line 052: Neri carried the blue token past marker 84205be3c541. Mara watched the eastern gate until dawn.

Ledger 17 line 053: Neri carried the blue token past marker ec86ae61225f. Mara watched the eastern gate until dawn.

Ledger 17 line 054: Neri carried the blue token past marker 58eaccdb6de7. Mara watched the eastern gate until dawn.

Ledger 17 line 055: Neri carried the blue token past marker 47f83f552c4e. Mara watched the eastern gate until dawn.

Ledger 17 line 056: Neri carried the blue token past marker b6076c39ba6f. Mara watched the eastern gate until dawn.

Ledger 17 line 057: Neri carried the blue token past marker 5054fb30b5f2. Mara watched the eastern gate until dawn.

Ledger 17 line 058: Neri carried the blue token past marker a013c58c7080. Mara watched the eastern gate until dawn.

Ledger 17 line 059: Neri carried the blue token past marker 185b77f9c31f. Mara watched the eastern gate until dawn.

Ledger 17 line 060: Neri carried the blue token past marker 4185a6842e47. Mara watched the eastern gate until dawn.

Ledger 17 line 061: Neri carried the blue token past marker 730593faff8a. Mara watched the eastern gate until dawn.

Ledger 17 line 062: Neri carried the blue token past marker 2fef6556efc7. Mara watched the eastern gate until dawn.

Ledger 17 line 063: Neri carried the blue token past marker 52067c5331d8. Mara watched the eastern gate until dawn.

Ledger 17 line 064: Neri carried the blue token past marker 871a4d18d66d. Mara watched the eastern gate until dawn.

Ledger 17 line 065: Neri carried the blue token past marker 6a65dc567267. Mara watched the eastern gate until dawn.

Ledger 17 line 066: Neri carried the blue token past marker 56aff441508c. Mara watched the eastern gate until dawn.

Ledger 17 line 067: Neri carried the blue token past marker f139449746eb. Mara watched the eastern gate until dawn.

Ledger 17 line 068: Neri carried the blue token past marker 4758e92514f0. Mara watched the eastern gate until dawn.

Ledger 17 line 069: Neri carried the blue token past marker dd3f9149b60e. Mara watched the eastern gate until dawn.

Ledger 17 line 070: Neri carried the blue token past marker c33d61254f01. Mara watched the eastern gate until dawn.

Ledger 17 line 071: Neri carried the blue token past marker f2bc2206d738. Mara watched the eastern gate until dawn.

Ledger 17 line 072: Neri carried the blue token past marker e2b760455f7d. Mara watched the eastern gate until dawn.

Ledger 17 line 073: Neri carried the blue token past marker 5cccdbc14b05. Mara watched the eastern gate until dawn.

Ledger 17 line 074: Neri carried the blue token past marker 76cf8fb643ab. Mara watched the eastern gate until dawn.

Ledger 17 line 075: Neri carried the blue token past marker fd7e8d161a17. Mara watched the eastern gate until dawn.

Ledger 17 line 076: Neri carried the blue token past marker 2d5f30e094ff. Mara watched the eastern gate until dawn.

Ledger 17 line 077: Neri carried the blue token past marker d01f6c85b246. Mara watched the eastern gate until dawn.

Ledger 17 line 078: Neri carried the blue token past marker e98b07f7942e. Mara watched the eastern gate until dawn.

Ledger 17 line 079: Neri carried the blue token past marker 54b144f5b7e1. Mara watched the eastern gate until dawn.

Ledger 17 line 080: Neri carried the blue token past marker dc7b0d8acd6a. Mara watched the eastern gate until dawn.

Ledger 17 line 081: Neri carried the blue token past marker e9c64a02ad1d. Mara watched the eastern gate until dawn.

Ledger 17 line 082: Neri carried the blue token past marker 017136ad9e9a. Mara watched the eastern gate until dawn.

Ledger 17 line 083: Neri carried the blue token past marker 42b8f2e245ae. Mara watched the eastern gate until dawn.

Ledger 17 line 084: Neri carried the blue token past marker 341a04c10da8. Mara watched the eastern gate until dawn.

Ledger 17 line 085: Neri carried the blue token past marker 12cc37e71fba. Mara watched the eastern gate until dawn.

Ledger 17 line 086: Neri carried the blue token past marker e4b32444e1f4. Mara watched the eastern gate until dawn.

Ledger 17 line 087: Neri carried the blue token past marker 66366728a76a. Mara watched the eastern gate until dawn.

Ledger 17 line 088: Neri carried the blue token past marker 3de1d33f8cdb. Mara watched the eastern gate until dawn.

Ledger 17 line 089: Neri carried the blue token past marker 0f49bd348fb7. Mara watched the eastern gate until dawn.

Ledger 17 line 090: Neri carried the blue token past marker 4a757e54493a. Mara watched the eastern gate until dawn.

Ledger 17 line 091: Neri carried the blue token past marker 66c3b82aacea. Mara watched the eastern gate until dawn.

Ledger 17 line 092: Neri carried the blue token past marker c581bc081e71. Mara watched the eastern gate until dawn.

Ledger 17 line 093: Neri carried the blue token past marker f15b1867307c. Mara watched the eastern gate until dawn.

Ledger 17 line 094: Neri carried the blue token past marker acc2a9a85328. Mara watched the eastern gate until dawn.

Ledger 17 line 095: Neri carried the blue token past marker bf261a60330e. Mara watched the eastern gate until dawn.

Ledger 17 line 096: Neri carried the blue token past marker fc0bf9bdfcab. Mara watched the eastern gate until dawn.

Ledger 17 line 097: Neri carried the blue token past marker 1ac0ef7d902c. Mara watched the eastern gate until dawn.

Ledger 17 line 098: Neri carried the blue token past marker afc5c02fe159. Mara watched the eastern gate until dawn.

Ledger 17 line 099: Neri carried the blue token past marker e147e416b81c. Mara watched the eastern gate until dawn.

Ledger 17 line 100: Neri carried the blue token past marker 3c36150708ae. Mara watched the eastern gate until dawn.

Ledger 17 line 101: Neri carried the blue token past marker 3ab69c979d13. Mara watched the eastern gate until dawn.

Ledger 17 line 102: Neri carried the blue token past marker b8c843df0ea4. Mara watched the eastern gate until dawn.

Ledger 17 line 103: Neri carried the blue token past marker 9f9f0da48942. Mara watched the eastern gate until dawn.

Ledger 17 line 104: Neri carried the blue token past marker b4253d932faa. Mara watched the eastern gate until dawn.

Ledger 17 line 105: Neri carried the blue token past marker 13c6234fbed1. Mara watched the eastern gate until dawn.

Ledger 17 line 106: Neri carried the blue token past marker d19d44d48fe7. Mara watched the eastern gate until dawn.

Ledger 17 line 107: Neri carried the blue token past marker 27da44b35c85. Mara watched the eastern gate until dawn.

Ledger 17 line 108: Neri carried the blue token past marker 2faddcfdbc0a. Mara watched the eastern gate until dawn.

Ledger 17 line 109: Neri carried the blue token past marker f2ec28d844cf. Mara watched the eastern gate until dawn.

Ledger 17 line 110: Neri carried the blue token past marker 5d20748b0e6a. Mara watched the eastern gate until dawn.

Ledger 17 line 111: Neri carried the blue token past marker 7b0561b35aa7. Mara watched the eastern gate until dawn.

Ledger 17 line 112: Neri carried the blue token past marker 27b039eec867. Mara watched the eastern gate until dawn.

Ledger 17 line 113: Neri carried the blue token past marker 52ba82b77121. Mara watched the eastern gate until dawn.

Ledger 17 line 114: Neri carried the blue token past marker 9a68d01d6dde. Mara watched the eastern gate until dawn.

Ledger 17 line 115: Neri carried the blue token past marker b5884d2c2680. Mara watched the eastern gate until dawn.

Ledger 17 line 116: Neri carried the blue token past marker 7d183f9c1cf0. Mara watched the eastern gate until dawn.

Ledger 17 line 117: Neri carried the blue token past marker 4446e573bbd7. Mara watched the eastern gate until dawn.

Ledger 17 line 118: Neri carried the blue token past marker 151d51a5eedb. Mara watched the eastern gate until dawn.

Ledger 17 line 119: Neri carried the blue token past marker 3973e90ba413. Mara watched the eastern gate until dawn.

Ledger 17 line 120: Neri carried the blue token past marker 1397fababa66. Mara watched the eastern gate until dawn.

Ledger 17 line 121: Neri carried the blue token past marker 00abe95e0e43. Mara watched the eastern gate until dawn.

Ledger 17 line 122: Neri carried the blue token past marker 45468f6ad2b4. Mara watched the eastern gate until dawn.

Ledger 17 line 123: Neri carried the blue token past marker 165299170c48. Mara watched the eastern gate until dawn.

Ledger 17 line 124: Neri carried the blue token past marker e169bfb62ace. Mara watched the eastern gate until dawn.

Ledger 17 line 125: Neri carried the blue token past marker 170d7fc44187. Mara watched the eastern gate until dawn.

Ledger 17 line 126: Neri carried the blue token past marker 1676dc16ce99. Mara watched the eastern gate until dawn.

Ledger 17 line 127: Neri carried the blue token past marker a4d5027c674a. Mara watched the eastern gate until dawn.

Ledger 17 line 128: Neri carried the blue token past marker b41937fe3ecf. Mara watched the eastern gate until dawn.

Ledger 17 line 129: Neri carried the blue token past marker af46a7ce449b. Mara watched the eastern gate until dawn.

Ledger 17 line 130: Neri carried the blue token past marker 368540e376b3. Mara watched the eastern gate until dawn.

Ledger 17 line 131: Neri carried the blue token past marker 8b5e1c4a938e. Mara watched the eastern gate until dawn.

Ledger 17 line 132: Neri carried the blue token past marker 9a0889585209. Mara watched the eastern gate until dawn.

Ledger 17 line 133: Neri carried the blue token past marker 99906967eb71. Mara watched the eastern gate until dawn.

Ledger 17 line 134: Neri carried the blue token past marker afbd3db0c10c. Mara watched the eastern gate until dawn.

Ledger 17 line 135: Neri carried the blue token past marker 27c138287e05. Mara watched the eastern gate until dawn.

Ledger 17 line 136: Neri carried the blue token past marker 7e0711f1595f. Mara watched the eastern gate until dawn.

Ledger 17 line 137: Neri carried the blue token past marker 3320208ac09d. Mara watched the eastern gate until dawn.

Ledger 17 line 138: Neri carried the blue token past marker d38a247ebbb9. Mara watched the eastern gate until dawn.

Ledger 17 line 139: Neri carried the blue token past marker 5e0fd10865a9. Mara watched the eastern gate until dawn.

Ledger 17 line 140: Neri carried the blue token past marker 2aca045e0157. Mara watched the eastern gate until dawn.
