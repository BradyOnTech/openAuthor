---
id: scene-0040
title: Recovery ledger 40
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.174110+00:00
updated_at: 2026-10-03T12:14:52.174110+00:00
---

Ledger 40 line 001: Neri carried the blue token past marker f5929e1a98f0. Mara watched the eastern gate until dawn.

Ledger 40 line 002: Neri carried the blue token past marker 1e5eb658fc34. Mara watched the eastern gate until dawn.

Ledger 40 line 003: Neri carried the blue token past marker 4430b9165734. Mara watched the eastern gate until dawn.

Ledger 40 line 004: Neri carried the blue token past marker f04efdddda0c. Mara watched the eastern gate until dawn.

Ledger 40 line 005: Neri carried the blue token past marker a8440133b400. Mara watched the eastern gate until dawn.

Ledger 40 line 006: Neri carried the blue token past marker 4a442a4c196a. Mara watched the eastern gate until dawn.

Ledger 40 line 007: Neri carried the blue token past marker 2bb111fb9ae0. Mara watched the eastern gate until dawn.

Ledger 40 line 008: Neri carried the blue token past marker e8fe9d2d9b11. Mara watched the eastern gate until dawn.

Ledger 40 line 009: Neri carried the blue token past marker 1cf9a0ff7fd8. Mara watched the eastern gate until dawn.

Ledger 40 line 010: Neri carried the blue token past marker a8a390121f55. Mara watched the eastern gate until dawn.

Ledger 40 line 011: Neri carried the blue token past marker 10bcfb944daf. Mara watched the eastern gate until dawn.

Ledger 40 line 012: Neri carried the blue token past marker 30ee6aa1ade7. Mara watched the eastern gate until dawn.

Ledger 40 line 013: Neri carried the blue token past marker fb5cbb5772b0. Mara watched the eastern gate until dawn.

Ledger 40 line 014: Neri carried the blue token past marker b77679689172. Mara watched the eastern gate until dawn.

Ledger 40 line 015: Neri carried the blue token past marker 5c254936c9e8. Mara watched the eastern gate until dawn.

Ledger 40 line 016: Neri carried the blue token past marker cf36ed9d81f7. Mara watched the eastern gate until dawn.

Ledger 40 line 017: Neri carried the blue token past marker 813a0fe9212f. Mara watched the eastern gate until dawn.

Ledger 40 line 018: Neri carried the blue token past marker c6e7146127a9. Mara watched the eastern gate until dawn.

Ledger 40 line 019: Neri carried the blue token past marker 7ec629f778b9. Mara watched the eastern gate until dawn.

Ledger 40 line 020: Neri carried the blue token past marker c025e51cac03. Mara watched the eastern gate until dawn.

Ledger 40 line 021: Neri carried the blue token past marker 68184192c602. Mara watched the eastern gate until dawn.

Ledger 40 line 022: Neri carried the blue token past marker 49aa60ac1b4d. Mara watched the eastern gate until dawn.

Ledger 40 line 023: Neri carried the blue token past marker b0deec4d8187. Mara watched the eastern gate until dawn.

Ledger 40 line 024: Neri carried the blue token past marker 99442ae3118a. Mara watched the eastern gate until dawn.

Ledger 40 line 025: Neri carried the blue token past marker 30732660a705. Mara watched the eastern gate until dawn.

Ledger 40 line 026: Neri carried the blue token past marker 6f3a18c31c15. Mara watched the eastern gate until dawn.

Ledger 40 line 027: Neri carried the blue token past marker c17b5c6f1be9. Mara watched the eastern gate until dawn.

Ledger 40 line 028: Neri carried the blue token past marker e1beff879181. Mara watched the eastern gate until dawn.

Ledger 40 line 029: Neri carried the blue token past marker c2273604bfd9. Mara watched the eastern gate until dawn.

Ledger 40 line 030: Neri carried the blue token past marker 63a11988dcc5. Mara watched the eastern gate until dawn.

Ledger 40 line 031: Neri carried the blue token past marker 32b70da252e9. Mara watched the eastern gate until dawn.

Ledger 40 line 032: Neri carried the blue token past marker 492a1a994e56. Mara watched the eastern gate until dawn.

Ledger 40 line 033: Neri carried the blue token past marker 14a0064d2a2b. Mara watched the eastern gate until dawn.

Ledger 40 line 034: Neri carried the blue token past marker a18e4a2405c7. Mara watched the eastern gate until dawn.

Ledger 40 line 035: Neri carried the blue token past marker 42e90f839706. Mara watched the eastern gate until dawn.

Ledger 40 line 036: Neri carried the blue token past marker 1453d1c68957. Mara watched the eastern gate until dawn.

Ledger 40 line 037: Neri carried the blue token past marker 53311a6fec8d. Mara watched the eastern gate until dawn.

Ledger 40 line 038: Neri carried the blue token past marker 73a88d908708. Mara watched the eastern gate until dawn.

Ledger 40 line 039: Neri carried the blue token past marker 88a1c5d334d5. Mara watched the eastern gate until dawn.

Ledger 40 line 040: Neri carried the blue token past marker a0813e2516f4. Mara watched the eastern gate until dawn.

Ledger 40 line 041: Neri carried the blue token past marker 3489eb95578e. Mara watched the eastern gate until dawn.

Ledger 40 line 042: Neri carried the blue token past marker b5ad9f95e24e. Mara watched the eastern gate until dawn.

Ledger 40 line 043: Neri carried the blue token past marker 23b3d40bb424. Mara watched the eastern gate until dawn.

Ledger 40 line 044: Neri carried the blue token past marker 10bbd3557a56. Mara watched the eastern gate until dawn.

Ledger 40 line 045: Neri carried the blue token past marker b03fe33b5d0d. Mara watched the eastern gate until dawn.

Ledger 40 line 046: Neri carried the blue token past marker 7b5fcedeb6b8. Mara watched the eastern gate until dawn.

Ledger 40 line 047: Neri carried the blue token past marker 01d4131a1480. Mara watched the eastern gate until dawn.

Ledger 40 line 048: Neri carried the blue token past marker 1ee6ccfa7a47. Mara watched the eastern gate until dawn.

Ledger 40 line 049: Neri carried the blue token past marker 8ac333cf69ed. Mara watched the eastern gate until dawn.

Ledger 40 line 050: Neri carried the blue token past marker 97e4313f19cc. Mara watched the eastern gate until dawn.

Ledger 40 line 051: Neri carried the blue token past marker ffb26e2af5c5. Mara watched the eastern gate until dawn.

Ledger 40 line 052: Neri carried the blue token past marker 3aeb07eb1072. Mara watched the eastern gate until dawn.

Ledger 40 line 053: Neri carried the blue token past marker 56f0711b8117. Mara watched the eastern gate until dawn.

Ledger 40 line 054: Neri carried the blue token past marker 2c40b7363ec7. Mara watched the eastern gate until dawn.

Ledger 40 line 055: Neri carried the blue token past marker 92ec95fc2062. Mara watched the eastern gate until dawn.

Ledger 40 line 056: Neri carried the blue token past marker 16233de0c942. Mara watched the eastern gate until dawn.

Ledger 40 line 057: Neri carried the blue token past marker d758a050af1e. Mara watched the eastern gate until dawn.

Ledger 40 line 058: Neri carried the blue token past marker 9087b2a169b3. Mara watched the eastern gate until dawn.

Ledger 40 line 059: Neri carried the blue token past marker 3f865d50b98b. Mara watched the eastern gate until dawn.

Ledger 40 line 060: Neri carried the blue token past marker 9980398ee768. Mara watched the eastern gate until dawn.

Ledger 40 line 061: Neri carried the blue token past marker 51649fbd8915. Mara watched the eastern gate until dawn.

Ledger 40 line 062: Neri carried the blue token past marker 50300d032609. Mara watched the eastern gate until dawn.

Ledger 40 line 063: Neri carried the blue token past marker c847bb79d12d. Mara watched the eastern gate until dawn.

Ledger 40 line 064: Neri carried the blue token past marker aa8be6804599. Mara watched the eastern gate until dawn.

Ledger 40 line 065: Neri carried the blue token past marker 1eed95139409. Mara watched the eastern gate until dawn.

Ledger 40 line 066: Neri carried the blue token past marker da137bee90d8. Mara watched the eastern gate until dawn.

Ledger 40 line 067: Neri carried the blue token past marker a194a1979c5b. Mara watched the eastern gate until dawn.

Ledger 40 line 068: Neri carried the blue token past marker f6aa18dd4383. Mara watched the eastern gate until dawn.

Ledger 40 line 069: Neri carried the blue token past marker 043776b3a33c. Mara watched the eastern gate until dawn.

Ledger 40 line 070: Neri carried the blue token past marker ca2622f1591b. Mara watched the eastern gate until dawn.

Ledger 40 line 071: Neri carried the blue token past marker 6d70578b3610. Mara watched the eastern gate until dawn.

Ledger 40 line 072: Neri carried the blue token past marker febbff59b350. Mara watched the eastern gate until dawn.

Ledger 40 line 073: Neri carried the blue token past marker 5565cd4bfd67. Mara watched the eastern gate until dawn.

Ledger 40 line 074: Neri carried the blue token past marker b7dd556e9178. Mara watched the eastern gate until dawn.

Ledger 40 line 075: Neri carried the blue token past marker 668a8e6810a4. Mara watched the eastern gate until dawn.

Ledger 40 line 076: Neri carried the blue token past marker 998891d05e9d. Mara watched the eastern gate until dawn.

Ledger 40 line 077: Neri carried the blue token past marker c3c8c8997685. Mara watched the eastern gate until dawn.

Ledger 40 line 078: Neri carried the blue token past marker f6f2fc3a4215. Mara watched the eastern gate until dawn.

Ledger 40 line 079: Neri carried the blue token past marker 3045c47aac40. Mara watched the eastern gate until dawn.

Ledger 40 line 080: Neri carried the blue token past marker c6d4496a9560. Mara watched the eastern gate until dawn.

Ledger 40 line 081: Neri carried the blue token past marker 93b6ea3c0ba0. Mara watched the eastern gate until dawn.

Ledger 40 line 082: Neri carried the blue token past marker b1aed9463238. Mara watched the eastern gate until dawn.

Ledger 40 line 083: Neri carried the blue token past marker 7f624e7ce8eb. Mara watched the eastern gate until dawn.

Ledger 40 line 084: Neri carried the blue token past marker 168304525272. Mara watched the eastern gate until dawn.

Ledger 40 line 085: Neri carried the blue token past marker d58b85d17209. Mara watched the eastern gate until dawn.

Ledger 40 line 086: Neri carried the blue token past marker 9115cb9975e7. Mara watched the eastern gate until dawn.

Ledger 40 line 087: Neri carried the blue token past marker 735385cc97bc. Mara watched the eastern gate until dawn.

Ledger 40 line 088: Neri carried the blue token past marker 80fead8e6e44. Mara watched the eastern gate until dawn.

Ledger 40 line 089: Neri carried the blue token past marker 4e3cc7ee421e. Mara watched the eastern gate until dawn.

Ledger 40 line 090: Neri carried the blue token past marker f56853126428. Mara watched the eastern gate until dawn.

Ledger 40 line 091: Neri carried the blue token past marker 8e3c6749bb96. Mara watched the eastern gate until dawn.

Ledger 40 line 092: Neri carried the blue token past marker 75cda7fa49a0. Mara watched the eastern gate until dawn.

Ledger 40 line 093: Neri carried the blue token past marker 38f828901286. Mara watched the eastern gate until dawn.

Ledger 40 line 094: Neri carried the blue token past marker 7ce624182cff. Mara watched the eastern gate until dawn.

Ledger 40 line 095: Neri carried the blue token past marker d7da99707194. Mara watched the eastern gate until dawn.

Ledger 40 line 096: Neri carried the blue token past marker a52effdb2e9c. Mara watched the eastern gate until dawn.

Ledger 40 line 097: Neri carried the blue token past marker 32f60445b021. Mara watched the eastern gate until dawn.

Ledger 40 line 098: Neri carried the blue token past marker 65a39cb66622. Mara watched the eastern gate until dawn.

Ledger 40 line 099: Neri carried the blue token past marker 05a03591b7b3. Mara watched the eastern gate until dawn.

Ledger 40 line 100: Neri carried the blue token past marker afe8bf6c5950. Mara watched the eastern gate until dawn.

Ledger 40 line 101: Neri carried the blue token past marker ca50589084d6. Mara watched the eastern gate until dawn.

Ledger 40 line 102: Neri carried the blue token past marker 1adfb8b78f05. Mara watched the eastern gate until dawn.

Ledger 40 line 103: Neri carried the blue token past marker 2c605694ad2a. Mara watched the eastern gate until dawn.

Ledger 40 line 104: Neri carried the blue token past marker e240e335a9ee. Mara watched the eastern gate until dawn.

Ledger 40 line 105: Neri carried the blue token past marker b3b53298f4f5. Mara watched the eastern gate until dawn.

Ledger 40 line 106: Neri carried the blue token past marker 91eebc08a92e. Mara watched the eastern gate until dawn.

Ledger 40 line 107: Neri carried the blue token past marker 2be09ff1a374. Mara watched the eastern gate until dawn.

Ledger 40 line 108: Neri carried the blue token past marker a1c6b9cad083. Mara watched the eastern gate until dawn.

Ledger 40 line 109: Neri carried the blue token past marker fe3627bffcd0. Mara watched the eastern gate until dawn.

Ledger 40 line 110: Neri carried the blue token past marker 0ede5d5fd0d7. Mara watched the eastern gate until dawn.

Ledger 40 line 111: Neri carried the blue token past marker 2729ea126f48. Mara watched the eastern gate until dawn.

Ledger 40 line 112: Neri carried the blue token past marker b477c82d4d5e. Mara watched the eastern gate until dawn.

Ledger 40 line 113: Neri carried the blue token past marker f8c3791f41aa. Mara watched the eastern gate until dawn.

Ledger 40 line 114: Neri carried the blue token past marker 444278bb1047. Mara watched the eastern gate until dawn.

Ledger 40 line 115: Neri carried the blue token past marker 2f1d8df05a73. Mara watched the eastern gate until dawn.

Ledger 40 line 116: Neri carried the blue token past marker 8b9c9e62205e. Mara watched the eastern gate until dawn.

Ledger 40 line 117: Neri carried the blue token past marker 86f331da9fcd. Mara watched the eastern gate until dawn.

Ledger 40 line 118: Neri carried the blue token past marker 06f913f33e91. Mara watched the eastern gate until dawn.

Ledger 40 line 119: Neri carried the blue token past marker 116882e525fc. Mara watched the eastern gate until dawn.

Ledger 40 line 120: Neri carried the blue token past marker 5e871d32613e. Mara watched the eastern gate until dawn.

Ledger 40 line 121: Neri carried the blue token past marker cf4515d4ba48. Mara watched the eastern gate until dawn.

Ledger 40 line 122: Neri carried the blue token past marker 559516320120. Mara watched the eastern gate until dawn.

Ledger 40 line 123: Neri carried the blue token past marker 79c399b70368. Mara watched the eastern gate until dawn.

Ledger 40 line 124: Neri carried the blue token past marker 3b57c3b905c1. Mara watched the eastern gate until dawn.

Ledger 40 line 125: Neri carried the blue token past marker 1cbbb3feceed. Mara watched the eastern gate until dawn.

Ledger 40 line 126: Neri carried the blue token past marker e68f121c5661. Mara watched the eastern gate until dawn.

Ledger 40 line 127: Neri carried the blue token past marker 11ccfd274d77. Mara watched the eastern gate until dawn.

Ledger 40 line 128: Neri carried the blue token past marker 374a888e3b07. Mara watched the eastern gate until dawn.

Ledger 40 line 129: Neri carried the blue token past marker 2ec595543aac. Mara watched the eastern gate until dawn.

Ledger 40 line 130: Neri carried the blue token past marker 8aa91d32fe02. Mara watched the eastern gate until dawn.

Ledger 40 line 131: Neri carried the blue token past marker 7f4d5a74b54f. Mara watched the eastern gate until dawn.

Ledger 40 line 132: Neri carried the blue token past marker bfdfb3098070. Mara watched the eastern gate until dawn.

Ledger 40 line 133: Neri carried the blue token past marker c031f664f58b. Mara watched the eastern gate until dawn.

Ledger 40 line 134: Neri carried the blue token past marker f2c0b1b38e34. Mara watched the eastern gate until dawn.

Ledger 40 line 135: Neri carried the blue token past marker d67f59b7f4c1. Mara watched the eastern gate until dawn.

Ledger 40 line 136: Neri carried the blue token past marker 122232c60c49. Mara watched the eastern gate until dawn.

Ledger 40 line 137: Neri carried the blue token past marker 0f41d8b2bb6f. Mara watched the eastern gate until dawn.

Ledger 40 line 138: Neri carried the blue token past marker a30533318341. Mara watched the eastern gate until dawn.

Ledger 40 line 139: Neri carried the blue token past marker 533c6cfbde77. Mara watched the eastern gate until dawn.

Ledger 40 line 140: Neri carried the blue token past marker 1e566df8eda6. Mara watched the eastern gate until dawn.
