---
id: scene-0021
title: Recovery ledger 21
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.163448+00:00
updated_at: 2026-10-03T12:14:52.163448+00:00
---

Ledger 21 line 001: Neri carried the blue token past marker 0e628792b9cd. Mara watched the eastern gate until dawn.

Ledger 21 line 002: Neri carried the blue token past marker e1aedd333389. Mara watched the eastern gate until dawn.

Ledger 21 line 003: Neri carried the blue token past marker cd8311c7f918. Mara watched the eastern gate until dawn.

Ledger 21 line 004: Neri carried the blue token past marker 45011f1d400b. Mara watched the eastern gate until dawn.

Ledger 21 line 005: Neri carried the blue token past marker 304ed3c70c23. Mara watched the eastern gate until dawn.

Ledger 21 line 006: Neri carried the blue token past marker f3f81d78c206. Mara watched the eastern gate until dawn.

Ledger 21 line 007: Neri carried the blue token past marker 5df389b55490. Mara watched the eastern gate until dawn.

Ledger 21 line 008: Neri carried the blue token past marker e676c6c5b06f. Mara watched the eastern gate until dawn.

Ledger 21 line 009: Neri carried the blue token past marker 3cbcb45ff26e. Mara watched the eastern gate until dawn.

Ledger 21 line 010: Neri carried the blue token past marker 3122b501b917. Mara watched the eastern gate until dawn.

Ledger 21 line 011: Neri carried the blue token past marker f572d1ea0ae0. Mara watched the eastern gate until dawn.

Ledger 21 line 012: Neri carried the blue token past marker f11efe99a68f. Mara watched the eastern gate until dawn.

Ledger 21 line 013: Neri carried the blue token past marker b28e0121c784. Mara watched the eastern gate until dawn.

Ledger 21 line 014: Neri carried the blue token past marker 0d42d8d71821. Mara watched the eastern gate until dawn.

Ledger 21 line 015: Neri carried the blue token past marker ecc36ac24a03. Mara watched the eastern gate until dawn.

Ledger 21 line 016: Neri carried the blue token past marker e6bb345fcb32. Mara watched the eastern gate until dawn.

Ledger 21 line 017: Neri carried the blue token past marker a798496eb290. Mara watched the eastern gate until dawn.

Ledger 21 line 018: Neri carried the blue token past marker 22e3e6978ecb. Mara watched the eastern gate until dawn.

Ledger 21 line 019: Neri carried the blue token past marker ee4a550a75ba. Mara watched the eastern gate until dawn.

Ledger 21 line 020: Neri carried the blue token past marker 77988845e0ae. Mara watched the eastern gate until dawn.

Ledger 21 line 021: Neri carried the blue token past marker 5d743249d7e2. Mara watched the eastern gate until dawn.

Ledger 21 line 022: Neri carried the blue token past marker 6ea90f136316. Mara watched the eastern gate until dawn.

Ledger 21 line 023: Neri carried the blue token past marker f80f32f74160. Mara watched the eastern gate until dawn.

Ledger 21 line 024: Neri carried the blue token past marker ad2ae1417990. Mara watched the eastern gate until dawn.

Ledger 21 line 025: Neri carried the blue token past marker 0d654ecfd8ce. Mara watched the eastern gate until dawn.

Ledger 21 line 026: Neri carried the blue token past marker 83aa894ac8b4. Mara watched the eastern gate until dawn.

Ledger 21 line 027: Neri carried the blue token past marker 9053f5e6e271. Mara watched the eastern gate until dawn.

Ledger 21 line 028: Neri carried the blue token past marker efa202fef09d. Mara watched the eastern gate until dawn.

Ledger 21 line 029: Neri carried the blue token past marker 73a928ede0d2. Mara watched the eastern gate until dawn.

Ledger 21 line 030: Neri carried the blue token past marker 9f793def4c05. Mara watched the eastern gate until dawn.

Ledger 21 line 031: Neri carried the blue token past marker 3e5284d4ba8b. Mara watched the eastern gate until dawn.

Ledger 21 line 032: Neri carried the blue token past marker 17958e94212b. Mara watched the eastern gate until dawn.

Ledger 21 line 033: Neri carried the blue token past marker 716e08ad2c52. Mara watched the eastern gate until dawn.

Ledger 21 line 034: Neri carried the blue token past marker b7e3761e8055. Mara watched the eastern gate until dawn.

Ledger 21 line 035: Neri carried the blue token past marker 8592d6c94200. Mara watched the eastern gate until dawn.

Ledger 21 line 036: Neri carried the blue token past marker 7684f83a627d. Mara watched the eastern gate until dawn.

Ledger 21 line 037: Neri carried the blue token past marker 10eb4b40e5d2. Mara watched the eastern gate until dawn.

Ledger 21 line 038: Neri carried the blue token past marker fa07735b913b. Mara watched the eastern gate until dawn.

Ledger 21 line 039: Neri carried the blue token past marker 99124f37a4c4. Mara watched the eastern gate until dawn.

Ledger 21 line 040: Neri carried the blue token past marker 945f708b3430. Mara watched the eastern gate until dawn.

Ledger 21 line 041: Neri carried the blue token past marker 333281adadff. Mara watched the eastern gate until dawn.

Ledger 21 line 042: Neri carried the blue token past marker 0291e497c9a1. Mara watched the eastern gate until dawn.

Ledger 21 line 043: Neri carried the blue token past marker ddbe81eae63c. Mara watched the eastern gate until dawn.

Ledger 21 line 044: Neri carried the blue token past marker 7659f972b0ef. Mara watched the eastern gate until dawn.

Ledger 21 line 045: Neri carried the blue token past marker 3e94b72a9103. Mara watched the eastern gate until dawn.

Ledger 21 line 046: Neri carried the blue token past marker b5a23b41a7ee. Mara watched the eastern gate until dawn.

Ledger 21 line 047: Neri carried the blue token past marker 2f4dc9dcaf3e. Mara watched the eastern gate until dawn.

Ledger 21 line 048: Neri carried the blue token past marker a1978dd4d94a. Mara watched the eastern gate until dawn.

Ledger 21 line 049: Neri carried the blue token past marker 99c4f8472e17. Mara watched the eastern gate until dawn.

Ledger 21 line 050: Neri carried the blue token past marker f0d1ca01910a. Mara watched the eastern gate until dawn.

Ledger 21 line 051: Neri carried the blue token past marker 0288285ac666. Mara watched the eastern gate until dawn.

Ledger 21 line 052: Neri carried the blue token past marker 7a5917ae73e3. Mara watched the eastern gate until dawn.

Ledger 21 line 053: Neri carried the blue token past marker 53cde3f27aad. Mara watched the eastern gate until dawn.

Ledger 21 line 054: Neri carried the blue token past marker d1b56f0064ec. Mara watched the eastern gate until dawn.

Ledger 21 line 055: Neri carried the blue token past marker b78f09d884be. Mara watched the eastern gate until dawn.

Ledger 21 line 056: Neri carried the blue token past marker 11fb35ff8b2b. Mara watched the eastern gate until dawn.

Ledger 21 line 057: Neri carried the blue token past marker 359e90e1d2ca. Mara watched the eastern gate until dawn.

Ledger 21 line 058: Neri carried the blue token past marker cdb6514fb396. Mara watched the eastern gate until dawn.

Ledger 21 line 059: Neri carried the blue token past marker 56f7f6e75409. Mara watched the eastern gate until dawn.

Ledger 21 line 060: Neri carried the blue token past marker 653518522ff6. Mara watched the eastern gate until dawn.

Ledger 21 line 061: Neri carried the blue token past marker df50df1d1ac1. Mara watched the eastern gate until dawn.

Ledger 21 line 062: Neri carried the blue token past marker 2e42f4703f0e. Mara watched the eastern gate until dawn.

Ledger 21 line 063: Neri carried the blue token past marker f68413f7bbf8. Mara watched the eastern gate until dawn.

Ledger 21 line 064: Neri carried the blue token past marker 1bab3bd90ac4. Mara watched the eastern gate until dawn.

Ledger 21 line 065: Neri carried the blue token past marker bc1a2e43a85b. Mara watched the eastern gate until dawn.

Ledger 21 line 066: Neri carried the blue token past marker bdb4a175df59. Mara watched the eastern gate until dawn.

Ledger 21 line 067: Neri carried the blue token past marker 284dec3e1b40. Mara watched the eastern gate until dawn.

Ledger 21 line 068: Neri carried the blue token past marker 263fcb08ee73. Mara watched the eastern gate until dawn.

Ledger 21 line 069: Neri carried the blue token past marker 8ab9e20ade42. Mara watched the eastern gate until dawn.

Ledger 21 line 070: Neri carried the blue token past marker 372333516fc1. Mara watched the eastern gate until dawn.

Ledger 21 line 071: Neri carried the blue token past marker 01d5a15dde91. Mara watched the eastern gate until dawn.

Ledger 21 line 072: Neri carried the blue token past marker 61ae3602448a. Mara watched the eastern gate until dawn.

Ledger 21 line 073: Neri carried the blue token past marker 22d904a8a1fb. Mara watched the eastern gate until dawn.

Ledger 21 line 074: Neri carried the blue token past marker 4a697058b2af. Mara watched the eastern gate until dawn.

Ledger 21 line 075: Neri carried the blue token past marker e406533eb96a. Mara watched the eastern gate until dawn.

Ledger 21 line 076: Neri carried the blue token past marker 9bf1345f1365. Mara watched the eastern gate until dawn.

Ledger 21 line 077: Neri carried the blue token past marker cd5635fc1589. Mara watched the eastern gate until dawn.

Ledger 21 line 078: Neri carried the blue token past marker c6f6770efefb. Mara watched the eastern gate until dawn.

Ledger 21 line 079: Neri carried the blue token past marker 8de5c78011fa. Mara watched the eastern gate until dawn.

Ledger 21 line 080: Neri carried the blue token past marker 77ae314034c9. Mara watched the eastern gate until dawn.

Ledger 21 line 081: Neri carried the blue token past marker beb98c6909ec. Mara watched the eastern gate until dawn.

Ledger 21 line 082: Neri carried the blue token past marker 61183825aaf6. Mara watched the eastern gate until dawn.

Ledger 21 line 083: Neri carried the blue token past marker 9186e0b61d70. Mara watched the eastern gate until dawn.

Ledger 21 line 084: Neri carried the blue token past marker 3edad422b50b. Mara watched the eastern gate until dawn.

Ledger 21 line 085: Neri carried the blue token past marker 431f1db54a8b. Mara watched the eastern gate until dawn.

Ledger 21 line 086: Neri carried the blue token past marker 67d510bb8739. Mara watched the eastern gate until dawn.

Ledger 21 line 087: Neri carried the blue token past marker 8c52a7fae14f. Mara watched the eastern gate until dawn.

Ledger 21 line 088: Neri carried the blue token past marker a9770edd94b7. Mara watched the eastern gate until dawn.

Ledger 21 line 089: Neri carried the blue token past marker 878166b7f800. Mara watched the eastern gate until dawn.

Ledger 21 line 090: Neri carried the blue token past marker f48b02e8d4b2. Mara watched the eastern gate until dawn.

Ledger 21 line 091: Neri carried the blue token past marker 1a5ba2ed52ff. Mara watched the eastern gate until dawn.

Ledger 21 line 092: Neri carried the blue token past marker 85ff6538f0db. Mara watched the eastern gate until dawn.

Ledger 21 line 093: Neri carried the blue token past marker 49ef9563a3ce. Mara watched the eastern gate until dawn.

Ledger 21 line 094: Neri carried the blue token past marker a6914170231c. Mara watched the eastern gate until dawn.

Ledger 21 line 095: Neri carried the blue token past marker 1d830a14402f. Mara watched the eastern gate until dawn.

Ledger 21 line 096: Neri carried the blue token past marker 864163f64497. Mara watched the eastern gate until dawn.

Ledger 21 line 097: Neri carried the blue token past marker 3976d07bed98. Mara watched the eastern gate until dawn.

Ledger 21 line 098: Neri carried the blue token past marker fe35316186eb. Mara watched the eastern gate until dawn.

Ledger 21 line 099: Neri carried the blue token past marker 48932544ff49. Mara watched the eastern gate until dawn.

Ledger 21 line 100: Neri carried the blue token past marker 25a3383a3d79. Mara watched the eastern gate until dawn.

Ledger 21 line 101: Neri carried the blue token past marker b9d977835cb7. Mara watched the eastern gate until dawn.

Ledger 21 line 102: Neri carried the blue token past marker 4ae47d165d81. Mara watched the eastern gate until dawn.

Ledger 21 line 103: Neri carried the blue token past marker 358e8f9652cd. Mara watched the eastern gate until dawn.

Ledger 21 line 104: Neri carried the blue token past marker be60c80b0149. Mara watched the eastern gate until dawn.

Ledger 21 line 105: Neri carried the blue token past marker 64626604181d. Mara watched the eastern gate until dawn.

Ledger 21 line 106: Neri carried the blue token past marker d58880ee846f. Mara watched the eastern gate until dawn.

Ledger 21 line 107: Neri carried the blue token past marker ad465ffeedb9. Mara watched the eastern gate until dawn.

Ledger 21 line 108: Neri carried the blue token past marker d46a45aad542. Mara watched the eastern gate until dawn.

Ledger 21 line 109: Neri carried the blue token past marker 2ddd9c9840cd. Mara watched the eastern gate until dawn.

Ledger 21 line 110: Neri carried the blue token past marker b5ceeb16b2bb. Mara watched the eastern gate until dawn.

Ledger 21 line 111: Neri carried the blue token past marker d5574532ded4. Mara watched the eastern gate until dawn.

Ledger 21 line 112: Neri carried the blue token past marker fc83a1550f27. Mara watched the eastern gate until dawn.

Ledger 21 line 113: Neri carried the blue token past marker b097c0a2f12c. Mara watched the eastern gate until dawn.

Ledger 21 line 114: Neri carried the blue token past marker 77be12ebce1e. Mara watched the eastern gate until dawn.

Ledger 21 line 115: Neri carried the blue token past marker 683f7f98e206. Mara watched the eastern gate until dawn.

Ledger 21 line 116: Neri carried the blue token past marker 3f27c580035f. Mara watched the eastern gate until dawn.

Ledger 21 line 117: Neri carried the blue token past marker 8a03c1141523. Mara watched the eastern gate until dawn.

Ledger 21 line 118: Neri carried the blue token past marker 69830f2bc271. Mara watched the eastern gate until dawn.

Ledger 21 line 119: Neri carried the blue token past marker d41c29e842a7. Mara watched the eastern gate until dawn.

Ledger 21 line 120: Neri carried the blue token past marker 9ef51aba8dfa. Mara watched the eastern gate until dawn.

Ledger 21 line 121: Neri carried the blue token past marker 9eb0b2b6992a. Mara watched the eastern gate until dawn.

Ledger 21 line 122: Neri carried the blue token past marker d850d02c342f. Mara watched the eastern gate until dawn.

Ledger 21 line 123: Neri carried the blue token past marker 1023fc7b7dc1. Mara watched the eastern gate until dawn.

Ledger 21 line 124: Neri carried the blue token past marker ec77a6b5a21e. Mara watched the eastern gate until dawn.

Ledger 21 line 125: Neri carried the blue token past marker f575b77088b1. Mara watched the eastern gate until dawn.

Ledger 21 line 126: Neri carried the blue token past marker 861a05bcbd53. Mara watched the eastern gate until dawn.

Ledger 21 line 127: Neri carried the blue token past marker a98313d3221c. Mara watched the eastern gate until dawn.

Ledger 21 line 128: Neri carried the blue token past marker 4b983d837ff2. Mara watched the eastern gate until dawn.

Ledger 21 line 129: Neri carried the blue token past marker 5ec523275d46. Mara watched the eastern gate until dawn.

Ledger 21 line 130: Neri carried the blue token past marker 5f9dee1fa0ca. Mara watched the eastern gate until dawn.

Ledger 21 line 131: Neri carried the blue token past marker 8e44663dd2db. Mara watched the eastern gate until dawn.

Ledger 21 line 132: Neri carried the blue token past marker e9cdbfbfc945. Mara watched the eastern gate until dawn.

Ledger 21 line 133: Neri carried the blue token past marker 04f99150d551. Mara watched the eastern gate until dawn.

Ledger 21 line 134: Neri carried the blue token past marker 510a6f459bf9. Mara watched the eastern gate until dawn.

Ledger 21 line 135: Neri carried the blue token past marker fbb1c80fd376. Mara watched the eastern gate until dawn.

Ledger 21 line 136: Neri carried the blue token past marker 12803a968e38. Mara watched the eastern gate until dawn.

Ledger 21 line 137: Neri carried the blue token past marker 102d45ae29bd. Mara watched the eastern gate until dawn.

Ledger 21 line 138: Neri carried the blue token past marker 58670e451c0e. Mara watched the eastern gate until dawn.

Ledger 21 line 139: Neri carried the blue token past marker 9239061af6cd. Mara watched the eastern gate until dawn.

Ledger 21 line 140: Neri carried the blue token past marker 3a208fc9fe7a. Mara watched the eastern gate until dawn.
