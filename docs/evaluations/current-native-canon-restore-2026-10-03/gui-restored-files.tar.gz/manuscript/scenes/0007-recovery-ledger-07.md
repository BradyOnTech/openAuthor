---
id: scene-0007
title: Recovery ledger 07
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.156521+00:00
updated_at: 2026-10-03T12:14:52.156521+00:00
---

Ledger 07 line 001: Neri carried the blue token past marker d3d2f5798ea0. Mara watched the eastern gate until dawn.

Ledger 07 line 002: Neri carried the blue token past marker 1b8b6b56bf9b. Mara watched the eastern gate until dawn.

Ledger 07 line 003: Neri carried the blue token past marker 653e83e7d95b. Mara watched the eastern gate until dawn.

Ledger 07 line 004: Neri carried the blue token past marker 64209b4db9fb. Mara watched the eastern gate until dawn.

Ledger 07 line 005: Neri carried the blue token past marker 23d7d6b21a48. Mara watched the eastern gate until dawn.

Ledger 07 line 006: Neri carried the blue token past marker ec0d3d4a0dad. Mara watched the eastern gate until dawn.

Ledger 07 line 007: Neri carried the blue token past marker 5d511a5bb45d. Mara watched the eastern gate until dawn.

Ledger 07 line 008: Neri carried the blue token past marker fc5755dd88cc. Mara watched the eastern gate until dawn.

Ledger 07 line 009: Neri carried the blue token past marker a5d116fd4fec. Mara watched the eastern gate until dawn.

Ledger 07 line 010: Neri carried the blue token past marker 9e3ee503c450. Mara watched the eastern gate until dawn.

Ledger 07 line 011: Neri carried the blue token past marker 6bbc2e197b33. Mara watched the eastern gate until dawn.

Ledger 07 line 012: Neri carried the blue token past marker 2d0ba250dbdb. Mara watched the eastern gate until dawn.

Ledger 07 line 013: Neri carried the blue token past marker c3cc57b776f2. Mara watched the eastern gate until dawn.

Ledger 07 line 014: Neri carried the blue token past marker 5a48a94de9c4. Mara watched the eastern gate until dawn.

Ledger 07 line 015: Neri carried the blue token past marker 170b6fbc9474. Mara watched the eastern gate until dawn.

Ledger 07 line 016: Neri carried the blue token past marker 248fbc032826. Mara watched the eastern gate until dawn.

Ledger 07 line 017: Neri carried the blue token past marker 4923c35f3650. Mara watched the eastern gate until dawn.

Ledger 07 line 018: Neri carried the blue token past marker 423fee38ed41. Mara watched the eastern gate until dawn.

Ledger 07 line 019: Neri carried the blue token past marker a08caf908398. Mara watched the eastern gate until dawn.

Ledger 07 line 020: Neri carried the blue token past marker 182b7c0b837d. Mara watched the eastern gate until dawn.

Ledger 07 line 021: Neri carried the blue token past marker a561d3161c5c. Mara watched the eastern gate until dawn.

Ledger 07 line 022: Neri carried the blue token past marker 5af6a8f235f8. Mara watched the eastern gate until dawn.

Ledger 07 line 023: Neri carried the blue token past marker db99060e1fc5. Mara watched the eastern gate until dawn.

Ledger 07 line 024: Neri carried the blue token past marker de90c0c4ad96. Mara watched the eastern gate until dawn.

Ledger 07 line 025: Neri carried the blue token past marker 16072344496c. Mara watched the eastern gate until dawn.

Ledger 07 line 026: Neri carried the blue token past marker 437ad5c84c76. Mara watched the eastern gate until dawn.

Ledger 07 line 027: Neri carried the blue token past marker f5deb0d6a80a. Mara watched the eastern gate until dawn.

Ledger 07 line 028: Neri carried the blue token past marker a99fb9b1e750. Mara watched the eastern gate until dawn.

Ledger 07 line 029: Neri carried the blue token past marker 1966fcab8e6d. Mara watched the eastern gate until dawn.

Ledger 07 line 030: Neri carried the blue token past marker 7a55ef3631c5. Mara watched the eastern gate until dawn.

Ledger 07 line 031: Neri carried the blue token past marker 39dd7998fade. Mara watched the eastern gate until dawn.

Ledger 07 line 032: Neri carried the blue token past marker 64b5838a9d3c. Mara watched the eastern gate until dawn.

Ledger 07 line 033: Neri carried the blue token past marker 5d6a08f9a445. Mara watched the eastern gate until dawn.

Ledger 07 line 034: Neri carried the blue token past marker 6080055524e9. Mara watched the eastern gate until dawn.

Ledger 07 line 035: Neri carried the blue token past marker 5465b5ac5d75. Mara watched the eastern gate until dawn.

Ledger 07 line 036: Neri carried the blue token past marker 56ce46b8f40f. Mara watched the eastern gate until dawn.

Ledger 07 line 037: Neri carried the blue token past marker 3b8f9fe426ec. Mara watched the eastern gate until dawn.

Ledger 07 line 038: Neri carried the blue token past marker a73769545a9a. Mara watched the eastern gate until dawn.

Ledger 07 line 039: Neri carried the blue token past marker c224483d5bad. Mara watched the eastern gate until dawn.

Ledger 07 line 040: Neri carried the blue token past marker 4e8ebb4b8003. Mara watched the eastern gate until dawn.

Ledger 07 line 041: Neri carried the blue token past marker 66959b3bbe23. Mara watched the eastern gate until dawn.

Ledger 07 line 042: Neri carried the blue token past marker f0c9be30fa29. Mara watched the eastern gate until dawn.

Ledger 07 line 043: Neri carried the blue token past marker 3ccb8f52a831. Mara watched the eastern gate until dawn.

Ledger 07 line 044: Neri carried the blue token past marker 46b628153157. Mara watched the eastern gate until dawn.

Ledger 07 line 045: Neri carried the blue token past marker 95ea448e753b. Mara watched the eastern gate until dawn.

Ledger 07 line 046: Neri carried the blue token past marker 0f6294d451ca. Mara watched the eastern gate until dawn.

Ledger 07 line 047: Neri carried the blue token past marker fcd844f40a4d. Mara watched the eastern gate until dawn.

Ledger 07 line 048: Neri carried the blue token past marker d430d4678141. Mara watched the eastern gate until dawn.

Ledger 07 line 049: Neri carried the blue token past marker aef7d464624b. Mara watched the eastern gate until dawn.

Ledger 07 line 050: Neri carried the blue token past marker 17b6c9370ab4. Mara watched the eastern gate until dawn.

Ledger 07 line 051: Neri carried the blue token past marker 07faedf54669. Mara watched the eastern gate until dawn.

Ledger 07 line 052: Neri carried the blue token past marker 405128cbbbe3. Mara watched the eastern gate until dawn.

Ledger 07 line 053: Neri carried the blue token past marker 7e615f5861c0. Mara watched the eastern gate until dawn.

Ledger 07 line 054: Neri carried the blue token past marker e5dda37c9e04. Mara watched the eastern gate until dawn.

Ledger 07 line 055: Neri carried the blue token past marker 7de178cdb331. Mara watched the eastern gate until dawn.

Ledger 07 line 056: Neri carried the blue token past marker c7f2715ce752. Mara watched the eastern gate until dawn.

Ledger 07 line 057: Neri carried the blue token past marker de7d6a3c5778. Mara watched the eastern gate until dawn.

Ledger 07 line 058: Neri carried the blue token past marker 9e7d1166cc4a. Mara watched the eastern gate until dawn.

Ledger 07 line 059: Neri carried the blue token past marker 3ee4ec362a35. Mara watched the eastern gate until dawn.

Ledger 07 line 060: Neri carried the blue token past marker cb27667debed. Mara watched the eastern gate until dawn.

Ledger 07 line 061: Neri carried the blue token past marker ef17e79b8f1f. Mara watched the eastern gate until dawn.

Ledger 07 line 062: Neri carried the blue token past marker 2f36d59ba876. Mara watched the eastern gate until dawn.

Ledger 07 line 063: Neri carried the blue token past marker 097f7c2ca635. Mara watched the eastern gate until dawn.

Ledger 07 line 064: Neri carried the blue token past marker b165a3a812a5. Mara watched the eastern gate until dawn.

Ledger 07 line 065: Neri carried the blue token past marker 12783acce11d. Mara watched the eastern gate until dawn.

Ledger 07 line 066: Neri carried the blue token past marker 00fc94cadc3d. Mara watched the eastern gate until dawn.

Ledger 07 line 067: Neri carried the blue token past marker 20cccd307054. Mara watched the eastern gate until dawn.

Ledger 07 line 068: Neri carried the blue token past marker 4e20f964eb57. Mara watched the eastern gate until dawn.

Ledger 07 line 069: Neri carried the blue token past marker 773640d7baee. Mara watched the eastern gate until dawn.

Ledger 07 line 070: Neri carried the blue token past marker 4693114176a6. Mara watched the eastern gate until dawn.

Ledger 07 line 071: Neri carried the blue token past marker 9d7dcbba500f. Mara watched the eastern gate until dawn.

Ledger 07 line 072: Neri carried the blue token past marker 8d6471f5d348. Mara watched the eastern gate until dawn.

Ledger 07 line 073: Neri carried the blue token past marker 09860a0d926b. Mara watched the eastern gate until dawn.

Ledger 07 line 074: Neri carried the blue token past marker 55b576fef11f. Mara watched the eastern gate until dawn.

Ledger 07 line 075: Neri carried the blue token past marker 51edab2fa16d. Mara watched the eastern gate until dawn.

Ledger 07 line 076: Neri carried the blue token past marker 96e3f9955058. Mara watched the eastern gate until dawn.

Ledger 07 line 077: Neri carried the blue token past marker 8cf243f8450b. Mara watched the eastern gate until dawn.

Ledger 07 line 078: Neri carried the blue token past marker a3a33811992e. Mara watched the eastern gate until dawn.

Ledger 07 line 079: Neri carried the blue token past marker 18ae0f158069. Mara watched the eastern gate until dawn.

Ledger 07 line 080: Neri carried the blue token past marker b61ab6e91d11. Mara watched the eastern gate until dawn.

Ledger 07 line 081: Neri carried the blue token past marker 355e4254d7ea. Mara watched the eastern gate until dawn.

Ledger 07 line 082: Neri carried the blue token past marker 1b4e6e418d01. Mara watched the eastern gate until dawn.

Ledger 07 line 083: Neri carried the blue token past marker 66685e6a3b92. Mara watched the eastern gate until dawn.

Ledger 07 line 084: Neri carried the blue token past marker ec98aa807538. Mara watched the eastern gate until dawn.

Ledger 07 line 085: Neri carried the blue token past marker a64a188d5a74. Mara watched the eastern gate until dawn.

Ledger 07 line 086: Neri carried the blue token past marker a62478850938. Mara watched the eastern gate until dawn.

Ledger 07 line 087: Neri carried the blue token past marker 8c688e896492. Mara watched the eastern gate until dawn.

Ledger 07 line 088: Neri carried the blue token past marker e2ddf085e7f9. Mara watched the eastern gate until dawn.

Ledger 07 line 089: Neri carried the blue token past marker 84a1123286fd. Mara watched the eastern gate until dawn.

Ledger 07 line 090: Neri carried the blue token past marker e898f3372c70. Mara watched the eastern gate until dawn.

Ledger 07 line 091: Neri carried the blue token past marker 5247d20f1f51. Mara watched the eastern gate until dawn.

Ledger 07 line 092: Neri carried the blue token past marker 38bae5cd6e8d. Mara watched the eastern gate until dawn.

Ledger 07 line 093: Neri carried the blue token past marker 004e275c0393. Mara watched the eastern gate until dawn.

Ledger 07 line 094: Neri carried the blue token past marker 01f0ba73d823. Mara watched the eastern gate until dawn.

Ledger 07 line 095: Neri carried the blue token past marker e8da47612260. Mara watched the eastern gate until dawn.

Ledger 07 line 096: Neri carried the blue token past marker d541daeb17bf. Mara watched the eastern gate until dawn.

Ledger 07 line 097: Neri carried the blue token past marker df5813af40c7. Mara watched the eastern gate until dawn.

Ledger 07 line 098: Neri carried the blue token past marker 4991b42ff7d5. Mara watched the eastern gate until dawn.

Ledger 07 line 099: Neri carried the blue token past marker 0ddd554eabb1. Mara watched the eastern gate until dawn.

Ledger 07 line 100: Neri carried the blue token past marker d93b1eb29058. Mara watched the eastern gate until dawn.

Ledger 07 line 101: Neri carried the blue token past marker e2a86ae84ae7. Mara watched the eastern gate until dawn.

Ledger 07 line 102: Neri carried the blue token past marker a121b1eca2cc. Mara watched the eastern gate until dawn.

Ledger 07 line 103: Neri carried the blue token past marker 070966a98333. Mara watched the eastern gate until dawn.

Ledger 07 line 104: Neri carried the blue token past marker 7cb49c186a4e. Mara watched the eastern gate until dawn.

Ledger 07 line 105: Neri carried the blue token past marker 4d356aa95bd2. Mara watched the eastern gate until dawn.

Ledger 07 line 106: Neri carried the blue token past marker 2e19accaac6b. Mara watched the eastern gate until dawn.

Ledger 07 line 107: Neri carried the blue token past marker 35cd9bee5efd. Mara watched the eastern gate until dawn.

Ledger 07 line 108: Neri carried the blue token past marker d6de652d28b6. Mara watched the eastern gate until dawn.

Ledger 07 line 109: Neri carried the blue token past marker 37bd43603273. Mara watched the eastern gate until dawn.

Ledger 07 line 110: Neri carried the blue token past marker 18e12f8efebd. Mara watched the eastern gate until dawn.

Ledger 07 line 111: Neri carried the blue token past marker 6bbf8160184b. Mara watched the eastern gate until dawn.

Ledger 07 line 112: Neri carried the blue token past marker 45deb8fa9f45. Mara watched the eastern gate until dawn.

Ledger 07 line 113: Neri carried the blue token past marker 6ae83483c882. Mara watched the eastern gate until dawn.

Ledger 07 line 114: Neri carried the blue token past marker 66b85c79bc18. Mara watched the eastern gate until dawn.

Ledger 07 line 115: Neri carried the blue token past marker 6e71dbc1ba4f. Mara watched the eastern gate until dawn.

Ledger 07 line 116: Neri carried the blue token past marker 3d8e2cc2a611. Mara watched the eastern gate until dawn.

Ledger 07 line 117: Neri carried the blue token past marker 4e508593d2d4. Mara watched the eastern gate until dawn.

Ledger 07 line 118: Neri carried the blue token past marker 2874ae4cad7c. Mara watched the eastern gate until dawn.

Ledger 07 line 119: Neri carried the blue token past marker e1ac9790c2b1. Mara watched the eastern gate until dawn.

Ledger 07 line 120: Neri carried the blue token past marker 9bf965a12466. Mara watched the eastern gate until dawn.

Ledger 07 line 121: Neri carried the blue token past marker cf048ca44487. Mara watched the eastern gate until dawn.

Ledger 07 line 122: Neri carried the blue token past marker abcfda0176b9. Mara watched the eastern gate until dawn.

Ledger 07 line 123: Neri carried the blue token past marker 21a554603b52. Mara watched the eastern gate until dawn.

Ledger 07 line 124: Neri carried the blue token past marker 28371a8fb03c. Mara watched the eastern gate until dawn.

Ledger 07 line 125: Neri carried the blue token past marker 2259a5632a72. Mara watched the eastern gate until dawn.

Ledger 07 line 126: Neri carried the blue token past marker 1ecf85feef1a. Mara watched the eastern gate until dawn.

Ledger 07 line 127: Neri carried the blue token past marker 59eba631efb1. Mara watched the eastern gate until dawn.

Ledger 07 line 128: Neri carried the blue token past marker f482a55c504d. Mara watched the eastern gate until dawn.

Ledger 07 line 129: Neri carried the blue token past marker e844af259903. Mara watched the eastern gate until dawn.

Ledger 07 line 130: Neri carried the blue token past marker d524fef2cb71. Mara watched the eastern gate until dawn.

Ledger 07 line 131: Neri carried the blue token past marker b50e93f0ba77. Mara watched the eastern gate until dawn.

Ledger 07 line 132: Neri carried the blue token past marker 649bbb3a8257. Mara watched the eastern gate until dawn.

Ledger 07 line 133: Neri carried the blue token past marker 9b2a1d6a337d. Mara watched the eastern gate until dawn.

Ledger 07 line 134: Neri carried the blue token past marker 7d0db4190068. Mara watched the eastern gate until dawn.

Ledger 07 line 135: Neri carried the blue token past marker 140360b94705. Mara watched the eastern gate until dawn.

Ledger 07 line 136: Neri carried the blue token past marker d34ccf43f612. Mara watched the eastern gate until dawn.

Ledger 07 line 137: Neri carried the blue token past marker db302d1f6a12. Mara watched the eastern gate until dawn.

Ledger 07 line 138: Neri carried the blue token past marker 81b2f6911d2f. Mara watched the eastern gate until dawn.

Ledger 07 line 139: Neri carried the blue token past marker fb253742d9c8. Mara watched the eastern gate until dawn.

Ledger 07 line 140: Neri carried the blue token past marker 943c493d927f. Mara watched the eastern gate until dawn.
