---
id: scene-0061
title: Recovery ledger 61
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.185495+00:00
updated_at: 2026-10-03T12:14:52.185495+00:00
---

Ledger 61 line 001: Neri carried the blue token past marker e0efba247e02. Mara watched the eastern gate until dawn.

Ledger 61 line 002: Neri carried the blue token past marker 72c3dd073292. Mara watched the eastern gate until dawn.

Ledger 61 line 003: Neri carried the blue token past marker 5e5679c17bc8. Mara watched the eastern gate until dawn.

Ledger 61 line 004: Neri carried the blue token past marker e6541e7e04f0. Mara watched the eastern gate until dawn.

Ledger 61 line 005: Neri carried the blue token past marker 864c83bf31e2. Mara watched the eastern gate until dawn.

Ledger 61 line 006: Neri carried the blue token past marker 7268b325b0bd. Mara watched the eastern gate until dawn.

Ledger 61 line 007: Neri carried the blue token past marker 1fa9478b0953. Mara watched the eastern gate until dawn.

Ledger 61 line 008: Neri carried the blue token past marker 28d83f5b2b15. Mara watched the eastern gate until dawn.

Ledger 61 line 009: Neri carried the blue token past marker dfb4349b3412. Mara watched the eastern gate until dawn.

Ledger 61 line 010: Neri carried the blue token past marker e909236757a5. Mara watched the eastern gate until dawn.

Ledger 61 line 011: Neri carried the blue token past marker ce3aa6386e24. Mara watched the eastern gate until dawn.

Ledger 61 line 012: Neri carried the blue token past marker cd578b2aebb3. Mara watched the eastern gate until dawn.

Ledger 61 line 013: Neri carried the blue token past marker 325be43c6def. Mara watched the eastern gate until dawn.

Ledger 61 line 014: Neri carried the blue token past marker 2b669fd4aa57. Mara watched the eastern gate until dawn.

Ledger 61 line 015: Neri carried the blue token past marker ee9e08a1e3e9. Mara watched the eastern gate until dawn.

Ledger 61 line 016: Neri carried the blue token past marker 3589e8f21404. Mara watched the eastern gate until dawn.

Ledger 61 line 017: Neri carried the blue token past marker 5d17a35b650c. Mara watched the eastern gate until dawn.

Ledger 61 line 018: Neri carried the blue token past marker e4edaca1f60b. Mara watched the eastern gate until dawn.

Ledger 61 line 019: Neri carried the blue token past marker 93a2a6b60024. Mara watched the eastern gate until dawn.

Ledger 61 line 020: Neri carried the blue token past marker 895cfabc84f0. Mara watched the eastern gate until dawn.

Ledger 61 line 021: Neri carried the blue token past marker 0b1d311c3d69. Mara watched the eastern gate until dawn.

Ledger 61 line 022: Neri carried the blue token past marker d3edf52bffc2. Mara watched the eastern gate until dawn.

Ledger 61 line 023: Neri carried the blue token past marker 4348887351c6. Mara watched the eastern gate until dawn.

Ledger 61 line 024: Neri carried the blue token past marker 228b70b192c6. Mara watched the eastern gate until dawn.

Ledger 61 line 025: Neri carried the blue token past marker cc3499e12ef6. Mara watched the eastern gate until dawn.

Ledger 61 line 026: Neri carried the blue token past marker 70e577beb29d. Mara watched the eastern gate until dawn.

Ledger 61 line 027: Neri carried the blue token past marker 6e55b8358fed. Mara watched the eastern gate until dawn.

Ledger 61 line 028: Neri carried the blue token past marker ded824def3e7. Mara watched the eastern gate until dawn.

Ledger 61 line 029: Neri carried the blue token past marker 00ed29812d2c. Mara watched the eastern gate until dawn.

Ledger 61 line 030: Neri carried the blue token past marker fc5b56ca7a5f. Mara watched the eastern gate until dawn.

Ledger 61 line 031: Neri carried the blue token past marker e5b9d5fa7fa0. Mara watched the eastern gate until dawn.

Ledger 61 line 032: Neri carried the blue token past marker 397bdbc2878e. Mara watched the eastern gate until dawn.

Ledger 61 line 033: Neri carried the blue token past marker d5d0d4b6960f. Mara watched the eastern gate until dawn.

Ledger 61 line 034: Neri carried the blue token past marker 0be4c08f4a17. Mara watched the eastern gate until dawn.

Ledger 61 line 035: Neri carried the blue token past marker 32b63d53a62a. Mara watched the eastern gate until dawn.

Ledger 61 line 036: Neri carried the blue token past marker 41ef5b729dec. Mara watched the eastern gate until dawn.

Ledger 61 line 037: Neri carried the blue token past marker defb53210c26. Mara watched the eastern gate until dawn.

Ledger 61 line 038: Neri carried the blue token past marker 7485df1a5beb. Mara watched the eastern gate until dawn.

Ledger 61 line 039: Neri carried the blue token past marker 88fca394428b. Mara watched the eastern gate until dawn.

Ledger 61 line 040: Neri carried the blue token past marker 13d6243cc8c7. Mara watched the eastern gate until dawn.

Ledger 61 line 041: Neri carried the blue token past marker d5dd67f52b8c. Mara watched the eastern gate until dawn.

Ledger 61 line 042: Neri carried the blue token past marker d98325d79faa. Mara watched the eastern gate until dawn.

Ledger 61 line 043: Neri carried the blue token past marker ed50012636c9. Mara watched the eastern gate until dawn.

Ledger 61 line 044: Neri carried the blue token past marker 694f7cb0e467. Mara watched the eastern gate until dawn.

Ledger 61 line 045: Neri carried the blue token past marker 6ab14bf2fd46. Mara watched the eastern gate until dawn.

Ledger 61 line 046: Neri carried the blue token past marker 3675ad5237a2. Mara watched the eastern gate until dawn.

Ledger 61 line 047: Neri carried the blue token past marker e592757c01a6. Mara watched the eastern gate until dawn.

Ledger 61 line 048: Neri carried the blue token past marker 4185efdd6a58. Mara watched the eastern gate until dawn.

Ledger 61 line 049: Neri carried the blue token past marker 2fcb30348002. Mara watched the eastern gate until dawn.

Ledger 61 line 050: Neri carried the blue token past marker 11a34bf0bee3. Mara watched the eastern gate until dawn.

Ledger 61 line 051: Neri carried the blue token past marker c117c4ccaf54. Mara watched the eastern gate until dawn.

Ledger 61 line 052: Neri carried the blue token past marker e151cb32b04a. Mara watched the eastern gate until dawn.

Ledger 61 line 053: Neri carried the blue token past marker 5930fa13484e. Mara watched the eastern gate until dawn.

Ledger 61 line 054: Neri carried the blue token past marker 8cf4543e6697. Mara watched the eastern gate until dawn.

Ledger 61 line 055: Neri carried the blue token past marker dd050f77845f. Mara watched the eastern gate until dawn.

Ledger 61 line 056: Neri carried the blue token past marker 2f1f885b7dd0. Mara watched the eastern gate until dawn.

Ledger 61 line 057: Neri carried the blue token past marker 26f4c96fa5c7. Mara watched the eastern gate until dawn.

Ledger 61 line 058: Neri carried the blue token past marker bcd9623fc2dc. Mara watched the eastern gate until dawn.

Ledger 61 line 059: Neri carried the blue token past marker 8bffb182858f. Mara watched the eastern gate until dawn.

Ledger 61 line 060: Neri carried the blue token past marker 6ca79fbe8649. Mara watched the eastern gate until dawn.

Ledger 61 line 061: Neri carried the blue token past marker 1cdf5ba5038f. Mara watched the eastern gate until dawn.

Ledger 61 line 062: Neri carried the blue token past marker 2518cb4f2f9f. Mara watched the eastern gate until dawn.

Ledger 61 line 063: Neri carried the blue token past marker c9359536f46a. Mara watched the eastern gate until dawn.

Ledger 61 line 064: Neri carried the blue token past marker 65d8e494213f. Mara watched the eastern gate until dawn.

Ledger 61 line 065: Neri carried the blue token past marker 0566b3e25c4c. Mara watched the eastern gate until dawn.

Ledger 61 line 066: Neri carried the blue token past marker 1f80686bd49f. Mara watched the eastern gate until dawn.

Ledger 61 line 067: Neri carried the blue token past marker b64df75e0f13. Mara watched the eastern gate until dawn.

Ledger 61 line 068: Neri carried the blue token past marker 941a6a48302d. Mara watched the eastern gate until dawn.

Ledger 61 line 069: Neri carried the blue token past marker b3118a26966a. Mara watched the eastern gate until dawn.

Ledger 61 line 070: Neri carried the blue token past marker 2cc3f2dfd7cb. Mara watched the eastern gate until dawn.

Ledger 61 line 071: Neri carried the blue token past marker 22eec4842e19. Mara watched the eastern gate until dawn.

Ledger 61 line 072: Neri carried the blue token past marker 6df35277bc48. Mara watched the eastern gate until dawn.

Ledger 61 line 073: Neri carried the blue token past marker fe1c3d416c0c. Mara watched the eastern gate until dawn.

Ledger 61 line 074: Neri carried the blue token past marker 0aa12e237d9b. Mara watched the eastern gate until dawn.

Ledger 61 line 075: Neri carried the blue token past marker 38bb6a33e9a4. Mara watched the eastern gate until dawn.

Ledger 61 line 076: Neri carried the blue token past marker 94e89c3f7fe6. Mara watched the eastern gate until dawn.

Ledger 61 line 077: Neri carried the blue token past marker 7a4b6a844206. Mara watched the eastern gate until dawn.

Ledger 61 line 078: Neri carried the blue token past marker 4d296c018db3. Mara watched the eastern gate until dawn.

Ledger 61 line 079: Neri carried the blue token past marker 406ef7c4a720. Mara watched the eastern gate until dawn.

Ledger 61 line 080: Neri carried the blue token past marker 4867afb1371a. Mara watched the eastern gate until dawn.

Ledger 61 line 081: Neri carried the blue token past marker aaa38e529102. Mara watched the eastern gate until dawn.

Ledger 61 line 082: Neri carried the blue token past marker cb0d29ff2192. Mara watched the eastern gate until dawn.

Ledger 61 line 083: Neri carried the blue token past marker 2b3321cac79b. Mara watched the eastern gate until dawn.

Ledger 61 line 084: Neri carried the blue token past marker 36d18a0cc955. Mara watched the eastern gate until dawn.

Ledger 61 line 085: Neri carried the blue token past marker 71c4c4ccd4b0. Mara watched the eastern gate until dawn.

Ledger 61 line 086: Neri carried the blue token past marker 66c846e00bd7. Mara watched the eastern gate until dawn.

Ledger 61 line 087: Neri carried the blue token past marker fd8bca3807a2. Mara watched the eastern gate until dawn.

Ledger 61 line 088: Neri carried the blue token past marker 79712dd566af. Mara watched the eastern gate until dawn.

Ledger 61 line 089: Neri carried the blue token past marker baff4a8dbc83. Mara watched the eastern gate until dawn.

Ledger 61 line 090: Neri carried the blue token past marker 853d41089f6a. Mara watched the eastern gate until dawn.

Ledger 61 line 091: Neri carried the blue token past marker 24cedf9bd916. Mara watched the eastern gate until dawn.

Ledger 61 line 092: Neri carried the blue token past marker 4ee43a15b6f6. Mara watched the eastern gate until dawn.

Ledger 61 line 093: Neri carried the blue token past marker ef0e9b4d83b8. Mara watched the eastern gate until dawn.

Ledger 61 line 094: Neri carried the blue token past marker ff2df2810aaa. Mara watched the eastern gate until dawn.

Ledger 61 line 095: Neri carried the blue token past marker f51936fe8871. Mara watched the eastern gate until dawn.

Ledger 61 line 096: Neri carried the blue token past marker 6c28185c7b2c. Mara watched the eastern gate until dawn.

Ledger 61 line 097: Neri carried the blue token past marker 26a6ce3eb4eb. Mara watched the eastern gate until dawn.

Ledger 61 line 098: Neri carried the blue token past marker bf0698b062f0. Mara watched the eastern gate until dawn.

Ledger 61 line 099: Neri carried the blue token past marker 397cba7e1d03. Mara watched the eastern gate until dawn.

Ledger 61 line 100: Neri carried the blue token past marker 44da7d404340. Mara watched the eastern gate until dawn.

Ledger 61 line 101: Neri carried the blue token past marker 546f77e1893d. Mara watched the eastern gate until dawn.

Ledger 61 line 102: Neri carried the blue token past marker c9f6210bd43e. Mara watched the eastern gate until dawn.

Ledger 61 line 103: Neri carried the blue token past marker e36e4f7f3bdb. Mara watched the eastern gate until dawn.

Ledger 61 line 104: Neri carried the blue token past marker 2c538ac7fdd8. Mara watched the eastern gate until dawn.

Ledger 61 line 105: Neri carried the blue token past marker f0f62e416bfc. Mara watched the eastern gate until dawn.

Ledger 61 line 106: Neri carried the blue token past marker 967a0c9bfcd6. Mara watched the eastern gate until dawn.

Ledger 61 line 107: Neri carried the blue token past marker ea7274109670. Mara watched the eastern gate until dawn.

Ledger 61 line 108: Neri carried the blue token past marker d9dcfa46e5b2. Mara watched the eastern gate until dawn.

Ledger 61 line 109: Neri carried the blue token past marker 9e9d5c8d8efc. Mara watched the eastern gate until dawn.

Ledger 61 line 110: Neri carried the blue token past marker c2726ca9c934. Mara watched the eastern gate until dawn.

Ledger 61 line 111: Neri carried the blue token past marker 7ea3539fb843. Mara watched the eastern gate until dawn.

Ledger 61 line 112: Neri carried the blue token past marker 2fa0cb1704b3. Mara watched the eastern gate until dawn.

Ledger 61 line 113: Neri carried the blue token past marker 706e7ac130c7. Mara watched the eastern gate until dawn.

Ledger 61 line 114: Neri carried the blue token past marker f1993aef083d. Mara watched the eastern gate until dawn.

Ledger 61 line 115: Neri carried the blue token past marker dce1be38d788. Mara watched the eastern gate until dawn.

Ledger 61 line 116: Neri carried the blue token past marker 7c29c7e9cf1f. Mara watched the eastern gate until dawn.

Ledger 61 line 117: Neri carried the blue token past marker 98ba7b411ae1. Mara watched the eastern gate until dawn.

Ledger 61 line 118: Neri carried the blue token past marker c662cfe5a9d7. Mara watched the eastern gate until dawn.

Ledger 61 line 119: Neri carried the blue token past marker a3221f51fb2a. Mara watched the eastern gate until dawn.

Ledger 61 line 120: Neri carried the blue token past marker f14dd0c202f3. Mara watched the eastern gate until dawn.

Ledger 61 line 121: Neri carried the blue token past marker 031b74fc835e. Mara watched the eastern gate until dawn.

Ledger 61 line 122: Neri carried the blue token past marker f3a0862ad34d. Mara watched the eastern gate until dawn.

Ledger 61 line 123: Neri carried the blue token past marker 34000803b330. Mara watched the eastern gate until dawn.

Ledger 61 line 124: Neri carried the blue token past marker 2228913664da. Mara watched the eastern gate until dawn.

Ledger 61 line 125: Neri carried the blue token past marker 8636383be63e. Mara watched the eastern gate until dawn.

Ledger 61 line 126: Neri carried the blue token past marker 4586b68b4446. Mara watched the eastern gate until dawn.

Ledger 61 line 127: Neri carried the blue token past marker 640fd660d345. Mara watched the eastern gate until dawn.

Ledger 61 line 128: Neri carried the blue token past marker 0c2a2ce84e24. Mara watched the eastern gate until dawn.

Ledger 61 line 129: Neri carried the blue token past marker 24d71316b3d1. Mara watched the eastern gate until dawn.

Ledger 61 line 130: Neri carried the blue token past marker f3f4a027a8b2. Mara watched the eastern gate until dawn.

Ledger 61 line 131: Neri carried the blue token past marker 0a4b3b786d47. Mara watched the eastern gate until dawn.

Ledger 61 line 132: Neri carried the blue token past marker a8f14963fd23. Mara watched the eastern gate until dawn.

Ledger 61 line 133: Neri carried the blue token past marker ca154dca39fa. Mara watched the eastern gate until dawn.

Ledger 61 line 134: Neri carried the blue token past marker e51fc13345aa. Mara watched the eastern gate until dawn.

Ledger 61 line 135: Neri carried the blue token past marker 42a78637066e. Mara watched the eastern gate until dawn.

Ledger 61 line 136: Neri carried the blue token past marker 103349184108. Mara watched the eastern gate until dawn.

Ledger 61 line 137: Neri carried the blue token past marker d84dc5e1ff12. Mara watched the eastern gate until dawn.

Ledger 61 line 138: Neri carried the blue token past marker 4e9500724983. Mara watched the eastern gate until dawn.

Ledger 61 line 139: Neri carried the blue token past marker 0a31b7730b6a. Mara watched the eastern gate until dawn.

Ledger 61 line 140: Neri carried the blue token past marker 6cd11084abcf. Mara watched the eastern gate until dawn.
