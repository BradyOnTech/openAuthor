---
id: scene-0036
title: Recovery ledger 36
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.171966+00:00
updated_at: 2026-10-03T12:14:52.171966+00:00
---

Ledger 36 line 001: Neri carried the blue token past marker 9d38c613c2ea. Mara watched the eastern gate until dawn.

Ledger 36 line 002: Neri carried the blue token past marker 0c25493d91df. Mara watched the eastern gate until dawn.

Ledger 36 line 003: Neri carried the blue token past marker 4007727e3d78. Mara watched the eastern gate until dawn.

Ledger 36 line 004: Neri carried the blue token past marker 315c4d06527a. Mara watched the eastern gate until dawn.

Ledger 36 line 005: Neri carried the blue token past marker 4877155984f7. Mara watched the eastern gate until dawn.

Ledger 36 line 006: Neri carried the blue token past marker 6abcaf6fd236. Mara watched the eastern gate until dawn.

Ledger 36 line 007: Neri carried the blue token past marker 2c0d6dcdf8e5. Mara watched the eastern gate until dawn.

Ledger 36 line 008: Neri carried the blue token past marker 8a7babd99405. Mara watched the eastern gate until dawn.

Ledger 36 line 009: Neri carried the blue token past marker 43328d90273c. Mara watched the eastern gate until dawn.

Ledger 36 line 010: Neri carried the blue token past marker cc1ca7073b08. Mara watched the eastern gate until dawn.

Ledger 36 line 011: Neri carried the blue token past marker 6c1ccce89ac6. Mara watched the eastern gate until dawn.

Ledger 36 line 012: Neri carried the blue token past marker c11475f491f1. Mara watched the eastern gate until dawn.

Ledger 36 line 013: Neri carried the blue token past marker 44029b0c7448. Mara watched the eastern gate until dawn.

Ledger 36 line 014: Neri carried the blue token past marker 27ae57cc7c86. Mara watched the eastern gate until dawn.

Ledger 36 line 015: Neri carried the blue token past marker c83e446f41d8. Mara watched the eastern gate until dawn.

Ledger 36 line 016: Neri carried the blue token past marker d5ea28aa0c63. Mara watched the eastern gate until dawn.

Ledger 36 line 017: Neri carried the blue token past marker b3a3083f6c87. Mara watched the eastern gate until dawn.

Ledger 36 line 018: Neri carried the blue token past marker 3a32a9862aca. Mara watched the eastern gate until dawn.

Ledger 36 line 019: Neri carried the blue token past marker 363628a943cc. Mara watched the eastern gate until dawn.

Ledger 36 line 020: Neri carried the blue token past marker 59f52db79209. Mara watched the eastern gate until dawn.

Ledger 36 line 021: Neri carried the blue token past marker b23882f922f4. Mara watched the eastern gate until dawn.

Ledger 36 line 022: Neri carried the blue token past marker 9882be313ee4. Mara watched the eastern gate until dawn.

Ledger 36 line 023: Neri carried the blue token past marker 6e8580fa249e. Mara watched the eastern gate until dawn.

Ledger 36 line 024: Neri carried the blue token past marker 8ebf5a013346. Mara watched the eastern gate until dawn.

Ledger 36 line 025: Neri carried the blue token past marker 815275c4aee9. Mara watched the eastern gate until dawn.

Ledger 36 line 026: Neri carried the blue token past marker f27de925e906. Mara watched the eastern gate until dawn.

Ledger 36 line 027: Neri carried the blue token past marker eb8de30c2b47. Mara watched the eastern gate until dawn.

Ledger 36 line 028: Neri carried the blue token past marker 9d5ffa13335d. Mara watched the eastern gate until dawn.

Ledger 36 line 029: Neri carried the blue token past marker 5f7d243a8447. Mara watched the eastern gate until dawn.

Ledger 36 line 030: Neri carried the blue token past marker 32164d514b4a. Mara watched the eastern gate until dawn.

Ledger 36 line 031: Neri carried the blue token past marker 136cb80adf9c. Mara watched the eastern gate until dawn.

Ledger 36 line 032: Neri carried the blue token past marker 43d40b9d9edd. Mara watched the eastern gate until dawn.

Ledger 36 line 033: Neri carried the blue token past marker eac091637c6e. Mara watched the eastern gate until dawn.

Ledger 36 line 034: Neri carried the blue token past marker d3d9978af6de. Mara watched the eastern gate until dawn.

Ledger 36 line 035: Neri carried the blue token past marker 8d3b425022a0. Mara watched the eastern gate until dawn.

Ledger 36 line 036: Neri carried the blue token past marker 5f55e2f2252f. Mara watched the eastern gate until dawn.

Ledger 36 line 037: Neri carried the blue token past marker d9a5c3c80066. Mara watched the eastern gate until dawn.

Ledger 36 line 038: Neri carried the blue token past marker e1f790ba7d3e. Mara watched the eastern gate until dawn.

Ledger 36 line 039: Neri carried the blue token past marker fa59835d5b62. Mara watched the eastern gate until dawn.

Ledger 36 line 040: Neri carried the blue token past marker f34844bd17bb. Mara watched the eastern gate until dawn.

Ledger 36 line 041: Neri carried the blue token past marker 5e2064466ac9. Mara watched the eastern gate until dawn.

Ledger 36 line 042: Neri carried the blue token past marker 4862397b4563. Mara watched the eastern gate until dawn.

Ledger 36 line 043: Neri carried the blue token past marker 63828a0d80d1. Mara watched the eastern gate until dawn.

Ledger 36 line 044: Neri carried the blue token past marker 4c9d4e5ce4e6. Mara watched the eastern gate until dawn.

Ledger 36 line 045: Neri carried the blue token past marker 38c2e69f3abd. Mara watched the eastern gate until dawn.

Ledger 36 line 046: Neri carried the blue token past marker e252223926c4. Mara watched the eastern gate until dawn.

Ledger 36 line 047: Neri carried the blue token past marker 8393fa41b9dd. Mara watched the eastern gate until dawn.

Ledger 36 line 048: Neri carried the blue token past marker 9673189c52a8. Mara watched the eastern gate until dawn.

Ledger 36 line 049: Neri carried the blue token past marker 03bf413cd069. Mara watched the eastern gate until dawn.

Ledger 36 line 050: Neri carried the blue token past marker b55a987bc7d8. Mara watched the eastern gate until dawn.

Ledger 36 line 051: Neri carried the blue token past marker 66145933cde7. Mara watched the eastern gate until dawn.

Ledger 36 line 052: Neri carried the blue token past marker 925d211c102d. Mara watched the eastern gate until dawn.

Ledger 36 line 053: Neri carried the blue token past marker 50cfcc5a1075. Mara watched the eastern gate until dawn.

Ledger 36 line 054: Neri carried the blue token past marker 444f5646b028. Mara watched the eastern gate until dawn.

Ledger 36 line 055: Neri carried the blue token past marker d657a311712f. Mara watched the eastern gate until dawn.

Ledger 36 line 056: Neri carried the blue token past marker c4aa577acd20. Mara watched the eastern gate until dawn.

Ledger 36 line 057: Neri carried the blue token past marker 3d999f404673. Mara watched the eastern gate until dawn.

Ledger 36 line 058: Neri carried the blue token past marker 36f62714c261. Mara watched the eastern gate until dawn.

Ledger 36 line 059: Neri carried the blue token past marker 345b748f7ea4. Mara watched the eastern gate until dawn.

Ledger 36 line 060: Neri carried the blue token past marker 6e66274eb595. Mara watched the eastern gate until dawn.

Ledger 36 line 061: Neri carried the blue token past marker b6991ed706c3. Mara watched the eastern gate until dawn.

Ledger 36 line 062: Neri carried the blue token past marker a70e8deb6a0f. Mara watched the eastern gate until dawn.

Ledger 36 line 063: Neri carried the blue token past marker 4f567364efbf. Mara watched the eastern gate until dawn.

Ledger 36 line 064: Neri carried the blue token past marker 5ebe7c025024. Mara watched the eastern gate until dawn.

Ledger 36 line 065: Neri carried the blue token past marker 23a5ab89f443. Mara watched the eastern gate until dawn.

Ledger 36 line 066: Neri carried the blue token past marker fe99b8d2b5de. Mara watched the eastern gate until dawn.

Ledger 36 line 067: Neri carried the blue token past marker f1fc41641c60. Mara watched the eastern gate until dawn.

Ledger 36 line 068: Neri carried the blue token past marker cb25547de0ef. Mara watched the eastern gate until dawn.

Ledger 36 line 069: Neri carried the blue token past marker 5678e4ef0de3. Mara watched the eastern gate until dawn.

Ledger 36 line 070: Neri carried the blue token past marker 2f50c0b9ec14. Mara watched the eastern gate until dawn.

Ledger 36 line 071: Neri carried the blue token past marker e6559ac0b423. Mara watched the eastern gate until dawn.

Ledger 36 line 072: Neri carried the blue token past marker 6797b1647bca. Mara watched the eastern gate until dawn.

Ledger 36 line 073: Neri carried the blue token past marker 8145fa96e44a. Mara watched the eastern gate until dawn.

Ledger 36 line 074: Neri carried the blue token past marker 41025c623d33. Mara watched the eastern gate until dawn.

Ledger 36 line 075: Neri carried the blue token past marker 62da1ad7640e. Mara watched the eastern gate until dawn.

Ledger 36 line 076: Neri carried the blue token past marker 3c9c3dc99806. Mara watched the eastern gate until dawn.

Ledger 36 line 077: Neri carried the blue token past marker 197833c3d722. Mara watched the eastern gate until dawn.

Ledger 36 line 078: Neri carried the blue token past marker 557e9709cc72. Mara watched the eastern gate until dawn.

Ledger 36 line 079: Neri carried the blue token past marker db7d2061312a. Mara watched the eastern gate until dawn.

Ledger 36 line 080: Neri carried the blue token past marker cec3f182bd65. Mara watched the eastern gate until dawn.

Ledger 36 line 081: Neri carried the blue token past marker f97a20d3a221. Mara watched the eastern gate until dawn.

Ledger 36 line 082: Neri carried the blue token past marker 174e13863323. Mara watched the eastern gate until dawn.

Ledger 36 line 083: Neri carried the blue token past marker 96e94b0a0aa8. Mara watched the eastern gate until dawn.

Ledger 36 line 084: Neri carried the blue token past marker 1bd711c4ada2. Mara watched the eastern gate until dawn.

Ledger 36 line 085: Neri carried the blue token past marker 1ee1f5e031e0. Mara watched the eastern gate until dawn.

Ledger 36 line 086: Neri carried the blue token past marker e7498f8ca3d0. Mara watched the eastern gate until dawn.

Ledger 36 line 087: Neri carried the blue token past marker a7d2489ee4c7. Mara watched the eastern gate until dawn.

Ledger 36 line 088: Neri carried the blue token past marker 47b9f1442575. Mara watched the eastern gate until dawn.

Ledger 36 line 089: Neri carried the blue token past marker b0a5c679ccd7. Mara watched the eastern gate until dawn.

Ledger 36 line 090: Neri carried the blue token past marker 6e7264c784aa. Mara watched the eastern gate until dawn.

Ledger 36 line 091: Neri carried the blue token past marker 79f7026bdce0. Mara watched the eastern gate until dawn.

Ledger 36 line 092: Neri carried the blue token past marker 217fd3f6f714. Mara watched the eastern gate until dawn.

Ledger 36 line 093: Neri carried the blue token past marker 8c3f6c2dd5e7. Mara watched the eastern gate until dawn.

Ledger 36 line 094: Neri carried the blue token past marker c34a9b2458ac. Mara watched the eastern gate until dawn.

Ledger 36 line 095: Neri carried the blue token past marker 8140e19bc3c7. Mara watched the eastern gate until dawn.

Ledger 36 line 096: Neri carried the blue token past marker cab62bd7f08a. Mara watched the eastern gate until dawn.

Ledger 36 line 097: Neri carried the blue token past marker 291d9d2019b2. Mara watched the eastern gate until dawn.

Ledger 36 line 098: Neri carried the blue token past marker 47449162bab9. Mara watched the eastern gate until dawn.

Ledger 36 line 099: Neri carried the blue token past marker 36e19e334e70. Mara watched the eastern gate until dawn.

Ledger 36 line 100: Neri carried the blue token past marker c9a54b1d4c60. Mara watched the eastern gate until dawn.

Ledger 36 line 101: Neri carried the blue token past marker d5556b8fa7a8. Mara watched the eastern gate until dawn.

Ledger 36 line 102: Neri carried the blue token past marker 236903b6a470. Mara watched the eastern gate until dawn.

Ledger 36 line 103: Neri carried the blue token past marker c9d682049e98. Mara watched the eastern gate until dawn.

Ledger 36 line 104: Neri carried the blue token past marker 1fbbc0452409. Mara watched the eastern gate until dawn.

Ledger 36 line 105: Neri carried the blue token past marker 3374d0fad626. Mara watched the eastern gate until dawn.

Ledger 36 line 106: Neri carried the blue token past marker 44b618ae1223. Mara watched the eastern gate until dawn.

Ledger 36 line 107: Neri carried the blue token past marker 1d5ef61cfb09. Mara watched the eastern gate until dawn.

Ledger 36 line 108: Neri carried the blue token past marker 826f6ab702bf. Mara watched the eastern gate until dawn.

Ledger 36 line 109: Neri carried the blue token past marker 53fd8e7e1a04. Mara watched the eastern gate until dawn.

Ledger 36 line 110: Neri carried the blue token past marker 1d234e792448. Mara watched the eastern gate until dawn.

Ledger 36 line 111: Neri carried the blue token past marker 538461590359. Mara watched the eastern gate until dawn.

Ledger 36 line 112: Neri carried the blue token past marker 34927a6f48b3. Mara watched the eastern gate until dawn.

Ledger 36 line 113: Neri carried the blue token past marker e7b4cbe023d6. Mara watched the eastern gate until dawn.

Ledger 36 line 114: Neri carried the blue token past marker 4f170e9fcf36. Mara watched the eastern gate until dawn.

Ledger 36 line 115: Neri carried the blue token past marker b0439ded2dbd. Mara watched the eastern gate until dawn.

Ledger 36 line 116: Neri carried the blue token past marker f64484168fea. Mara watched the eastern gate until dawn.

Ledger 36 line 117: Neri carried the blue token past marker a3cd7197897d. Mara watched the eastern gate until dawn.

Ledger 36 line 118: Neri carried the blue token past marker fb56f95e0534. Mara watched the eastern gate until dawn.

Ledger 36 line 119: Neri carried the blue token past marker c3ee3e1ccd07. Mara watched the eastern gate until dawn.

Ledger 36 line 120: Neri carried the blue token past marker 9e2ba9fe688a. Mara watched the eastern gate until dawn.

Ledger 36 line 121: Neri carried the blue token past marker 21d26d84cefe. Mara watched the eastern gate until dawn.

Ledger 36 line 122: Neri carried the blue token past marker b55b49914cc9. Mara watched the eastern gate until dawn.

Ledger 36 line 123: Neri carried the blue token past marker 2a81ccbaa74b. Mara watched the eastern gate until dawn.

Ledger 36 line 124: Neri carried the blue token past marker bb3669c4980d. Mara watched the eastern gate until dawn.

Ledger 36 line 125: Neri carried the blue token past marker ef021ca1bd98. Mara watched the eastern gate until dawn.

Ledger 36 line 126: Neri carried the blue token past marker d23b063b0b78. Mara watched the eastern gate until dawn.

Ledger 36 line 127: Neri carried the blue token past marker b199be055abf. Mara watched the eastern gate until dawn.

Ledger 36 line 128: Neri carried the blue token past marker 6c276f01a967. Mara watched the eastern gate until dawn.

Ledger 36 line 129: Neri carried the blue token past marker 32646eb48d58. Mara watched the eastern gate until dawn.

Ledger 36 line 130: Neri carried the blue token past marker b8581291aff2. Mara watched the eastern gate until dawn.

Ledger 36 line 131: Neri carried the blue token past marker 629e4aabbaf4. Mara watched the eastern gate until dawn.

Ledger 36 line 132: Neri carried the blue token past marker 02d45f8f96a7. Mara watched the eastern gate until dawn.

Ledger 36 line 133: Neri carried the blue token past marker 884e9c081904. Mara watched the eastern gate until dawn.

Ledger 36 line 134: Neri carried the blue token past marker bcb3fec36e40. Mara watched the eastern gate until dawn.

Ledger 36 line 135: Neri carried the blue token past marker c5a3d2b77b99. Mara watched the eastern gate until dawn.

Ledger 36 line 136: Neri carried the blue token past marker 12f46d932bb9. Mara watched the eastern gate until dawn.

Ledger 36 line 137: Neri carried the blue token past marker bb71097281f7. Mara watched the eastern gate until dawn.

Ledger 36 line 138: Neri carried the blue token past marker d91f1664c843. Mara watched the eastern gate until dawn.

Ledger 36 line 139: Neri carried the blue token past marker 87977acae289. Mara watched the eastern gate until dawn.

Ledger 36 line 140: Neri carried the blue token past marker a33b780ab861. Mara watched the eastern gate until dawn.
