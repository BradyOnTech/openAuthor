---
id: scene-0039
title: Recovery ledger 39
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.173466+00:00
updated_at: 2026-10-03T12:14:52.173466+00:00
---

Ledger 39 line 001: Neri carried the blue token past marker 9f1a077685eb. Mara watched the eastern gate until dawn.

Ledger 39 line 002: Neri carried the blue token past marker 398778a9b741. Mara watched the eastern gate until dawn.

Ledger 39 line 003: Neri carried the blue token past marker 5818768fc701. Mara watched the eastern gate until dawn.

Ledger 39 line 004: Neri carried the blue token past marker 3020310caa9f. Mara watched the eastern gate until dawn.

Ledger 39 line 005: Neri carried the blue token past marker 3c5298b3dfa1. Mara watched the eastern gate until dawn.

Ledger 39 line 006: Neri carried the blue token past marker 102db63b0075. Mara watched the eastern gate until dawn.

Ledger 39 line 007: Neri carried the blue token past marker 8c6544e28d91. Mara watched the eastern gate until dawn.

Ledger 39 line 008: Neri carried the blue token past marker 1e942eafd8af. Mara watched the eastern gate until dawn.

Ledger 39 line 009: Neri carried the blue token past marker fcf7e841e86a. Mara watched the eastern gate until dawn.

Ledger 39 line 010: Neri carried the blue token past marker 08e18a32f5af. Mara watched the eastern gate until dawn.

Ledger 39 line 011: Neri carried the blue token past marker 5bea2a97208f. Mara watched the eastern gate until dawn.

Ledger 39 line 012: Neri carried the blue token past marker 19c1fe5e0db8. Mara watched the eastern gate until dawn.

Ledger 39 line 013: Neri carried the blue token past marker 13d1eb2371f6. Mara watched the eastern gate until dawn.

Ledger 39 line 014: Neri carried the blue token past marker 06cc01115823. Mara watched the eastern gate until dawn.

Ledger 39 line 015: Neri carried the blue token past marker c83e93608e22. Mara watched the eastern gate until dawn.

Ledger 39 line 016: Neri carried the blue token past marker cc7cb5b1dbea. Mara watched the eastern gate until dawn.

Ledger 39 line 017: Neri carried the blue token past marker 67c099e27a03. Mara watched the eastern gate until dawn.

Ledger 39 line 018: Neri carried the blue token past marker 745d96b80b2c. Mara watched the eastern gate until dawn.

Ledger 39 line 019: Neri carried the blue token past marker 73c4cb48fa6c. Mara watched the eastern gate until dawn.

Ledger 39 line 020: Neri carried the blue token past marker 859f884c5b90. Mara watched the eastern gate until dawn.

Ledger 39 line 021: Neri carried the blue token past marker 28033d6d00b3. Mara watched the eastern gate until dawn.

Ledger 39 line 022: Neri carried the blue token past marker 41219f867524. Mara watched the eastern gate until dawn.

Ledger 39 line 023: Neri carried the blue token past marker 77c0ecaf66ce. Mara watched the eastern gate until dawn.

Ledger 39 line 024: Neri carried the blue token past marker 767ea41b2a7c. Mara watched the eastern gate until dawn.

Ledger 39 line 025: Neri carried the blue token past marker fd65cf38f8df. Mara watched the eastern gate until dawn.

Ledger 39 line 026: Neri carried the blue token past marker e6e9ee5cf4cd. Mara watched the eastern gate until dawn.

Ledger 39 line 027: Neri carried the blue token past marker daf13845621d. Mara watched the eastern gate until dawn.

Ledger 39 line 028: Neri carried the blue token past marker 1042b36fc940. Mara watched the eastern gate until dawn.

Ledger 39 line 029: Neri carried the blue token past marker 04159b414037. Mara watched the eastern gate until dawn.

Ledger 39 line 030: Neri carried the blue token past marker 6888b3c39d8f. Mara watched the eastern gate until dawn.

Ledger 39 line 031: Neri carried the blue token past marker 6ad4eef28977. Mara watched the eastern gate until dawn.

Ledger 39 line 032: Neri carried the blue token past marker 14edb02ae1ce. Mara watched the eastern gate until dawn.

Ledger 39 line 033: Neri carried the blue token past marker aff710a69ae1. Mara watched the eastern gate until dawn.

Ledger 39 line 034: Neri carried the blue token past marker 524ee3ad2d22. Mara watched the eastern gate until dawn.

Ledger 39 line 035: Neri carried the blue token past marker af023f3123fe. Mara watched the eastern gate until dawn.

Ledger 39 line 036: Neri carried the blue token past marker eb5bd4d4e7bd. Mara watched the eastern gate until dawn.

Ledger 39 line 037: Neri carried the blue token past marker f91af095c374. Mara watched the eastern gate until dawn.

Ledger 39 line 038: Neri carried the blue token past marker e7888f188c1e. Mara watched the eastern gate until dawn.

Ledger 39 line 039: Neri carried the blue token past marker f35afdee96c1. Mara watched the eastern gate until dawn.

Ledger 39 line 040: Neri carried the blue token past marker c1465ca46dda. Mara watched the eastern gate until dawn.

Ledger 39 line 041: Neri carried the blue token past marker 936e3cdb1d6d. Mara watched the eastern gate until dawn.

Ledger 39 line 042: Neri carried the blue token past marker 377e8b9d5f07. Mara watched the eastern gate until dawn.

Ledger 39 line 043: Neri carried the blue token past marker 0b8ed436b846. Mara watched the eastern gate until dawn.

Ledger 39 line 044: Neri carried the blue token past marker 9b665cc39841. Mara watched the eastern gate until dawn.

Ledger 39 line 045: Neri carried the blue token past marker c72c106557c1. Mara watched the eastern gate until dawn.

Ledger 39 line 046: Neri carried the blue token past marker 268e080e9dbf. Mara watched the eastern gate until dawn.

Ledger 39 line 047: Neri carried the blue token past marker 255bd2611028. Mara watched the eastern gate until dawn.

Ledger 39 line 048: Neri carried the blue token past marker 88f3f23d64fd. Mara watched the eastern gate until dawn.

Ledger 39 line 049: Neri carried the blue token past marker 6a1bdc216f6a. Mara watched the eastern gate until dawn.

Ledger 39 line 050: Neri carried the blue token past marker ce5b588984a3. Mara watched the eastern gate until dawn.

Ledger 39 line 051: Neri carried the blue token past marker 34f2f4662162. Mara watched the eastern gate until dawn.

Ledger 39 line 052: Neri carried the blue token past marker ff94ed73bcc5. Mara watched the eastern gate until dawn.

Ledger 39 line 053: Neri carried the blue token past marker 8f2bc9051a43. Mara watched the eastern gate until dawn.

Ledger 39 line 054: Neri carried the blue token past marker e8cd97df067b. Mara watched the eastern gate until dawn.

Ledger 39 line 055: Neri carried the blue token past marker c07f563b6ae1. Mara watched the eastern gate until dawn.

Ledger 39 line 056: Neri carried the blue token past marker 8f2b0c2a06aa. Mara watched the eastern gate until dawn.

Ledger 39 line 057: Neri carried the blue token past marker f227517189a7. Mara watched the eastern gate until dawn.

Ledger 39 line 058: Neri carried the blue token past marker a7d583757487. Mara watched the eastern gate until dawn.

Ledger 39 line 059: Neri carried the blue token past marker 3aa3e3361fda. Mara watched the eastern gate until dawn.

Ledger 39 line 060: Neri carried the blue token past marker b7e891e0a746. Mara watched the eastern gate until dawn.

Ledger 39 line 061: Neri carried the blue token past marker 3ff82f17dc6d. Mara watched the eastern gate until dawn.

Ledger 39 line 062: Neri carried the blue token past marker a15c54ef7378. Mara watched the eastern gate until dawn.

Ledger 39 line 063: Neri carried the blue token past marker f798691ccb2c. Mara watched the eastern gate until dawn.

Ledger 39 line 064: Neri carried the blue token past marker a5e839485d65. Mara watched the eastern gate until dawn.

Ledger 39 line 065: Neri carried the blue token past marker 091d38ce66cd. Mara watched the eastern gate until dawn.

Ledger 39 line 066: Neri carried the blue token past marker bcaadb1fc346. Mara watched the eastern gate until dawn.

Ledger 39 line 067: Neri carried the blue token past marker e32df6e33fed. Mara watched the eastern gate until dawn.

Ledger 39 line 068: Neri carried the blue token past marker 93313094e500. Mara watched the eastern gate until dawn.

Ledger 39 line 069: Neri carried the blue token past marker 7ac577dedb74. Mara watched the eastern gate until dawn.

Ledger 39 line 070: Neri carried the blue token past marker 5ee37bf81071. Mara watched the eastern gate until dawn.

Ledger 39 line 071: Neri carried the blue token past marker 16a4f04995e8. Mara watched the eastern gate until dawn.

Ledger 39 line 072: Neri carried the blue token past marker 577731419a89. Mara watched the eastern gate until dawn.

Ledger 39 line 073: Neri carried the blue token past marker 1230c269e7d5. Mara watched the eastern gate until dawn.

Ledger 39 line 074: Neri carried the blue token past marker 183716469123. Mara watched the eastern gate until dawn.

Ledger 39 line 075: Neri carried the blue token past marker 75ff8fb5b473. Mara watched the eastern gate until dawn.

Ledger 39 line 076: Neri carried the blue token past marker 64de5049b434. Mara watched the eastern gate until dawn.

Ledger 39 line 077: Neri carried the blue token past marker 6df9912bdb93. Mara watched the eastern gate until dawn.

Ledger 39 line 078: Neri carried the blue token past marker ee1abdd806c5. Mara watched the eastern gate until dawn.

Ledger 39 line 079: Neri carried the blue token past marker 5ad975e64ba2. Mara watched the eastern gate until dawn.

Ledger 39 line 080: Neri carried the blue token past marker 84abb6e83c3d. Mara watched the eastern gate until dawn.

Ledger 39 line 081: Neri carried the blue token past marker ab01eebe9116. Mara watched the eastern gate until dawn.

Ledger 39 line 082: Neri carried the blue token past marker 6ddc6ba0927e. Mara watched the eastern gate until dawn.

Ledger 39 line 083: Neri carried the blue token past marker 56edb6c102be. Mara watched the eastern gate until dawn.

Ledger 39 line 084: Neri carried the blue token past marker 5d64be8d0acf. Mara watched the eastern gate until dawn.

Ledger 39 line 085: Neri carried the blue token past marker 91f50205a6a9. Mara watched the eastern gate until dawn.

Ledger 39 line 086: Neri carried the blue token past marker b83395e309bb. Mara watched the eastern gate until dawn.

Ledger 39 line 087: Neri carried the blue token past marker 6815ef57f278. Mara watched the eastern gate until dawn.

Ledger 39 line 088: Neri carried the blue token past marker f8340e1cc4ee. Mara watched the eastern gate until dawn.

Ledger 39 line 089: Neri carried the blue token past marker e308098649fa. Mara watched the eastern gate until dawn.

Ledger 39 line 090: Neri carried the blue token past marker 77071ef4e398. Mara watched the eastern gate until dawn.

Ledger 39 line 091: Neri carried the blue token past marker 5a34637700ad. Mara watched the eastern gate until dawn.

Ledger 39 line 092: Neri carried the blue token past marker 68ad149adb4c. Mara watched the eastern gate until dawn.

Ledger 39 line 093: Neri carried the blue token past marker 9b785e265b97. Mara watched the eastern gate until dawn.

Ledger 39 line 094: Neri carried the blue token past marker 27aa6afcc332. Mara watched the eastern gate until dawn.

Ledger 39 line 095: Neri carried the blue token past marker 49ebb9f567dc. Mara watched the eastern gate until dawn.

Ledger 39 line 096: Neri carried the blue token past marker 253a07197aef. Mara watched the eastern gate until dawn.

Ledger 39 line 097: Neri carried the blue token past marker d55af606bed0. Mara watched the eastern gate until dawn.

Ledger 39 line 098: Neri carried the blue token past marker 501f498286fe. Mara watched the eastern gate until dawn.

Ledger 39 line 099: Neri carried the blue token past marker 790575ada225. Mara watched the eastern gate until dawn.

Ledger 39 line 100: Neri carried the blue token past marker 6b3bd130feda. Mara watched the eastern gate until dawn.

Ledger 39 line 101: Neri carried the blue token past marker 9d2ede670d9f. Mara watched the eastern gate until dawn.

Ledger 39 line 102: Neri carried the blue token past marker 5d05ed344ba1. Mara watched the eastern gate until dawn.

Ledger 39 line 103: Neri carried the blue token past marker 168f248f9135. Mara watched the eastern gate until dawn.

Ledger 39 line 104: Neri carried the blue token past marker 97194c2e8f19. Mara watched the eastern gate until dawn.

Ledger 39 line 105: Neri carried the blue token past marker c9164a65cae9. Mara watched the eastern gate until dawn.

Ledger 39 line 106: Neri carried the blue token past marker 9ae51b80dee0. Mara watched the eastern gate until dawn.

Ledger 39 line 107: Neri carried the blue token past marker a98f287ceee6. Mara watched the eastern gate until dawn.

Ledger 39 line 108: Neri carried the blue token past marker 806569ff4d27. Mara watched the eastern gate until dawn.

Ledger 39 line 109: Neri carried the blue token past marker bf73ef3a9a03. Mara watched the eastern gate until dawn.

Ledger 39 line 110: Neri carried the blue token past marker 4aaf134580bf. Mara watched the eastern gate until dawn.

Ledger 39 line 111: Neri carried the blue token past marker f16d9383e486. Mara watched the eastern gate until dawn.

Ledger 39 line 112: Neri carried the blue token past marker ce4b573ab016. Mara watched the eastern gate until dawn.

Ledger 39 line 113: Neri carried the blue token past marker 0baadcf55e7e. Mara watched the eastern gate until dawn.

Ledger 39 line 114: Neri carried the blue token past marker b6d053a090c9. Mara watched the eastern gate until dawn.

Ledger 39 line 115: Neri carried the blue token past marker be21715d359b. Mara watched the eastern gate until dawn.

Ledger 39 line 116: Neri carried the blue token past marker d5b2a58a39fb. Mara watched the eastern gate until dawn.

Ledger 39 line 117: Neri carried the blue token past marker 06bec8bd20ab. Mara watched the eastern gate until dawn.

Ledger 39 line 118: Neri carried the blue token past marker a6104139810d. Mara watched the eastern gate until dawn.

Ledger 39 line 119: Neri carried the blue token past marker f7bcf31a3eb7. Mara watched the eastern gate until dawn.

Ledger 39 line 120: Neri carried the blue token past marker 72938a0313df. Mara watched the eastern gate until dawn.

Ledger 39 line 121: Neri carried the blue token past marker 4e824af1a638. Mara watched the eastern gate until dawn.

Ledger 39 line 122: Neri carried the blue token past marker 5a14ca3eea5a. Mara watched the eastern gate until dawn.

Ledger 39 line 123: Neri carried the blue token past marker ae9bc46e58a7. Mara watched the eastern gate until dawn.

Ledger 39 line 124: Neri carried the blue token past marker 1a66a83c1ace. Mara watched the eastern gate until dawn.

Ledger 39 line 125: Neri carried the blue token past marker b2a0ce5922c8. Mara watched the eastern gate until dawn.

Ledger 39 line 126: Neri carried the blue token past marker 0e03fd431bf0. Mara watched the eastern gate until dawn.

Ledger 39 line 127: Neri carried the blue token past marker f0694ee9ba08. Mara watched the eastern gate until dawn.

Ledger 39 line 128: Neri carried the blue token past marker 46ac0f893ea8. Mara watched the eastern gate until dawn.

Ledger 39 line 129: Neri carried the blue token past marker 1d1c9782101a. Mara watched the eastern gate until dawn.

Ledger 39 line 130: Neri carried the blue token past marker bcb767488ff2. Mara watched the eastern gate until dawn.

Ledger 39 line 131: Neri carried the blue token past marker ef7b163aaf91. Mara watched the eastern gate until dawn.

Ledger 39 line 132: Neri carried the blue token past marker ec384e7bde4d. Mara watched the eastern gate until dawn.

Ledger 39 line 133: Neri carried the blue token past marker f65ccb1e25ff. Mara watched the eastern gate until dawn.

Ledger 39 line 134: Neri carried the blue token past marker ec875771547b. Mara watched the eastern gate until dawn.

Ledger 39 line 135: Neri carried the blue token past marker 2a9c9886d97f. Mara watched the eastern gate until dawn.

Ledger 39 line 136: Neri carried the blue token past marker 8889d009dd4d. Mara watched the eastern gate until dawn.

Ledger 39 line 137: Neri carried the blue token past marker 57ebbb6eade3. Mara watched the eastern gate until dawn.

Ledger 39 line 138: Neri carried the blue token past marker cf3a03bb7143. Mara watched the eastern gate until dawn.

Ledger 39 line 139: Neri carried the blue token past marker e44bd4975583. Mara watched the eastern gate until dawn.

Ledger 39 line 140: Neri carried the blue token past marker fd0c90ebfb6f. Mara watched the eastern gate until dawn.
