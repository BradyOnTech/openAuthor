---
id: scene-0005
title: Recovery ledger 05
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.155536+00:00
updated_at: 2026-10-03T12:14:52.155536+00:00
---

Ledger 05 line 001: Neri carried the blue token past marker b8db3faf7572. Mara watched the eastern gate until dawn.

Ledger 05 line 002: Neri carried the blue token past marker 06a89c05b4ea. Mara watched the eastern gate until dawn.

Ledger 05 line 003: Neri carried the blue token past marker fdfc31f70114. Mara watched the eastern gate until dawn.

Ledger 05 line 004: Neri carried the blue token past marker ff060f43ada2. Mara watched the eastern gate until dawn.

Ledger 05 line 005: Neri carried the blue token past marker 73eb9911bdc6. Mara watched the eastern gate until dawn.

Ledger 05 line 006: Neri carried the blue token past marker 6527243b137e. Mara watched the eastern gate until dawn.

Ledger 05 line 007: Neri carried the blue token past marker a524479da1a7. Mara watched the eastern gate until dawn.

Ledger 05 line 008: Neri carried the blue token past marker 723eb67036c8. Mara watched the eastern gate until dawn.

Ledger 05 line 009: Neri carried the blue token past marker 6523f09afbc5. Mara watched the eastern gate until dawn.

Ledger 05 line 010: Neri carried the blue token past marker b8f2c6f5430e. Mara watched the eastern gate until dawn.

Ledger 05 line 011: Neri carried the blue token past marker 916639634200. Mara watched the eastern gate until dawn.

Ledger 05 line 012: Neri carried the blue token past marker 844f5767a567. Mara watched the eastern gate until dawn.

Ledger 05 line 013: Neri carried the blue token past marker 8bcc5e834c35. Mara watched the eastern gate until dawn.

Ledger 05 line 014: Neri carried the blue token past marker 083de4c8fb03. Mara watched the eastern gate until dawn.

Ledger 05 line 015: Neri carried the blue token past marker 9cf303d9e86d. Mara watched the eastern gate until dawn.

Ledger 05 line 016: Neri carried the blue token past marker f331957a6229. Mara watched the eastern gate until dawn.

Ledger 05 line 017: Neri carried the blue token past marker cf46a5f0d232. Mara watched the eastern gate until dawn.

Ledger 05 line 018: Neri carried the blue token past marker 22520d68cf37. Mara watched the eastern gate until dawn.

Ledger 05 line 019: Neri carried the blue token past marker 7762cec0379f. Mara watched the eastern gate until dawn.

Ledger 05 line 020: Neri carried the blue token past marker 4fe17714b9f5. Mara watched the eastern gate until dawn.

Ledger 05 line 021: Neri carried the blue token past marker e5939b0541ff. Mara watched the eastern gate until dawn.

Ledger 05 line 022: Neri carried the blue token past marker 0e44545c3c07. Mara watched the eastern gate until dawn.

Ledger 05 line 023: Neri carried the blue token past marker 2d38207e810e. Mara watched the eastern gate until dawn.

Ledger 05 line 024: Neri carried the blue token past marker ba75b3eacd69. Mara watched the eastern gate until dawn.

Ledger 05 line 025: Neri carried the blue token past marker 9ed61271bd5a. Mara watched the eastern gate until dawn.

Ledger 05 line 026: Neri carried the blue token past marker 6516a5335e3f. Mara watched the eastern gate until dawn.

Ledger 05 line 027: Neri carried the blue token past marker 7fd7fd2f60b1. Mara watched the eastern gate until dawn.

Ledger 05 line 028: Neri carried the blue token past marker 4524c4c69641. Mara watched the eastern gate until dawn.

Ledger 05 line 029: Neri carried the blue token past marker 52c8db4179ac. Mara watched the eastern gate until dawn.

Ledger 05 line 030: Neri carried the blue token past marker 245950404a0f. Mara watched the eastern gate until dawn.

Ledger 05 line 031: Neri carried the blue token past marker 7cd3f1dcce97. Mara watched the eastern gate until dawn.

Ledger 05 line 032: Neri carried the blue token past marker 16f6fc79c84e. Mara watched the eastern gate until dawn.

Ledger 05 line 033: Neri carried the blue token past marker 81d7bee4cc66. Mara watched the eastern gate until dawn.

Ledger 05 line 034: Neri carried the blue token past marker f7802518a281. Mara watched the eastern gate until dawn.

Ledger 05 line 035: Neri carried the blue token past marker 4247d5158d87. Mara watched the eastern gate until dawn.

Ledger 05 line 036: Neri carried the blue token past marker c425d5c10241. Mara watched the eastern gate until dawn.

Ledger 05 line 037: Neri carried the blue token past marker 3ba65d89e494. Mara watched the eastern gate until dawn.

Ledger 05 line 038: Neri carried the blue token past marker 240c0657df0d. Mara watched the eastern gate until dawn.

Ledger 05 line 039: Neri carried the blue token past marker 2959e15a79ab. Mara watched the eastern gate until dawn.

Ledger 05 line 040: Neri carried the blue token past marker fb4194839061. Mara watched the eastern gate until dawn.

Ledger 05 line 041: Neri carried the blue token past marker 962a292a3e69. Mara watched the eastern gate until dawn.

Ledger 05 line 042: Neri carried the blue token past marker f5e754c12fa2. Mara watched the eastern gate until dawn.

Ledger 05 line 043: Neri carried the blue token past marker 866f84f63824. Mara watched the eastern gate until dawn.

Ledger 05 line 044: Neri carried the blue token past marker e29277fa66d8. Mara watched the eastern gate until dawn.

Ledger 05 line 045: Neri carried the blue token past marker 0eface02e070. Mara watched the eastern gate until dawn.

Ledger 05 line 046: Neri carried the blue token past marker dffaf3f30615. Mara watched the eastern gate until dawn.

Ledger 05 line 047: Neri carried the blue token past marker 699a81442d8a. Mara watched the eastern gate until dawn.

Ledger 05 line 048: Neri carried the blue token past marker f5720170b44e. Mara watched the eastern gate until dawn.

Ledger 05 line 049: Neri carried the blue token past marker 0539273ddab5. Mara watched the eastern gate until dawn.

Ledger 05 line 050: Neri carried the blue token past marker 0491b2821293. Mara watched the eastern gate until dawn.

Ledger 05 line 051: Neri carried the blue token past marker b89db0492243. Mara watched the eastern gate until dawn.

Ledger 05 line 052: Neri carried the blue token past marker 3d44c99d0541. Mara watched the eastern gate until dawn.

Ledger 05 line 053: Neri carried the blue token past marker 685796858f72. Mara watched the eastern gate until dawn.

Ledger 05 line 054: Neri carried the blue token past marker 0c1e6327e3f2. Mara watched the eastern gate until dawn.

Ledger 05 line 055: Neri carried the blue token past marker 7dd587306117. Mara watched the eastern gate until dawn.

Ledger 05 line 056: Neri carried the blue token past marker 2a06435ebda7. Mara watched the eastern gate until dawn.

Ledger 05 line 057: Neri carried the blue token past marker df2727eca045. Mara watched the eastern gate until dawn.

Ledger 05 line 058: Neri carried the blue token past marker 99831851c4c9. Mara watched the eastern gate until dawn.

Ledger 05 line 059: Neri carried the blue token past marker d04e0fcbcca1. Mara watched the eastern gate until dawn.

Ledger 05 line 060: Neri carried the blue token past marker fe615d5861a8. Mara watched the eastern gate until dawn.

Ledger 05 line 061: Neri carried the blue token past marker 510052686f76. Mara watched the eastern gate until dawn.

Ledger 05 line 062: Neri carried the blue token past marker 45c34a98fa26. Mara watched the eastern gate until dawn.

Ledger 05 line 063: Neri carried the blue token past marker 9c194ef2ce3b. Mara watched the eastern gate until dawn.

Ledger 05 line 064: Neri carried the blue token past marker 7ac0ad67e288. Mara watched the eastern gate until dawn.

Ledger 05 line 065: Neri carried the blue token past marker b4f75e20987a. Mara watched the eastern gate until dawn.

Ledger 05 line 066: Neri carried the blue token past marker 3fd56fd8f094. Mara watched the eastern gate until dawn.

Ledger 05 line 067: Neri carried the blue token past marker 00285a6b88eb. Mara watched the eastern gate until dawn.

Ledger 05 line 068: Neri carried the blue token past marker e12caf9eba97. Mara watched the eastern gate until dawn.

Ledger 05 line 069: Neri carried the blue token past marker bd8d09e28ae9. Mara watched the eastern gate until dawn.

Ledger 05 line 070: Neri carried the blue token past marker ff164e6ffeb3. Mara watched the eastern gate until dawn.

Ledger 05 line 071: Neri carried the blue token past marker 05401561ac49. Mara watched the eastern gate until dawn.

Ledger 05 line 072: Neri carried the blue token past marker 951b9d8f0c44. Mara watched the eastern gate until dawn.

Ledger 05 line 073: Neri carried the blue token past marker 0577e2a1c344. Mara watched the eastern gate until dawn.

Ledger 05 line 074: Neri carried the blue token past marker 8a218097ab78. Mara watched the eastern gate until dawn.

Ledger 05 line 075: Neri carried the blue token past marker 36429db9c7ec. Mara watched the eastern gate until dawn.

Ledger 05 line 076: Neri carried the blue token past marker bf19f556fa10. Mara watched the eastern gate until dawn.

Ledger 05 line 077: Neri carried the blue token past marker 7d5dc99bc01b. Mara watched the eastern gate until dawn.

Ledger 05 line 078: Neri carried the blue token past marker ee33e55f4f35. Mara watched the eastern gate until dawn.

Ledger 05 line 079: Neri carried the blue token past marker 4c0f2960554b. Mara watched the eastern gate until dawn.

Ledger 05 line 080: Neri carried the blue token past marker 0d79cf871af0. Mara watched the eastern gate until dawn.

Ledger 05 line 081: Neri carried the blue token past marker 554c625f1ea5. Mara watched the eastern gate until dawn.

Ledger 05 line 082: Neri carried the blue token past marker bf6b549f45a3. Mara watched the eastern gate until dawn.

Ledger 05 line 083: Neri carried the blue token past marker 51b78e2d8e3c. Mara watched the eastern gate until dawn.

Ledger 05 line 084: Neri carried the blue token past marker fb082bbcf98f. Mara watched the eastern gate until dawn.

Ledger 05 line 085: Neri carried the blue token past marker 64b5074405aa. Mara watched the eastern gate until dawn.

Ledger 05 line 086: Neri carried the blue token past marker 40bf32dc978c. Mara watched the eastern gate until dawn.

Ledger 05 line 087: Neri carried the blue token past marker 886ff4c3c8e8. Mara watched the eastern gate until dawn.

Ledger 05 line 088: Neri carried the blue token past marker de291892e600. Mara watched the eastern gate until dawn.

Ledger 05 line 089: Neri carried the blue token past marker 202243603739. Mara watched the eastern gate until dawn.

Ledger 05 line 090: Neri carried the blue token past marker fb8d7acfc0c6. Mara watched the eastern gate until dawn.

Ledger 05 line 091: Neri carried the blue token past marker 2a74bbedf750. Mara watched the eastern gate until dawn.

Ledger 05 line 092: Neri carried the blue token past marker 835aa7e4f74c. Mara watched the eastern gate until dawn.

Ledger 05 line 093: Neri carried the blue token past marker db63f8267af3. Mara watched the eastern gate until dawn.

Ledger 05 line 094: Neri carried the blue token past marker 72eba412ff0b. Mara watched the eastern gate until dawn.

Ledger 05 line 095: Neri carried the blue token past marker b9cc946a9902. Mara watched the eastern gate until dawn.

Ledger 05 line 096: Neri carried the blue token past marker 32719dcf8f66. Mara watched the eastern gate until dawn.

Ledger 05 line 097: Neri carried the blue token past marker f2d888779693. Mara watched the eastern gate until dawn.

Ledger 05 line 098: Neri carried the blue token past marker bcb95ab53c47. Mara watched the eastern gate until dawn.

Ledger 05 line 099: Neri carried the blue token past marker ac094efe70c6. Mara watched the eastern gate until dawn.

Ledger 05 line 100: Neri carried the blue token past marker abe0adce36c1. Mara watched the eastern gate until dawn.

Ledger 05 line 101: Neri carried the blue token past marker 032b00b4fc8c. Mara watched the eastern gate until dawn.

Ledger 05 line 102: Neri carried the blue token past marker 1dce2dd826b1. Mara watched the eastern gate until dawn.

Ledger 05 line 103: Neri carried the blue token past marker 4e95d9e9e12f. Mara watched the eastern gate until dawn.

Ledger 05 line 104: Neri carried the blue token past marker 1b8300437a9d. Mara watched the eastern gate until dawn.

Ledger 05 line 105: Neri carried the blue token past marker 134f85878d98. Mara watched the eastern gate until dawn.

Ledger 05 line 106: Neri carried the blue token past marker 56494293d007. Mara watched the eastern gate until dawn.

Ledger 05 line 107: Neri carried the blue token past marker 55a9c19db098. Mara watched the eastern gate until dawn.

Ledger 05 line 108: Neri carried the blue token past marker 233fa11d1885. Mara watched the eastern gate until dawn.

Ledger 05 line 109: Neri carried the blue token past marker 031be495fd29. Mara watched the eastern gate until dawn.

Ledger 05 line 110: Neri carried the blue token past marker 99c23c13b6f0. Mara watched the eastern gate until dawn.

Ledger 05 line 111: Neri carried the blue token past marker 5d623ff1067a. Mara watched the eastern gate until dawn.

Ledger 05 line 112: Neri carried the blue token past marker 6dc452be6230. Mara watched the eastern gate until dawn.

Ledger 05 line 113: Neri carried the blue token past marker 43f94150a8b9. Mara watched the eastern gate until dawn.

Ledger 05 line 114: Neri carried the blue token past marker 11589b393a9f. Mara watched the eastern gate until dawn.

Ledger 05 line 115: Neri carried the blue token past marker 77a2513432ac. Mara watched the eastern gate until dawn.

Ledger 05 line 116: Neri carried the blue token past marker 592b5c31d3fc. Mara watched the eastern gate until dawn.

Ledger 05 line 117: Neri carried the blue token past marker 4bfcc2d3fc50. Mara watched the eastern gate until dawn.

Ledger 05 line 118: Neri carried the blue token past marker 90f518acb7c3. Mara watched the eastern gate until dawn.

Ledger 05 line 119: Neri carried the blue token past marker dd6ace61bd17. Mara watched the eastern gate until dawn.

Ledger 05 line 120: Neri carried the blue token past marker a68b7b24867c. Mara watched the eastern gate until dawn.

Ledger 05 line 121: Neri carried the blue token past marker 43de0a4b2a39. Mara watched the eastern gate until dawn.

Ledger 05 line 122: Neri carried the blue token past marker 1ed2db465ccc. Mara watched the eastern gate until dawn.

Ledger 05 line 123: Neri carried the blue token past marker ae6ea6b7b451. Mara watched the eastern gate until dawn.

Ledger 05 line 124: Neri carried the blue token past marker 55f1e2f275e8. Mara watched the eastern gate until dawn.

Ledger 05 line 125: Neri carried the blue token past marker 1a06c2d932fc. Mara watched the eastern gate until dawn.

Ledger 05 line 126: Neri carried the blue token past marker 5de8a9e21af2. Mara watched the eastern gate until dawn.

Ledger 05 line 127: Neri carried the blue token past marker 9412b1ac057d. Mara watched the eastern gate until dawn.

Ledger 05 line 128: Neri carried the blue token past marker f9ccde6a9763. Mara watched the eastern gate until dawn.

Ledger 05 line 129: Neri carried the blue token past marker 4cd1693e42b8. Mara watched the eastern gate until dawn.

Ledger 05 line 130: Neri carried the blue token past marker 9dc4aaf98bcf. Mara watched the eastern gate until dawn.

Ledger 05 line 131: Neri carried the blue token past marker 094e380c4f56. Mara watched the eastern gate until dawn.

Ledger 05 line 132: Neri carried the blue token past marker dc30856ff6b8. Mara watched the eastern gate until dawn.

Ledger 05 line 133: Neri carried the blue token past marker b4c840511695. Mara watched the eastern gate until dawn.

Ledger 05 line 134: Neri carried the blue token past marker 4cd323802c51. Mara watched the eastern gate until dawn.

Ledger 05 line 135: Neri carried the blue token past marker 9e7a631e7fdb. Mara watched the eastern gate until dawn.

Ledger 05 line 136: Neri carried the blue token past marker ed0c2b22ca26. Mara watched the eastern gate until dawn.

Ledger 05 line 137: Neri carried the blue token past marker 702c2b18343c. Mara watched the eastern gate until dawn.

Ledger 05 line 138: Neri carried the blue token past marker 50539a35a983. Mara watched the eastern gate until dawn.

Ledger 05 line 139: Neri carried the blue token past marker 926b8cf68f0e. Mara watched the eastern gate until dawn.

Ledger 05 line 140: Neri carried the blue token past marker c4b212e92615. Mara watched the eastern gate until dawn.
