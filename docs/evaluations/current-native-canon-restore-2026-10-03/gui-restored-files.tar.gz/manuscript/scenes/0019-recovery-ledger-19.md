---
id: scene-0019
title: Recovery ledger 19
summary: 
pov: 
status: draft
created_at: 2026-10-03T12:14:52.162497+00:00
updated_at: 2026-10-03T12:14:52.162497+00:00
---

Ledger 19 line 001: Neri carried the blue token past marker 52a6cc54b97c. Mara watched the eastern gate until dawn.

Ledger 19 line 002: Neri carried the blue token past marker 5184c24d95fc. Mara watched the eastern gate until dawn.

Ledger 19 line 003: Neri carried the blue token past marker 81bf917e85d5. Mara watched the eastern gate until dawn.

Ledger 19 line 004: Neri carried the blue token past marker a6c92d4fc496. Mara watched the eastern gate until dawn.

Ledger 19 line 005: Neri carried the blue token past marker e514a55c6068. Mara watched the eastern gate until dawn.

Ledger 19 line 006: Neri carried the blue token past marker 15e91bbc928d. Mara watched the eastern gate until dawn.

Ledger 19 line 007: Neri carried the blue token past marker 90d1f6cb981e. Mara watched the eastern gate until dawn.

Ledger 19 line 008: Neri carried the blue token past marker fb37dd4e408b. Mara watched the eastern gate until dawn.

Ledger 19 line 009: Neri carried the blue token past marker b717487010db. Mara watched the eastern gate until dawn.

Ledger 19 line 010: Neri carried the blue token past marker 2e67235582e9. Mara watched the eastern gate until dawn.

Ledger 19 line 011: Neri carried the blue token past marker 726696a6b155. Mara watched the eastern gate until dawn.

Ledger 19 line 012: Neri carried the blue token past marker 49706e8e68d5. Mara watched the eastern gate until dawn.

Ledger 19 line 013: Neri carried the blue token past marker 440ed0ac0601. Mara watched the eastern gate until dawn.

Ledger 19 line 014: Neri carried the blue token past marker 7c67230b09e6. Mara watched the eastern gate until dawn.

Ledger 19 line 015: Neri carried the blue token past marker 1e5bc24e0628. Mara watched the eastern gate until dawn.

Ledger 19 line 016: Neri carried the blue token past marker 7224417e0588. Mara watched the eastern gate until dawn.

Ledger 19 line 017: Neri carried the blue token past marker b3b01e6410ca. Mara watched the eastern gate until dawn.

Ledger 19 line 018: Neri carried the blue token past marker 1d0a182f07cb. Mara watched the eastern gate until dawn.

Ledger 19 line 019: Neri carried the blue token past marker 195402c466ed. Mara watched the eastern gate until dawn.

Ledger 19 line 020: Neri carried the blue token past marker f6c8736635e0. Mara watched the eastern gate until dawn.

Ledger 19 line 021: Neri carried the blue token past marker 0240b76a1c3b. Mara watched the eastern gate until dawn.

Ledger 19 line 022: Neri carried the blue token past marker 81ecf3491ab0. Mara watched the eastern gate until dawn.

Ledger 19 line 023: Neri carried the blue token past marker 72d18a6b2c70. Mara watched the eastern gate until dawn.

Ledger 19 line 024: Neri carried the blue token past marker 446e0afa2bbc. Mara watched the eastern gate until dawn.

Ledger 19 line 025: Neri carried the blue token past marker be53efd59a39. Mara watched the eastern gate until dawn.

Ledger 19 line 026: Neri carried the blue token past marker 36c6ebb10059. Mara watched the eastern gate until dawn.

Ledger 19 line 027: Neri carried the blue token past marker a5de2767506d. Mara watched the eastern gate until dawn.

Ledger 19 line 028: Neri carried the blue token past marker bea6c303d65a. Mara watched the eastern gate until dawn.

Ledger 19 line 029: Neri carried the blue token past marker d40178a715e4. Mara watched the eastern gate until dawn.

Ledger 19 line 030: Neri carried the blue token past marker cf2bf78b16dd. Mara watched the eastern gate until dawn.

Ledger 19 line 031: Neri carried the blue token past marker 253ada94ef7a. Mara watched the eastern gate until dawn.

Ledger 19 line 032: Neri carried the blue token past marker 672c91567dc3. Mara watched the eastern gate until dawn.

Ledger 19 line 033: Neri carried the blue token past marker 1ed0ab0921f1. Mara watched the eastern gate until dawn.

Ledger 19 line 034: Neri carried the blue token past marker 2a74de4ba6d2. Mara watched the eastern gate until dawn.

Ledger 19 line 035: Neri carried the blue token past marker 9f6cc9ac9009. Mara watched the eastern gate until dawn.

Ledger 19 line 036: Neri carried the blue token past marker c2e69355fa15. Mara watched the eastern gate until dawn.

Ledger 19 line 037: Neri carried the blue token past marker af616b472245. Mara watched the eastern gate until dawn.

Ledger 19 line 038: Neri carried the blue token past marker b38019a5c767. Mara watched the eastern gate until dawn.

Ledger 19 line 039: Neri carried the blue token past marker 6b2462a7d330. Mara watched the eastern gate until dawn.

Ledger 19 line 040: Neri carried the blue token past marker 948a322a5913. Mara watched the eastern gate until dawn.

Ledger 19 line 041: Neri carried the blue token past marker 833471b34ef3. Mara watched the eastern gate until dawn.

Ledger 19 line 042: Neri carried the blue token past marker 443e77f10be0. Mara watched the eastern gate until dawn.

Ledger 19 line 043: Neri carried the blue token past marker 37c7b25c5b2c. Mara watched the eastern gate until dawn.

Ledger 19 line 044: Neri carried the blue token past marker dfa570161bdc. Mara watched the eastern gate until dawn.

Ledger 19 line 045: Neri carried the blue token past marker c416c05d925b. Mara watched the eastern gate until dawn.

Ledger 19 line 046: Neri carried the blue token past marker ea8285654cf1. Mara watched the eastern gate until dawn.

Ledger 19 line 047: Neri carried the blue token past marker 6926da785207. Mara watched the eastern gate until dawn.

Ledger 19 line 048: Neri carried the blue token past marker b744b3d14b98. Mara watched the eastern gate until dawn.

Ledger 19 line 049: Neri carried the blue token past marker 71e141218efa. Mara watched the eastern gate until dawn.

Ledger 19 line 050: Neri carried the blue token past marker 069864e1fa4a. Mara watched the eastern gate until dawn.

Ledger 19 line 051: Neri carried the blue token past marker 7a8b9d7a80ea. Mara watched the eastern gate until dawn.

Ledger 19 line 052: Neri carried the blue token past marker 2a3991fec67d. Mara watched the eastern gate until dawn.

Ledger 19 line 053: Neri carried the blue token past marker ecd00c94f447. Mara watched the eastern gate until dawn.

Ledger 19 line 054: Neri carried the blue token past marker aa5d615331e9. Mara watched the eastern gate until dawn.

Ledger 19 line 055: Neri carried the blue token past marker 680d5136474d. Mara watched the eastern gate until dawn.

Ledger 19 line 056: Neri carried the blue token past marker 921fc77acb42. Mara watched the eastern gate until dawn.

Ledger 19 line 057: Neri carried the blue token past marker da87109496ff. Mara watched the eastern gate until dawn.

Ledger 19 line 058: Neri carried the blue token past marker 35d79547a104. Mara watched the eastern gate until dawn.

Ledger 19 line 059: Neri carried the blue token past marker d929719f80fb. Mara watched the eastern gate until dawn.

Ledger 19 line 060: Neri carried the blue token past marker 27e7d34b7e54. Mara watched the eastern gate until dawn.

Ledger 19 line 061: Neri carried the blue token past marker 0ebc927fe842. Mara watched the eastern gate until dawn.

Ledger 19 line 062: Neri carried the blue token past marker 99629454aad4. Mara watched the eastern gate until dawn.

Ledger 19 line 063: Neri carried the blue token past marker c614dc34cd72. Mara watched the eastern gate until dawn.

Ledger 19 line 064: Neri carried the blue token past marker efa0afc80b30. Mara watched the eastern gate until dawn.

Ledger 19 line 065: Neri carried the blue token past marker eeeaa8cd6fc8. Mara watched the eastern gate until dawn.

Ledger 19 line 066: Neri carried the blue token past marker 4af850fa54b8. Mara watched the eastern gate until dawn.

Ledger 19 line 067: Neri carried the blue token past marker 1feeed7ae48c. Mara watched the eastern gate until dawn.

Ledger 19 line 068: Neri carried the blue token past marker d43e97bed5ea. Mara watched the eastern gate until dawn.

Ledger 19 line 069: Neri carried the blue token past marker 818595197579. Mara watched the eastern gate until dawn.

Ledger 19 line 070: Neri carried the blue token past marker d1cdbccf24ab. Mara watched the eastern gate until dawn.

Ledger 19 line 071: Neri carried the blue token past marker c11b72fa0a85. Mara watched the eastern gate until dawn.

Ledger 19 line 072: Neri carried the blue token past marker 72376b044c55. Mara watched the eastern gate until dawn.

Ledger 19 line 073: Neri carried the blue token past marker ddb6df513a28. Mara watched the eastern gate until dawn.

Ledger 19 line 074: Neri carried the blue token past marker e4459d7baa1f. Mara watched the eastern gate until dawn.

Ledger 19 line 075: Neri carried the blue token past marker a97e76c8f57e. Mara watched the eastern gate until dawn.

Ledger 19 line 076: Neri carried the blue token past marker e68ae8ef2b8f. Mara watched the eastern gate until dawn.

Ledger 19 line 077: Neri carried the blue token past marker 6ac0433f714d. Mara watched the eastern gate until dawn.

Ledger 19 line 078: Neri carried the blue token past marker fc84f672093a. Mara watched the eastern gate until dawn.

Ledger 19 line 079: Neri carried the blue token past marker 6055ee426970. Mara watched the eastern gate until dawn.

Ledger 19 line 080: Neri carried the blue token past marker ad7d1f16849a. Mara watched the eastern gate until dawn.

Ledger 19 line 081: Neri carried the blue token past marker f71ec31bcf21. Mara watched the eastern gate until dawn.

Ledger 19 line 082: Neri carried the blue token past marker 932f5ed47c7c. Mara watched the eastern gate until dawn.

Ledger 19 line 083: Neri carried the blue token past marker acb123b37697. Mara watched the eastern gate until dawn.

Ledger 19 line 084: Neri carried the blue token past marker eb260b48908c. Mara watched the eastern gate until dawn.

Ledger 19 line 085: Neri carried the blue token past marker ae8729725403. Mara watched the eastern gate until dawn.

Ledger 19 line 086: Neri carried the blue token past marker 01a5029418fe. Mara watched the eastern gate until dawn.

Ledger 19 line 087: Neri carried the blue token past marker 7edbf2e86c5b. Mara watched the eastern gate until dawn.

Ledger 19 line 088: Neri carried the blue token past marker 964ea11bd262. Mara watched the eastern gate until dawn.

Ledger 19 line 089: Neri carried the blue token past marker 11d3dcdfd332. Mara watched the eastern gate until dawn.

Ledger 19 line 090: Neri carried the blue token past marker c94c4dab5d29. Mara watched the eastern gate until dawn.

Ledger 19 line 091: Neri carried the blue token past marker 6bb9823952b3. Mara watched the eastern gate until dawn.

Ledger 19 line 092: Neri carried the blue token past marker 8caeb563a493. Mara watched the eastern gate until dawn.

Ledger 19 line 093: Neri carried the blue token past marker 3c56a1a44016. Mara watched the eastern gate until dawn.

Ledger 19 line 094: Neri carried the blue token past marker 45f64a6996f7. Mara watched the eastern gate until dawn.

Ledger 19 line 095: Neri carried the blue token past marker fe0d56d2af56. Mara watched the eastern gate until dawn.

Ledger 19 line 096: Neri carried the blue token past marker 2ad2f9dc858e. Mara watched the eastern gate until dawn.

Ledger 19 line 097: Neri carried the blue token past marker 683e6cfcfbf1. Mara watched the eastern gate until dawn.

Ledger 19 line 098: Neri carried the blue token past marker 3c630fa88bb2. Mara watched the eastern gate until dawn.

Ledger 19 line 099: Neri carried the blue token past marker 8305d3d3a4ac. Mara watched the eastern gate until dawn.

Ledger 19 line 100: Neri carried the blue token past marker bc48173d8581. Mara watched the eastern gate until dawn.

Ledger 19 line 101: Neri carried the blue token past marker d597e4247f5d. Mara watched the eastern gate until dawn.

Ledger 19 line 102: Neri carried the blue token past marker 2641682c8d10. Mara watched the eastern gate until dawn.

Ledger 19 line 103: Neri carried the blue token past marker b8523ad2bd5e. Mara watched the eastern gate until dawn.

Ledger 19 line 104: Neri carried the blue token past marker 5328bc22c39a. Mara watched the eastern gate until dawn.

Ledger 19 line 105: Neri carried the blue token past marker ebdfac20e8b0. Mara watched the eastern gate until dawn.

Ledger 19 line 106: Neri carried the blue token past marker 34a8fe80d8ef. Mara watched the eastern gate until dawn.

Ledger 19 line 107: Neri carried the blue token past marker 740fe6041c2a. Mara watched the eastern gate until dawn.

Ledger 19 line 108: Neri carried the blue token past marker 4a9e3228714f. Mara watched the eastern gate until dawn.

Ledger 19 line 109: Neri carried the blue token past marker d9d2de598482. Mara watched the eastern gate until dawn.

Ledger 19 line 110: Neri carried the blue token past marker 2929a8930b3b. Mara watched the eastern gate until dawn.

Ledger 19 line 111: Neri carried the blue token past marker 76c480e68c29. Mara watched the eastern gate until dawn.

Ledger 19 line 112: Neri carried the blue token past marker 74e668308e82. Mara watched the eastern gate until dawn.

Ledger 19 line 113: Neri carried the blue token past marker 7bcb36cfa728. Mara watched the eastern gate until dawn.

Ledger 19 line 114: Neri carried the blue token past marker 835204695a2c. Mara watched the eastern gate until dawn.

Ledger 19 line 115: Neri carried the blue token past marker d2cde3207233. Mara watched the eastern gate until dawn.

Ledger 19 line 116: Neri carried the blue token past marker f439b3885ae4. Mara watched the eastern gate until dawn.

Ledger 19 line 117: Neri carried the blue token past marker 99e65153e289. Mara watched the eastern gate until dawn.

Ledger 19 line 118: Neri carried the blue token past marker 0a2ecba5860d. Mara watched the eastern gate until dawn.

Ledger 19 line 119: Neri carried the blue token past marker 1793304f7230. Mara watched the eastern gate until dawn.

Ledger 19 line 120: Neri carried the blue token past marker 39f86380c008. Mara watched the eastern gate until dawn.

Ledger 19 line 121: Neri carried the blue token past marker 2fc168b9b912. Mara watched the eastern gate until dawn.

Ledger 19 line 122: Neri carried the blue token past marker e326b97a945b. Mara watched the eastern gate until dawn.

Ledger 19 line 123: Neri carried the blue token past marker 0415be5e7eac. Mara watched the eastern gate until dawn.

Ledger 19 line 124: Neri carried the blue token past marker 8913280b53e9. Mara watched the eastern gate until dawn.

Ledger 19 line 125: Neri carried the blue token past marker 9f558d74d2bc. Mara watched the eastern gate until dawn.

Ledger 19 line 126: Neri carried the blue token past marker 93267230cb9b. Mara watched the eastern gate until dawn.

Ledger 19 line 127: Neri carried the blue token past marker a1ce5acf5f44. Mara watched the eastern gate until dawn.

Ledger 19 line 128: Neri carried the blue token past marker 0b604ff0de80. Mara watched the eastern gate until dawn.

Ledger 19 line 129: Neri carried the blue token past marker 71583c7bd428. Mara watched the eastern gate until dawn.

Ledger 19 line 130: Neri carried the blue token past marker c7814964f33a. Mara watched the eastern gate until dawn.

Ledger 19 line 131: Neri carried the blue token past marker 6e2d91122d86. Mara watched the eastern gate until dawn.

Ledger 19 line 132: Neri carried the blue token past marker f2bf4c5e2d79. Mara watched the eastern gate until dawn.

Ledger 19 line 133: Neri carried the blue token past marker 389fefb7358e. Mara watched the eastern gate until dawn.

Ledger 19 line 134: Neri carried the blue token past marker adf10a5bd4d8. Mara watched the eastern gate until dawn.

Ledger 19 line 135: Neri carried the blue token past marker 319a43a14270. Mara watched the eastern gate until dawn.

Ledger 19 line 136: Neri carried the blue token past marker 7366a661315a. Mara watched the eastern gate until dawn.

Ledger 19 line 137: Neri carried the blue token past marker 4a4cb8237d66. Mara watched the eastern gate until dawn.

Ledger 19 line 138: Neri carried the blue token past marker 17d22831d470. Mara watched the eastern gate until dawn.

Ledger 19 line 139: Neri carried the blue token past marker ca9c380884aa. Mara watched the eastern gate until dawn.

Ledger 19 line 140: Neri carried the blue token past marker 88fc86487eb8. Mara watched the eastern gate until dawn.
