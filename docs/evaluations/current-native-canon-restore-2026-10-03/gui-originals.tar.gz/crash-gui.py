import ctypes,hashlib,json,os,signal,struct,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int
def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0: raise ProcessLookupError(pid)
  return str(Path(os.fsdecode(buffer.value)).resolve())
def argv(pid):
  mib = (ctypes.c_int*3)(1,49,pid)
  capacity = ctypes.c_size_t(1024*1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib,3,buffer,ctypes.byref(capacity),None,0): raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i',raw)[0]
  assert 0<count<500
  cursor=raw.find(b'\0',4)
  while cursor<len(raw) and raw[cursor]==0: cursor+=1
  values=[]
  for _ in range(count):
    end=raw.find(b'\0',cursor)
    assert end>=0
    values.append(os.fsdecode(raw[cursor:end]));cursor=end+1
  return values
def details(pid):
  result=subprocess.run(['/bin/ps','-p',str(pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  if result.returncode or not result.stdout.strip(): raise ProcessLookupError(pid)
  parts=result.stdout.strip().split()
  return {'pid':pid,'ppid':int(parts[0]),'start':' '.join(parts[1:-1]),'state':parts[-1],'executable':executable(pid),'argv':argv(pid)}
def cwd(pid):
  result=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,timeout=3)
  paths=[line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  assert result.returncode==0 and len(paths)==1
  return str(Path(paths[0]).resolve())

root=Path('/private/tmp/openauthor-current-backup-interruption-4g079g__')
out=root/'gui-crash.json'
assert not out.exists()
captured=json.loads((root/'gui-observation/result.json').read_text())
owner=details(41441);worker=details(43443)
for row,key in [(owner,'owner'),(worker,'worker')]:
 old=captured[key]
 assert all(row[k]==old[k] for k in ['pid','start','executable','argv'])
assert worker['ppid']==owner['pid'] and 'T' in worker['state']
assert cwd(worker['pid'])==captured['cwd']
assert hashlib.sha256(Path(owner['executable']).read_bytes()).hexdigest()=='195c81233806fda9fc3f68d6d162af3f7c294357e88f352200ef218ccf31946f'
assert hashlib.sha256(Path(worker['executable']).read_bytes()).hexdigest()=='59a902c9eee68de88a56099a584fab057e414c800f9c73892383d548b2c4950c'
manifest=json.loads((root/'preparation/manifest.json').read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def files(p): return {q.relative_to(p).as_posix():sha(q) for q in p.rglob('*') if q.is_file() and not q.is_symlink()}
assert files(Path(captured['stage'])/'project')==captured['staged_file_sha256']
assert not Path(captured['target']).exists()
assert sha(Path(captured['source']))==manifest['archive_sha256']
assert files(Path(manifest['book']))==manifest['original_book_sha256']
listing=subprocess.run(['/bin/ps','-axo','pid=,ppid='],capture_output=True,text=True,timeout=3,check=True).stdout
children=[int(x.split()[0]) for x in listing.splitlines() if len(x.split())==2 and int(x.split()[1])==41441]
readers=[]
for pid in children:
 if pid==43443: continue
 try: row=details(pid)
 except ProcessLookupError: continue
 if row['executable']!=worker['executable']: continue
 tail=row['argv'][1:]
 while tail and tail[0] in ['-I','-B']: tail=tail[1:]
 assert tail==['-m','openauthor','serve'], row
 reader_cwd=cwd(pid)
 assert reader_cwd=='/private/tmp/openauthor-current-canon-root-8fponqmo/book',reader_cwd
 row['cwd']=reader_cwd; readers.append(row)
events=[]
def kill_exact(row):
 now=details(row['pid'])
 assert all(now[k]==row[k] for k in ['start','executable','argv'])
 if 'cwd' in row: assert cwd(row['pid'])==row['cwd']
 os.kill(row['pid'],signal.SIGKILL)
 events.append({'pid':row['pid'],'signal':'SIGKILL','at':datetime.now(timezone.utc).isoformat()})
kill_exact(owner)
for row in readers: kill_exact(row)
assert 'T' in details(worker['pid'])['state']
kill_exact(worker)
time.sleep(.5)
def terminal(pid):
 r=subprocess.run(['/bin/ps','-p',str(pid),'-o','stat='],capture_output=True,text=True,timeout=2)
 return not r.stdout.strip() or r.stdout.strip().startswith('Z')
assert all(terminal(r['pid']) for r in [owner,*readers,worker])
assert files(Path(captured['stage'])/'project')==captured['staged_file_sha256']
assert not Path(captured['target']).exists()
assert sha(Path(captured['source']))==manifest['archive_sha256']
assert files(Path(manifest['book']))==manifest['original_book_sha256']
receipt={'scope':'Root exact owned native QA crash during unmodified partial backup extraction','owner_before':owner,'readers_before':readers,'worker_before':worker,'events':events,'all_owned_terminal':True,'destination_absent_before_and_after':True,'partial_stage_unchanged':True,'source_and_zip_unchanged':True,'paused_gui_root_transcription':{'source':'Inline CUA AX and screenshot, no archived native screenshot','visible':'Verifying and restoring…; source and target disabled; only recent Current Canon native acceptance book; no partial restored book','observed_before_kill':True},'production_hooks_or_monkeypatches':False,'new_provider_calls':0,'completed_at':datetime.now(timezone.utc).isoformat()}
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out),'readers_killed':len(readers),'all_owned_terminal':True,'target_absent':True}))
