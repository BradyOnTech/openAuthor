import ctypes,hashlib,json,os,signal,struct,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int
def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0: raise ProcessLookupError(pid)
  return str(Path(os.fsdecode(buffer.value)).resolve())
def argv(pid):
  mib = (ctypes.c_int*3)(1,49,pid)
  capacity = ctypes.c_size_t(1024*1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib,3,buffer,ctypes.byref(capacity),None,0): raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i',raw)[0]
  assert 0<count<500
  cursor=raw.find(b'\0',4)
  while cursor<len(raw) and raw[cursor]==0: cursor+=1
  values=[]
  for _ in range(count):
    end=raw.find(b'\0',cursor)
    assert end>=0
    values.append(os.fsdecode(raw[cursor:end]));cursor=end+1
  return values
def details(pid):
  result=subprocess.run(['/bin/ps','-p',str(pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  if result.returncode or not result.stdout.strip(): raise ProcessLookupError(pid)
  parts=result.stdout.strip().split()
  return {'pid':pid,'ppid':int(parts[0]),'start':' '.join(parts[1:-1]),'state':parts[-1],'executable':executable(pid),'argv':argv(pid)}
def cwd(pid):
  result=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,timeout=3)
  paths=[line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  assert result.returncode==0 and len(paths)==1
  return str(Path(paths[0]).resolve())


root=Path('/private/tmp/openauthor-current-backup-interruption-4g079g__')
listing=subprocess.run(['/bin/ps','-axo','pid=,comm='],capture_output=True,text=True,check=True,timeout=3).stdout
exe='/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app/Contents/MacOS/openauthor-desktop'
pids=[int(x.strip().split(' ',1)[0]) for x in listing.splitlines() if x.strip().split(' ',1)[1].strip()==exe]
assert len(pids)==1,pids
row=details(pids[0]); assert row['executable']==exe and row['argv']==[exe]
assert hashlib.sha256(Path(exe).read_bytes()).hexdigest()=='195c81233806fda9fc3f68d6d162af3f7c294357e88f352200ef218ccf31946f'
row['cwd']=cwd(row['pid']); assert row['cwd']=='/private/tmp/openauthor-current-native-36a4058-pd_q29st'
row['captured_at']=datetime.now(timezone.utc).isoformat(); (root/'gui-relaunched-process.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
