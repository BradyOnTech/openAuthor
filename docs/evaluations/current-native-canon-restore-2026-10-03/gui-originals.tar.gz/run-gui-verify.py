"""Sanitize environment for private installed-package acceptance helpers."""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
app = Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/normal-36a4058.app')
runtime = app / 'Contents/Resources/resources/runtime'
mode = sys.argv[1]
assert mode in ('prepare', 'trial', 'verify')
env = {key: value for key, value in os.environ.items()
  if not key.startswith(('CODEX_', 'OPENAUTHOR_', 'PYTHON', 'GIT_'))
  and key not in ('OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'OPENROUTER_API_KEY')}
env.update({'PATH':str(runtime/'python/bin')+':'+str(runtime/'git/bin')+':/usr/bin:/bin:/usr/sbin:/sbin',
  'OPENAUTHOR_GIT_BIN':str(runtime/'git/bin/git'), 'OPENAUTHOR_CODEX_BIN':'/bin/false',
  'OPENAUTHOR_CODEX_HOME':str(root/'empty-auth'),'PYTHONDONTWRITEBYTECODE':'1',
  'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1',
  'GIT_AUTHOR_NAME':'Private Recovery Acceptance','GIT_AUTHOR_EMAIL':'acceptance@example.invalid',
  'GIT_COMMITTER_NAME':'Private Recovery Acceptance','GIT_COMMITTER_EMAIL':'acceptance@example.invalid',
  'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','LC_CTYPE':'en_US.UTF-8'})
command=[str(runtime/'python/bin/python3'),'-I','-B',str(root/f'{mode}.py'),str(app),*sys.argv[2:]]
record={'command':command,'cwd':str(root/'working'),'started_at':datetime.now(timezone.utc).isoformat(),'timeout_seconds':180}
with (root/f'gui-{mode}.stdout.txt').open('w') as out,(root/f'gui-{mode}.stderr.txt').open('w') as err:
  process=subprocess.Popen(command,cwd=root/'working',env=env,stdout=out,stderr=err)
  record['pid']=process.pid
  (root/f'gui-{mode}-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({'mode':mode,'pid':process.pid}),flush=True)
  try:
    code=process.wait(timeout=180)
    record['timed_out']=False
  except subprocess.TimeoutExpired:
    record['timed_out']=True
    process.kill()
    code=process.wait(timeout=10)
record.update({'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':code})
(root/f'gui-{mode}-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'mode':mode,'exit_code':code,'evidence':str(root)}))
raise SystemExit(code if code>=0 else 1)
