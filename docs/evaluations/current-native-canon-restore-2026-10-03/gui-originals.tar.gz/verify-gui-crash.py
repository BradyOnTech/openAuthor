import ctypes,hashlib,json,os,signal,struct,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int
def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0: raise ProcessLookupError(pid)
  return str(Path(os.fsdecode(buffer.value)).resolve())
def argv(pid):
  mib = (ctypes.c_int*3)(1,49,pid)
  capacity = ctypes.c_size_t(1024*1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib,3,buffer,ctypes.byref(capacity),None,0): raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i',raw)[0]
  assert 0<count<500
  cursor=raw.find(b'\0',4)
  while cursor<len(raw) and raw[cursor]==0: cursor+=1
  values=[]
  for _ in range(count):
    end=raw.find(b'\0',cursor)
    assert end>=0
    values.append(os.fsdecode(raw[cursor:end]));cursor=end+1
  return values
def details(pid):
  result=subprocess.run(['/bin/ps','-p',str(pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  if result.returncode or not result.stdout.strip(): raise ProcessLookupError(pid)
  parts=result.stdout.strip().split()
  return {'pid':pid,'ppid':int(parts[0]),'start':' '.join(parts[1:-1]),'state':parts[-1],'executable':executable(pid),'argv':argv(pid)}
def cwd(pid):
  result=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,timeout=3)
  paths=[line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  assert result.returncode==0 and len(paths)==1
  return str(Path(paths[0]).resolve())


root=Path('/private/tmp/openauthor-current-backup-interruption-4g079g__')
c=json.loads((root/'gui-observation/result.json').read_text()); m=json.loads((root/'preparation/manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files(p):return {q.relative_to(p).as_posix():sha(q) for q in p.rglob('*') if q.is_file() and not q.is_symlink()}
terminal={}
for pid in [41441,43443]:
 x=subprocess.run(['/bin/ps','-p',str(pid),'-o','stat='],capture_output=True,text=True,timeout=2)
 terminal[str(pid)]={'state':x.stdout.strip(),'terminal':not x.stdout.strip() or x.stdout.strip().startswith('Z')}
assert all(x['terminal'] for x in terminal.values())
assert files(Path(c['stage'])/'project')==c['staged_file_sha256']
assert not Path(c['target']).exists()
assert sha(Path(c['source']))==m['archive_sha256']
assert files(Path(m['book']))==m['original_book_sha256']
x={'scope':'Native QA crash after GUI restore paused during actual extraction','observer':'gui-observation/result.json','root_execution':'crash-gui.py verified app and worker identity/start/argv/executable hashes, private cwd, stage/source baselines; SIGKILL of exact QA parent executed. Worker was observed stopped after parent kill, then disappeared before final worker kill identity lookup. No final worker signal is claimed.','harness_outcome':'ProcessLookupError at final worker lookup; recovered by direct terminal/file readback','parent_pid':41441,'worker_pid':43443,'terminal_probe':terminal,'destination_absent_before_and_after':True,'partial_stage_unchanged':True,'source_and_zip_unchanged':True,'paused_gui_root_transcription':{'source':'Inline CUA AX and screenshot; no archived native screenshot','visible':'Verifying and restoring…; disabled source and target fields; only recent Current Canon native acceptance; no partial restored book'},'production_hooks_or_monkeypatches':False,'provider_calls':0,'completed_at':datetime.now(timezone.utc).isoformat()}
(root/'gui-crash.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'terminal':terminal,'stage_unchanged':True,'source_and_zip_unchanged':True,'destination_absent':True}))
