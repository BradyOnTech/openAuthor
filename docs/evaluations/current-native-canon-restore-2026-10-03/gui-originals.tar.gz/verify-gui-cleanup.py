import ctypes,hashlib,json,os,signal,struct,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
libproc = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib', use_errno=True)
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int
libc.sysctl.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_uint, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
libc.sysctl.restype = ctypes.c_int
def executable(pid):
  buffer = ctypes.create_string_buffer(4096)
  if libproc.proc_pidpath(pid, buffer, len(buffer)) <= 0: raise ProcessLookupError(pid)
  return str(Path(os.fsdecode(buffer.value)).resolve())
def argv(pid):
  mib = (ctypes.c_int*3)(1,49,pid)
  capacity = ctypes.c_size_t(1024*1024)
  buffer = ctypes.create_string_buffer(capacity.value)
  if libc.sysctl(mib,3,buffer,ctypes.byref(capacity),None,0): raise ProcessLookupError(pid)
  raw = buffer.raw[:capacity.value]
  count = struct.unpack_from('i',raw)[0]
  assert 0<count<500
  cursor=raw.find(b'\0',4)
  while cursor<len(raw) and raw[cursor]==0: cursor+=1
  values=[]
  for _ in range(count):
    end=raw.find(b'\0',cursor)
    assert end>=0
    values.append(os.fsdecode(raw[cursor:end]));cursor=end+1
  return values
def details(pid):
  result=subprocess.run(['/bin/ps','-p',str(pid),'-o','ppid=','-o','lstart=','-o','stat='],capture_output=True,text=True,timeout=2)
  if result.returncode or not result.stdout.strip(): raise ProcessLookupError(pid)
  parts=result.stdout.strip().split()
  return {'pid':pid,'ppid':int(parts[0]),'start':' '.join(parts[1:-1]),'state':parts[-1],'executable':executable(pid),'argv':argv(pid)}
def cwd(pid):
  result=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,timeout=3)
  paths=[line[1:] for line in result.stdout.splitlines() if line.startswith('n')]
  assert result.returncode==0 and len(paths)==1
  return str(Path(paths[0]).resolve())


r=Path('/private/tmp/openauthor-current-backup-interruption-4g079g__')
owner=json.loads((r/'gui-relaunched-process.json').read_text())
probe=subprocess.run(['/bin/ps','-p',str(owner['pid']),'-o','stat='],capture_output=True,text=True,timeout=2)
assert not probe.stdout.strip() or probe.stdout.strip().startswith('Z')
listing=subprocess.run(['/bin/ps','-axo','pid=,comm='],capture_output=True,text=True,check=True,timeout=3).stdout
python=str(Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st/acceptance-36a4058.app/Contents/Resources/resources/runtime/python/bin/python3').resolve())
remaining=[]
for line in listing.splitlines():
 parts=line.strip().split(' ',1)
 if len(parts)!=2 or parts[1].strip()!=python:continue
 pid=int(parts[0]);row=details(pid);tail=row['argv'][1:]
 while tail and tail[0] in ['-I','-B']:tail=tail[1:]
 if tail!=['-m','openauthor','serve']:continue
 location=cwd(pid)
 if location!=str(r/'recovered-gui'):continue
 assert row['ppid'] in [1,owner['pid']]
 os.kill(pid,signal.SIGTERM);remaining.append({'before':row,'cwd':location,'signal':'SIGTERM'})
time.sleep(.25)
for item in remaining:
 pid=item['before']['pid'];probe=subprocess.run(['/bin/ps','-p',str(pid),'-o','stat='],capture_output=True,text=True,timeout=2)
 assert not probe.stdout.strip() or probe.stdout.strip().startswith('Z')
x={'captured_at':datetime.now(timezone.utc).isoformat(),'qa_pid':owner['pid'],'normal_native_quit':True,'exact_private_readers_signaled':remaining,'all_owned_terminal':True,'no_broad_process_sweep':True}
(r/'gui-cleanup.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
