from pathlib import Path
import os, sys, json, subprocess, shutil, datetime, hashlib
root=Path('~/Developer/openAuthor')
packet=Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st')
flavor=sys.argv[1]
assert flavor in ('normal','qa')
env=os.environ.copy()
env['PATH']='~/.rustup/toolchains/stable-aarch64-apple-darwin/bin:'+env.get('PATH','')
for key in ['OPENAI_API_KEY','ANTHROPIC_API_KEY','OPENROUTER_API_KEY','OPENAUTHOR_PYTHON_BIN','OPENAUTHOR_RUNTIME_DIR','OPENAUTHOR_GIT_BIN','VIRTUAL_ENV','PYTHONPATH']:
 env.pop(key,None)
env.update({'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','CARGO_NET_OFFLINE':'true','GITHUB_SHA':'36a40582bd4667440f5614c4f73141ea1bdaf51b','OPENAUTHOR_REQUIRE_SIGNED_BUNDLE':'0','OPENAUTHOR_EXPECT_ARCH':'arm64'})
if flavor=='qa':
 env.update({'VITE_PROJECT_REGISTRY':'local','VITE_SUPABASE_URL':'','VITE_SUPABASE_ANON_KEY':''})
cmd=['npm','run','tauri:build','--','--bundles','app','--no-sign']
if flavor=='qa':cmd+=['--config',str(packet/'tauri.acceptance.json')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (packet/(flavor+'-build.txt')).open('w') as log:
 r=subprocess.run(cmd,cwd=root/'desktop',env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':cmd,'cwd':str(root/'desktop'),'started_at_utc':started,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'provider_keys_removed':True,'cargo_offline':True,'source_commit':'36a40582bd4667440f5614c4f73141ea1bdaf51b','head_at_build':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'flavor':flavor}
if r.returncode==0:
 built=root/'desktop/src-tauri/target/release/bundle/macos/openAuthor.app'
 app=packet/('normal-36a4058.app' if flavor=='normal' else 'acceptance-36a4058.app')
 assert not app.exists()
 shutil.copytree(built,app,symlinks=True)
 record['app']=str(app)
 if flavor=='qa':record['build_environment_overrides']={key:env[key] for key in ['VITE_PROJECT_REGISTRY','VITE_SUPABASE_URL','VITE_SUPABASE_ANON_KEY']}
 else:record['build_environment_overrides']='Canonical configuration and current dotenv files; no QA registry override.'
(packet/(flavor+'-build-receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(r.returncode)
