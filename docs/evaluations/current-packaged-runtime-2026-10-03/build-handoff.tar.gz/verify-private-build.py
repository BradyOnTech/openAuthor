from pathlib import Path
import json, hashlib, sys, os
packet=Path(__file__).resolve().parent
root=Path('~/Developer/openAuthor')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence=json.loads((packet/'evidence-sha256.json').read_text())
for name,expected in evidence['files'].items():
 assert sha(packet/name)==expected,name
for flavor in ['normal','qa']:
 manifest=json.loads((packet/(flavor+'-app-files.json')).read_text())
 app=Path(manifest['app'])
 actual={p.relative_to(app).as_posix():sha(p) for p in sorted(app.rglob('*')) if p.is_file() and '__pycache__' not in p.relative_to(app).parts}
 assert actual==manifest['files'],flavor+' bundle bytes changed'
 actual_links={p.relative_to(app).as_posix():os.readlink(p) for p in sorted(app.rglob('*')) if p.is_symlink()}
 assert actual_links==manifest['symlinks'],flavor+' bundle links changed'
if '--current' in sys.argv:
 source=json.loads((packet/'source-hashes-before-build.json').read_text())
 for name,expected in source['files'].items():assert sha(root/name)==expected,name
 for name,expected in json.loads((packet/'author-hashes-before.json').read_text()).items():assert sha(root/name)==expected,name
print(json.dumps({'private_build_evidence_integrity':'passed','bundles_byte_integrity':'passed','current_source_and_author_integrity':'passed' if '--current' in sys.argv else 'not checked','scope':'Integrity only; original builds, recovery and contract tests are not rerun.'}))
