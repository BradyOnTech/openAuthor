from pathlib import Path
import os, sys, json, subprocess, datetime
root=Path('~/Developer/openAuthor');packet=Path('/private/tmp/openauthor-current-native-36a4058-pd_q29st')
flavor=sys.argv[1];assert flavor in ('normal','qa')
app=packet/('normal-36a4058.app' if flavor=='normal' else 'acceptance-36a4058.app')
python=app/'Contents/Resources/resources/runtime/python/bin/python3'
env=os.environ.copy()
for key in ['OPENAI_API_KEY','ANTHROPIC_API_KEY','OPENROUTER_API_KEY','OPENAUTHOR_PYTHON_BIN','OPENAUTHOR_RUNTIME_DIR','OPENAUTHOR_GIT_BIN','VIRTUAL_ENV','PYTHONPATH']:
 env.pop(key,None)
env.update({'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','GITHUB_SHA':'36a40582bd4667440f5614c4f73141ea1bdaf51b','OPENAUTHOR_REQUIRE_SIGNED_BUNDLE':'0','OPENAUTHOR_EXPECT_ARCH':'arm64'})
if flavor=='normal':
 env['OPENAUTHOR_BUNDLE_REPORT_PATH']=str(packet/'normal-bundle-report.json')
 cmd=['bash',str(root/'scripts/verify_macos_bundle.sh'),str(app)]
else:
 cmd=[str(python),'-I','-B',str(root/'scripts/verify_packaged_sources.py'),'--report',str(packet/'qa-core-verification.json')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (packet/(flavor+'-verification.txt')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':cmd,'started_at_utc':started,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'app':str(app),'canonical_identifier_guard_applied':flavor=='normal','scope':'canonical unsigned bundle and packaged recovery + local Codex contract' if flavor=='normal' else 'alternate-identifier QA core only; same pinned runtimes; no canonical app identity or signing acceptance'}
(packet/(flavor+'-verification-receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True);raise SystemExit(r.returncode)
