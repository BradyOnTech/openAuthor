#!/usr/bin/env python3
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('~/Developer/openAuthor')

def now():
  return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(argv, timeout=12):
  started = now()
  try:
    result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
    return {'argv': argv, 'started_at_utc': started, 'finished_at_utc': now(),
      'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
  except subprocess.TimeoutExpired:
    return {'argv': argv, 'started_at_utc': started, 'finished_at_utc': now(),
      'exit_code': None, 'timeout': True, 'stdout': '', 'stderr': ''}
  except OSError as error:
    return {'argv': argv, 'started_at_utc': started, 'finished_at_utc': now(),
      'exit_code': None, 'error_type': type(error).__name__, 'stdout': '', 'stderr': ''}

def safe_command(argv, timeout=12):
  record = run(argv, timeout)
  # These tool/version commands are chosen so they do not report accounts,
  # certificates or device identities. Replace the user's home in path output.
  for key in ('stdout', 'stderr'):
    record[key] = record[key].replace(str(Path.home()), '${HOME}')
  return record

def write(name, value):
  (ROOT/name).write_text(json.dumps(value, indent=2)+'\n')
  print(json.dumps(value, indent=2))

def base():
  names = ['xcodebuild','xcrun','clang','rustup','rustc','cargo','node','npm',
    'python3','adb','sdkmanager','emulator','codesign','security','spctl','xcode-select']
  executables = {name: shutil.which(name) for name in names}
  sdk_names = ['ANDROID_HOME','ANDROID_SDK_ROOT','ANDROID_AVD_HOME']
  sdk_paths = {}
  # Only these non-secret SDK path variables are read. Credential variables
  # below are checked for key presence, never read or persisted.
  for name in sdk_names:
    value = os.environ.get(name)
    sdk_paths[name] = {'configured': value is not None,
      'directory_exists': bool(value and Path(value).is_dir())}
  standard_paths = {
    'Xcode_default': Path('/Applications/Xcode.app'),
    'Android_Studio_default': Path('/Applications/Android Studio.app'),
    'Android_SDK_default': Path.home()/'Library/Android/sdk',
    'Command_Line_Tools_default': Path('/Library/Developer/CommandLineTools'),
  }
  records = [safe_command(['/usr/bin/sw_vers']),safe_command(['/usr/bin/uname','-m']),
    safe_command(['/usr/sbin/sysctl','-n','hw.optional.arm64']),
    safe_command(['/usr/bin/xcode-select','-p'])]
  commands = [('xcodebuild',['-version']),('xcrun',['--find','devicectl']),
    ('xcrun',['--find','simctl']),('xcrun',['--find','clang']),
    ('xcrun',['--find','notarytool']),('rustup',['target','list','--installed']),
    ('rustc',['-Vv']),('cargo',['-V']),('node',['--version']),('npm',['--version']),
    ('python3',['--version']),('adb',['version'])]
  for name, args in commands:
    if executables[name]:
      records.append(safe_command([executables[name], *args]))
  credential_names = ['APPLE_CERTIFICATE','APPLE_CERTIFICATE_PASSWORD',
    'APPLE_SIGNING_IDENTITY','APPLE_ID','APPLE_PASSWORD','APPLE_TEAM_ID',
    'APPLE_API_KEY','APPLE_API_ISSUER','APPLE_API_KEY_PATH']
  write('toolchains.json', {'observed_at_utc':now(),
    'platform_machine':platform.machine(),
    'executables':{k:(v.replace(str(Path.home()),'${HOME}') if v else None) for k,v in executables.items()},
    'standard_path_presence':{k:v.exists() for k,v in standard_paths.items()},
    'android_sdk_configuration':sdk_paths,
    'release_credential_environment_names_present':{k:k in os.environ for k in credential_names},
    'credential_values_read':False,'commands':records,
    'local_notarization_keychain_profile_presence':'unknown; no explicit local profile configured in inspected release config; Keychain credentials not enumerated',
    'remote_repository_secret_presence':'not checked; local-only inventory'})

def signing():
  result = run(['/usr/bin/security','find-identity','-v','-p','codesigning'])
  lines = result['stdout'].splitlines()
  matches = [line for line in lines if re.match(r'\s*\d+\)\s+[0-9A-Fa-f]{40}\s+"',line)]
  total = re.search(r'(\d+) valid identities found',result['stdout'])
  classes = ['Developer ID Application','Developer ID Installer','Apple Development',
    'Apple Distribution','Mac Developer','Mac App Distribution','iPhone Developer',
    'iPhone Distribution']
  counts = {name:sum(('"'+name+':') in line for line in matches) for name in classes}
  summary = {'observed_at_utc':now(),'argv':result['argv'],
    'started_at_utc':result['started_at_utc'],'finished_at_utc':result['finished_at_utc'],
    'exit_code':result['exit_code'], 'timeout':result.get('timeout',False),
    'valid_code_signing_identity_count':int(total.group(1)) if total else None,
    'parsed_identity_line_count':len(matches),'identity_type_counts':counts,
    'stderr_present':bool(result['stderr']),
    'stderr_access_denial':bool(re.search('denied|permitted|authorization|interaction', result['stderr'],re.I)),
    'account_membership':'unknown; not inferred from certificate count',
    'certificate_names_hashes_account_names_private_keys_retained':False,
    'scope':'valid code signing identities visible to security in this process; no signing operation'}
  if result.get('error_type'):
    summary['error_type']=result['error_type']
  write('signing-identities.json',summary)

def extended():
  records = [safe_command(['/usr/sbin/sysctl','-n','hw.optional.arm64']),
    safe_command(['/usr/bin/xcrun','--show-sdk-version','--sdk','macosx']),
    safe_command(['/usr/bin/clang','--version'])]
  rustup = shutil.which('rustup')
  for executable in ['rustc','cargo']:
    if rustup:
      result = run([rustup,'which',executable])
      binary = result['stdout'].strip() if result['exit_code']==0 else ''
      result['stdout'] = result['stdout'].replace(str(Path.home()),'${HOME}')
      result['stderr'] = result['stderr'].replace(str(Path.home()),'${HOME}')
      records.append(result)
      if binary and Path(binary).is_file():
        records.append(safe_command([binary,'-Vv'] if executable=='rustc' else [binary,'-V']))
  usb = run(['/usr/sbin/system_profiler','SPUSBDataType','-json'],timeout=20)
  # Retain only aggregate type hints. No USB names, serials, paths, identities
  # or raw profiler output are persisted.
  hints={'iphone_or_ipad_name_hint_count':0,'android_or_pixel_name_hint_count':0,
    'samsung_vendor_hint_count':0}
  parsed=False
  def inspect(value):
    if isinstance(value, dict):
      name=str(value.get('_name','')).lower()
      vendor=str(value.get('vendor_id','')).lower()
      if 'iphone' in name or 'ipad' in name:
        hints['iphone_or_ipad_name_hint_count'] += 1
      if 'android' in name or 'pixel' in name:
        hints['android_or_pixel_name_hint_count'] += 1
      if '0x04e8' in vendor:
        hints['samsung_vendor_hint_count'] += 1
      for nested in value.values():
        inspect(nested)
    elif isinstance(value,list):
      for nested in value:
        inspect(nested)
  if usb['exit_code']==0:
    try:
      inspect(json.loads(usb['stdout']))
      parsed=True
    except (ValueError,TypeError):
      pass
  write('extended-toolchains-and-usb.json',{'observed_at_utc':now(),
    'commands':records,'usb_aggregate_observation':{'argv':usb['argv'],
      'started_at_utc':usb['started_at_utc'],'finished_at_utc':usb['finished_at_utc'],
      'exit_code':usb['exit_code'],'timeout':usb.get('timeout',False),
      'stderr_present':bool(usb['stderr']),'json_parsed':parsed,'aggregate_hints':hints,
      'raw_device_names_identifiers_and_output_retained':False,
      'scope':'USB type hints only; zero hints does not establish absence of physical or wirelessly connected devices'}})

def guard():
  before=json.loads((ROOT/'before.json').read_text())
  hashes={name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() if (REPO/name).is_file() else None
    for name in before['author_hashes']}
  status=run(['git','status','--short'])
  head=run(['git','rev-parse','HEAD'])
  write('after.json',{'observed_at_utc':now(),'head':head['stdout'].strip(),
    'author_hashes':hashes,'author_hashes_unchanged':hashes==before['author_hashes'],
    'git_status':status['stdout'].splitlines(),
    'scope':'author hashes protected; other agents may perform authorized source work concurrently'})

def finish():
  final_commands = [safe_command(['/opt/homebrew/bin/rustup','toolchain','list']),
    safe_command(['/usr/bin/xcrun','notarytool','--version'])]
  write('final-version-commands.json',{'observed_at_utc':now(),'commands':final_commands})
  inputs=['CLAUDE.md','docs/macos-release-setup.md','mobile/release-checklist.md',
    '.github/workflows/release-macos.yml','.github/workflows/package-macos.yml',
    'scripts/configure_macos_release.sh','scripts/verify_macos_bundle.sh',
    'scripts/prepare_bundled_runtime.sh','desktop/src-tauri/tauri.conf.json',
    'desktop/src-tauri/Cargo.toml','desktop/src-tauri/Entitlements.plist',
    'desktop/src-tauri/Info.plist','mobile/package.json','mobile/eas.json','mobile/app.json']
  captured={}
  for name in inputs:
    source=REPO/name
    if source.is_file():
      destination=ROOT/'inspected-configs'/name
      destination.parent.mkdir(parents=True,exist_ok=True)
      destination.write_bytes(source.read_bytes())
      captured[name]=hashlib.sha256(destination.read_bytes()).hexdigest()
  write('config-hashes.json',{'captured_at_utc':now(),'files':captured,
    'capture_scope':'configuration bytes captured after system inventory commands; not an asserted pre-command source freeze',
    'native_project_directory_presence':{'mobile/ios':(REPO/'mobile/ios').is_dir(),
      'mobile/android':(REPO/'mobile/android').is_dir()},
    'notarization_profile_configuration':'No explicit local Keychain profile in inspected release workflow/helper/Tauri configs. Credential values not read; Keychain profiles not enumerated.'})
  guard()
  after=json.loads((ROOT/'after.json').read_text())
  result={'observed_at_utc':now(),'repository_head_at_start':json.loads((ROOT/'before.json').read_text())['head'],
    'repository_head_at_finish':after['head'],'author_hashes_unchanged':after['author_hashes_unchanged'],
    'capabilities':{'host':'Native Apple Silicon arm64, macOS 15.7.3 build 24G419',
      'desktop_arm64':'CLT, macOS SDK 15.5, Apple clang 17.0.0, Rust/Cargo 1.98.1 and aarch64-apple-darwin installed; Rust absolute toolchain paths work despite inherited PATH omission.',
      'desktop_intel':'Current default Rust target list contains no x86_64-apple-darwin. Native Intel acceptance unavailable on this ARM host; both repository workflows configure a separate macos-15-intel runner, not inspected/executed here.',
      'ios':'Active developer directory is CLT. Default Xcode app absent; xcodebuild -version fails and xcrun cannot find devicectl/simctl. Native iOS device/build acceptance cannot proceed with this configured toolchain.',
      'android':'No adb, sdkmanager or emulator in PATH; no Android SDK path env configuration; default SDK and Android Studio locations absent. Other possible installations were not exhaustively searched.',
      'phones':'No USB phone type hints observed. Physical or wirelessly connected phone availability remains unknown; no functional phone/device access verified.',
      'signing':'Zero valid code-signing identities observed in both sandboxed and approved unsandboxed security count; Developer ID Application and Apple Development/Distribution counts zero. Account membership remains unknown.',
      'notarization':'notarytool executable available; no explicit local Keychain profile configured in inspected release configs. Profile existence and credential validity remain unknown; no Keychain credential records or remote repository secrets read.',
      'release_credential_environment':'Expected Apple credential variable names are absent from this subprocess environment; no value read. This does not establish absence from other storage or remote secrets.'},
    'safe_next_actions':['Build and verify the current unsigned ARM desktop bundle using installed toolchains and reviewed embedded runtime inputs, without signing or provider/deployment calls.',
      'Continue isolated native GUI recovery and keyboard checks on exact-current source; keep physical/signed/clean-machine acceptance unverified.',
      'Prepare an exact physical-device/manual release matrix and artifact checksum recording from existing approved criteria; no device pairing, software installation or remote mutation required.'],
    'external_requirements':['Owner-supplied valid Developer ID/private-key and notarization configuration; signed artifact validation must succeed, not just credential presence.',
      'Configured native iOS/Android toolchains and accessible physical phones with appropriate authorization for installation/audio/system-setting checks.',
      'Separate clean Apple Silicon and Intel installation/upgrade acceptance; this developer machine is not a clean-machine substitute.'],
    'mutations':{'source_docs_author_files':0,'system_settings':0,'keychain':0,
      'device_pairing_or_installation':0,'signing':0,'software_install_update_download':0,
      'remote_provider_or_deployment_calls':0},
    'scope':'Local read-only capability inventory; private evidence written only under its /private/tmp packet. No requirement 4/6 completion or release certification claim.'}
  write('results.json',result)
  hashes={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
    for path in ROOT.rglob('*') if path.is_file() and path.name!='evidence-sha256.json'}
  write('evidence-sha256.json',{'sealed_at_utc':now(),'files':hashes})

if __name__ == '__main__':
  {'base':base,'signing':signing,'extended':extended,'guard':guard,'finish':finish}[sys.argv[1]]()
