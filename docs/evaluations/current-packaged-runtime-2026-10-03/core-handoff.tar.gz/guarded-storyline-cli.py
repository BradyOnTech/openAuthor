"""Actual packaged CLI refuses loaded Canon versions from another Storyline."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
app = Path(sys.argv[1]).resolve()
runtime = app / "Contents/Resources/resources/runtime"
assert sys.flags.isolated == 1
assert Path(sys.executable).resolve() == (runtime / "python/bin/python3").resolve()
assert not any(key in os.environ for key in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY", "PYTHONPATH"))

import openauthor
from openauthor.canon import add_canon_fact, list_canon_facts, update_canon_fact
from openauthor.git_ops import create_snapshot, initialize_git
from openauthor.project import initialize_project
from openauthor.scenes import add_scene, get_scene
from openauthor.storylines import create_storyline

installed = Path(openauthor.__file__).resolve().parent
assert installed.is_relative_to((runtime / "python").resolve())
book = root / "guarded-storyline-cli-book"
assert not book.exists(), "Do not overwrite prior probe evidence"
paths = initialize_project(book, name="Packaged guarded Memory review")
add_scene(paths, title="The loom", body="Neri set a blue token beside the loom.")
add_scene(paths, title="At dawn", body="Neri returned the blue token to the cabinet.")
add_canon_fact(paths, subject_entity_id="", predicate="token color", value="blue",
  evidence=[{"scene_id": "scene-0001", "excerpt": "Neri set a blue token beside the loom."}])
initialize_git(paths)
create_snapshot(paths, "Original Canon review scope")
loaded = list_canon_facts(paths, for_editing=True)[0]
original_prose = {identifier: get_scene(paths, identifier)["body"] for identifier in ("scene-0001", "scene-0002")}
create_storyline(paths, name="Cabinet alternative", hypothesis="Test another ending")
current = list_canon_facts(paths, for_editing=True)[0]
assert current["updated_at"] == loaded["updated_at"]
assert current["edit_version"] != loaded["edit_version"]
memory = paths.root / "codex/memory.json"
records = []


def refuse(label: str, *, version: str, disposition: str, evidence=None, phrase: str) -> None:
  before = memory.read_bytes()
  command = [sys.executable, "-I", "-B", "-m", "openauthor", "memory", "fact-review",
    "--id", loaded["id"], "--disposition", disposition, "--expected-version", version, "--json"]
  if evidence is not None:
    command.extend(["--evidence-json", json.dumps(evidence)])
  result = subprocess.run(command, cwd=book, capture_output=True, text=True, timeout=20)
  (root / f"{label}.stdout.txt").write_text(result.stdout)
  (root / f"{label}.stderr.txt").write_text(result.stderr)
  assert result.returncode != 0, f"{label} changed Memory"
  assert phrase in result.stdout + result.stderr, (label, result.stdout, result.stderr)
  assert memory.read_bytes() == before
  records.append({"label": label, "command": command, "cwd": str(book), "exit_code": result.returncode,
    "original_version_sent": version, "memory_sha256_before_and_after": hashlib.sha256(before).hexdigest(),
    "refusal_verified": phrase, "memory_byte_exact": True})


for disposition in ("accepted", "rejected"):
  refuse(f"old-storyline-{disposition}", version=loaded["edit_version"], disposition=disposition, phrase="Storyline changed")
withdrawn = update_canon_fact(paths, current["id"], expected_version=current["edit_version"],
  changes={"status": "rejected", "validity": {"from_scene_id": "scene-0002", "to_scene_id": "scene-0001"}})
refuse("inverted-validity-restore", version=withdrawn["edit_version"], disposition="accepted",
  evidence=withdrawn["evidence"], phrase="before it begins")
assert all(get_scene(paths, identifier)["body"] == body for identifier, body in original_prose.items())
result = {"fixture": str(book), "installed_core": str(installed), "python": str(Path(sys.executable).resolve()),
  "updated_at_same_across_storylines": True, "edit_version_differs_across_storylines": True,
  "actual_cli_refusals": records, "prose_unchanged": True, "legacy_timestamp_scope_protection_claimed": False,
  "author_quality_claimed": False, "provider_calls": 0}
(root / "guarded-storyline-cli-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
