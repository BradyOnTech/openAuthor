"""Launch private packaged acceptance with a bounded, sanitized environment."""
from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
app = Path(sys.argv[1]).resolve()
check = sys.argv[2]
scripts = {"core": "run-packaged-tests.py", "storyline-cli": "guarded-storyline-cli.py"}
assert check in scripts
runtime = app / "Contents/Resources/resources/runtime"
python = runtime / "python/bin/python3"
codex = runtime / "codex/bin/codex"
git = runtime / "git/bin/git"
assert all(path.is_file() and os.access(path, os.X_OK) for path in (python, codex, git))
environment = {key: value for key, value in os.environ.items()
  if not key.startswith(("CODEX_", "OPENAUTHOR_", "PYTHON", "GIT_"))
  and key not in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY")}
environment.update({
  "PATH": str(python.parent) + os.pathsep + str(git.parent) + ":/usr/bin:/bin:/usr/sbin:/sbin",
  "OPENAUTHOR_GIT_BIN": str(git), "OPENAUTHOR_CODEX_BIN": str(codex),
  "OPENAUTHOR_CODEX_HOME": str(root / "empty-auth"), "OPENAUTHOR_CODEX_CONTRACT_BIN": str(codex),
  "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1",
  "GIT_AUTHOR_NAME": "Packaged Acceptance Fixture", "GIT_AUTHOR_EMAIL": "acceptance@example.invalid",
  "GIT_COMMITTER_NAME": "Packaged Acceptance Fixture", "GIT_COMMITTER_EMAIL": "acceptance@example.invalid",
  "LC_ALL": "en_US.UTF-8", "LANG": "en_US.UTF-8", "LC_CTYPE": "en_US.UTF-8",
  "PYTHONDONTWRITEBYTECODE": "1",
})
command = [str(python), "-I", "-B", str(root / scripts[check]), str(app)]
limit = 600 if check == "core" else 90
started = time.monotonic()
record = {"command": command, "cwd": str(root / "working"), "timeout_seconds": limit,
  "started_at": datetime.now(timezone.utc).isoformat(), "environment_sanitized": True}
record_path = root / f"{check}-invocation.json"
with (root / f"{check}-bootstrap.stdout.txt").open("w") as out, (root / f"{check}-bootstrap.stderr.txt").open("w") as err:
  process = subprocess.Popen(command, cwd=root / "working", env=environment,
    stdout=out, stderr=err, start_new_session=True)
  record["pid"] = process.pid
  record_path.write_text(json.dumps(record, indent=2) + "\n")
  print(json.dumps({"check": check, "pid": process.pid, "invocation": str(record_path)}), flush=True)
  try:
    code = process.wait(timeout=limit)
    record["timed_out"] = False
  except subprocess.TimeoutExpired:
    record["timed_out"] = True
    os.killpg(process.pid, signal.SIGKILL)
    code = process.wait(timeout=10)
record.update({"finished_at": datetime.now(timezone.utc).isoformat(), "duration_seconds": time.monotonic() - started,
  "exit_code": code, "script_sha256": hashlib.sha256((root / scripts[check]).read_bytes()).hexdigest()})
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"check": check, "exit_code": code, "timed_out": record["timed_out"], "evidence_root": str(root)}))
raise SystemExit(code if code >= 0 else 1)
