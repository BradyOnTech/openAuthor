"""Private acceptance runner: original tests, current installed package only."""
from __future__ import annotations

import hashlib
import importlib.machinery
import json
import os
import platform
import subprocess
import sys
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path


root = Path(__file__).resolve().parent
inputs = root / "inputs"
app = Path(sys.argv[1]).resolve()
runtime = app / "Contents/Resources/resources/runtime"
python = runtime / "python/bin/python3"
git = runtime / "git/bin/git"
codex = runtime / "codex/bin/codex"
snapshot = json.loads((root / "source-before.json").read_text())


def digest(path: Path) -> str:
  return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name: str, value) -> None:
  (root / name).write_text(json.dumps(value, indent=2) + "\n")


assert sys.flags.isolated == 1, "Require bundled Python -I"
assert sys.dont_write_bytecode, "Use -B to keep bundled bytecode unchanged"
assert Path(sys.executable).resolve() == python.resolve()
assert not any(name in os.environ for name in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY"))
assert "PYTHONPATH" not in os.environ
assert os.environ["OPENAUTHOR_CODEX_HOME"] == str(root / "empty-auth")
assert os.environ["OPENAUTHOR_CODEX_CONTRACT_BIN"] == str(codex)
assert os.environ["OPENAUTHOR_GIT_BIN"] == str(git)
auth_initial_files = [p.relative_to(root / "empty-auth").as_posix() for p in (root / "empty-auth").rglob("*") if p.is_file()]
assert auth_initial_files == [], "Use an initially empty acceptance account home"

import openauthor

installed = Path(openauthor.__file__).resolve().parent
assert installed.is_relative_to((runtime / "python").resolve()), installed
expected = {key.removeprefix("openauthor/"): value for key, value in snapshot["source_sha256"].items()}
actual = {p.relative_to(installed).as_posix(): digest(p) for p in installed.rglob("*.py")}
assert actual == expected, "Installed source is not the captured current source"
fingerprint = hashlib.sha256()
for name, sha in sorted(actual.items()):
  fingerprint.update(name.encode() + b"\0" + bytes.fromhex(sha))

# Original tests deliberately give CLI children PYTHONPATH=<test-root>. Expose
# the actual installed package there, so those children use bundled bytes too.
package_link = inputs / "openauthor"
if package_link.is_symlink():
  assert package_link.resolve() == installed
else:
  assert not package_link.exists()
  package_link.symlink_to(installed, target_is_directory=True)
assert not any((inputs / rel).is_file() and digest(inputs / rel) != sha for rel, sha in snapshot["input_sha256"].items())
sys.path.insert(0, str(inputs))

import_errors = []
class InstalledCoreGuard:
  def find_spec(self, fullname, path=None, target=None):
    if fullname != "openauthor" and not fullname.startswith("openauthor."):
      return None
    spec = importlib.machinery.PathFinder.find_spec(fullname, path)
    if spec is None or spec.origin is None or not Path(spec.origin).resolve().is_relative_to(installed):
      import_errors.append({"name": fullname, "origin": None if spec is None else spec.origin})
      raise ImportError(f"Unbundled openauthor import refused: {fullname}")
    return spec

sys.meta_path.insert(0, InstalledCoreGuard())
versions = {}
for name, binary in (("git", git), ("codex", codex)):
  result = subprocess.run([str(binary), "--version"], capture_output=True, text=True, timeout=10)
  assert result.returncode == 0, result.stderr
  versions[name] = result.stdout.strip()

child_script = (
  "import json,sys; from pathlib import Path; import openauthor,openauthor.canon,openauthor.cli; "
  "print(json.dumps({'python':str(Path(sys.executable).resolve()),"
  "'modules':{name:str(Path(module.__file__).resolve()) for name,module in sys.modules.items() "
  "if (name=='openauthor' or name.startswith('openauthor.')) and getattr(module,'__file__',None)}}))"
)
child = subprocess.run([sys.executable, "-c", child_script], capture_output=True, text=True, timeout=10,
  cwd=root / "working", env={**os.environ, "PYTHONPATH": str(inputs)})
assert child.returncode == 0, child.stderr
child_origin = json.loads(child.stdout)
assert child_origin["python"] == str(python.resolve())
assert all(Path(path).is_relative_to(installed) for path in child_origin["modules"].values())
save("runtime-before.json", {
  "captured_at": datetime.now(timezone.utc).isoformat(), "app": str(app),
  "sys_executable": sys.executable, "resolved_python": str(python.resolve()),
  "python_version": platform.python_version(), "isolated": sys.flags.isolated,
  "dont_write_bytecode": sys.dont_write_bytecode,
  "reviewed_head": snapshot["head"], "last_core_change_commit": snapshot["last_core_change_commit"],
  "core_package": str(installed), "core_source_sha256": fingerprint.hexdigest(),
  "source_modules": actual, "versions": versions, "sys_path": sys.path,
  "binaries": {name: {"path": str(path.resolve()), "sha256": digest(path)}
    for name, path in (("python", python), ("git", git), ("codex", codex))},
  "environment": {name: os.environ.get(name) for name in (
    "PATH", "OPENAUTHOR_GIT_BIN", "OPENAUTHOR_CODEX_BIN", "OPENAUTHOR_CODEX_HOME",
    "OPENAUTHOR_CODEX_CONTRACT_BIN", "GIT_CONFIG_GLOBAL", "GIT_CONFIG_NOSYSTEM",
    "GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL")},
  "api_keys_absent": True, "parent_pythonpath_absent": True,
  "auth_home_initially_empty": True,
  "cli_child_module_origins": child_origin,
  "scope": "Packaged Python engine acceptance; no GUI, signing or author quality claim",
})

suite = unittest.defaultTestLoader.discover(str(inputs / "tests"), pattern="test_*.py")
discovered = suite.countTestCases()
assert discovered == 583, f"Unexpected test count {discovered}; audit scope before continuing"
started = time.monotonic()
with (root / "full-core-tests.txt").open("w") as log:
  result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
  log.flush()
modules = {name: {"origin": str(Path(module.__file__).resolve()), "sha256": digest(Path(module.__file__))}
  for name, module in sorted(sys.modules.items())
  if (name == "openauthor" or name.startswith("openauthor.")) and getattr(module, "__file__", None)}
assert all(Path(record["origin"]).is_relative_to(installed) for record in modules.values())
unchanged = all(digest(inputs / rel) == sha for rel, sha in snapshot["input_sha256"].items())
installed_after = {p.relative_to(installed).as_posix(): digest(p) for p in installed.rglob("*.py")}
report = {
  "finished_at": datetime.now(timezone.utc).isoformat(), "duration_seconds": time.monotonic() - started,
  "discovered": discovered, "tests_run": result.testsRun, "failures": len(result.failures),
  "errors": len(result.errors), "skips": [{"test": str(test), "reason": reason} for test, reason in result.skipped],
  "unexpected_successes": len(result.unexpectedSuccesses), "expected_failures": len(result.expectedFailures),
  "successful": result.wasSuccessful(), "test_inputs_unchanged": unchanged,
  "installed_core_unchanged": installed_after == actual, "import_guard_errors": import_errors,
  "imported_core_modules": modules,
  "core_source_sha256": fingerprint.hexdigest(), "codex_contract_enabled": True,
  "local_wire_test_only": True, "legacy_timestamp_storyline_protection_claimed": False,
}
save("full-core-result.json", report)
print(json.dumps({key: value for key, value in report.items() if key != "imported_core_modules"}))
assert unchanged and installed_after == actual and not import_errors
raise SystemExit(0 if result.wasSuccessful() else 1)
