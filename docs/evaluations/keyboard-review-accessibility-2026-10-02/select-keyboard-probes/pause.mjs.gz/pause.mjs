import fs from "node:fs/promises";
import path from "node:path";
import { chromium, webkit } from "~/Developer/openAuthor/desktop/node_modules/playwright/index.mjs";
const outputDirectory = "/private/tmp/openauthor-select-keyboard-probe-7c1d43";
await fs.mkdir(outputDirectory, { recursive: true });
const sequences = [
  ["pause-1200-end", ["b", "PAUSE1200", "a", "Enter", "Tab"]],
  ["pause-1500-end", ["b", "PAUSE1500", "a", "Enter", "Tab"]],
];
const results = [];
for (const [engine, launcher, executable] of [
  ["chrome", chromium, "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"],
  ["webkit", webkit, "~/Library/Caches/ms-playwright/webkit-2359/pw_run.sh"],
]) {
  const browser = await launcher.launch({ executablePath: executable, headless: true });
  try {
    for (const [name, keys, size = 1] of sequences) {
      const page = await browser.newPage();
      try {
        await page.setContent(`<!doctype html><html><body><label>Reading position for C<select id="position" size="${size}"><option value="a">Before A</option><option value="b">Before B</option><option value="" selected>At end of chapter</option></select></label><button id="move">Move C</button><script>
        window.observations = [];
        const select = document.querySelector("#position");
        for (const type of ["focus", "blur", "keydown", "keypress", "keyup", "input", "change", "mousedown", "mouseup", "click"]) {
          select.addEventListener(type, event => window.observations.push({ type, key: event.key || "", code: event.code || "", trusted: event.isTrusted, value: select.value, selectedIndex: select.selectedIndex, active: document.activeElement.id, defaultPrevented: event.defaultPrevented }));
        }
        </script></body></html>`);
        const control = page.locator("#position");
        const snapshot = async step => ({ step, ...await control.evaluate(select => ({ value: select.value, selectedIndex: select.selectedIndex, active: document.activeElement.id, events: window.observations.slice() })) });
        const steps = [await snapshot("initial")];
        await control.focus();
        steps.push(await snapshot("focused"));
        for (const key of keys) {
          if (key.startsWith("PAUSE")) await page.waitForTimeout(Number(key.slice(5))); else await page.keyboard.press(key);
          steps.push(await snapshot(key));
        }
        results.push({ engine, version: browser.version(), name, keys, size, steps });
        console.log(JSON.stringify({ engine, name, final: steps.at(-1), steps: steps.map(({ step, value, selectedIndex, active }) => ({ step, value, selectedIndex, active })) }));
      } finally { await page.close(); }
    }
  } finally { await browser.close(); }
}
await fs.writeFile(path.join(outputDirectory, "pause-observations.json"), JSON.stringify({ scope: "bare native select; installed headless engines; no app server, providers, network or repository source edits", results }, null, 2) + "\n");

