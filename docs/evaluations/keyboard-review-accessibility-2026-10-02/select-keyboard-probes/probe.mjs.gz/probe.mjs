import fs from "node:fs/promises";
import path from "node:path";
import { chromium, webkit } from "~/Developer/openAuthor/desktop/node_modules/playwright/index.mjs";
const outputDirectory = "/private/tmp/openauthor-select-keyboard-probe-7c1d43";
await fs.mkdir(outputDirectory, { recursive: true });
const sequences = [
  ["focus-arrows-tab", ["ArrowUp", "ArrowUp", "Tab"]],
  ["focus-arrows-enter-tab", ["ArrowUp", "ArrowUp", "Enter", "Tab"]],
  ["space-arrows-enter-tab", ["Space", "ArrowUp", "ArrowUp", "Enter", "Tab"]],
  ["alt-open-arrows-enter-tab", ["Alt+ArrowDown", "ArrowUp", "ArrowUp", "Enter", "Tab"]],
  ["home-enter-tab", ["Home", "Enter", "Tab"]],
  ["typing-a-enter-tab", ["a", "Enter", "Tab"]],
];
const results = [];
for (const [engine, launcher, executable] of [
  ["chrome", chromium, "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"],
  ["webkit", webkit, "~/Library/Caches/ms-playwright/webkit-2359/pw_run.sh"],
]) {
  const browser = await launcher.launch({ executablePath: executable, headless: true });
  try {
    for (const [name, keys] of sequences) {
      const page = await browser.newPage();
      try {
        await page.setContent(`<!doctype html><html><body><label>Reading position for C<select id="position"><option value="a">Before A</option><option value="b">Before B</option><option value="" selected>At end of chapter</option></select></label><button id="move">Move C</button><script>
        window.observations = [];
        const select = document.querySelector("#position");
        for (const type of ["focus", "blur", "keydown", "keypress", "keyup", "input", "change", "mousedown", "mouseup", "click"]) {
          select.addEventListener(type, event => window.observations.push({ type, key: event.key || "", code: event.code || "", trusted: event.isTrusted, value: select.value, selectedIndex: select.selectedIndex, active: document.activeElement.id, defaultPrevented: event.defaultPrevented }));
        }
        </script></body></html>`);
        const control = page.getByRole("combobox", { name: "Reading position for C" });
        const snapshot = async step => ({ step, ...await control.evaluate(select => ({ value: select.value, selectedIndex: select.selectedIndex, active: document.activeElement.id, events: window.observations.slice() })) });
        const steps = [await snapshot("initial")];
        await control.focus();
        steps.push(await snapshot("focused"));
        for (const key of keys) {
          await page.keyboard.press(key);
          steps.push(await snapshot(key));
        }
        results.push({ engine, version: browser.version(), name, keys, steps });
        console.log(JSON.stringify({ engine, name, final: steps.at(-1), steps: steps.map(({ step, value, selectedIndex, active }) => ({ step, value, selectedIndex, active })) }));
      } finally { await page.close(); }
    }
  } finally { await browser.close(); }
}
await fs.writeFile(path.join(outputDirectory, "observations.json"), JSON.stringify({ scope: "bare native select; installed headless engines; no app server, providers, network or repository source edits", results }, null, 2) + "\n");

