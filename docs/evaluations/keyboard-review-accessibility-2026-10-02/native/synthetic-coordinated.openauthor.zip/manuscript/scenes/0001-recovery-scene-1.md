---
id: scene-0001
title: Recovery scene 1
summary: 
pov: 
status: draft
created_at: 2026-10-03T03:01:49.452508+00:00
updated_at: 2026-10-03T03:01:49.452508+00:00
---

The signal began to drift.
