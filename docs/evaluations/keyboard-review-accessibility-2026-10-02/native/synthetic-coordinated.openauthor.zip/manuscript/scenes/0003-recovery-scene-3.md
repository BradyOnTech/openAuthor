---
id: scene-0003
title: Recovery scene 3
summary: 
pov: 
status: draft
created_at: 2026-10-03T03:01:49.627329+00:00
updated_at: 2026-10-03T03:01:49.627329+00:00
---

Ivo really waited beside the very narrow door.
