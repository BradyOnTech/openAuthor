# Manuscript

Scene files live in `manuscript/scenes/` and are revisioned locally by openAuthor.
