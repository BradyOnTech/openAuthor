---
id: scene-0002
title: Recovery scene 2
summary: 
pov: 
status: draft
created_at: 2026-10-03T03:01:49.537628+00:00
updated_at: 2026-10-03T03:01:49.537628+00:00
---

Mara started to pace beside the gate.
